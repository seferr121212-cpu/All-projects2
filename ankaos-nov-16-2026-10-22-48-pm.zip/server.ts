import 'dotenv/config';
import dns from 'node:dns/promises';
import fs from 'node:fs/promises';
import net from 'node:net';
import path from 'node:path';
import express from 'express';
import type { Request, Response } from 'express';

const SYNC_DIR = path.resolve(process.cwd(), '.ankaos-sync');

const PORT = Number(process.env.PORT) || 3000;
const HOST = '0.0.0.0';
const FETCH_TIMEOUT_MS = 8000;
const SEARCH_TIMEOUT_MS = 3500;
const MAX_BODY_BYTES = 1_500_000;

const BROWSER_UA =
  'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36 AnkaBrowser/3.5';
const WIKI_UA = 'AnkaOS-AnkaArama/3.5 (https://ankaos.local; desktop-sandbox) NodeFetch/20';

function isPrivateOrBlockedHost(hostname: string): boolean {
  const h = hostname.trim().toLowerCase().replace(/^\[|\]$/g, '');
  if (!h) return true;
  if (
    h === 'localhost' ||
    h === '::1' ||
    h === '0.0.0.0' ||
    h.endsWith('.local') ||
    h.endsWith('.internal') ||
    h.endsWith('.localhost')
  ) {
    return true;
  }
  if (/^127\./.test(h)) return true;
  if (/^10\./.test(h)) return true;
  if (/^192\.168\./.test(h)) return true;
  if (/^169\.254\./.test(h)) return true;
  if (/^172\.(1[6-9]|2\d|3[0-1])\./.test(h)) return true;
  if (/^(fc|fd|fe80)/i.test(h)) return true;
  return false;
}

async function validatePublicUrl(rawUrl: string): Promise<{ ok: true; url: URL } | { ok: false; error: string }> {
  let parsed: URL;
  try {
    parsed = new URL(rawUrl.trim());
  } catch {
    return { ok: false, error: 'Geçersiz URL biçimi.' };
  }
  if (parsed.protocol !== 'http:' && parsed.protocol !== 'https:') {
    return { ok: false, error: 'Yalnızca http:// ve https:// protokolleri desteklenir.' };
  }
  if (isPrivateOrBlockedHost(parsed.hostname)) {
    return { ok: false, error: 'Yerel ağ ve loopback adreslerine erişim güvenlik nedeniyle engellendi.' };
  }
  try {
    const resolved = await dns.lookup(parsed.hostname);
    if (isPrivateOrBlockedHost(resolved.address)) {
      return { ok: false, error: 'Çözümlenen hedef IP özel ağ aralığında olduğu için engellendi.' };
    }
  } catch {
    // Allow fetch to surface exact DNS error cleanly if needed, or return host unreachable
  }
  return { ok: true, url: parsed };
}

function decodeHtmlEntities(input: string): string {
  return input
    .replace(/&amp;/g, '&')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"')
    .replace(/&#39;|&apos;/g, "'")
    .replace(/&nbsp;/g, ' ')
    .replace(/&#(\d+);/g, (_, dec) => String.fromCharCode(Number(dec)))
    .replace(/&#x([0-9a-f]+);/gi, (_, hex) => String.fromCharCode(parseInt(hex, 16)));
}

function stripTags(html: string): string {
  return decodeHtmlEntities(html.replace(/<[^>]+>/g, ' '))
    .replace(/\s+/g, ' ')
    .trim();
}

function extractReadablePage(html: string): { title: string; description: string; textPreview: string } {
  const titleMatch = html.match(/<title[^>]*>([\s\S]*?)<\/title>/i);
  const title = titleMatch ? stripTags(titleMatch[1]) : '';
  const descMatch =
    html.match(/<meta[^>]+name=["']description["'][^>]+content=["']([\s\S]*?)["'][^>]*>/i) ||
    html.match(/<meta[^>]+content=["']([\s\S]*?)["'][^>]+name=["']description["'][^>]*>/i);
  const description = descMatch ? decodeHtmlEntities(descMatch[1]).trim() : '';

  const cleaned = html
    .replace(/<script[\s\S]*?<\/script>/gi, ' ')
    .replace(/<style[\s\S]*?<\/style>/gi, ' ')
    .replace(/<noscript[\s\S]*?<\/noscript>/gi, ' ')
    .replace(/<svg[\s\S]*?<\/svg>/gi, ' ')
    .replace(/<\/(p|div|h1|h2|h3|h4|li|tr|blockquote|section|article|br)>/gi, '\n')
    .replace(/<[^>]+>/g, ' ');

  const lines = decodeHtmlEntities(cleaned)
    .split('\n')
    .map((l) => l.replace(/\s+/g, ' ').trim())
    .filter((l) => l.length > 0);

  const deduped: string[] = [];
  for (const line of lines) {
    if (deduped[deduped.length - 1] !== line) {
      deduped.push(line);
    }
  }

  return {
    title,
    description,
    textPreview: deduped.join('\n\n').slice(0, 24_000),
  };
}

interface SearchHit {
  title: string;
  url: string;
  domain: string;
  snippet: string;
  source: string;
  thumbUrl?: string;
  publishedAt?: string;
  meta?: {
    stars?: number;
    language?: string;
    answers?: number;
    width?: number;
    height?: number;
    version?: string;
  };
}

interface KnowledgeCard {
  title: string;
  subtitle?: string;
  summary: string;
  url: string;
  source: string;
  imageUrl?: string;
}

const searchCache = new Map<string, { expiresAt: number; payload: Record<string, unknown> }>();
const MAX_SEARCH_CACHE = 40;
const SEARCH_CACHE_TTL_MS = 60_000;

function normalizeDuckDuckGoUrl(rawHref: string): string {
  const decoded = decodeHtmlEntities(rawHref).trim();
  if (decoded.startsWith('//')) return `https:${decoded}`;
  try {
    const u = new URL(decoded.startsWith('http') ? decoded : `https://duckduckgo.com${decoded}`);
    const uddg = u.searchParams.get('uddg');
    if (uddg) return uddg;
    return u.toString();
  } catch {
    return decoded;
  }
}

async function searchDuckDuckGoHtml(query: string): Promise<{ hits: SearchHit[]; ok: boolean; error?: string }> {
  try {
    const endpoint = `https://html.duckduckgo.com/html/?q=${encodeURIComponent(query)}`;
    const resp = await fetch(endpoint, {
      headers: {
        'User-Agent': BROWSER_UA,
        Accept: 'text/html,application/xhtml+xml',
      },
      signal: AbortSignal.timeout(SEARCH_TIMEOUT_MS),
    });
    if (!resp.ok) {
      return { hits: [], ok: false, error: `HTTP ${resp.status}` };
    }
    const html = await resp.text();
    const hits: SearchHit[] = [];

    const blockRegex = /<a[^>]+class="[^"]*result__a[^"]*"[^>]+href="([^"]+)"[^>]*>([\s\S]*?)<\/a>[\s\S]*?(?:class="[^"]*result__snippet[^"]*"[^>]*>([\s\S]*?)<\/(?:a|div|span)>)?/gi;
    let match: RegExpExecArray | null;
    while ((match = blockRegex.exec(html)) !== null && hits.length < 10) {
      const targetUrl = normalizeDuckDuckGoUrl(match[1]);
      if (!targetUrl.startsWith('http')) continue;
      let domain = '';
      try {
        domain = new URL(targetUrl).hostname.replace(/^www\./, '');
      } catch {
        continue;
      }
      const title = stripTags(match[2]);
      const snippet = match[3] ? stripTags(match[3]) : '';
      if (!title) continue;
      hits.push({
        title,
        url: targetUrl,
        domain,
        snippet,
        source: 'DuckDuckGo',
      });
    }
    if (hits.length > 0) return { hits, ok: true };

    // Fallback to DuckDuckGo Lite if main HTML endpoint returned 0 hits
    const liteResp = await fetch(`https://lite.duckduckgo.com/lite/?q=${encodeURIComponent(query)}`, {
      headers: { 'User-Agent': BROWSER_UA, Accept: 'text/html' },
      signal: AbortSignal.timeout(SEARCH_TIMEOUT_MS),
    });
    if (liteResp.ok) {
      const liteHtml = await liteResp.text();
      const linkRegex = /<a[^>]+rel="nofollow"[^>]+href="([^"]+)"[^>]*class='result-link'[^>]*>([\s\S]*?)<\/a>|<a[^>]+class="[^"]*result-link[^"]*"[^>]+href="([^"]+)"[^>]*>([\s\S]*?)<\/a>/gi;
      let lm: RegExpExecArray | null;
      while ((lm = linkRegex.exec(liteHtml)) !== null && hits.length < 10) {
        const rawHref = lm[1] || lm[3] || '';
        const rawTitle = lm[2] || lm[4] || '';
        const targetUrl = normalizeDuckDuckGoUrl(rawHref);
        if (!targetUrl.startsWith('http')) continue;
        try {
          const domain = new URL(targetUrl).hostname.replace(/^www\./, '');
          const title = stripTags(rawTitle);
          if (title) {
            hits.push({ title, url: targetUrl, domain, snippet: '', source: 'DuckDuckGo Lite' });
          }
        } catch {
          // skip
        }
      }
    }
    return { hits, ok: true };
  } catch (err) {
    return {
      hits: [],
      ok: false,
      error: err instanceof Error ? err.message : 'DuckDuckGo erişilemedi',
    };
  }
}

async function searchDuckDuckGoInstant(query: string): Promise<{
  heading: string;
  abstract: string;
  abstractUrl: string;
  abstractSource: string;
  related: SearchHit[];
} | null> {
  try {
    const resp = await fetch(
      `https://api.duckduckgo.com/?q=${encodeURIComponent(query)}&format=json&no_html=1&skip_disambig=1`,
      {
        headers: { 'User-Agent': BROWSER_UA, Accept: 'application/json' },
        signal: AbortSignal.timeout(SEARCH_TIMEOUT_MS),
      }
    );
    if (!resp.ok) return null;
    const data = (await resp.json()) as {
      Heading?: string;
      AbstractText?: string;
      AbstractURL?: string;
      AbstractSource?: string;
      RelatedTopics?: Array<{ Text?: string; FirstURL?: string }>;
    };
    const related: SearchHit[] = [];
    for (const item of data.RelatedTopics || []) {
      if (item.FirstURL && item.Text && related.length < 4) {
        try {
          const domain = new URL(item.FirstURL).hostname.replace(/^www\./, '');
          related.push({
            title: item.Text.split(' - ')[0] || item.Text.slice(0, 64),
            url: item.FirstURL,
            domain,
            snippet: item.Text,
            source: 'DuckDuckGo IA',
          });
        } catch {
          // skip
        }
      }
    }
    if (!data.AbstractText && related.length === 0) return null;
    return {
      heading: data.Heading || query,
      abstract: data.AbstractText || '',
      abstractUrl: data.AbstractURL || '',
      abstractSource: data.AbstractSource || 'DuckDuckGo',
      related,
    };
  } catch {
    return null;
  }
}

async function searchWikipedia(
  query: string,
  lang: string
): Promise<{ hits: SearchHit[]; knowledgeCard: KnowledgeCard | null; ok: boolean; error?: string }> {
  const wikiLang = lang === 'en' ? 'en' : 'tr';
  try {
    const endpoint = `https://${wikiLang}.wikipedia.org/w/api.php?action=query&list=search&srsearch=${encodeURIComponent(
      query
    )}&format=json&utf8=1&srlimit=6`;
    const resp = await fetch(endpoint, {
      headers: { 'User-Agent': WIKI_UA, Accept: 'application/json' },
      signal: AbortSignal.timeout(SEARCH_TIMEOUT_MS),
    });
    if (resp.ok) {
      const json = (await resp.json()) as {
        query?: { search?: Array<{ title: string; snippet: string; pageid: number }> };
      };
      const items = json.query?.search || [];
      const hits: SearchHit[] = items.map((item) => ({
        title: `${item.title} — Vikipedi`,
        url: `https://${wikiLang}.wikipedia.org/wiki/${encodeURIComponent(item.title.replace(/ /g, '_'))}`,
        domain: `${wikiLang}.wikipedia.org`,
        snippet: stripTags(item.snippet),
        source: 'Wikipedia',
      }));

      let knowledgeCard: KnowledgeCard | null = null;
      if (items[0]) {
        try {
          const summaryResp = await fetch(
            `https://${wikiLang}.wikipedia.org/api/rest_v1/page/summary/${encodeURIComponent(
              items[0].title.replace(/ /g, '_')
            )}`,
            {
              headers: { 'User-Agent': WIKI_UA, Accept: 'application/json' },
              signal: AbortSignal.timeout(2500),
            }
          );
          if (summaryResp.ok) {
            const summaryData = (await summaryResp.json()) as {
              title?: string;
              description?: string;
              extract?: string;
              thumbnail?: { source?: string };
              content_urls?: { desktop?: { page?: string } };
            };
            if (summaryData.extract) {
              knowledgeCard = {
                title: summaryData.title || items[0].title,
                subtitle: summaryData.description,
                summary: summaryData.extract.slice(0, 480),
                url: summaryData.content_urls?.desktop?.page || hits[0].url,
                source: `${wikiLang.toUpperCase()} Vikipedi`,
                imageUrl: summaryData.thumbnail?.source,
              };
            }
          }
        } catch {
          // Summary card is optional
        }
      }

      if (hits.length > 0) {
        return { hits, knowledgeCard, ok: true };
      }
    }

    // Fallback: DuckDuckGo site:wikipedia.org + Instant Answer (handles Wikimedia cloud IP rate limits)
    const [ddgWiki, ddgInstant] = await Promise.all([
      searchDuckDuckGoHtml(`${query} site:${wikiLang}.wikipedia.org`),
      searchDuckDuckGoInstant(query),
    ]);
    const fallbackHits = ddgWiki.hits.map((h) => ({ ...h, source: 'Wikipedia (DDG)' }));
    const fallbackCard: KnowledgeCard | null =
      ddgInstant?.abstract
        ? {
            title: ddgInstant.heading,
            summary: ddgInstant.abstract.slice(0, 480),
            url: ddgInstant.abstractUrl || fallbackHits[0]?.url || `https://${wikiLang}.wikipedia.org`,
            source: ddgInstant.abstractSource || 'Bilgi Kartı',
          }
        : null;
    if (fallbackHits.length > 0 || fallbackCard) {
      return { hits: fallbackHits, knowledgeCard: fallbackCard, ok: true };
    }

    return { hits: [], knowledgeCard: null, ok: false, error: `Wikipedia HTTP ${resp.status}` };
  } catch (err) {
    return {
      hits: [],
      knowledgeCard: null,
      ok: false,
      error: err instanceof Error ? err.message : 'Wikipedia erişilemedi',
    };
  }
}

async function searchDeveloperSources(query: string): Promise<{ hits: SearchHit[]; ok: boolean; error?: string }> {
  const hits: SearchHit[] = [];
  let anyOk = false;

  const [ghRes, npmRes, soRes] = await Promise.allSettled([
    fetch(`https://api.github.com/search/repositories?q=${encodeURIComponent(query)}&sort=stars&per_page=5`, {
      headers: { 'User-Agent': BROWSER_UA, Accept: 'application/vnd.github+json' },
      signal: AbortSignal.timeout(SEARCH_TIMEOUT_MS),
    }),
    fetch(`https://registry.npmjs.org/-/v1/search?text=${encodeURIComponent(query)}&size=4`, {
      headers: { 'User-Agent': BROWSER_UA, Accept: 'application/json' },
      signal: AbortSignal.timeout(SEARCH_TIMEOUT_MS),
    }),
    fetch(
      `https://api.stackexchange.com/2.3/search/advanced?order=desc&sort=relevance&q=${encodeURIComponent(
        query
      )}&site=stackoverflow&pagesize=5`,
      {
        headers: { 'User-Agent': BROWSER_UA, Accept: 'application/json' },
        signal: AbortSignal.timeout(SEARCH_TIMEOUT_MS),
      }
    ),
  ]);

  if (ghRes.status === 'fulfilled' && ghRes.value.ok) {
    anyOk = true;
    const data = (await ghRes.value.json()) as {
      items?: Array<{
        full_name: string;
        html_url: string;
        description?: string;
        stargazers_count: number;
        language?: string;
      }>;
    };
    for (const repo of data.items || []) {
      hits.push({
        title: repo.full_name,
        url: repo.html_url,
        domain: 'github.com',
        snippet: repo.description || 'GitHub açık kaynak deposu',
        source: 'GitHub',
        meta: { stars: repo.stargazers_count, language: repo.language || undefined },
      });
    }
  }

  if (npmRes.status === 'fulfilled' && npmRes.value.ok) {
    anyOk = true;
    const data = (await npmRes.value.json()) as {
      objects?: Array<{ package: { name: string; version: string; description?: string; links?: { npm?: string } } }>;
    };
    for (const item of data.objects || []) {
      const pkg = item.package;
      hits.push({
        title: `${pkg.name} (v${pkg.version})`,
        url: pkg.links?.npm || `https://www.npmjs.com/package/${encodeURIComponent(pkg.name)}`,
        domain: 'npmjs.com',
        snippet: pkg.description || 'npm JavaScript/TypeScript paketi',
        source: 'npm',
        meta: { version: pkg.version },
      });
    }
  }

  if (soRes.status === 'fulfilled' && soRes.value.ok) {
    anyOk = true;
    const data = (await soRes.value.json()) as {
      items?: Array<{ title: string; link: string; score: number; answer_count: number; tags?: string[] }>;
    };
    for (const q of data.items || []) {
      hits.push({
        title: decodeHtmlEntities(q.title),
        url: q.link,
        domain: 'stackoverflow.com',
        snippet: q.tags?.length ? `Etiketler: ${q.tags.slice(0, 4).join(', ')}` : 'StackOverflow tartışması',
        source: 'StackOverflow',
        meta: { stars: q.score, answers: q.answer_count },
      });
    }
  }

  return { hits, ok: anyOk, error: anyOk ? undefined : 'Geliştirici kaynaklarına ulaşılamadı' };
}

async function searchNewsSources(query: string, lang: string): Promise<{ hits: SearchHit[]; ok: boolean; error?: string }> {
  const hits: SearchHit[] = [];
  let anyOk = false;

  const hl = lang === 'en' ? 'en-US' : 'tr';
  const gl = lang === 'en' ? 'US' : 'TR';
  const ceid = lang === 'en' ? 'US:en' : 'TR:tr';

  const [gnRes, hnRes] = await Promise.allSettled([
    fetch(`https://news.google.com/rss/search?q=${encodeURIComponent(query)}&hl=${hl}&gl=${gl}&ceid=${ceid}`, {
      headers: { 'User-Agent': BROWSER_UA, Accept: 'application/rss+xml, application/xml, text/xml' },
      signal: AbortSignal.timeout(SEARCH_TIMEOUT_MS),
    }),
    fetch(`https://hn.algolia.com/api/v1/search?query=${encodeURIComponent(query)}&tags=story&hitsPerPage=6`, {
      headers: { 'User-Agent': BROWSER_UA, Accept: 'application/json' },
      signal: AbortSignal.timeout(SEARCH_TIMEOUT_MS),
    }),
  ]);

  if (gnRes.status === 'fulfilled' && gnRes.value.ok) {
    anyOk = true;
    const xml = await gnRes.value.text();
    const itemRegex = /<item>([\s\S]*?)<\/item>/gi;
    let m: RegExpExecArray | null;
    while ((m = itemRegex.exec(xml)) !== null && hits.length < 8) {
      const block = m[1];
      const titleMatch = block.match(/<title>([\s\S]*?)<\/title>/i);
      const linkMatch = block.match(/<link>([\s\S]*?)<\/link>/i);
      const pubMatch = block.match(/<pubDate>([\s\S]*?)<\/pubDate>/i);
      const srcMatch = block.match(/<source[^>]*>([\s\S]*?)<\/source>/i);
      if (titleMatch && linkMatch) {
        const cleanTitle = stripTags(titleMatch[1].replace(/<!\[CDATA\[|\]\]>/g, ''));
        const cleanLink = linkMatch[1].trim();
        const srcName = srcMatch ? stripTags(srcMatch[1]) : 'Google Haberler';
        hits.push({
          title: cleanTitle,
          url: cleanLink,
          domain: srcName,
          snippet: pubMatch ? `${srcName} · ${pubMatch[1].replace(/\s*\+\d{4}$/, '')}` : srcName,
          source: srcName,
          publishedAt: pubMatch ? pubMatch[1].trim() : undefined,
        });
      }
    }
  }

  if (hnRes.status === 'fulfilled' && hnRes.value.ok) {
    anyOk = true;
    const data = (await hnRes.value.json()) as {
      hits?: Array<{ title?: string; url?: string; objectID: string; points?: number; num_comments?: number; created_at?: string }>;
    };
    for (const story of data.hits || []) {
      const targetUrl = story.url || `https://news.ycombinator.com/item?id=${story.objectID}`;
      if (!story.title) continue;
      let domain = 'news.ycombinator.com';
      try {
        domain = new URL(targetUrl).hostname.replace(/^www\./, '');
      } catch {
        // keep default
      }
      hits.push({
        title: story.title,
        url: targetUrl,
        domain,
        snippet: `Hacker News · ${story.points || 0} puan · ${story.num_comments || 0} yorum`,
        source: 'Hacker News',
        publishedAt: story.created_at,
        meta: { stars: story.points || 0, answers: story.num_comments || 0 },
      });
    }
  }

  return { hits, ok: anyOk, error: anyOk ? undefined : 'Haber kaynaklarına ulaşılamadı' };
}

async function searchWikimediaImages(query: string): Promise<{ hits: SearchHit[]; ok: boolean; error?: string }> {
  try {
    const endpoint = `https://commons.wikimedia.org/w/api.php?action=query&generator=search&gsrnamespace=6&gsrsearch=${encodeURIComponent(
      query
    )}&gsrlimit=12&prop=imageinfo&iiprop=url|size|mime&iiurlwidth=480&format=json`;
    const resp = await fetch(endpoint, {
      headers: { 'User-Agent': WIKI_UA, Accept: 'application/json' },
      signal: AbortSignal.timeout(SEARCH_TIMEOUT_MS),
    });
    if (resp.ok) {
      const json = (await resp.json()) as {
        query?: {
          pages?: Record<
            string,
            {
              title: string;
              imageinfo?: Array<{
                url?: string;
                thumburl?: string;
                descriptionurl?: string;
                width?: number;
                height?: number;
                mime?: string;
              }>;
            }
          >;
        };
      };
      const pages = Object.values(json.query?.pages || {});
      const hits: SearchHit[] = [];
      for (const p of pages) {
        const info = p.imageinfo?.[0];
        if (!info?.url || !info.mime?.startsWith('image/')) continue;
        hits.push({
          title: p.title.replace(/^File:/i, '').replace(/\.[^.]+$/, ''),
          url: info.descriptionurl || info.url,
          thumbUrl: info.thumburl || info.url,
          domain: 'commons.wikimedia.org',
          snippet: `${info.width || '?'}×${info.height || '?'} · ${info.mime}`,
          source: 'Wikimedia Commons',
          meta: { width: info.width, height: info.height },
        });
      }
      if (hits.length > 0) return { hits, ok: true };
    }

    // Fallback to Openverse public CC image API if Wikimedia returns 429 or 0 results
    const ovResp = await fetch(
      `https://api.openverse.org/v1/images/?q=${encodeURIComponent(query)}&page_size=12`,
      {
        headers: { 'User-Agent': WIKI_UA, Accept: 'application/json' },
        signal: AbortSignal.timeout(SEARCH_TIMEOUT_MS),
      }
    );
    if (ovResp.ok) {
      const ovJson = (await ovResp.json()) as {
        results?: Array<{
          title?: string;
          url?: string;
          thumbnail?: string;
          foreign_landing_url?: string;
          source?: string;
          width?: number;
          height?: number;
        }>;
      };
      const ovHits: SearchHit[] = [];
      for (const item of ovJson.results || []) {
        const thumb = item.thumbnail || item.url;
        const target = item.foreign_landing_url || item.url;
        if (!thumb || !target) continue;
        ovHits.push({
          title: item.title || query,
          url: target,
          thumbUrl: thumb,
          domain: item.source || 'openverse.org',
          snippet: `${item.width || '?'}×${item.height || '?'} · ${item.source || 'Openverse'}`,
          source: 'Openverse',
          meta: { width: item.width, height: item.height },
        });
      }
      return { hits: ovHits, ok: true };
    }

    return { hits: [], ok: false, error: `Wikimedia HTTP ${resp.status}` };
  } catch (err) {
    return {
      hits: [],
      ok: false,
      error: err instanceof Error ? err.message : 'Görsel arama başarısız',
    };
  }
}

function rankSearchHits(hits: SearchHit[], query: string): SearchHit[] {
  const terms = query.toLowerCase().split(/\s+/).filter((t) => t.length >= 2);
  return [...hits]
    .map((hit, idx) => {
      let score = Math.max(0, 20 - idx);
      const tLow = hit.title.toLowerCase();
      const sLow = hit.snippet.toLowerCase();
      for (const term of terms) {
        if (tLow.includes(term)) score += 10;
        if (sLow.includes(term)) score += 4;
      }
      if (hit.meta?.stars) score += Math.min(12, Math.log10(hit.meta.stars + 1) * 3);
      if (hit.domain.includes('wikipedia.org')) score += 6;
      if (hit.domain === 'github.com' || hit.domain === 'developer.mozilla.org') score += 5;
      return { hit, score };
    })
    .sort((a, b) => b.score - a.score)
    .map((x) => x.hit);
}

function measureTcpRtt(host: string, port: number): Promise<number> {
  return new Promise((resolve, reject) => {
    const start = performance.now();
    const socket = net.createConnection({ host, port, timeout: 4500 });
    socket.on('connect', () => {
      const rtt = Number((performance.now() - start).toFixed(2));
      socket.destroy();
      resolve(rtt);
    });
    socket.on('timeout', () => {
      socket.destroy();
      reject(new Error('Zaman aşımı'));
    });
    socket.on('error', (err) => {
      socket.destroy();
      reject(err);
    });
  });
}

async function startServer() {
  const app = express();
  app.use(express.json({ limit: '6mb' }));

  // 1. Live Internet Connectivity Check
  app.get('/api/net/status', async (_req: Request, res: Response) => {
    const t0 = performance.now();
    try {
      const dnsRes = await dns.lookup('duckduckgo.com');
      const probe = await fetch('https://api.duckduckgo.com/?q=AnkaOS&format=json&no_html=1', {
        headers: { 'User-Agent': BROWSER_UA },
        signal: AbortSignal.timeout(4500),
      });
      const rttMs = Math.max(1, Math.round(performance.now() - t0));
      res.json({
        online: probe.ok,
        rttMs,
        dnsOk: Boolean(dnsRes.address),
        gatewayIp: dnsRes.address,
        provider: 'AnkaNet Express Bridge',
        checkedAt: Date.now(),
      });
    } catch (err) {
      res.json({
        online: false,
        rttMs: Math.round(performance.now() - t0),
        dnsOk: false,
        provider: 'AnkaNet Express Bridge',
        checkedAt: Date.now(),
        error: err instanceof Error ? err.message : 'Ağ bağlantısı doğrulanamadı',
      });
    }
  });

  // 2. Real DNS Resolution Endpoint
  app.get('/api/dns', async (req: Request, res: Response) => {
    const host = String(req.query.host || '').trim().toLowerCase();
    if (!host || !/^[a-z0-9.-]+$/.test(host)) {
      res.status(400).json({ ok: false, error: 'Geçerli bir alan adı girin (ör. wikipedia.org).' });
      return;
    }
    const t0 = performance.now();
    try {
      const lookup = await dns.lookup(host, { all: true });
      const [v4, v6, mx, ns] = await Promise.allSettled([
        dns.resolve4(host),
        dns.resolve6(host),
        dns.resolveMx(host),
        dns.resolveNs(host),
      ]);
      res.json({
        ok: true,
        host,
        tookMs: Number((performance.now() - t0).toFixed(2)),
        addresses: lookup,
        v4: v4.status === 'fulfilled' ? v4.value : [],
        v6: v6.status === 'fulfilled' ? v6.value : [],
        mx: mx.status === 'fulfilled' ? mx.value : [],
        ns: ns.status === 'fulfilled' ? ns.value : [],
      });
    } catch (err) {
      res.status(502).json({
        ok: false,
        host,
        tookMs: Number((performance.now() - t0).toFixed(2)),
        error: err instanceof Error ? err.message : 'DNS çözümleme başarısız',
      });
    }
  });

  // 3. Real TCP/HTTPS Ping Probe
  app.get('/api/net/ping', async (req: Request, res: Response) => {
    const host = String(req.query.host || '').trim().toLowerCase();
    if (!host || !/^[a-z0-9.-]+$/.test(host) || isPrivateOrBlockedHost(host)) {
      res.status(400).json({ ok: false, error: 'Geçerli ve genel erişilebilir bir alan adı girin.' });
      return;
    }
    try {
      const resolved = await dns.lookup(host);
      if (isPrivateOrBlockedHost(resolved.address)) {
        res.status(403).json({ ok: false, error: 'Özel ağ adresine ping engellendi.' });
        return;
      }
      let port = 443;
      let rttMs: number;
      try {
        rttMs = await measureTcpRtt(resolved.address, 443);
      } catch {
        port = 80;
        rttMs = await measureTcpRtt(resolved.address, 80);
      }
      res.json({
        ok: true,
        host,
        ip: resolved.address,
        port,
        rttMs,
      });
    } catch (err) {
      res.status(502).json({
        ok: false,
        host,
        error: err instanceof Error ? err.message : 'Ulaşılamadı',
      });
    }
  });

  // 4. AnkaArama Live Web Search Aggregator (Multi-source + Categorized + Cached)
  app.get('/api/search', async (req: Request, res: Response) => {
    const query = String(req.query.q || '').trim();
    const lang = String(req.query.lang || 'tr') === 'en' ? 'en' : 'tr';
    const rawCat = String(req.query.category || 'all').toLowerCase();
    const category = ['all', 'wiki', 'dev', 'news', 'images'].includes(rawCat) ? rawCat : 'all';

    if (!query) {
      res.status(400).json({ ok: false, error: 'Arama sorgusu boş olamaz.' });
      return;
    }

    const cacheKey = `${lang}:${category}:${query.toLowerCase()}`;
    const cachedEntry = searchCache.get(cacheKey);
    if (cachedEntry && cachedEntry.expiresAt > Date.now()) {
      res.json({ ...cachedEntry.payload, cached: true, tookMs: 1 });
      return;
    }

    const t0 = performance.now();
    const seen = new Set<string>();
    const combined: SearchHit[] = [];
    const pushHit = (hit: SearchHit) => {
      const normKey = hit.url.replace(/\/$/, '').toLowerCase();
      if (seen.has(normKey)) return;
      seen.add(normKey);
      combined.push(hit);
    };

    let knowledgeCard: KnowledgeCard | null = null;
    let instantAnswer: { heading: string; abstract: string; url: string; source: string } | null = null;
    const sourceStatus: Record<string, string> = {};
    let anyUpstreamOk = false;

    if (category === 'images') {
      const imgRes = await searchWikimediaImages(query);
      anyUpstreamOk = imgRes.ok;
      sourceStatus.wikimedia = imgRes.ok ? 'OK' : imgRes.error || 'ERR';
      for (const h of imgRes.hits) pushHit(h);
    } else if (category === 'dev') {
      const [devRes, ddgHtml] = await Promise.all([
        searchDeveloperSources(query),
        searchDuckDuckGoHtml(`${query} docs`),
      ]);
      anyUpstreamOk = devRes.ok || ddgHtml.ok;
      sourceStatus.developer = devRes.ok ? 'OK' : devRes.error || 'ERR';
      sourceStatus.duckduckgo = ddgHtml.ok ? 'OK' : ddgHtml.error || 'ERR';
      for (const h of devRes.hits) pushHit(h);
      for (const h of ddgHtml.hits) pushHit(h);
    } else if (category === 'news') {
      const newsRes = await searchNewsSources(query, lang);
      anyUpstreamOk = newsRes.ok;
      sourceStatus.news = newsRes.ok ? 'OK' : newsRes.error || 'ERR';
      for (const h of newsRes.hits) pushHit(h);
    } else if (category === 'wiki') {
      const wiki = await searchWikipedia(query, lang);
      anyUpstreamOk = wiki.ok;
      knowledgeCard = wiki.knowledgeCard;
      sourceStatus.wikipedia = wiki.ok ? 'OK' : wiki.error || 'ERR';
      for (const h of wiki.hits) pushHit(h);
    } else {
      const devHint = /\b(js|ts|typescript|javascript|react|rust|python|wasm|linux|kernel|api|npm|git|css|html|sql)\b/i.test(query);
      const [ddgHtml, ddgInstant, wiki, devRes] = await Promise.all([
        searchDuckDuckGoHtml(query),
        searchDuckDuckGoInstant(query),
        searchWikipedia(query, lang),
        devHint ? searchDeveloperSources(query) : Promise.resolve({ hits: [] as SearchHit[], ok: false }),
      ]);

      for (const h of ddgHtml.hits) pushHit(h);
      for (const h of wiki.hits) pushHit(h);
      for (const h of devRes.hits.slice(0, 3)) pushHit(h);
      if (ddgInstant?.related) {
        for (const h of ddgInstant.related) pushHit(h);
      }

      knowledgeCard = wiki.knowledgeCard;
      if (ddgInstant?.abstract) {
        instantAnswer = {
          heading: ddgInstant.heading,
          abstract: ddgInstant.abstract,
          url: ddgInstant.abstractUrl,
          source: ddgInstant.abstractSource,
        };
      }
      anyUpstreamOk = ddgHtml.ok || wiki.ok || devRes.ok || Boolean(ddgInstant);
      sourceStatus.duckduckgo = ddgHtml.ok ? 'OK' : ddgHtml.error || 'ERR';
      sourceStatus.wikipedia = wiki.ok ? 'OK' : wiki.error || 'ERR';
      if (devHint) sourceStatus.developer = devRes.ok ? 'OK' : 'ERR';
    }

    const rankedResults =
      category === 'images' || category === 'news' ? combined.slice(0, 16) : rankSearchHits(combined, query).slice(0, 16);
    const tookMs = Math.max(1, Math.round(performance.now() - t0));

    const payload = {
      ok: anyUpstreamOk,
      query,
      lang,
      category,
      engine: 'AnkaArama Multi-Engine v3.5',
      tookMs,
      cached: false,
      instantAnswer,
      knowledgeCard,
      results: rankedResults,
      sourceStatus,
    };

    if (anyUpstreamOk && rankedResults.length > 0) {
      if (searchCache.size >= MAX_SEARCH_CACHE) {
        const oldestKey = searchCache.keys().next().value;
        if (oldestKey) searchCache.delete(oldestKey);
      }
      searchCache.set(cacheKey, { expiresAt: Date.now() + SEARCH_CACHE_TTL_MS, payload });
    }

    res.json(payload);
  });

  // 4b. AnkaArama Live Autocomplete Suggestions
  app.get('/api/suggest', async (req: Request, res: Response) => {
    const query = String(req.query.q || '').trim();
    const lang = String(req.query.lang || 'tr') === 'en' ? 'en' : 'tr';
    if (query.length < 2) {
      res.json({ ok: true, suggestions: [] });
      return;
    }

    const wikiLang = lang === 'en' ? 'en' : 'tr';
    const [ddgAc, wikiAc] = await Promise.allSettled([
      fetch(`https://duckduckgo.com/ac/?q=${encodeURIComponent(query)}&type=list`, {
        headers: { 'User-Agent': BROWSER_UA, Accept: 'application/json' },
        signal: AbortSignal.timeout(1800),
      }),
      fetch(
        `https://${wikiLang}.wikipedia.org/w/api.php?action=opensearch&search=${encodeURIComponent(
          query
        )}&limit=5&namespace=0&format=json`,
        {
          headers: { 'User-Agent': WIKI_UA, Accept: 'application/json' },
          signal: AbortSignal.timeout(1800),
        }
      ),
    ]);

    const merged: string[] = [];
    const seenSugg = new Set<string>();
    const addSuggestion = (s: string) => {
      const clean = s.trim();
      const key = clean.toLowerCase();
      if (!clean || key === query.toLowerCase() || seenSugg.has(key)) return;
      seenSugg.add(key);
      merged.push(clean);
    };

    if (ddgAc.status === 'fulfilled' && ddgAc.value.ok) {
      try {
        const data = (await ddgAc.value.json()) as unknown;
        if (Array.isArray(data) && Array.isArray(data[1])) {
          for (const item of data[1] as string[]) addSuggestion(String(item));
        }
      } catch {
        // ignore parse error
      }
    }

    if (wikiAc.status === 'fulfilled' && wikiAc.value.ok) {
      try {
        const data = (await wikiAc.value.json()) as unknown;
        if (Array.isArray(data) && Array.isArray(data[1])) {
          for (const item of data[1] as string[]) addSuggestion(String(item));
        }
      } catch {
        // ignore parse error
      }
    }

    res.json({ ok: true, suggestions: merged.slice(0, 8) });
  });

  // 5. Raw / Reader-Mode Fetch Endpoint (CORS-free for curl, wget, Reader Mode)
  app.get('/api/fetch', async (req: Request, res: Response) => {
    const rawUrl = String(req.query.url || '').trim();
    const check = await validatePublicUrl(rawUrl);
    if (!check.ok) {
      res.status(400).json({ ok: false, error: check.error });
      return;
    }

    try {
      const upstream = await fetch(check.url.toString(), {
        headers: {
          'User-Agent': BROWSER_UA,
          Accept: 'text/html,application/json,text/plain,*/*',
        },
        redirect: 'follow',
        signal: AbortSignal.timeout(FETCH_TIMEOUT_MS),
      });

      const contentType = upstream.headers.get('content-type') || 'text/plain';
      const buf = Buffer.from(await upstream.arrayBuffer());
      const sliced = buf.subarray(0, MAX_BODY_BYTES);
      const rawText = sliced.toString('utf8');

      if (contentType.includes('text/html') || contentType.includes('application/xhtml')) {
        const extracted = extractReadablePage(rawText);
        res.json({
          ok: upstream.ok,
          url: check.url.toString(),
          finalUrl: upstream.url || check.url.toString(),
          status: upstream.status,
          contentType,
          bytes: sliced.length,
          title: extracted.title || check.url.hostname,
          description: extracted.description,
          textPreview: extracted.textPreview,
          rawText: rawText.slice(0, 120_000),
        });
        return;
      }

      res.json({
        ok: upstream.ok,
        url: check.url.toString(),
        finalUrl: upstream.url || check.url.toString(),
        status: upstream.status,
        contentType,
        bytes: sliced.length,
        title: check.url.hostname,
        description: '',
        textPreview: rawText.slice(0, 24_000),
        rawText: rawText.slice(0, 120_000),
      });
    } catch (err) {
      res.status(502).json({
        ok: false,
        url: check.url.toString(),
        error: err instanceof Error ? err.message : 'Sayfa alınamadı',
      });
    }
  });

  // 6. Live HTML Proxy for AnkaTarayıcı iframe rendering
  app.get('/api/proxy', async (req: Request, res: Response) => {
    const rawUrl = String(req.query.url || '').trim();
    const check = await validatePublicUrl(rawUrl);
    if (!check.ok) {
      res.status(400).send(`<body style="font-family:system-ui;padding:32px;background:#0f172a;color:#e2e8f0"><h3>Erişim Engellendi</h3><p>${check.error}</p></body>`);
      return;
    }

    try {
      const upstream = await fetch(check.url.toString(), {
        headers: {
          'User-Agent': BROWSER_UA,
          Accept: 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        },
        redirect: 'follow',
        signal: AbortSignal.timeout(FETCH_TIMEOUT_MS),
      });

      const finalUrl = upstream.url || check.url.toString();
      const contentType = upstream.headers.get('content-type') || 'text/html; charset=utf-8';
      const buf = Buffer.from(await upstream.arrayBuffer());
      const sliced = buf.subarray(0, MAX_BODY_BYTES);

      if (contentType.includes('text/html') || contentType.includes('application/xhtml')) {
        let html = sliced.toString('utf8');
        html = html.replace(/<meta[^>]+http-equiv=["'](?:Content-Security-Policy|X-Frame-Options)["'][^>]*>/gi, '');

        const helperSnippet = `<base href="${finalUrl}" />
<script>
(function(){
  document.addEventListener('click', function(ev){
    var a = ev.target && ev.target.closest ? ev.target.closest('a[href]') : null;
    if (!a) return;
    var href = a.getAttribute('href');
    if (!href || href.startsWith('#') || href.startsWith('javascript:')) return;
    try {
      var resolved = new URL(href, ${JSON.stringify(finalUrl)}).toString();
      if (resolved.startsWith('http://') || resolved.startsWith('https://')) {
        ev.preventDefault();
        window.parent.postMessage({ type: 'ankaos-browser-navigate', url: resolved }, '*');
      }
    } catch (_) {}
  }, true);
})();
</script>`;

        if (/<head[^>]*>/i.test(html)) {
          html = html.replace(/<head[^>]*>/i, (m) => `${m}\n${helperSnippet}`);
        } else {
          html = `<head>${helperSnippet}</head>${html}`;
        }

        res.setHeader('Content-Type', 'text/html; charset=utf-8');
        res.status(upstream.status).send(html);
        return;
      }

      res.setHeader('Content-Type', contentType);
      res.status(upstream.status).send(sliced);
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Bağlantı zaman aşımı';
      res
        .status(502)
        .setHeader('Content-Type', 'text/html; charset=utf-8')
        .send(`<body style="font-family:system-ui;padding:32px;background:#0f172a;color:#e2e8f0"><h3>Sayfa Yüklenemedi</h3><p>${msg}</p><p style="color:#94a3b8">İpucu: AnkaTarayıcı araç çubuğundan <strong>Okuma Modu</strong> seçeneğini deneyebilirsiniz.</p></body>`);
    }
  });

  // 7. Server-side VFS & Snapshot Cloud Sync
  app.post('/api/sync/snapshot', async (req: Request, res: Response) => {
    const rawKey = String((req.body as { syncKey?: string })?.syncKey || '').trim();
    const rawSnapshot = (req.body as { snapshotJson?: unknown })?.snapshotJson;
    if (!/^[a-z0-9_-]{3,40}$/i.test(rawKey)) {
      res.status(400).json({
        ok: false,
        error: 'Geçersiz eşitleme anahtarı (3-40 karakter, harf/rakam/-/_ kullanın).',
      });
      return;
    }
    const snapshotText = typeof rawSnapshot === 'string' ? rawSnapshot : JSON.stringify(rawSnapshot);
    if (!snapshotText || snapshotText.length < 10) {
      res.status(400).json({ ok: false, error: 'Snapshot verisi boş veya geçersiz.' });
      return;
    }
    try {
      const parsed = JSON.parse(snapshotText) as { schema?: string };
      if (parsed.schema !== 'ankaos-snapshot-v1') {
        res.status(400).json({ ok: false, error: 'Desteklenmeyen snapshot şeması.' });
        return;
      }
      await fs.mkdir(SYNC_DIR, { recursive: true });
      const filePath = path.join(SYNC_DIR, `${rawKey.toLowerCase()}.json`);
      const record = {
        syncKey: rawKey.toLowerCase(),
        savedAt: Date.now(),
        bytes: Buffer.byteLength(snapshotText, 'utf8'),
        snapshotJson: snapshotText,
      };
      await fs.writeFile(filePath, JSON.stringify(record), 'utf8');
      res.json({
        ok: true,
        syncKey: record.syncKey,
        savedAt: record.savedAt,
        bytes: record.bytes,
      });
    } catch (err) {
      res.status(500).json({
        ok: false,
        error: err instanceof Error ? err.message : 'Sunucuya yazılamadı',
      });
    }
  });

  app.get('/api/sync/snapshot', async (req: Request, res: Response) => {
    const rawKey = String(req.query.key || '').trim();
    if (!/^[a-z0-9_-]{3,40}$/i.test(rawKey)) {
      res.status(400).json({
        ok: false,
        error: 'Geçersiz eşitleme anahtarı (3-40 karakter, harf/rakam/-/_ kullanın).',
      });
      return;
    }
    try {
      const filePath = path.join(SYNC_DIR, `${rawKey.toLowerCase()}.json`);
      const content = await fs.readFile(filePath, 'utf8');
      const parsed = JSON.parse(content) as {
        syncKey: string;
        savedAt: number;
        bytes: number;
        snapshotJson: string;
      };
      res.json({
        ok: true,
        syncKey: parsed.syncKey,
        savedAt: parsed.savedAt,
        bytes: parsed.bytes,
        snapshotJson: parsed.snapshotJson,
      });
    } catch {
      res.status(404).json({
        ok: false,
        error: `Sunucuda '${rawKey}' anahtarına ait bir yedek bulunamadı.`,
      });
    }
  });

  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.resolve(process.cwd(), 'dist');
    app.use(express.static(distDir));
    app.get('*', (_req: Request, res: Response) => {
      res.sendFile(path.join(distDir, 'index.html'));
    });
  }

  app.listen(PORT, HOST, () => {
    console.log(`AnkaOS server listening on http://${HOST}:${PORT}`);
  });
}

void startServer();
