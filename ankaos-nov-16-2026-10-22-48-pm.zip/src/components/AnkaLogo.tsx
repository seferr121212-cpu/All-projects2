import React from 'react';

interface AnkaLogoProps {
  size?: number;
  animated?: boolean;
  monochrome?: boolean;
  withFrame?: boolean;
  className?: string;
}

/**
 * AnkaOS resmi geometrik Anka Kuşu (Phoenix) amblemi.
 * Tüm tema ve vurgu renkleriyle (--anka-accent) uyumlu ölçeklenebilir vektör logo.
 */
export const AnkaLogo: React.FC<AnkaLogoProps> = ({
  size = 32,
  animated = false,
  monochrome = false,
  withFrame = false,
  className = '',
}) => {
  const gradId = React.useId();

  const svg = (
    <svg
      width={size}
      height={size}
      viewBox="0 0 64 64"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      aria-label="AnkaOS Logo"
      className={animated ? 'anka-logo-rise' : undefined}
    >
      <defs>
        <linearGradient id={`${gradId}-wing`} x1="8" y1="10" x2="56" y2="56" gradientUnits="userSpaceOnUse">
          <stop offset="0%" stopColor={monochrome ? 'currentColor' : 'var(--anka-accent-hover, #38bdf8)'} />
          <stop offset="100%" stopColor={monochrome ? 'currentColor' : 'var(--anka-accent, #0284c7)'} />
        </linearGradient>
        <linearGradient id={`${gradId}-core`} x1="32" y1="8" x2="32" y2="58" gradientUnits="userSpaceOnUse">
          <stop offset="0%" stopColor={monochrome ? 'currentColor' : '#fbbf24'} />
          <stop offset="55%" stopColor={monochrome ? 'currentColor' : 'var(--anka-accent-hover, #38bdf8)'} />
          <stop offset="100%" stopColor={monochrome ? 'currentColor' : 'var(--anka-accent, #0284c7)'} />
        </linearGradient>
      </defs>

      {/* Outer geometric wing tiers - Left */}
      <path
        d="M28 34L8 16C11.5 23.5 16 28.5 23 32L12 31C16 36.5 21 39 27 40L18 45C22.5 47 26.5 46.5 30 44"
        fill={`url(#${gradId}-wing)`}
        fillOpacity={monochrome ? 0.9 : 0.94}
        className={animated ? 'anka-wing-left' : undefined}
      />

      {/* Outer geometric wing tiers - Right */}
      <path
        d="M36 34L56 16C52.5 23.5 48 28.5 41 32L52 31C48 36.5 43 39 37 40L46 45C41.5 47 37.5 46.5 34 44"
        fill={`url(#${gradId}-wing)`}
        fillOpacity={monochrome ? 0.9 : 0.94}
        className={animated ? 'anka-wing-right' : undefined}
      />

      {/* Upper Inner Wing Blades */}
      <path
        d="M30 30L17 12C22 15.5 26.5 20.5 30 26.5L32 22L34 26.5C37.5 20.5 42 15.5 47 12L34 30Z"
        fill={`url(#${gradId}-wing)`}
        fillOpacity={monochrome ? 0.72 : 0.85}
        className={animated ? 'anka-core-ignite' : undefined}
      />

      {/* Central Phoenix Crest, Body & Ascending Tail Spear */}
      <path
        d="M32 7L36.2 15.8L33.5 19.2L35.2 35.5L32 57L28.8 35.5L30.5 19.2L27.8 15.8L32 7Z"
        fill={`url(#${gradId}-core)`}
        className={animated ? 'anka-core-ignite' : undefined}
      />

      {/* Precision Crest Crown */}
      <path
        d="M32 10.5L33.6 15L32 17.5L30.4 15L32 10.5Z"
        fill={monochrome ? 'currentColor' : '#fef3c7'}
        fillOpacity={monochrome ? 0.85 : 0.95}
        className={animated ? 'anka-core-ignite' : undefined}
      />
    </svg>
  );

  if (!withFrame) {
    return <span className={`inline-flex items-center justify-center shrink-0 ${className}`}>{svg}</span>;
  }

  return (
    <span
      className={`inline-flex items-center justify-center shrink-0 rounded-2xl border border-[var(--anka-border-strong)] bg-[var(--anka-surface-muted)] shadow-sm ${className}`}
      style={{ width: Math.round(size * 1.45), height: Math.round(size * 1.45) }}
    >
      {svg}
    </span>
  );
};
