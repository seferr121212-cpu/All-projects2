import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  Camera,
  ClipboardPaste,
  Copy,
  Edit3,
  FileCode2,
  FileText,
  Folder,
  FolderOpen,
  FolderPlus,
  Globe,
  Image as ImageIcon,
  Moon,
  Plus,
  RefreshCw,
  RotateCcw,
  Settings,
  ShieldAlert,
  Sun,
  Terminal,
  Trash2,
} from 'lucide-react';
import {
  CompositorBufferSnapshot,
  computeWindowRect,
  DoubleBufferedCompositor,
} from '../os/compositor';
import { t, WALLPAPERS } from '../os/i18n';
import { useOS } from '../os/kernel';
import { VFSNode, WindowSnap } from '../os/types';
import { HOME_PATH, listDir } from '../os/vfs';
import { AppIcon } from './AppIcon';
import { AppLauncher } from './AppLauncher';
import { Dock } from './Dock';
import { ToastHost } from './ToastHost';
import { TopBar } from './TopBar';
import { WindowFrame } from './WindowFrame';
import { WindowSwitcher } from './WindowSwitcher';

export const Desktop: React.FC = () => {
  const {
    vfs,
    windows,
    activeWorkspace,
    currentUser,
    settings,
    launchApp,
    openFileWithDefaultApp,
    makeDir,
    writeFile,
    renameNode,
    copyNode,
    moveNode,
    trashNode,
    emptyTrash,
    clipboard,
    setClipboard,
    pushNotification,
    updateSettings,
    toggleTheme,
    updateCompositorStats,
    captureDesktopScreenshot,
    pendingPermissionRequest,
    resolvePermissionRequest,
  } = useOS();

  const lang = settings.language;
  const tr = lang === 'tr';
  const userHome = currentUser.homeDir || HOME_PATH;
  const desktopPath = `${userHome}/Masaüstü`;
  const trashPath = `${userHome}/.Trash`;

  const wallpaper =
    WALLPAPERS.find((w) => w.id === settings.wallpaperId) || WALLPAPERS[0];

  const desktopFiles = listDir(vfs, desktopPath);
  const trashItems = listDir(vfs, trashPath);

  const [ctxMenu, setCtxMenu] = useState<{ x: number; y: number } | null>(null);
  const [itemMenu, setItemMenu] = useState<{ x: number; y: number; path: string; node: VFSNode } | null>(null);
  const [renameTarget, setRenameTarget] = useState<{ path: string; name: string } | null>(null);
  const [renameValue, setRenameValue] = useState('');
  const [dragOverDesktop, setDragOverDesktop] = useState(false);
  const [selectedIds, setSelectedIds] = useState<string[]>([]);
  const [marquee, setMarquee] = useState<{
    startX: number;
    startY: number;
    currX: number;
    currY: number;
  } | null>(null);
  const [draggingIcon, setDraggingIcon] = useState<{
    key: string;
    x: number;
    y: number;
  } | null>(null);
  const iconRefs = useRef<Record<string, HTMLButtonElement | null>>({});
  const suppressNextClickRef = useRef(false);
  const [snapPreview, setSnapPreview] = useState<WindowSnap>('none');
  const [refreshPulse, setRefreshPulse] = useState(0);
  const [viewport, setViewport] = useState(() => ({
    w: typeof window !== 'undefined' ? window.innerWidth : 1280,
    h: typeof window !== 'undefined' ? window.innerHeight : 800,
  }));

  // Double-Buffered Compositor Loop (BackBuffer -> FrontBuffer atomic swap on VSync rAF)
  const compositorRef = useRef<DoubleBufferedCompositor | null>(null);
  if (!compositorRef.current) {
    compositorRef.current = new DoubleBufferedCompositor();
  }
  const sceneRef = useRef({ windows, activeWorkspace, viewport });
  sceneRef.current = { windows, activeWorkspace, viewport };
  const lastStatsSyncRef = useRef<{
    at: number;
    surfaceCount: number;
    prevSwapTs: number;
  }>({
    at: 0,
    surfaceCount: -1,
    prevSwapTs: 0,
  });
  const updateCompositorStatsRef = useRef(updateCompositorStats);
  updateCompositorStatsRef.current = updateCompositorStats;
  const [frontBuffer, setFrontBuffer] = useState<CompositorBufferSnapshot | null>(null);

  useEffect(() => {
    const onResize = () => setViewport({ w: window.innerWidth, h: window.innerHeight });
    window.addEventListener('resize', onResize);
    return () => window.removeEventListener('resize', onResize);
  }, []);

  useEffect(() => {
    const comp = compositorRef.current!;
    const stopLoop = comp.startLoop(
      () => ({
        windows: sceneRef.current.windows,
        activeWorkspace: sceneRef.current.activeWorkspace,
        viewportW: sceneRef.current.viewport.w,
        viewportH: sceneRef.current.viewport.h,
      }),
      (snapshot) => {
        const now = Date.now();
        const deltaMs =
          lastStatsSyncRef.current.prevSwapTs > 0
            ? Math.max(0.1, Number((snapshot.swapTimestamp - lastStatsSyncRef.current.prevSwapTs).toFixed(2)))
            : 16.67;
        lastStatsSyncRef.current.prevSwapTs = snapshot.swapTimestamp;

        if (
          now - lastStatsSyncRef.current.at >= 500 ||
          lastStatsSyncRef.current.surfaceCount !== snapshot.surfaces.length
        ) {
          lastStatsSyncRef.current.at = now;
          lastStatsSyncRef.current.surfaceCount = snapshot.surfaces.length;
          updateCompositorStatsRef.current({
            frameId: snapshot.frameId,
            vsyncHz: snapshot.vsyncHz,
            surfaceCount: snapshot.surfaces.length,
            lastSwapMs: deltaMs,
          });
        }

        setFrontBuffer((prev) => {
          if (
            prev &&
            prev.surfaces.length === snapshot.surfaces.length &&
            prev.surfaces.every((s, idx) => {
              const n = snapshot.surfaces[idx];
              return (
                s.windowId === n.windowId &&
                s.snap === n.snap &&
                s.rect.x === n.rect.x &&
                s.rect.y === n.rect.y &&
                s.rect.width === n.rect.width &&
                s.rect.height === n.rect.height &&
                s.rect.zIndex === n.rect.zIndex
              );
            })
          ) {
            return prev;
          }
          return snapshot;
        });
      }
    );
    return stopLoop;
  }, []);

  const surfaceMap = useMemo(() => {
    const map = new Map<string, CompositorBufferSnapshot['surfaces'][number]>();
    frontBuffer?.surfaces.forEach((s) => map.set(s.windowId, s));
    return map;
  }, [frontBuffer]);

  const snapGhostRect = useMemo(() => {
    if (snapPreview === 'none') return null;
    return computeWindowRect(
      { x: 0, y: 0, width: 640, height: 480, snap: snapPreview, zIndex: 15 },
      viewport.w,
      viewport.h
    );
  }, [snapPreview, viewport]);

  const handleContextMenu = (e: React.MouseEvent) => {
    if ((e.target as HTMLElement).closest('[data-window-surface]')) return;
    e.preventDefault();
    setItemMenu(null);
    setCtxMenu({
      x: Math.min(e.clientX, window.innerWidth - 230),
      y: Math.min(e.clientY, window.innerHeight - 310),
    });
  };

  const handleDesktopDrop = async (e: React.DragEvent) => {
    if ((e.target as HTMLElement).closest('[data-window-surface]')) return;
    e.preventDefault();
    setDragOverDesktop(false);
    const files = Array.from(e.dataTransfer.files);
    if (files.length === 0) return;

    let imported = 0;
    for (const file of files) {
      const targetPath = `${desktopPath}/${file.name}`;
      if (file.type.startsWith('image/')) {
        const dataUrl = await new Promise<string>((resolve) => {
          const r = new FileReader();
          r.onload = () => resolve(typeof r.result === 'string' ? r.result : '');
          r.readAsDataURL(file);
        });
        if (dataUrl && writeFile(targetPath, dataUrl, file.type).ok) imported++;
      } else {
        const text = await file.text();
        if (writeFile(targetPath, text, file.type || 'text/plain').ok) imported++;
      }
    }
    if (imported > 0) {
      pushNotification(
        tr ? 'Masaüstüne Aktarıldı' : 'Imported to Desktop',
        tr ? `${imported} dosya ~/Masaüstü klasörüne kaydedildi.` : `${imported} file(s) saved to ~/Masaüstü.`,
        'files'
      );
    }
  };

  const handlePasteToDesktop = () => {
    if (!clipboard || clipboard.kind !== 'vfs' || !clipboard.path) return;
    const baseName = clipboard.path.split('/').pop() || 'kopya';
    if (clipboard.mode === 'cut') {
      moveNode(clipboard.path, `${desktopPath}/${baseName}`);
      setClipboard(null);
    } else {
      copyNode(clipboard.path, `${desktopPath}/Kopya_${baseName}`);
    }
    setCtxMenu(null);
  };

  const handleCreateDesktopFolder = () => {
    const idx = desktopFiles.length + 1;
    makeDir(`${desktopPath}/Yeni_Klasor_${idx}`);
    setCtxMenu(null);
  };

  const handleCreateDesktopFile = () => {
    const idx = desktopFiles.length + 1;
    writeFile(`${desktopPath}/Not_${idx}.txt`, '');
    setCtxMenu(null);
  };

  const cycleWallpaper = () => {
    const idx = WALLPAPERS.findIndex((w) => w.id === settings.wallpaperId);
    const next = WALLPAPERS[(idx + 1) % WALLPAPERS.length];
    updateSettings({ wallpaperId: next.id, customWallpaperUrl: null });
    setCtxMenu(null);
  };

  const selectedVfsPaths = useMemo(
    () =>
      desktopFiles
        .filter((n) => selectedIds.includes(n.id))
        .map((n) => `${desktopPath}/${n.name}`),
    [desktopFiles, selectedIds, desktopPath]
  );

  const handleBulkTrash = () => {
    selectedVfsPaths.forEach((p) => trashNode(p));
    setSelectedIds([]);
    setCtxMenu(null);
    setItemMenu(null);
  };

  const handleDesktopPointerDown = (e: React.PointerEvent) => {
    if (e.button !== 0) return;
    const target = e.target as HTMLElement;
    if (
      target.closest('[data-window-surface]') ||
      target.closest('button') ||
      target.closest('[data-desktop-overlay]')
    ) {
      return;
    }

    const startX = e.clientX;
    const startY = e.clientY;
    let moved = false;

    const onMove = (ev: PointerEvent) => {
      const dx = ev.clientX - startX;
      const dy = ev.clientY - startY;
      if (!moved && Math.hypot(dx, dy) < 6) return;
      moved = true;
      const box = { startX, startY, currX: ev.clientX, currY: ev.clientY };
      setMarquee(box);

      const left = Math.min(startX, ev.clientX);
      const right = Math.max(startX, ev.clientX);
      const top = Math.min(startY, ev.clientY);
      const bottom = Math.max(startY, ev.clientY);

      const hits: string[] = [];
      Object.entries(iconRefs.current).forEach(([key, el]) => {
        if (!el) return;
        const r = el.getBoundingClientRect();
        const intersects = !(r.right < left || r.left > right || r.bottom < top || r.top > bottom);
        if (intersects) hits.push(key);
      });
      setSelectedIds(hits);
    };

    const onUp = () => {
      if (moved) {
        suppressNextClickRef.current = true;
      }
      setMarquee(null);
      window.removeEventListener('pointermove', onMove);
      window.removeEventListener('pointerup', onUp);
    };

    window.addEventListener('pointermove', onMove);
    window.addEventListener('pointerup', onUp);
  };

  const startIconDrag = (e: React.PointerEvent<HTMLButtonElement>, key: string) => {
    if (e.button !== 0) return;
    const el = e.currentTarget;
    const rect = el.getBoundingClientRect();
    const startX = e.clientX;
    const startY = e.clientY;
    const origX = rect.left;
    const origY = rect.top;
    let moved = false;
    let finalX = origX;
    let finalY = origY;

    const onMove = (ev: PointerEvent) => {
      const dx = ev.clientX - startX;
      const dy = ev.clientY - startY;
      if (!moved && Math.hypot(dx, dy) < 6) return;
      moved = true;
      finalX = Math.max(8, Math.min(window.innerWidth - rect.width - 8, origX + dx));
      finalY = Math.max(44, Math.min(window.innerHeight - rect.height - 84, origY + dy));
      setDraggingIcon({ key, x: finalX, y: finalY });
    };

    const onUp = () => {
      if (moved) {
        suppressNextClickRef.current = true;
        updateSettings({
          desktopIconPositions: {
            ...(settings.desktopIconPositions || {}),
            [key]: { x: Math.round(finalX), y: Math.round(finalY) },
          },
        });
      }
      setDraggingIcon(null);
      window.removeEventListener('pointermove', onMove);
      window.removeEventListener('pointerup', onUp);
    };

    window.addEventListener('pointermove', onMove);
    window.addEventListener('pointerup', onUp);
  };

  const toggleSelectIcon = (e: React.MouseEvent, key: string) => {
    e.stopPropagation();
    if (suppressNextClickRef.current) {
      suppressNextClickRef.current = false;
      return;
    }
    if (e.ctrlKey || e.metaKey || e.shiftKey) {
      setSelectedIds((prev) =>
        prev.includes(key) ? prev.filter((id) => id !== key) : [...prev, key]
      );
    } else {
      setSelectedIds([key]);
    }
  };

  const getIconPosStyle = (key: string): React.CSSProperties | undefined => {
    if (draggingIcon?.key === key) {
      return { position: 'fixed', left: draggingIcon.x, top: draggingIcon.y, zIndex: 25 };
    }
    const saved = settings.desktopIconPositions?.[key];
    if (saved) {
      return { position: 'fixed', left: saved.x, top: saved.y, zIndex: 12 };
    }
    return undefined;
  };

  const hasCustomIconPositions =
    Boolean(settings.desktopIconPositions) &&
    Object.keys(settings.desktopIconPositions || {}).length > 0;

  return (
    <div
      className="fixed inset-0 overflow-hidden select-none"
      onPointerDown={handleDesktopPointerDown}
      onContextMenu={handleContextMenu}
      onDragOver={(e) => {
        if ((e.target as HTMLElement).closest('[data-window-surface]')) return;
        if (e.dataTransfer.types.includes('Files')) {
          e.preventDefault();
          setDragOverDesktop(true);
        }
      }}
      onDragLeave={() => setDragOverDesktop(false)}
      onDrop={(e) => void handleDesktopDrop(e)}
      onClick={() => {
        setCtxMenu(null);
        setItemMenu(null);
        if (suppressNextClickRef.current) {
          suppressNextClickRef.current = false;
          return;
        }
        setSelectedIds([]);
      }}
    >
      <img
        src={settings.customWallpaperUrl || wallpaper.url}
        alt={tr ? wallpaper.nameTr : wallpaper.nameEn}
        referrerPolicy="no-referrer"
        className="absolute inset-0 w-full h-full object-cover pointer-events-none"
      />
      <div
        className={`absolute inset-0 pointer-events-none transition-colors duration-300 ${
          settings.theme === 'dark' ? 'bg-slate-950/20' : 'bg-slate-900/5'
        }`}
      />

      <TopBar />
      <ToastHost />

      {settings.showDesktopIcons && (
        <div
          key={refreshPulse}
          className="absolute top-12 left-4 bottom-24 flex flex-col flex-wrap content-start gap-2 z-10 pointer-events-auto"
        >
          <button
            ref={(el) => {
              iconRefs.current['shortcut-files'] = el;
            }}
            style={getIconPosStyle('shortcut-files')}
            onPointerDown={(e) => startIconDrag(e, 'shortcut-files')}
            onClick={(e) => toggleSelectIcon(e, 'shortcut-files')}
            onDoubleClick={() => launchApp('files')}
            className={`w-24 p-2 rounded-xl flex flex-col items-center text-center transition-colors ${
              selectedIds.includes('shortcut-files')
                ? 'bg-white/25 ring-1 ring-white/40'
                : 'hover:bg-white/15'
            }`}
          >
            <AppIcon appId="files" size={20} />
            <span className="mt-1.5 text-xs font-medium text-white drop-shadow-sm truncate w-full">
              {tr ? 'Dosyalar' : 'Files'}
            </span>
          </button>

          <button
            ref={(el) => {
              iconRefs.current['shortcut-terminal'] = el;
            }}
            style={getIconPosStyle('shortcut-terminal')}
            onPointerDown={(e) => startIconDrag(e, 'shortcut-terminal')}
            onClick={(e) => toggleSelectIcon(e, 'shortcut-terminal')}
            onDoubleClick={() => launchApp('terminal')}
            className={`w-24 p-2 rounded-xl flex flex-col items-center text-center transition-colors ${
              selectedIds.includes('shortcut-terminal')
                ? 'bg-white/25 ring-1 ring-white/40'
                : 'hover:bg-white/15'
            }`}
          >
            <AppIcon appId="terminal" size={20} />
            <span className="mt-1.5 text-xs font-medium text-white drop-shadow-sm truncate w-full">
              {tr ? 'Uçbirim' : 'Terminal'}
            </span>
          </button>

          <button
            ref={(el) => {
              iconRefs.current['shortcut-trash'] = el;
            }}
            style={getIconPosStyle('shortcut-trash')}
            onPointerDown={(e) => startIconDrag(e, 'shortcut-trash')}
            onClick={(e) => toggleSelectIcon(e, 'shortcut-trash')}
            onDoubleClick={() => launchApp('files', { path: trashPath })}
            onContextMenu={(e) => {
              e.preventDefault();
              e.stopPropagation();
              setCtxMenu(null);
              setItemMenu({
                x: Math.min(e.clientX, window.innerWidth - 220),
                y: Math.min(e.clientY, window.innerHeight - 160),
                path: trashPath,
                node: {
                  id: 'desktop-trash',
                  name: t(lang, 'trash'),
                  type: 'dir',
                  permissions: 'drwxr-xr-x',
                  owner: currentUser.username,
                  size: 0,
                  createdAt: 0,
                  updatedAt: 0,
                },
              });
            }}
            className={`w-24 p-2 rounded-xl flex flex-col items-center text-center transition-colors ${
              selectedIds.includes('shortcut-trash')
                ? 'bg-white/25 ring-1 ring-white/40'
                : 'hover:bg-white/15'
            }`}
          >
            <div className="w-10 h-10 rounded-xl bg-slate-900/75 backdrop-blur-md border border-white/20 flex items-center justify-center shadow-sm">
              <Trash2 size={20} className={trashItems.length > 0 ? 'text-amber-400' : 'text-slate-300'} />
            </div>
            <span className="mt-1.5 text-xs font-medium text-white drop-shadow-sm truncate w-full">
              {trashItems.length > 0 ? `${t(lang, 'trash')} (${trashItems.length})` : t(lang, 'trash')}
            </span>
          </button>

          {desktopFiles.map((node) => {
            const path = `${desktopPath}/${node.name}`;
            const selected = selectedIds.includes(node.id);
            return (
              <button
                key={node.id}
                ref={(el) => {
                  iconRefs.current[node.id] = el;
                }}
                style={getIconPosStyle(node.id)}
                onPointerDown={(e) => startIconDrag(e, node.id)}
                onClick={(e) => toggleSelectIcon(e, node.id)}
                onDoubleClick={() => openFileWithDefaultApp(path)}
                onContextMenu={(e) => {
                  e.preventDefault();
                  e.stopPropagation();
                  setCtxMenu(null);
                  if (!selectedIds.includes(node.id)) {
                    setSelectedIds([node.id]);
                  }
                  setItemMenu({
                    x: Math.min(e.clientX, window.innerWidth - 220),
                    y: Math.min(e.clientY, window.innerHeight - 260),
                    path,
                    node,
                  });
                }}
                className={`w-24 p-2 rounded-xl flex flex-col items-center text-center transition-colors ${
                  selected ? 'bg-white/25 ring-1 ring-white/40' : 'hover:bg-white/15'
                }`}
              >
                <div className="w-10 h-10 rounded-xl bg-slate-900/75 backdrop-blur-md border border-white/20 flex items-center justify-center shadow-sm">
                  {node.type === 'dir' ? (
                    <Folder size={20} className="text-sky-400" />
                  ) : node.mimeType?.startsWith('image/') ? (
                    <ImageIcon size={20} className="text-amber-400" />
                  ) : /\.html?$/i.test(node.name) ? (
                    <Globe size={20} className="text-indigo-400" />
                  ) : node.name.endsWith('.js') ? (
                    <FileCode2 size={20} className="text-emerald-400" />
                  ) : (
                    <FileText size={20} className="text-slate-200" />
                  )}
                </div>
                <span className="mt-1.5 text-xs font-medium text-white drop-shadow-sm truncate w-full">
                  {node.name}
                </span>
              </button>
            );
          })}
        </div>
      )}

      {/* Marquee Multi-Selection Box */}
      {marquee && (
        <div
          style={{
            left: Math.min(marquee.startX, marquee.currX),
            top: Math.min(marquee.startY, marquee.currY),
            width: Math.abs(marquee.currX - marquee.startX),
            height: Math.abs(marquee.currY - marquee.startY),
            borderColor: 'var(--anka-accent)',
            backgroundColor: 'var(--anka-accent-soft)',
          }}
          className="fixed z-30 border rounded pointer-events-none"
        />
      )}

      {/* Host File Drag-and-Drop Overlay */}
      {dragOverDesktop && (
        <div className="fixed inset-10 top-14 bottom-24 z-40 rounded-2xl border-2 border-dashed border-[var(--anka-accent)] bg-[var(--anka-accent-soft)] backdrop-blur-sm pointer-events-none flex items-center justify-center">
          <div className="px-5 py-3 rounded-xl bg-[var(--anka-glass)] border border-[var(--anka-border)] text-sm font-medium text-[var(--anka-text)] shadow-xl">
            {tr ? 'Masaüstüne (~/Masaüstü) içe aktarmak için bırakın' : 'Drop files to import to ~/Masaüstü'}
          </div>
        </div>
      )}

      {/* Edge-Snap Translucent Preview Ghost */}
      {snapGhostRect && (
        <div
          style={{
            transform: `translate3d(${snapGhostRect.x}px, ${snapGhostRect.y}px, 0)`,
            width: snapGhostRect.width,
            height: snapGhostRect.height,
            borderColor: 'var(--anka-accent)',
            backgroundColor: 'var(--anka-accent-soft)',
          }}
          className="fixed top-0 left-0 z-40 rounded-xl border-2 backdrop-blur-sm pointer-events-none transition-all duration-100"
        />
      )}

      <div data-window-surface="true">
        {windows.map((win) => (
          <WindowFrame
            key={win.id}
            win={win}
            compositedRect={surfaceMap.get(win.id)?.rect}
            onSnapPreview={setSnapPreview}
          />
        ))}
      </div>

      {/* Syscall-level Sandbox Permission Prompt Modal */}
      {pendingPermissionRequest && (
        <div
          onClick={(e) => e.stopPropagation()}
          className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-sm flex items-center justify-center p-4"
        >
          <div className="w-full max-w-md rounded-2xl border border-[var(--anka-border)] bg-[var(--anka-surface)] shadow-2xl p-5 space-y-4 text-[var(--anka-text)]">
            <div className="flex items-start gap-3">
              <div className="w-10 h-10 rounded-xl bg-amber-500/15 text-amber-500 flex items-center justify-center shrink-0">
                <ShieldAlert size={20} />
              </div>
              <div className="space-y-1">
                <h3 className="text-sm font-semibold">
                  {tr ? 'Sandbox Dosya Erişim İzni İstemi' : 'Sandbox Filesystem Permission Request'}
                </h3>
                <p className="text-xs text-[var(--anka-text-muted)] leading-relaxed">
                  <span className="font-mono font-semibold text-[var(--anka-accent)]">
                    {pendingPermissionRequest.appId}
                  </span>{' '}
                  (PID {pendingPermissionRequest.pid}) kullanıcı belgesi yoluna erişmek istiyor:
                </p>
                <div className="px-2.5 py-1.5 rounded-lg bg-[var(--anka-surface-muted)] border border-[var(--anka-border)] font-mono text-[11px] break-all text-[var(--anka-text-muted)]">
                  {pendingPermissionRequest.operation.toUpperCase()}: {pendingPermissionRequest.targetPath}
                </div>
              </div>
            </div>
            <div className="flex items-center justify-end gap-2">
              <button
                onClick={() => resolvePermissionRequest(false)}
                className="px-3.5 py-1.5 rounded-lg text-xs font-medium border border-[var(--anka-border)] hover:bg-[var(--anka-surface-elevated)] transition-colors"
              >
                {tr ? 'Reddet' : 'Deny'}
              </button>
              <button
                onClick={() => resolvePermissionRequest(true)}
                className="px-3.5 py-1.5 rounded-lg text-xs font-medium bg-[var(--anka-accent)] hover:bg-[var(--anka-accent-hover)] text-[var(--anka-accent-fg)] transition-colors"
              >
                {tr ? 'Belgeler Erişimine İzin Ver' : 'Allow Documents Access'}
              </button>
            </div>
          </div>
        </div>
      )}

      {ctxMenu && (
        <div
          data-desktop-overlay="true"
          style={{ top: ctxMenu.y, left: ctxMenu.x }}
          onClick={(e) => e.stopPropagation()}
          className="fixed z-50 w-56 rounded-xl border border-[var(--anka-border)] bg-[var(--anka-glass)] backdrop-blur-xl shadow-2xl p-1.5 text-xs text-[var(--anka-text)] space-y-0.5"
        >
          {selectedVfsPaths.length > 1 && (
            <>
              <button
                onClick={handleBulkTrash}
                className="w-full flex items-center gap-2.5 px-2.5 py-2 rounded-lg hover:bg-rose-500/10 text-rose-500 text-left transition-colors"
              >
                <Trash2 size={14} />
                <span>
                  {tr
                    ? `Seçilenleri Çöpe Taşı (${selectedVfsPaths.length})`
                    : `Move Selected to Trash (${selectedVfsPaths.length})`}
                </span>
              </button>
              <div className="h-px bg-[var(--anka-border)] my-1" />
            </>
          )}
          <button
            onClick={handleCreateDesktopFolder}
            className="w-full flex items-center gap-2.5 px-2.5 py-2 rounded-lg hover:bg-[var(--anka-surface-elevated)] text-left transition-colors"
          >
            <FolderPlus size={14} className="text-[var(--anka-accent)]" />
            <span>{t(lang, 'newFolder')}</span>
          </button>
          <button
            onClick={handleCreateDesktopFile}
            className="w-full flex items-center gap-2.5 px-2.5 py-2 rounded-lg hover:bg-[var(--anka-surface-elevated)] text-left transition-colors"
          >
            <Plus size={14} className="text-emerald-500" />
            <span>{t(lang, 'newFile')}</span>
          </button>
          {clipboard?.kind === 'vfs' && clipboard.path && (
            <button
              onClick={handlePasteToDesktop}
              className="w-full flex items-center gap-2.5 px-2.5 py-2 rounded-lg hover:bg-[var(--anka-surface-elevated)] text-left transition-colors"
            >
              <ClipboardPaste size={14} className="text-[var(--anka-accent)]" />
              <span>{t(lang, 'paste')}</span>
            </button>
          )}
          <button
            onClick={() => {
              launchApp('terminal', { cwd: desktopPath });
              setCtxMenu(null);
            }}
            className="w-full flex items-center gap-2.5 px-2.5 py-2 rounded-lg hover:bg-[var(--anka-surface-elevated)] text-left transition-colors"
          >
            <Terminal size={14} />
            <span>{t(lang, 'openTerminalHere')}</span>
          </button>
          <button
            onClick={() => {
              void captureDesktopScreenshot();
              setCtxMenu(null);
            }}
            className="w-full flex items-center gap-2.5 px-2.5 py-2 rounded-lg hover:bg-[var(--anka-surface-elevated)] text-left transition-colors"
          >
            <Camera size={14} className="text-sky-500" />
            <span>{tr ? 'Ekran Görüntüsü Al' : 'Take Screenshot'}</span>
          </button>
          <button
            onClick={() => {
              setRefreshPulse((n) => n + 1);
              setCtxMenu(null);
            }}
            className="w-full flex items-center gap-2.5 px-2.5 py-2 rounded-lg hover:bg-[var(--anka-surface-elevated)] text-left transition-colors"
          >
            <RefreshCw size={14} />
            <span>{t(lang, 'refreshDesktop')}</span>
          </button>
          {hasCustomIconPositions && (
            <button
              onClick={() => {
                updateSettings({ desktopIconPositions: {} });
                setCtxMenu(null);
              }}
              className="w-full flex items-center gap-2.5 px-2.5 py-2 rounded-lg hover:bg-[var(--anka-surface-elevated)] text-left transition-colors"
            >
              <RotateCcw size={14} />
              <span>{tr ? 'Simge Konumlarını Sıfırla' : 'Reset Icon Positions'}</span>
            </button>
          )}
          <div className="h-px bg-[var(--anka-border)] my-1" />
          <button
            onClick={() => {
              toggleTheme();
              setCtxMenu(null);
            }}
            className="w-full flex items-center gap-2.5 px-2.5 py-2 rounded-lg hover:bg-[var(--anka-surface-elevated)] text-left transition-colors"
          >
            {settings.theme === 'dark' ? (
              <Sun size={14} className="text-amber-500" />
            ) : (
              <Moon size={14} className="text-[var(--anka-accent)]" />
            )}
            <span>
              {settings.theme === 'dark'
                ? tr
                  ? 'Aydınlık Moda Geç'
                  : 'Switch to Light Mode'
                : tr
                  ? 'Karanlık Moda Geç'
                  : 'Switch to Dark Mode'}
            </span>
          </button>
          <button
            onClick={cycleWallpaper}
            className="w-full flex items-center gap-2.5 px-2.5 py-2 rounded-lg hover:bg-[var(--anka-surface-elevated)] text-left transition-colors"
          >
            <ImageIcon size={14} />
            <span>{t(lang, 'changeWallpaper')}</span>
          </button>
          <button
            onClick={() => {
              launchApp('settings');
              setCtxMenu(null);
            }}
            className="w-full flex items-center gap-2.5 px-2.5 py-2 rounded-lg hover:bg-[var(--anka-surface-elevated)] text-left transition-colors"
          >
            <Settings size={14} />
            <span>{t(lang, 'displaySettings')}</span>
          </button>
        </div>
      )}

      {/* Per-Item Desktop Icon Context Menu */}
      {itemMenu && (
        <div
          style={{ top: itemMenu.y, left: itemMenu.x }}
          onClick={(e) => e.stopPropagation()}
          className="fixed z-50 w-52 rounded-xl border border-[var(--anka-border)] bg-[var(--anka-glass)] backdrop-blur-xl shadow-2xl p-1.5 text-xs text-[var(--anka-text)] space-y-0.5"
        >
          {itemMenu.path === trashPath ? (
            <>
              <button
                onClick={() => {
                  launchApp('files', { path: trashPath });
                  setItemMenu(null);
                }}
                className="w-full flex items-center gap-2.5 px-2.5 py-2 rounded-lg hover:bg-[var(--anka-surface-elevated)] text-left"
              >
                <FolderOpen size={14} className="text-[var(--anka-accent)]" />
                <span>{t(lang, 'open')}</span>
              </button>
              <button
                onClick={() => {
                  emptyTrash();
                  setItemMenu(null);
                }}
                disabled={trashItems.length === 0}
                className="w-full flex items-center gap-2.5 px-2.5 py-2 rounded-lg hover:bg-rose-500/10 text-rose-500 disabled:opacity-40 text-left"
              >
                <Trash2 size={14} />
                <span>{tr ? 'Çöp Kutusunu Boşalt' : 'Empty Trash'}</span>
              </button>
            </>
          ) : (
            <>
              <button
                onClick={() => {
                  openFileWithDefaultApp(itemMenu.path);
                  setItemMenu(null);
                }}
                className="w-full flex items-center gap-2.5 px-2.5 py-2 rounded-lg hover:bg-[var(--anka-surface-elevated)] text-left"
              >
                <FolderOpen size={14} className="text-[var(--anka-accent)]" />
                <span>{t(lang, 'open')}</span>
              </button>
              {itemMenu.node.type === 'file' && (
                <button
                  onClick={() => {
                    launchApp('editor', { path: itemMenu.path });
                    setItemMenu(null);
                  }}
                  className="w-full flex items-center gap-2.5 px-2.5 py-2 rounded-lg hover:bg-[var(--anka-surface-elevated)] text-left"
                >
                  <FileCode2 size={14} />
                  <span>{t(lang, 'openInEditor')}</span>
                </button>
              )}
              <button
                onClick={() => {
                  setClipboard({ kind: 'vfs', mode: 'copy', path: itemMenu.path });
                  setItemMenu(null);
                }}
                className="w-full flex items-center gap-2.5 px-2.5 py-2 rounded-lg hover:bg-[var(--anka-surface-elevated)] text-left"
              >
                <Copy size={14} />
                <span>{t(lang, 'copy')}</span>
              </button>
              <button
                onClick={() => {
                  setRenameTarget({ path: itemMenu.path, name: itemMenu.node.name });
                  setRenameValue(itemMenu.node.name);
                  setItemMenu(null);
                }}
                className="w-full flex items-center gap-2.5 px-2.5 py-2 rounded-lg hover:bg-[var(--anka-surface-elevated)] text-left"
              >
                <Edit3 size={14} />
                <span>{t(lang, 'rename')}</span>
              </button>
              <div className="h-px bg-[var(--anka-border)] my-1" />
              {selectedVfsPaths.length > 1 && selectedIds.includes(itemMenu.node.id) ? (
                <button
                  onClick={handleBulkTrash}
                  className="w-full flex items-center gap-2.5 px-2.5 py-2 rounded-lg hover:bg-rose-500/10 text-rose-500 text-left"
                >
                  <Trash2 size={14} />
                  <span>
                    {tr
                      ? `Seçilenleri Çöpe Taşı (${selectedVfsPaths.length})`
                      : `Move Selected to Trash (${selectedVfsPaths.length})`}
                  </span>
                </button>
              ) : (
                <button
                  onClick={() => {
                    trashNode(itemMenu.path);
                    setItemMenu(null);
                  }}
                  className="w-full flex items-center gap-2.5 px-2.5 py-2 rounded-lg hover:bg-rose-500/10 text-rose-500 text-left"
                >
                  <Trash2 size={14} />
                  <span>{t(lang, 'moveToTrash')}</span>
                </button>
              )}
            </>
          )}
        </div>
      )}

      {/* Inline Desktop Item Rename Modal */}
      {renameTarget && (
        <div
          onClick={(e) => e.stopPropagation()}
          className="fixed inset-0 z-50 bg-slate-950/50 backdrop-blur-sm flex items-center justify-center p-4"
        >
          <form
            onSubmit={(e) => {
              e.preventDefault();
              if (renameValue.trim() && renameValue.trim() !== renameTarget.name) {
                renameNode(renameTarget.path, renameValue.trim());
              }
              setRenameTarget(null);
            }}
            className="w-full max-w-sm rounded-2xl border border-[var(--anka-border)] bg-[var(--anka-surface)] p-4 shadow-2xl space-y-3 text-xs text-[var(--anka-text)]"
          >
            <div className="font-semibold text-sm">{t(lang, 'rename')}</div>
            <input
              autoFocus
              type="text"
              value={renameValue}
              onChange={(e) => setRenameValue(e.target.value)}
              className="w-full px-3 py-2 rounded-lg border border-[var(--anka-border-strong)] bg-[var(--anka-surface-muted)] outline-none focus:border-[var(--anka-accent)]"
            />
            <div className="flex items-center justify-end gap-2">
              <button
                type="button"
                onClick={() => setRenameTarget(null)}
                className="px-3 py-1.5 rounded-lg border border-[var(--anka-border)] hover:bg-[var(--anka-surface-elevated)]"
              >
                {t(lang, 'cancel')}
              </button>
              <button
                type="submit"
                className="px-3 py-1.5 rounded-lg bg-[var(--anka-accent)] text-[var(--anka-accent-fg)] font-medium hover:bg-[var(--anka-accent-hover)]"
              >
                {t(lang, 'save')}
              </button>
            </div>
          </form>
        </div>
      )}

      <Dock />
      <AppLauncher />
      <WindowSwitcher />
    </div>
  );
};
