import React, { useEffect, useMemo, useState } from 'react';
import {
  Bell,
  BellOff,
  Calendar as CalendarIcon,
  Camera,
  Check,
  Lock,
  Moon,
  Power,
  RotateCcw,
  Search,
  Settings,
  Sun,
  User,
  Volume2,
  VolumeX,
  Wifi,
  WifiOff,
  Zap,
} from 'lucide-react';
import { APP_MANIFESTS } from '../os/apps';
import { t } from '../os/i18n';
import { useOS } from '../os/kernel';
import { POWER_PROFILE_META } from '../os/services';
import { PowerProfile, WorkspaceId } from '../os/types';
import { getNodeAtPath, HOME_PATH } from '../os/vfs';
import { AnkaLogo } from './AnkaLogo';

export const TopBar: React.FC = () => {
  const {
    windows,
    activeWindowId,
    activeWorkspace,
    setActiveWorkspace,
    settings,
    updateSettings,
    toggleTheme,
    setBootPhase,
    rebootSystem,
    launchApp,
    notifications,
    clearNotifications,
    markNotificationsRead,
    setLauncherOpen,
    users,
    currentUser,
    switchUser,
    powerProfile,
    setPowerProfile,
    netStatus,
    refreshNetStatus,
    captureDesktopScreenshot,
    vfs,
    installedPackages,
    uptimeSec,
  } = useOS();

  const [now, setNow] = useState(new Date());
  const [sysMenuOpen, setSysMenuOpen] = useState(false);
  const [notifOpen, setNotifOpen] = useState(false);
  const [netOpen, setNetOpen] = useState(false);
  const [audioOpen, setAudioOpen] = useState(false);
  const [calOpen, setCalOpen] = useState(false);

  const lang = settings.language;
  const tr = lang === 'tr';
  const unreadCount = notifications.filter((n) => !n.read).length;

  const todayKey = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')}`;
  const calendarEvents = useMemo(() => {
    const storePath = `${currentUser.homeDir || HOME_PATH}/.sandbox/pkg-calendar/events.json`;
    const node = getNodeAtPath(vfs, storePath);
    if (node?.type !== 'file' || !node.content) return [];
    try {
      const parsed = JSON.parse(node.content) as Array<{
        id: string;
        date: string;
        time: string;
        title: string;
        done?: boolean;
      }>;
      return Array.isArray(parsed) ? parsed : [];
    } catch {
      return [];
    }
  }, [vfs, currentUser.homeDir]);

  const todayEvents = useMemo(
    () => calendarEvents.filter((ev) => ev.date === todayKey),
    [calendarEvents, todayKey]
  );

  const miniMonthCells = useMemo(() => {
    const y = now.getFullYear();
    const m = now.getMonth();
    const first = new Date(y, m, 1);
    const total = new Date(y, m + 1, 0).getDate();
    const offset = (first.getDay() + 6) % 7;
    const cells: Array<{ day: number | null; key?: string }> = [];
    for (let i = 0; i < offset; i++) cells.push({ day: null });
    for (let d = 1; d <= total; d++) {
      cells.push({
        day: d,
        key: `${y}-${String(m + 1).padStart(2, '0')}-${String(d).padStart(2, '0')}`,
      });
    }
    return cells;
  }, [now]);

  useEffect(() => {
    const id = window.setInterval(() => setNow(new Date()), 1000);
    return () => window.clearInterval(id);
  }, []);

  const activeWindow = windows.find(
    (w) => w.id === activeWindowId && w.workspace === activeWorkspace
  );
  const activeAppLabel = activeWindow
    ? lang === 'tr'
      ? APP_MANIFESTS[activeWindow.appId].nameTr
      : APP_MANIFESTS[activeWindow.appId].nameEn
    : lang === 'tr'
      ? 'Masaüstü'
      : 'Desktop';

  const clockStr = now.toLocaleTimeString(lang === 'tr' ? 'tr-TR' : 'en-US', {
    hour: '2-digit',
    minute: '2-digit',
  });
  const dateStr = now.toLocaleDateString(lang === 'tr' ? 'tr-TR' : 'en-US', {
    day: 'numeric',
    month: 'short',
  });

  const workspaces: WorkspaceId[] = [1, 2, 3, 4];

  const handleSelectUser = async (username: string, hasPassword: boolean) => {
    setSysMenuOpen(false);
    if (username === currentUser.username) return;
    if (hasPassword) {
      setBootPhase('locked');
      return;
    }
    await switchUser(username);
  };

  return (
    <header className="fixed top-0 left-0 right-0 h-9 px-3 flex items-center justify-between bg-[var(--anka-glass)] backdrop-blur-xl border-b border-[var(--anka-border)] text-[var(--anka-text)] z-50 select-none anka-theme-transition">
      {/* Left: OS Menu + Workspace Switcher + Active App */}
      <div className="flex items-center gap-3 relative">
        <button
          onClick={() => {
            setSysMenuOpen((v) => !v);
            setNotifOpen(false);
            setNetOpen(false);
            setAudioOpen(false);
            setCalOpen(false);
          }}
          className="flex items-center gap-1.5 px-2 py-1 rounded-md text-xs font-display font-bold tracking-tight hover:bg-[var(--anka-surface-elevated)] transition-colors whitespace-nowrap"
        >
          <AnkaLogo size={15} />
          <span>AnkaOS</span>
        </button>

        {/* Virtual Workspaces 1..4 */}
        <div className="hidden sm:flex items-center gap-0.5 p-0.5 rounded-md bg-[var(--anka-surface-elevated)]/80">
          {workspaces.map((ws) => {
            const count = windows.filter((w) => w.workspace === ws).length;
            const active = activeWorkspace === ws;
            return (
              <button
                key={ws}
                onClick={() => setActiveWorkspace(ws)}
                title={`${t(lang, 'workspace')} ${ws} (Alt+${ws})`}
                className={`px-2 py-0.5 rounded text-[11px] font-mono tabular-nums transition-colors ${
                  active
                    ? 'bg-[var(--anka-surface)] text-[var(--anka-text)] shadow-sm font-semibold'
                    : count > 0
                      ? 'text-[var(--anka-accent)] hover:bg-[var(--anka-surface)]/40'
                      : 'text-[var(--anka-text-subtle)] hover:text-[var(--anka-text)]'
                }`}
              >
                {ws}
              </button>
            );
          })}
        </div>

        <span className="text-xs font-medium text-[var(--anka-text-muted)] truncate max-w-[160px]">
          {activeAppLabel}
        </span>

        {sysMenuOpen && (
          <div
            onMouseLeave={() => setSysMenuOpen(false)}
            className="absolute top-8 left-0 w-56 rounded-xl border border-[var(--anka-border)] bg-[var(--anka-glass)] backdrop-blur-xl shadow-xl p-1.5 text-xs space-y-0.5 z-50"
          >
            <div className="px-2.5 py-1.5 flex items-center justify-between text-[11px] text-[var(--anka-text-subtle)]">
              <span className="flex items-center gap-1.5 font-medium text-[var(--anka-text)]">
                <User size={12} className="text-[var(--anka-accent)]" />
                {currentUser.username}
              </span>
              <span className="font-mono">UID {currentUser.uid}</span>
            </div>

            {users.length > 1 && (
              <>
                <div className="h-px bg-[var(--anka-border)] my-1" />
                <div className="px-2.5 py-1 text-[10px] font-semibold text-[var(--anka-text-subtle)]">
                  {tr ? 'Kullanıcı Değiştir' : 'Switch User'}
                </div>
                {users.map((u) => {
                  const isActive = u.username === currentUser.username;
                  return (
                    <button
                      key={u.username}
                      onClick={() => void handleSelectUser(u.username, u.passwordHash !== null)}
                      className="w-full flex items-center justify-between px-2.5 py-1.5 rounded-lg hover:bg-[var(--anka-surface-elevated)] text-left transition-colors"
                    >
                      <span className="truncate">{u.username}</span>
                      {isActive ? (
                        <Check size={12} className="text-emerald-500 shrink-0" />
                      ) : u.passwordHash ? (
                        <Lock size={11} className="text-[var(--anka-text-subtle)] shrink-0" />
                      ) : null}
                    </button>
                  );
                })}
              </>
            )}

            <div className="h-px bg-[var(--anka-border)] my-1" />
            <button
              onClick={() => {
                launchApp('settings');
                setSysMenuOpen(false);
              }}
              className="w-full flex items-center gap-2.5 px-2.5 py-2 rounded-lg hover:bg-[var(--anka-surface-elevated)] text-left transition-colors"
            >
              <Settings size={14} />
              <span>{t(lang, 'displaySettings')}</span>
            </button>
            <div className="h-px bg-[var(--anka-border)] my-1" />
            <button
              onClick={() => {
                setSysMenuOpen(false);
                setBootPhase('locked');
              }}
              className="w-full flex items-center gap-2.5 px-2.5 py-2 rounded-lg hover:bg-[var(--anka-surface-elevated)] text-left transition-colors"
            >
              <Lock size={14} />
              <span>{t(lang, 'lockScreen')}</span>
            </button>
            <button
              onClick={() => {
                setSysMenuOpen(false);
                rebootSystem();
              }}
              className="w-full flex items-center gap-2.5 px-2.5 py-2 rounded-lg hover:bg-[var(--anka-surface-elevated)] text-left transition-colors"
            >
              <RotateCcw size={14} />
              <span>{t(lang, 'restart')}</span>
            </button>
            <button
              onClick={() => {
                setSysMenuOpen(false);
                setBootPhase('shutdown');
              }}
              className="w-full flex items-center gap-2.5 px-2.5 py-2 rounded-lg hover:bg-rose-500/15 text-rose-600 dark:text-rose-400 text-left transition-colors"
            >
              <Power size={14} />
              <span>{t(lang, 'shutdown')}</span>
            </button>
          </div>
        )}
      </div>

      {/* Right: Spotlight, Network/Power, Audio, Theme, Notifications, Clock */}
      <div className="flex items-center gap-1.5 relative">
        <button
          onClick={() => setLauncherOpen(true)}
          title="Alt+Space"
          className="p-1.5 rounded-md hover:bg-[var(--anka-surface-elevated)] text-[var(--anka-text-muted)] transition-colors"
        >
          <Search size={14} />
        </button>

        <button
          onClick={() => void captureDesktopScreenshot()}
          title={tr ? 'Ekran Görüntüsü Al' : 'Take Screenshot'}
          className="p-1.5 rounded-md hover:bg-[var(--anka-surface-elevated)] text-[var(--anka-text-muted)] transition-colors"
        >
          <Camera size={14} />
        </button>

        <button
          onClick={() => {
            setNetOpen((v) => !v);
            setNotifOpen(false);
            setSysMenuOpen(false);
            setAudioOpen(false);
            setCalOpen(false);
            void refreshNetStatus();
          }}
          title={tr ? 'Ağ & Güç Profili' : 'Network & Power'}
          className="p-1.5 rounded-md hover:bg-[var(--anka-surface-elevated)] text-[var(--anka-text-muted)] transition-colors flex items-center gap-1"
        >
          {netStatus?.online === false ? (
            <WifiOff size={14} className="text-rose-500" />
          ) : (
            <Wifi size={14} className={netStatus?.online ? 'text-emerald-500' : ''} />
          )}
        </button>

        <button
          onClick={() => {
            setAudioOpen((v) => !v);
            setNotifOpen(false);
            setSysMenuOpen(false);
            setNetOpen(false);
            setCalOpen(false);
          }}
          title={tr ? `Ses Düzeyi (%${settings.muted ? 0 : settings.volume})` : `Volume (${settings.muted ? 0 : settings.volume}%)`}
          className="p-1.5 rounded-md hover:bg-[var(--anka-surface-elevated)] text-[var(--anka-text-muted)] transition-colors"
        >
          {settings.muted || settings.volume === 0 ? <VolumeX size={14} /> : <Volume2 size={14} />}
        </button>

        <button
          onClick={toggleTheme}
          title={settings.theme === 'dark' ? 'Aydınlık Moda Geç' : 'Karanlık Moda Geç'}
          className="p-1.5 rounded-md hover:bg-[var(--anka-surface-elevated)] text-[var(--anka-text-muted)] transition-colors"
        >
          {settings.theme === 'dark' ? <Sun size={14} /> : <Moon size={14} />}
        </button>

        <button
          onClick={() => {
            setNotifOpen((v) => !v);
            setSysMenuOpen(false);
            setNetOpen(false);
            setAudioOpen(false);
            setCalOpen(false);
            markNotificationsRead();
          }}
          title={settings.doNotDisturb ? (tr ? 'Rahatsız Etme Modu Açık' : 'Do Not Disturb On') : t(lang, 'notifications')}
          className="relative p-1.5 rounded-md hover:bg-[var(--anka-surface-elevated)] text-[var(--anka-text-muted)] transition-colors"
        >
          {settings.doNotDisturb ? (
            <BellOff size={14} className="text-amber-500" />
          ) : (
            <Bell size={14} />
          )}
          {unreadCount > 0 && !settings.doNotDisturb && (
            <span className="absolute top-1 right-1 w-1.5 h-1.5 rounded-full bg-[var(--anka-accent)]" />
          )}
        </button>

        <button
          onClick={() => {
            setCalOpen((v) => !v);
            setNotifOpen(false);
            setSysMenuOpen(false);
            setNetOpen(false);
            setAudioOpen(false);
          }}
          title={tr ? 'Takvim ve Saat' : 'Calendar & Clock'}
          className="px-2 py-1 rounded-md text-xs font-medium tabular-nums whitespace-nowrap text-[var(--anka-text)] hover:bg-[var(--anka-surface-elevated)] transition-colors"
        >
          {dateStr} · {clockStr}
        </button>

        {/* Audio Volume Slider Popover */}
        {audioOpen && (
          <div className="absolute top-9 right-12 w-60 rounded-xl border border-[var(--anka-border)] bg-[var(--anka-glass)] backdrop-blur-xl shadow-2xl p-3 space-y-2.5 z-50 text-xs">
            <div className="flex items-center justify-between">
              <span className="font-semibold flex items-center gap-1.5">
                {settings.muted || settings.volume === 0 ? <VolumeX size={13} /> : <Volume2 size={13} className="text-[var(--anka-accent)]" />}
                <span>{tr ? 'Ana Ses Düzeyi' : 'Master Volume'}</span>
              </span>
              <span className="font-mono text-[11px] tabular-nums text-[var(--anka-text-subtle)]">
                %{settings.muted ? 0 : settings.volume}
              </span>
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={() => updateSettings({ muted: !settings.muted })}
                title={settings.muted ? (tr ? 'Sesi Aç' : 'Unmute') : (tr ? 'Sessize Al' : 'Mute')}
                className={`p-1.5 rounded-lg border transition-colors shrink-0 ${
                  settings.muted
                    ? 'border-rose-500/40 bg-rose-500/10 text-rose-500'
                    : 'border-[var(--anka-border)] hover:bg-[var(--anka-surface-elevated)] text-[var(--anka-text)]'
                }`}
              >
                {settings.muted ? <VolumeX size={13} /> : <Volume2 size={13} />}
              </button>
              <input
                type="range"
                min={0}
                max={100}
                value={settings.muted ? 0 : settings.volume}
                onChange={(e) => {
                  const val = Number(e.target.value);
                  updateSettings({ volume: val, muted: val === 0 });
                }}
                className="w-full accent-sky-500 cursor-pointer"
              />
            </div>
          </div>
        )}

        {/* Network & Power Popover */}
        {netOpen && (
          <div className="absolute top-9 right-8 w-72 rounded-xl border border-[var(--anka-border)] bg-[var(--anka-glass)] backdrop-blur-xl shadow-2xl p-3 space-y-3 z-50 text-xs">
            <div className="space-y-1">
              <div className="flex items-center justify-between">
                <span className="font-semibold flex items-center gap-1.5">
                  <Wifi size={13} className="text-[var(--anka-accent)]" />
                  <span>{tr ? 'İnternet Bağlantısı' : 'Internet Link'}</span>
                </span>
                <span
                  className={`font-mono text-[11px] tabular-nums ${
                    netStatus?.online ? 'text-emerald-500' : 'text-rose-500'
                  }`}
                >
                  {netStatus === null
                    ? '...'
                    : netStatus.online
                      ? `${tr ? 'Bağlı' : 'Online'} · ${netStatus.rttMs} ms`
                      : tr
                        ? 'Çevrimdışı'
                        : 'Offline'}
                </span>
              </div>
              <div className="text-[11px] text-[var(--anka-text-subtle)] font-mono">
                {netStatus?.gatewayIp ? `Gateway: ${netStatus.gatewayIp} · eth0` : 'eth0 · 192.168.1.42'}
              </div>
              <div className="flex items-center gap-2 pt-1">
                <button
                  onClick={() => {
                    launchApp('browser');
                    setNetOpen(false);
                  }}
                  className="flex-1 py-1.5 rounded-lg bg-[var(--anka-accent)] text-[var(--anka-accent-fg)] font-medium hover:bg-[var(--anka-accent-hover)]"
                >
                  AnkaArama
                </button>
                <button
                  onClick={() => void refreshNetStatus()}
                  className="px-2.5 py-1.5 rounded-lg border border-[var(--anka-border-strong)] hover:bg-[var(--anka-surface-elevated)]"
                >
                  {tr ? 'Test' : 'Probe'}
                </button>
              </div>
            </div>

            <div className="h-px bg-[var(--anka-border)]" />

            <div className="space-y-1.5">
              <div className="font-semibold flex items-center gap-1.5">
                <Zap size={13} className="text-amber-500" />
                <span>{tr ? 'Güç Profili' : 'Power Profile'}</span>
              </div>
              <div className="grid grid-cols-3 gap-1">
                {(['performance', 'balanced', 'powersaver'] as PowerProfile[]).map((mode) => {
                  const meta = POWER_PROFILE_META[mode];
                  const active = powerProfile === mode;
                  return (
                    <button
                      key={mode}
                      onClick={() => setPowerProfile(mode)}
                      className={`py-1.5 px-1.5 rounded-lg text-[11px] font-medium border transition-colors ${
                        active
                          ? 'bg-[var(--anka-accent-soft)] border-[var(--anka-accent)] text-[var(--anka-accent)]'
                          : 'border-[var(--anka-border)] text-[var(--anka-text-muted)] hover:bg-[var(--anka-surface-elevated)]'
                      }`}
                    >
                      {mode === 'performance'
                        ? tr
                          ? 'Hızlı'
                          : 'Perf'
                        : mode === 'balanced'
                          ? tr
                            ? 'Dengeli'
                            : 'Balanced'
                          : tr
                            ? 'Tasarruf'
                            : 'Saver'}
                    </button>
                  );
                })}
              </div>
              <div className="text-[11px] text-[var(--anka-text-subtle)]">
                {tr ? POWER_PROFILE_META[powerProfile].descTr : POWER_PROFILE_META[powerProfile].descEn}
              </div>
            </div>
          </div>
        )}

        {notifOpen && (
          <div className="absolute top-9 right-0 w-72 rounded-xl border border-[var(--anka-border)] bg-[var(--anka-glass)] backdrop-blur-xl shadow-2xl p-3 space-y-2.5 z-50">
            <div className="flex items-center justify-between text-xs gap-2">
              <span className="font-semibold">{t(lang, 'notifications')}</span>
              <div className="flex items-center gap-2 shrink-0">
                <button
                  onClick={() => updateSettings({ doNotDisturb: !settings.doNotDisturb })}
                  title={tr ? 'Rahatsız Etme Modu' : 'Do Not Disturb'}
                  className={`flex items-center gap-1 px-1.5 py-0.5 rounded border text-[10px] transition-colors whitespace-nowrap ${
                    settings.doNotDisturb
                      ? 'border-amber-500/40 bg-amber-500/15 text-amber-500 font-medium'
                      : 'border-[var(--anka-border)] text-[var(--anka-text-subtle)] hover:text-[var(--anka-text)]'
                  }`}
                >
                  {settings.doNotDisturb ? <BellOff size={11} /> : <Bell size={11} />}
                  <span>{tr ? 'Rahatsız Etme' : 'DND'}</span>
                </button>
                {notifications.length > 0 && (
                  <button
                    onClick={clearNotifications}
                    className="text-[var(--anka-accent)] hover:underline whitespace-nowrap"
                  >
                    {t(lang, 'clearAll')}
                  </button>
                )}
              </div>
            </div>
            {notifications.length === 0 ? (
              <p className="text-xs text-[var(--anka-text-subtle)] py-4 text-center">
                {t(lang, 'noNotifications')}
              </p>
            ) : (
              <div className="max-h-64 overflow-y-auto os-scroll space-y-2">
                {notifications.map((n) => (
                  <button
                    key={n.id}
                    onClick={() => {
                      if (n.appId) launchApp(n.appId);
                      setNotifOpen(false);
                    }}
                    className="w-full text-left p-2.5 rounded-lg bg-[var(--anka-surface-muted)] hover:bg-[var(--anka-surface-elevated)] transition-colors"
                  >
                    <div className="text-xs font-semibold">{n.title}</div>
                    <div className="text-[11px] text-[var(--anka-text-subtle)] mt-0.5 break-all">
                      {n.body}
                    </div>
                  </button>
                ))}
              </div>
            )}
          </div>
        )}
        {/* Interactive Calendar & Clock Popover */}
        {calOpen && (
          <div className="absolute top-9 right-0 w-72 rounded-xl border border-[var(--anka-border)] bg-[var(--anka-glass)] backdrop-blur-xl shadow-2xl p-3.5 space-y-3 z-50 text-xs">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-lg font-mono font-bold tabular-nums">
                  {now.toLocaleTimeString(lang === 'tr' ? 'tr-TR' : 'en-US', {
                    hour: '2-digit',
                    minute: '2-digit',
                    second: '2-digit',
                  })}
                </div>
                <div className="text-[11px] text-[var(--anka-text-subtle)]">
                  {now.toLocaleDateString(lang === 'tr' ? 'tr-TR' : 'en-US', {
                    weekday: 'long',
                    day: 'numeric',
                    month: 'long',
                    year: 'numeric',
                  })}
                </div>
              </div>
              <span className="text-[11px] font-mono tabular-nums text-[var(--anka-text-subtle)]">
                up {uptimeSec}s
              </span>
            </div>

            <div className="grid grid-cols-7 gap-1 text-center text-[10px]">
              {(tr ? ['Pt', 'Sa', 'Ça', 'Pe', 'Cu', 'Ct', 'Pz'] : ['Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa', 'Su']).map((d) => (
                <div key={d} className="text-[var(--anka-text-subtle)] font-medium py-0.5">
                  {d}
                </div>
              ))}
              {miniMonthCells.map((c, idx) => {
                if (!c.day || !c.key) return <div key={`empty-${idx}`} />;
                const isToday = c.key === todayKey;
                const hasEvent = calendarEvents.some((ev) => ev.date === c.key);
                return (
                  <div
                    key={c.key}
                    className={`py-1 rounded-md font-mono tabular-nums relative ${
                      isToday
                        ? 'bg-[var(--anka-accent)] text-[var(--anka-accent-fg)] font-bold'
                        : 'text-[var(--anka-text)]'
                    }`}
                  >
                    {c.day}
                    {hasEvent && !isToday && (
                      <span className="absolute bottom-0.5 left-1/2 -translate-x-1/2 w-1 h-1 rounded-full bg-[var(--anka-accent)]" />
                    )}
                  </div>
                );
              })}
            </div>

            <div className="h-px bg-[var(--anka-border)]" />

            <div className="space-y-1.5">
              <div className="flex items-center justify-between text-[11px]">
                <span className="font-semibold flex items-center gap-1.5">
                  <CalendarIcon size={12} className="text-[var(--anka-accent)]" />
                  <span>{tr ? 'Bugünkü Etkinlikler' : "Today's Agenda"}</span>
                </span>
                <button
                  onClick={() => {
                    launchApp(installedPackages.includes('pkg-calendar') ? 'pkg-calendar' : 'pkg');
                    setCalOpen(false);
                  }}
                  className="text-[var(--anka-accent)] hover:underline"
                >
                  {installedPackages.includes('pkg-calendar')
                    ? tr
                      ? 'Takvimi Aç'
                      : 'Open Calendar'
                    : tr
                      ? 'Takvimi Kur'
                      : 'Get Calendar'}
                </button>
              </div>
              {todayEvents.length === 0 ? (
                <div className="text-[11px] text-[var(--anka-text-subtle)] py-1">
                  {tr ? 'Bugün için planlanmış etkinlik yok.' : 'No events scheduled today.'}
                </div>
              ) : (
                <div className="space-y-1 max-h-24 overflow-y-auto os-scroll">
                  {todayEvents.map((ev) => (
                    <div
                      key={ev.id}
                      className="flex items-center gap-2 px-2 py-1 rounded-md bg-[var(--anka-surface-muted)] text-[11px]"
                    >
                      <span className="font-mono text-[var(--anka-accent)] tabular-nums shrink-0">
                        {ev.time}
                      </span>
                      <span className={`truncate ${ev.done ? 'line-through opacity-50' : ''}`}>
                        {ev.title}
                      </span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </header>
  );
};
