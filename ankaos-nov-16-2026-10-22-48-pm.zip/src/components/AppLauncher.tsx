import React, { useMemo, useState } from 'react';
import {
  Calculator,
  Camera,
  FileText,
  Folder,
  Globe,
  HardDrive,
  Lock,
  Moon,
  Search,
  Sun,
  Terminal,
  Zap,
} from 'lucide-react';
import { APP_LIST } from '../os/apps';
import { t } from '../os/i18n';
import { useOS } from '../os/kernel';
import { PackageAppId } from '../os/types';
import { searchVFS } from '../os/vfs';
import { AppIcon } from './AppIcon';

function tryCalc(raw: string): string | null {
  const cleaned = raw.trim().replace(/^=\s*/, '');
  if (!cleaned || !/^[0-9+\-*/().%\s^]+$/.test(cleaned) || !/[+\-*/%^]/.test(cleaned)) {
    return null;
  }
  try {
    const val = Function(`"use strict"; return (${cleaned.replace(/\^/g, '**')})`)();
    return typeof val === 'number' && Number.isFinite(val) ? String(val) : null;
  } catch {
    return null;
  }
}

function isLikelyUrl(raw: string): boolean {
  const trimmed = raw.trim();
  if (!trimmed || /\s/.test(trimmed)) return false;
  if (/^https?:\/\//i.test(trimmed)) return true;
  return /^[a-z0-9-]+(\.[a-z0-9-]+)+(\/.*)?$/i.test(trimmed) && !/^\d+(\.\d+)+$/.test(trimmed);
}

export const AppLauncher: React.FC = () => {
  const {
    launcherOpen,
    setLauncherOpen,
    launchApp,
    openFileWithDefaultApp,
    installedPackages,
    vfs,
    settings,
    toggleTheme,
    setBootPhase,
    captureDesktopScreenshot,
    runDiskCheck,
    pushNotification,
  } = useOS();
  const [query, setQuery] = useState('');

  const lang = settings.language;
  const tr = lang === 'tr';

  const quickActions = useMemo(
    () => [
      {
        id: 'act-theme',
        title:
          settings.theme === 'dark'
            ? tr
              ? 'Aydınlık Temaya Geç'
              : 'Switch to Light Theme'
            : tr
              ? 'Karanlık Temaya Geç'
              : 'Switch to Dark Theme',
        keywords: 'tema theme dark light karanlık aydınlık',
        icon: settings.theme === 'dark' ? Sun : Moon,
        run: () => toggleTheme(),
      },
      {
        id: 'act-shot',
        title: tr ? 'Ekran Görüntüsü Al (~/Resimler)' : 'Take Desktop Screenshot',
        keywords: 'ekran görüntüsü screenshot camera resim png',
        icon: Camera,
        run: () => void captureDesktopScreenshot(),
      },
      {
        id: 'act-fsck',
        title: tr ? 'VFS Bütünlük Denetimi Çalıştır (fsck)' : 'Run Filesystem Check (fsck)',
        keywords: 'fsck disk onar repair vfs kontrol',
        icon: HardDrive,
        run: () => {
          const rep = runDiskCheck(true);
          pushNotification(
            tr ? 'VFS Denetimi Tamamlandı' : 'VFS Check Complete',
            tr
              ? `${rep.checkedNodes} düğüm incelendi, ${rep.repairedCount} onarım yapıldı.`
              : `${rep.checkedNodes} nodes checked, ${rep.repairedCount} repaired.`,
            'monitor'
          );
        },
      },
      {
        id: 'act-lock',
        title: tr ? 'Ekranı Kilitle (Alt+L)' : 'Lock Screen (Alt+L)',
        keywords: 'kilitle lock oturum çıkış',
        icon: Lock,
        run: () => setBootPhase('locked'),
      },
    ],
    [settings.theme, tr, toggleTheme, captureDesktopScreenshot, runDiskCheck, pushNotification, setBootPhase]
  );

  const availableApps = useMemo(
    () =>
      APP_LIST.filter(
        (a) => !a.isPackage || installedPackages.includes(a.id as PackageAppId)
      ),
    [installedPackages]
  );

  const matchingApps = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q || q.startsWith('>')) return q.startsWith('>') ? [] : availableApps;
    return availableApps.filter(
      (a) =>
        a.nameTr.toLowerCase().includes(q) ||
        a.nameEn.toLowerCase().includes(q) ||
        a.descriptionTr.toLowerCase().includes(q)
    );
  }, [query, availableApps]);

  const matchingActions = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q || q.startsWith('>')) return [];
    return quickActions.filter(
      (a) => a.title.toLowerCase().includes(q) || a.keywords.includes(q)
    );
  }, [query, quickActions]);

  const matchingFiles = useMemo(() => {
    const q = query.trim();
    if (!q || q.startsWith('>')) return [];
    return searchVFS(vfs, q).slice(0, 6);
  }, [vfs, query]);

  const calcResult = useMemo(() => tryCalc(query), [query]);

  if (!launcherOpen) return null;

  const trimmedQuery = query.trim();
  const isShellCmd = trimmedQuery.startsWith('>');
  const shellCmdText = isShellCmd ? trimmedQuery.slice(1).trim() : '';
  const directUrl = !isShellCmd && isLikelyUrl(trimmedQuery);

  const closeAndClear = () => {
    setLauncherOpen(false);
    setQuery('');
  };

  return (
    <div
      onClick={() => setLauncherOpen(false)}
      className="fixed inset-0 z-50 bg-slate-950/45 backdrop-blur-sm flex items-start justify-center pt-20 px-4"
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="w-full max-w-2xl rounded-2xl border border-[var(--anka-border)] bg-[var(--anka-surface)]/95 backdrop-blur-2xl shadow-2xl overflow-hidden text-[var(--anka-text)]"
      >
        <div className="flex items-center gap-3 px-4 py-3.5 border-b border-[var(--anka-border)]">
          <Search size={18} className="text-[var(--anka-text-subtle)] shrink-0" />
          <input
            autoFocus
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter' && trimmedQuery) {
                if (isShellCmd && shellCmdText) {
                  launchApp('terminal', { cmd: shellCmdText });
                  closeAndClear();
                  return;
                }
                if (directUrl) {
                  launchApp('browser', { url: trimmedQuery });
                  closeAndClear();
                  return;
                }
                if (matchingApps.length > 0 && matchingFiles.length === 0) {
                  launchApp(matchingApps[0].id);
                  closeAndClear();
                  return;
                }
                if (matchingApps.length === 0 && matchingActions.length > 0) {
                  matchingActions[0].run();
                  closeAndClear();
                  return;
                }
                if (matchingApps.length === 0 && matchingFiles.length === 0) {
                  launchApp('browser', { query: trimmedQuery });
                  closeAndClear();
                }
              }
            }}
            placeholder={
              tr
                ? "Uygulama, dosya, > komut, URL, hesaplama (=2+2) veya web'de ara..."
                : t(lang, 'searchPlaceholder')
            }
            className="flex-1 bg-transparent outline-none text-sm text-[var(--anka-text)] placeholder:text-[var(--anka-text-subtle)]"
          />
          <span className="text-[11px] font-mono text-[var(--anka-text-subtle)]">ESC</span>
        </div>

        <div className="p-4 max-h-[60vh] overflow-y-auto os-scroll space-y-5">
          {calcResult !== null && (
            <div className="flex items-center justify-between px-3.5 py-2.5 rounded-xl bg-[var(--anka-surface-muted)] border border-[var(--anka-border)]">
              <div className="flex items-center gap-2 text-xs text-[var(--anka-text-subtle)]">
                <Calculator size={15} className="text-[var(--anka-accent)]" />
                <span className="font-mono">{trimmedQuery.replace(/^=\s*/, '')}</span>
              </div>
              <span className="text-base font-mono font-bold tabular-nums text-[var(--anka-accent)]">
                = {calcResult}
              </span>
            </div>
          )}

          {isShellCmd && (
            <button
              onClick={() => {
                launchApp('terminal', shellCmdText ? { cmd: shellCmdText } : undefined);
                closeAndClear();
              }}
              className="w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl bg-emerald-500/15 border border-emerald-500/30 hover:bg-emerald-500/20 text-left transition-colors"
            >
              <div className="flex items-center gap-2.5 min-w-0">
                <Terminal size={16} className="text-emerald-500 shrink-0" />
                <span className="text-xs font-mono font-semibold truncate">
                  {shellCmdText
                    ? `ankash $ ${shellCmdText}`
                    : tr
                      ? 'Uçbirimde komut çalıştırmak için yazın (ör. > neofetch)'
                      : 'Type a command to run in Terminal (e.g. > neofetch)'}
                </span>
              </div>
              <span className="text-[11px] font-mono text-emerald-500 shrink-0">Enter ↵</span>
            </button>
          )}

          {directUrl && (
            <button
              onClick={() => {
                launchApp('browser', { url: trimmedQuery });
                closeAndClear();
              }}
              className="w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl bg-sky-500/15 border border-sky-500/30 hover:bg-sky-500/20 text-left transition-colors"
            >
              <div className="flex items-center gap-2.5 min-w-0">
                <Globe size={16} className="text-sky-500 shrink-0" />
                <span className="text-xs font-semibold truncate">
                  {tr ? `Web sitesini aç: ${trimmedQuery}` : `Open URL: ${trimmedQuery}`}
                </span>
              </div>
              <span className="text-[11px] font-mono text-sky-500 shrink-0">AnkaTarayıcı</span>
            </button>
          )}

          {trimmedQuery && !isShellCmd && (
            <button
              onClick={() => {
                launchApp('browser', { query: trimmedQuery });
                closeAndClear();
              }}
              className="w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl bg-[var(--anka-accent-soft)] hover:bg-[var(--anka-surface-elevated)] text-left transition-colors"
            >
              <div className="flex items-center gap-2.5 min-w-0">
                <Globe size={16} className="text-[var(--anka-accent)] shrink-0" />
                <span className="text-xs font-semibold truncate">
                  {tr ? `AnkaArama ile web'de ara: "${trimmedQuery}"` : `Search web with AnkaArama: "${trimmedQuery}"`}
                </span>
              </div>
              <span className="text-[11px] font-mono text-[var(--anka-accent)] shrink-0">AnkaTarayıcı</span>
            </button>
          )}

          {matchingActions.length > 0 && (
            <div>
              <div className="text-xs font-medium text-[var(--anka-text-subtle)] mb-2 flex items-center gap-1.5">
                <Zap size={12} className="text-amber-500" />
                <span>{tr ? 'Hızlı Sistem Eylemleri' : 'Quick System Actions'}</span>
              </div>
              <div className="space-y-1">
                {matchingActions.map((act) => {
                  const Icon = act.icon;
                  return (
                    <button
                      key={act.id}
                      onClick={() => {
                        act.run();
                        closeAndClear();
                      }}
                      className="w-full flex items-center gap-3 px-3 py-2 rounded-lg hover:bg-[var(--anka-surface-elevated)] text-left transition-colors text-xs font-medium"
                    >
                      <Icon size={15} className="text-[var(--anka-accent)] shrink-0" />
                      <span>{act.title}</span>
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {!isShellCmd && (
            <div>
              <div className="text-xs font-medium text-[var(--anka-text-subtle)] mb-3">
                {t(lang, 'applications')}
              </div>
              {matchingApps.length === 0 ? (
                <div className="text-xs text-[var(--anka-text-subtle)] py-3">{t(lang, 'noResults')}</div>
              ) : (
                <div className="grid grid-cols-3 sm:grid-cols-4 gap-2.5">
                  {matchingApps.map((app) => (
                    <button
                      key={app.id}
                      onClick={() => {
                        launchApp(app.id);
                        closeAndClear();
                      }}
                      className="flex flex-col items-center p-3 rounded-xl hover:bg-[var(--anka-surface-elevated)] transition-colors text-center"
                    >
                      <AppIcon appId={app.id} size={22} />
                      <span className="mt-2 text-xs font-medium truncate w-full">
                        {tr ? app.nameTr : app.nameEn}
                      </span>
                    </button>
                  ))}
                </div>
              )}
            </div>
          )}

          {matchingFiles.length > 0 && (
            <div>
              <div className="text-xs font-medium text-[var(--anka-text-subtle)] mb-2">
                {t(lang, 'files')}
              </div>
              <div className="space-y-1">
                {matchingFiles.map((item) => (
                  <button
                    key={item.path}
                    onClick={() => {
                      openFileWithDefaultApp(item.path);
                      closeAndClear();
                    }}
                    className="w-full flex items-center gap-3 px-3 py-2 rounded-lg hover:bg-[var(--anka-surface-elevated)] text-left transition-colors"
                  >
                    {item.node.type === 'dir' ? (
                      <Folder size={15} className="text-[var(--anka-accent)] shrink-0" />
                    ) : (
                      <FileText size={15} className="text-[var(--anka-text-subtle)] shrink-0" />
                    )}
                    <div className="min-w-0 flex-1">
                      <div className="text-xs font-medium truncate">{item.node.name}</div>
                      <div className="text-[11px] font-mono text-[var(--anka-text-subtle)] truncate">
                        {item.path}
                      </div>
                    </div>
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
