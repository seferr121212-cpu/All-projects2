import React from 'react';
import { Bell, X } from 'lucide-react';
import { useOS } from '../os/kernel';

export const ToastHost: React.FC = () => {
  const { activeToasts, dismissToast, launchApp, settings } = useOS();

  if (settings.doNotDisturb || activeToasts.length === 0) {
    return null;
  }

  return (
    <div className="fixed top-11 right-3 z-50 flex flex-col gap-2 w-80 max-w-[calc(100vw-24px)] pointer-events-none">
      {activeToasts.map((toast) => (
        <div
          key={toast.id}
          onClick={() => {
            if (toast.appId) launchApp(toast.appId);
            dismissToast(toast.id);
          }}
          className="pointer-events-auto rounded-xl border border-[var(--anka-border-strong)] bg-[var(--anka-glass)] backdrop-blur-xl shadow-2xl p-3 flex items-start gap-2.5 text-[var(--anka-text)] cursor-pointer hover:border-[var(--anka-accent)] transition-colors"
        >
          <div className="w-7 h-7 rounded-lg bg-[var(--anka-accent-soft)] text-[var(--anka-accent)] flex items-center justify-center shrink-0 mt-0.5">
            <Bell size={14} />
          </div>
          <div className="min-w-0 flex-1">
            <div className="text-xs font-semibold truncate">{toast.title}</div>
            <div className="text-[11px] text-[var(--anka-text-muted)] line-clamp-2 break-words mt-0.5">
              {toast.body}
            </div>
          </div>
          <button
            onClick={(e) => {
              e.stopPropagation();
              dismissToast(toast.id);
            }}
            aria-label="Kapat"
            className="p-1 rounded-md text-[var(--anka-text-subtle)] hover:text-[var(--anka-text)] hover:bg-[var(--anka-surface-elevated)] shrink-0"
          >
            <X size={12} />
          </button>
        </div>
      ))}
    </div>
  );
};
