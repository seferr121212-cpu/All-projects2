import React, { useCallback, useEffect, useRef, useState } from 'react';
import { ArrowRight, Terminal, Volume2, VolumeX } from 'lucide-react';
import { playBootChime } from '../os/bootAudio';
import { t } from '../os/i18n';
import { useOS } from '../os/kernel';
import { AnkaLogo } from './AnkaLogo';

const BOOT_STEPS = [
  {
    stageTr: 'AnkaKernel 6.1.0 Çekirdeği Yükleniyor',
    stageEn: 'Loading AnkaKernel 6.1.0',
    log: '[0.000] AnkaKernel 6.1.0-ankaos (x86_64/wasm) önyükleniyor...',
  },
  {
    stageTr: 'MMU Copy-on-Write & LRU Swap (4096 MiB)',
    stageEn: 'Initializing MMU CoW & LRU Swap (4096 MiB)',
    log: '[0.084] MMU: 128 sayfa çerçevesi + 64 swap yuvası (4096 MiB) hazır',
  },
  {
    stageTr: 'AnkaVFS & Ring 0/3 Sandbox Bağlanıyor',
    stageEn: 'Mounting AnkaVFS & Ring 0/3 Sandbox',
    log: '[0.215] VFS: Sanal dosya sistemi / ve POSIX sandbox doğrulandı',
  },
  {
    stageTr: 'Preemptive Priority Zamanlayıcı',
    stageEn: 'Starting Preemptive Priority Scheduler',
    log: '[0.340] sched: Öncelik tabanlı kesintili zamanlayıcı başlatıldı',
  },
  {
    stageTr: 'Double-Buffered Kompozitör (60 Hz)',
    stageEn: 'Starting Double-Buffered Compositor',
    log: '[0.490] ankawm: 4-köşe yerleşimli kompozitör hazır',
  },
  {
    stageTr: 'AnkaNet Köprüsü & AnkaArama Motoru',
    stageEn: 'Connecting AnkaNet Bridge & AnkaArama',
    log: '[0.620] netd: Express ağ köprüsü ve SSRF güvenlik filtresi etkin',
  },
  {
    stageTr: 'Oturum Yöneticisi Hazır',
    stageEn: 'Display Manager Ready',
    log: '[0.780] login: Çoklu kullanıcı oturum ekranına geçiliyor...',
  },
];

export const BootScreen: React.FC = () => {
  const { bootPhase, setBootPhase, settings, updateSettings, rebootSystem } = useOS();
  const [stepIdx, setStepIdx] = useState(1);
  const [showKernelLog, setShowKernelLog] = useState(false);
  const [isExiting, setIsExiting] = useState(false);
  const chimePlayedRef = useRef(false);
  const finishStartedRef = useRef(false);
  const lang = settings.language;
  const tr = lang === 'tr';

  const triggerChimeOnce = useCallback(() => {
    if (!chimePlayedRef.current) {
      playBootChime(settings.volume, settings.muted);
      chimePlayedRef.current = true;
    }
  }, [settings.muted, settings.volume]);

  const finishBoot = useCallback(() => {
    if (finishStartedRef.current) return;
    finishStartedRef.current = true;
    setIsExiting(true);
    window.setTimeout(() => {
      setBootPhase('locked');
    }, 260);
  }, [setBootPhase]);

  useEffect(() => {
    if (bootPhase !== 'booting') return;
    setStepIdx(1);
    setIsExiting(false);
    chimePlayedRef.current = false;
    finishStartedRef.current = false;

    const interval = window.setInterval(() => {
      setStepIdx((prev) => {
        if (prev >= BOOT_STEPS.length) {
          window.clearInterval(interval);
          return prev;
        }
        return prev + 1;
      });
    }, 290);

    return () => window.clearInterval(interval);
  }, [bootPhase]);

  useEffect(() => {
    if (bootPhase !== 'booting' || stepIdx < BOOT_STEPS.length) return;
    const timer = window.setTimeout(() => {
      finishBoot();
    }, 420);
    return () => window.clearTimeout(timer);
  }, [bootPhase, stepIdx, finishBoot]);

  useEffect(() => {
    if (bootPhase !== 'booting') return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'F2') {
        e.preventDefault();
        setShowKernelLog((v) => !v);
      } else if (e.key === 'Enter' || e.key === ' ') {
        e.preventDefault();
        triggerChimeOnce();
        finishBoot();
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [bootPhase, triggerChimeOnce, finishBoot]);

  if (bootPhase === 'shutdown') {
    return (
      <div className="fixed inset-0 bg-[#040813] text-slate-100 flex flex-col items-center justify-center p-6 text-center space-y-6">
        <div className="relative flex items-center justify-center">
          <div className="w-24 h-24 rounded-3xl border border-slate-800 bg-slate-900/90 flex items-center justify-center shadow-2xl">
            <AnkaLogo size={54} monochrome className="text-slate-400" />
          </div>
        </div>
        <div className="space-y-2 max-w-sm">
          <h1 className="text-xl font-semibold font-display">{t(lang, 'powerOffTitle')}</h1>
          <p className="text-sm text-slate-400">{t(lang, 'powerOffSubtitle')}</p>
        </div>
        <button
          type="button"
          onClick={() => {
            playBootChime(settings.volume, settings.muted);
            rebootSystem();
          }}
          className="px-6 py-2.5 rounded-xl text-sm font-medium bg-[var(--anka-accent)] text-[var(--anka-accent-fg)] hover:bg-[var(--anka-accent-hover)] transition-colors whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[var(--anka-accent)]"
        >
          {t(lang, 'powerOnBtn')}
        </button>
      </div>
    );
  }

  const activeStep = BOOT_STEPS[Math.min(BOOT_STEPS.length - 1, Math.max(0, stepIdx - 1))];
  const progressRatio = Math.min(1, Math.max(0.08, stepIdx / BOOT_STEPS.length));
  const progressPct = Math.round((stepIdx / BOOT_STEPS.length) * 100);

  return (
    <div
      onClick={triggerChimeOnce}
      className={`fixed inset-0 bg-[#040813] text-slate-100 flex flex-col justify-between p-6 sm:p-8 select-none overflow-hidden transition-all duration-300 ease-[cubic-bezier(0.16,1,0.3,1)] ${
        isExiting ? 'opacity-0 scale-[1.015]' : 'opacity-100 scale-100'
      }`}
    >
      {/* Subtle Ambient Horizon Gradient */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute inset-0"
        style={{
          background:
            'radial-gradient(ellipse 68% 48% at 50% 46%, var(--anka-accent-soft) 0%, rgba(4, 8, 19, 0) 72%)',
        }}
      />

      {/* Top Action Bar */}
      <div className="relative z-10 flex items-center justify-between gap-4">
        <div className="flex items-center gap-2.5 text-xs text-slate-400 whitespace-nowrap shrink-0">
          <AnkaLogo size={20} />
          <span className="font-display font-semibold text-slate-200">AnkaOS</span>
          <span aria-hidden="true">·</span>
          <span className="font-mono tabular-nums">3.5 Kuzgun</span>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              const nextMuted = !settings.muted;
              updateSettings({ muted: nextMuted });
              if (!nextMuted) playBootChime(settings.volume, false);
            }}
            aria-label={settings.muted ? (tr ? 'Açılış Sesini Aç' : 'Unmute Intro') : tr ? 'Sessize Al' : 'Mute'}
            title={settings.muted ? (tr ? 'Açılış Sesini Aç' : 'Unmute Intro') : tr ? 'Sessize Al' : 'Mute'}
            className="p-2 rounded-lg border border-slate-800 bg-slate-900/75 text-slate-400 hover:text-white hover:border-slate-700 transition-colors focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[var(--anka-accent)]"
          >
            {settings.muted ? <VolumeX size={14} /> : <Volume2 size={14} />}
          </button>
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              setShowKernelLog((v) => !v);
            }}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium border transition-colors whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[var(--anka-accent)] ${
              showKernelLog
                ? 'border-[var(--anka-accent)] bg-slate-900 text-white'
                : 'border-slate-800 bg-slate-900/75 text-slate-400 hover:text-white hover:border-slate-700'
            }`}
          >
            <Terminal size={13} />
            <span>{tr ? 'Çekirdek Günlüğü' : 'Boot Log'}</span>
          </button>
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              triggerChimeOnce();
              finishBoot();
            }}
            className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg text-xs font-medium bg-slate-900 border border-slate-700 text-slate-200 hover:bg-slate-800 transition-colors whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[var(--anka-accent)]"
          >
            <span>{t(lang, 'bootSkip')}</span>
            <ArrowRight size={13} />
          </button>
        </div>
      </div>

      {/* Centerpiece Logo Intro Stage */}
      <div className="relative z-10 flex flex-col items-center justify-center my-auto space-y-7">
        <div className="relative flex items-center justify-center">
          {/* Breathing Ambient Halo */}
          <div
            aria-hidden="true"
            className="anka-halo-breathe absolute w-48 h-48 rounded-full"
            style={{
              background:
                'radial-gradient(circle, var(--anka-accent-soft) 0%, rgba(4, 8, 19, 0) 70%)',
            }}
          />

          {/* Precision Rotating Outer Arc */}
          <svg
            aria-hidden="true"
            viewBox="0 0 180 180"
            className="anka-ring-spin absolute w-44 h-44 pointer-events-none"
          >
            <circle
              cx="90"
              cy="90"
              r="82"
              fill="none"
              stroke="rgba(148, 163, 184, 0.14)"
              strokeWidth="1"
              strokeDasharray="6 8"
            />
            <circle
              cx="90"
              cy="90"
              r="82"
              fill="none"
              stroke="var(--anka-accent)"
              strokeWidth="1.75"
              strokeLinecap="round"
              strokeDasharray="76 440"
              opacity="0.82"
            />
          </svg>

          {/* Settling Inner Ring */}
          <div
            aria-hidden="true"
            className="anka-orbit-settle absolute w-36 h-36 rounded-full border border-[var(--anka-accent)]/30"
          />

          {/* Framed Phoenix Crest */}
          <div className="relative w-28 h-28 rounded-3xl border border-slate-800/90 bg-slate-950/90 shadow-2xl flex items-center justify-center">
            <AnkaLogo size={78} animated />
          </div>
        </div>

        {/* Wordmark & Active Stage Indicator */}
        <div className="anka-fade-up text-center space-y-2" style={{ animationDelay: '140ms' }}>
          <h1 className="text-3xl sm:text-4xl font-display font-bold tracking-tight text-white">
            AnkaOS
          </h1>
          <p
            key={stepIdx}
            className="anka-stage-enter text-xs sm:text-sm text-slate-400 min-h-[1.25rem]"
          >
            {tr ? activeStep.stageTr : activeStep.stageEn}
          </p>
        </div>

        {/* GPU-Composited Progress Bar with Moving Sheen */}
        <div className="anka-fade-up w-full max-w-sm space-y-2.5" style={{ animationDelay: '220ms' }}>
          <div
            role="progressbar"
            aria-label={tr ? 'AnkaOS önyükleme ilerlemesi' : 'AnkaOS boot progress'}
            aria-valuemin={0}
            aria-valuemax={100}
            aria-valuenow={progressPct}
            className="relative h-1.5 w-full bg-slate-900/90 rounded-full overflow-hidden border border-slate-800/80"
          >
            <div
              className="relative h-full w-full origin-left rounded-full overflow-hidden transition-transform duration-300 ease-[cubic-bezier(0.16,1,0.3,1)]"
              style={{
                transform: `scaleX(${progressRatio})`,
                backgroundColor: 'var(--anka-accent)',
              }}
            >
              <div
                aria-hidden="true"
                className="anka-bar-sheen absolute inset-y-0 left-0 w-1/3"
                style={{
                  background:
                    'linear-gradient(90deg, rgba(255,255,255,0) 0%, rgba(255,255,255,0.48) 50%, rgba(255,255,255,0) 100%)',
                }}
              />
            </div>
          </div>

          <div className="flex items-center justify-between text-[11px] font-mono tabular-nums text-slate-500">
            <span>AnkaKernel 6.1.0</span>
            <div className="flex items-center gap-3">
              <span>
                {stepIdx}/{BOOT_STEPS.length}
              </span>
              <span className="text-slate-300 font-medium">{progressPct}%</span>
            </div>
          </div>
        </div>

        {/* Expandable Kernel Boot Console */}
        {showKernelLog && (
          <div className="anka-stage-enter w-full max-w-2xl rounded-xl border border-slate-800 bg-slate-950/95 p-4 font-mono text-xs space-y-1.5 shadow-2xl max-h-48 overflow-y-auto os-scroll">
            {BOOT_STEPS.slice(0, stepIdx).map((step, i) => (
              <div key={i} className="text-slate-300 flex items-start gap-2">
                <span className="text-emerald-400 shrink-0">[OK]</span>
                <span>{step.log}</span>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Quiet Footer */}
      <div className="relative z-10 flex items-center justify-center text-[11px] text-slate-500">
        <span>
          {tr
            ? 'Geçmek için Enter · Günlük için F2 · AnkaOS 3.5 (Kuzgun)'
            : 'Press Enter to skip · F2 for log · AnkaOS 3.5 (Kuzgun)'}
        </span>
      </div>
    </div>
  );
};

