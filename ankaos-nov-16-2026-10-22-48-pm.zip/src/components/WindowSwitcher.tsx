import React from 'react';
import { useOS } from '../os/kernel';
import { AppIcon } from './AppIcon';

export const WindowSwitcher: React.FC = () => {
  const {
    switcherOpen,
    setSwitcherOpen,
    windows,
    activeWindowId,
    setActiveWorkspace,
    focusWindow,
    settings,
  } = useOS();
  const tr = settings.language === 'tr';

  if (!switcherOpen) return null;

  return (
    <div
      onClick={() => setSwitcherOpen(false)}
      className="fixed inset-0 z-50 bg-slate-950/45 backdrop-blur-sm flex items-center justify-center px-4"
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="w-full max-w-xl rounded-2xl border border-[var(--anka-border)] bg-[var(--anka-surface)]/95 backdrop-blur-2xl shadow-2xl p-4 text-[var(--anka-text)] space-y-3"
      >
        <div className="flex items-center justify-between text-xs text-[var(--anka-text-subtle)]">
          <span className="font-semibold text-[var(--anka-text)]">
            {tr ? 'Açık Pencereler' : 'Open Windows'}
          </span>
          <span className="font-mono">Alt+Tab · ESC</span>
        </div>

        {windows.length === 0 ? (
          <div className="py-8 text-center text-xs text-[var(--anka-text-subtle)]">
            {tr ? 'Şu anda açık pencere yok.' : 'No open windows.'}
          </div>
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
            {windows.map((win) => {
              const active = win.id === activeWindowId;
              return (
                <button
                  key={win.id}
                  onClick={() => {
                    setActiveWorkspace(win.workspace);
                    focusWindow(win.id);
                    setSwitcherOpen(false);
                  }}
                  style={
                    active
                      ? {
                          borderColor: 'var(--anka-accent)',
                          backgroundColor: 'var(--anka-accent-soft)',
                        }
                      : undefined
                  }
                  className={`flex items-center gap-3 p-3 rounded-xl border text-left transition-colors ${
                    active
                      ? ''
                      : 'border-[var(--anka-border)] hover:bg-[var(--anka-surface-elevated)]'
                  }`}
                >
                  <AppIcon appId={win.appId} size={18} />
                  <div className="min-w-0 flex-1">
                    <div className="text-xs font-semibold truncate">{win.title}</div>
                    <div className="text-[11px] font-mono text-[var(--anka-text-subtle)] tabular-nums">
                      WS{win.workspace} · PID {win.pid}
                    </div>
                  </div>
                </button>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
