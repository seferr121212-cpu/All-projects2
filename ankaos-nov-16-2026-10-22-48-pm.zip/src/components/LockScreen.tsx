import React, { useEffect, useState } from 'react';
import { ArrowRight, User } from 'lucide-react';
import { playUnlockChime } from '../os/bootAudio';
import { t, WALLPAPERS } from '../os/i18n';
import { useOS } from '../os/kernel';
import { AnkaLogo } from './AnkaLogo';

export const LockScreen: React.FC = () => {
  const { setBootPhase, settings, users, currentUser, switchUser } = useOS();
  const [selectedUsername, setSelectedUsername] = useState(currentUser.username);
  const [now, setNow] = useState(new Date());
  const [password, setPassword] = useState('');
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  useEffect(() => {
    const id = window.setInterval(() => setNow(new Date()), 1000);
    return () => window.clearInterval(id);
  }, []);

  const wallpaper =
    WALLPAPERS.find((w) => w.id === settings.wallpaperId) || WALLPAPERS[0];
  const lang = settings.language;
  const activeAccount = users.find((u) => u.username === selectedUsername) || currentUser;
  const hasPassword = activeAccount.passwordHash !== null;

  const unlock = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    const res = await switchUser(activeAccount.username, password);
    if (!res.ok) {
      setErrorMsg(t(lang, 'wrongPassword'));
      setPassword('');
      return;
    }
    setErrorMsg(null);
    playUnlockChime(settings.volume, settings.muted);
    setBootPhase('desktop');
  };

  const timeStr = now.toLocaleTimeString(lang === 'tr' ? 'tr-TR' : 'en-US', {
    hour: '2-digit',
    minute: '2-digit',
  });
  const dateStr = now.toLocaleDateString(lang === 'tr' ? 'tr-TR' : 'en-US', {
    weekday: 'long',
    day: 'numeric',
    month: 'long',
  });

  return (
    <div className="fixed inset-0 flex flex-col items-center justify-between py-16 px-6 text-white overflow-hidden">
      <img
        src={wallpaper.url}
        alt="Wallpaper"
        referrerPolicy="no-referrer"
        className="absolute inset-0 w-full h-full object-cover scale-105 blur-md"
      />
      <div className="absolute inset-0 bg-slate-950/55" />

      <div className="relative z-10 text-center space-y-1 mt-4">
        <div className="text-6xl sm:text-7xl font-semibold font-display tracking-tight tabular-nums">
          {timeStr}
        </div>
        <div className="text-base text-slate-200/90 capitalize">{dateStr}</div>
      </div>

      <form
        onSubmit={unlock}
        className="relative z-10 flex flex-col items-center space-y-4 w-full max-w-xs"
      >
        <div className="w-16 h-16 rounded-full bg-white/15 backdrop-blur-md border border-white/25 flex items-center justify-center">
          <User size={28} className="text-white" />
        </div>

        {/* Multi-user account selector */}
        <div className="flex items-center gap-1.5 flex-wrap justify-center">
          {users.map((u) => (
            <button
              key={u.username}
              type="button"
              onClick={() => {
                setSelectedUsername(u.username);
                setPassword('');
                setErrorMsg(null);
              }}
              className={`px-3 py-1 rounded-lg text-xs font-medium transition-colors ${
                selectedUsername === u.username
                  ? 'bg-[var(--anka-accent)] text-[var(--anka-accent-fg)]'
                  : 'bg-white/15 text-slate-200 hover:bg-white/25'
              }`}
            >
              {u.username}
            </button>
          ))}
        </div>

        <div className="text-base font-semibold font-display">{activeAccount.fullName}</div>

        <div className="w-full flex items-center gap-2">
          <input
            type="password"
            value={password}
            onChange={(e) => {
              setPassword(e.target.value);
              if (errorMsg) setErrorMsg(null);
            }}
            placeholder={
              hasPassword
                ? t(lang, 'passwordPlaceholder')
                : lang === 'tr'
                  ? 'Parola ayarlanmadı (Enter)'
                  : 'No password set (Enter)'
            }
            autoFocus
            className="flex-1 px-3.5 py-2.5 rounded-xl bg-white/15 backdrop-blur-md border border-white/25 text-sm text-white placeholder:text-slate-300/80 outline-none focus:border-[var(--anka-accent)]"
          />
          <button
            type="submit"
            aria-label={t(lang, 'unlockBtn')}
            className="p-2.5 rounded-xl bg-[var(--anka-accent)] hover:bg-[var(--anka-accent-hover)] text-[var(--anka-accent-fg)] transition-colors shrink-0"
          >
            <ArrowRight size={18} />
          </button>
        </div>

        {errorMsg ? (
          <div className="text-xs text-rose-300 font-medium">{errorMsg}</div>
        ) : (
          <button
            type="submit"
            className="text-xs text-slate-200/80 hover:text-white transition-colors text-center"
          >
            {hasPassword ? t(lang, 'unlockHint') : t(lang, 'noPasswordHint')}
          </button>
        )}
      </form>

      <div className="relative z-10 flex items-center gap-2 text-xs text-slate-200/80">
        <AnkaLogo size={18} />
        <span>AnkaOS 3.5 (Kuzgun)</span>
      </div>
    </div>
  );
};
