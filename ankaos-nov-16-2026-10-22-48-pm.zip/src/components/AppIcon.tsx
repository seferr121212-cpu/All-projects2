import React from 'react';
import {
  Activity,
  Binary,
  Bomb,
  BookOpen,
  Calculator,
  Calendar,
  Cpu,
  FileCode2,
  FolderOpen,
  Gamepad2,
  Gauge,
  GitCompare,
  Globe,
  Grid2x2,
  Image as ImageIcon,
  KanbanSquare,
  Mic,
  Music,
  Network,
  Package,
  Palette,
  Settings,
  StickyNote,
  Terminal,
  Timer,
} from 'lucide-react';
import { AppId } from '../os/types';

interface AppIconProps {
  appId: AppId;
  size?: number;
  withContainer?: boolean;
}

const ICON_COLORS: Record<AppId, string> = {
  terminal: 'bg-slate-800 text-emerald-400 border-slate-700',
  files: 'bg-sky-600 text-white border-sky-500',
  editor: 'bg-indigo-600 text-white border-indigo-500',
  browser: 'bg-blue-600 text-white border-blue-500',
  notes: 'bg-amber-500 text-slate-950 border-amber-400',
  paint: 'bg-rose-600 text-white border-rose-500',
  media: 'bg-teal-600 text-white border-teal-500',
  'wasm-builder': 'bg-amber-600 text-white border-amber-500',
  monitor: 'bg-emerald-600 text-white border-emerald-500',
  pkg: 'bg-violet-600 text-white border-violet-500',
  calculator: 'bg-slate-700 text-sky-300 border-slate-600',
  viewer: 'bg-amber-600 text-white border-amber-500',
  settings: 'bg-slate-600 text-slate-100 border-slate-500',
  'pkg-snake': 'bg-emerald-700 text-emerald-100 border-emerald-500',
  'pkg-hex': 'bg-slate-800 text-amber-300 border-slate-600',
  'pkg-timer': 'bg-sky-700 text-white border-sky-500',
  'pkg-mines': 'bg-rose-700 text-white border-rose-500',
  'pkg-2048': 'bg-amber-600 text-white border-amber-500',
  'pkg-kanban': 'bg-indigo-600 text-white border-indigo-500',
  'pkg-sysbench': 'bg-teal-700 text-white border-teal-500',
  'pkg-calendar': 'bg-rose-600 text-white border-rose-500',
  'pkg-markdown': 'bg-sky-700 text-white border-sky-500',
  'pkg-recorder': 'bg-red-600 text-white border-red-500',
  'pkg-nettools': 'bg-cyan-700 text-white border-cyan-500',
  'pkg-diff': 'bg-violet-700 text-white border-violet-500',
};

export const AppIcon: React.FC<AppIconProps> = ({ appId, size = 20, withContainer = true }) => {
  const Icon = (() => {
    switch (appId) {
      case 'terminal':
        return Terminal;
      case 'files':
        return FolderOpen;
      case 'editor':
        return FileCode2;
      case 'browser':
        return Globe;
      case 'notes':
        return StickyNote;
      case 'paint':
        return Palette;
      case 'media':
        return Music;
      case 'wasm-builder':
        return Cpu;
      case 'monitor':
        return Activity;
      case 'pkg':
        return Package;
      case 'calculator':
        return Calculator;
      case 'viewer':
        return ImageIcon;
      case 'settings':
        return Settings;
      case 'pkg-snake':
        return Gamepad2;
      case 'pkg-hex':
        return Binary;
      case 'pkg-timer':
        return Timer;
      case 'pkg-mines':
        return Bomb;
      case 'pkg-2048':
        return Grid2x2;
      case 'pkg-kanban':
        return KanbanSquare;
      case 'pkg-sysbench':
        return Gauge;
      case 'pkg-calendar':
        return Calendar;
      case 'pkg-markdown':
        return BookOpen;
      case 'pkg-recorder':
        return Mic;
      case 'pkg-nettools':
        return Network;
      case 'pkg-diff':
        return GitCompare;
    }
  })();

  if (!withContainer) {
    return <Icon size={size} />;
  }

  return (
    <div
      className={`flex items-center justify-center rounded-xl border shadow-sm ${ICON_COLORS[appId]}`}
      style={{ width: size * 2, height: size * 2 }}
    >
      <Icon size={size} />
    </div>
  );
};
