import React, { useMemo, useState } from 'react';
import {
  Activity,
  ArrowDownUp,
  FolderOpen,
  Flame,
  Play,
  RotateCcw,
  Save,
  Search,
} from 'lucide-react';
import {
  FlameCategory,
  formatDurationUs,
  WasmFlameNode,
  WasmProfileReport,
} from '../os/wasmProfiler';

interface WasmProfilerViewProps {
  tr: boolean;
  report: WasmProfileReport | null;
  targetLabel: string;
  availableFns: string[];
  selectedFn: string;
  onSelectFn: (fn: string) => void;
  iterations: number;
  onChangeIterations: (iters: number) => void;
  isProfiling: boolean;
  onRunProfile: () => void;
  onLoadLastWasmrun: () => void;
  hasLastWasmrun: boolean;
  onSaveProfile: () => void;
  traceFiles: Array<{ path: string; name: string; size: number }>;
  onSelectTraceFile: (path: string) => void;
}

const CATEGORY_STYLE: Record<
  FlameCategory,
  { bg: string; border: string; labelTr: string; labelEn: string }
> = {
  runtime: {
    bg: 'bg-sky-600/85 dark:bg-sky-600/80 text-white',
    border: 'border-sky-400/50',
    labelTr: 'Çalışma Zamanı',
    labelEn: 'Runtime',
  },
  compile: {
    bg: 'bg-indigo-600/85 dark:bg-indigo-500/80 text-white',
    border: 'border-indigo-400/50',
    labelTr: 'Derleme / Yükleme',
    labelEn: 'Compile / Inst',
  },
  function: {
    bg: 'bg-amber-600/90 dark:bg-amber-500/85 text-white',
    border: 'border-amber-300/60',
    labelTr: 'Fonksiyon',
    labelEn: 'Function',
  },
  loop: {
    bg: 'bg-rose-600/90 dark:bg-rose-500/85 text-white',
    border: 'border-rose-300/60',
    labelTr: 'Döngü Yoğunluğu',
    labelEn: 'Loop Hotspot',
  },
  memory: {
    bg: 'bg-emerald-600/90 dark:bg-emerald-500/85 text-white',
    border: 'border-emerald-300/60',
    labelTr: 'Lineer Bellek',
    labelEn: 'Linear Memory',
  },
  alu: {
    bg: 'bg-cyan-600/85 dark:bg-cyan-500/80 text-white',
    border: 'border-cyan-300/60',
    labelTr: 'ALU / Komut',
    labelEn: 'ALU / Instr',
  },
};

function flattenTree(node: WasmFlameNode): WasmFlameNode[] {
  const out: WasmFlameNode[] = [node];
  for (const child of node.children) {
    out.push(...flattenTree(child));
  }
  return out;
}

function findNodePath(root: WasmFlameNode, targetId: string): WasmFlameNode[] | null {
  if (root.id === targetId) return [root];
  for (const c of root.children) {
    const sub = findNodePath(c, targetId);
    if (sub) return [root, ...sub];
  }
  return null;
}

function collectSubtreeRows(
  zoomNode: WasmFlameNode,
  maxDepthOffset = 6
): Array<{ node: WasmFlameNode; relLeftPct: number; relWidthPct: number; relDepth: number }> {
  const rows: Array<{
    node: WasmFlameNode;
    relLeftPct: number;
    relWidthPct: number;
    relDepth: number;
  }> = [];

  const baseWidth = Math.max(0.001, zoomNode.widthPct);
  const baseStart = zoomNode.startPct;

  const walk = (n: WasmFlameNode, depthOffset: number) => {
    if (depthOffset > maxDepthOffset) return;
    const relLeft = Math.max(0, Math.min(100, ((n.startPct - baseStart) / baseWidth) * 100));
    const relWidth = Math.max(0.6, Math.min(100 - relLeft, (n.widthPct / baseWidth) * 100));
    rows.push({
      node: n,
      relLeftPct: relLeft,
      relWidthPct: relWidth,
      relDepth: depthOffset,
    });
    for (const c of n.children) {
      walk(c, depthOffset + 1);
    }
  };

  walk(zoomNode, 0);
  return rows;
}

export const WasmProfilerView: React.FC<WasmProfilerViewProps> = ({
  tr,
  report,
  targetLabel,
  availableFns,
  selectedFn,
  onSelectFn,
  iterations,
  onChangeIterations,
  isProfiling,
  onRunProfile,
  onLoadLastWasmrun,
  hasLastWasmrun,
  onSaveProfile,
  traceFiles,
  onSelectTraceFile,
}) => {
  const [zoomNodeId, setZoomNodeId] = useState<string>('root');
  const [inspectedId, setInspectedId] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [layoutMode, setLayoutMode] = useState<'flame' | 'icicle'>('flame');

  const allNodes = useMemo(
    () => (report ? flattenTree(report.flameRoot) : []),
    [report]
  );

  const zoomPath = useMemo(() => {
    if (!report) return [];
    return findNodePath(report.flameRoot, zoomNodeId) || [report.flameRoot];
  }, [report, zoomNodeId]);

  const zoomNode = zoomPath[zoomPath.length - 1] || report?.flameRoot || null;

  const placedNodes = useMemo(() => {
    if (!zoomNode) return [];
    return collectSubtreeRows(zoomNode);
  }, [zoomNode]);

  const maxRelDepth = useMemo(
    () => placedNodes.reduce((m, item) => Math.max(m, item.relDepth), 0),
    [placedNodes]
  );

  const inspectedNode = useMemo(() => {
    if (!report) return null;
    if (inspectedId) {
      const found = allNodes.find((n) => n.id === inspectedId);
      if (found) return found;
    }
    return zoomNode || report.flameRoot;
  }, [report, inspectedId, allNodes, zoomNode]);

  const cleanSearch = searchTerm.trim().toLowerCase();

  return (
    <div className="flex-1 min-h-0 flex flex-col bg-[var(--anka-bg)] overflow-hidden">
      {/* Profiler Control Toolbar */}
      <div className="px-4 py-2.5 border-b border-[var(--anka-border)] bg-[var(--anka-surface-muted)] flex flex-wrap items-center justify-between gap-3 shrink-0">
        <div className="flex flex-wrap items-center gap-2 min-w-0">
          <span className="text-xs font-medium text-[var(--anka-text-muted)] truncate max-w-[220px]">
            {targetLabel}
          </span>

          {availableFns.length > 0 && (
            <select
              value={selectedFn}
              onChange={(e) => onSelectFn(e.target.value)}
              aria-label={tr ? 'Hedef fonksiyon' : 'Target function'}
              className="px-2.5 py-1.5 rounded-lg border border-[var(--anka-border)] bg-[var(--anka-surface)] text-xs font-mono outline-none focus:border-[var(--anka-accent)]"
            >
              {availableFns.map((fn) => (
                <option key={fn} value={fn}>
                  {fn}()
                </option>
              ))}
            </select>
          )}

          {/* Segmented Iterations Control */}
          <div className="flex items-center gap-0.5 p-0.5 rounded-lg border border-[var(--anka-border)] bg-[var(--anka-surface)]">
            {[100, 300, 1000].map((cnt) => (
              <button
                key={cnt}
                type="button"
                onClick={() => onChangeIterations(cnt)}
                className={`px-2.5 py-1 rounded-md text-xs font-mono tabular-nums transition-colors whitespace-nowrap shrink-0 ${
                  iterations === cnt
                    ? 'bg-[var(--anka-accent)] text-[var(--anka-accent-fg)] font-medium'
                    : 'text-[var(--anka-text-muted)] hover:text-[var(--anka-text)]'
                }`}
              >
                {cnt}×
              </button>
            ))}
          </div>

          {traceFiles.length > 0 && (
            <select
              value=""
              onChange={(e) => {
                if (e.target.value) {
                  setZoomNodeId('root');
                  setInspectedId(null);
                  onSelectTraceFile(e.target.value);
                }
              }}
              aria-label={tr ? 'Kayıtlı iz dosyaları' : 'Saved trace files'}
              className="px-2.5 py-1.5 rounded-lg border border-[var(--anka-border)] bg-[var(--anka-surface)] text-xs font-mono outline-none focus:border-[var(--anka-accent)] max-w-[210px]"
            >
              <option value="">
                {tr ? `VFS İzleri (${traceFiles.length})` : `VFS Traces (${traceFiles.length})`}
              </option>
              {traceFiles.map((tf) => (
                <option key={tf.path} value={tf.path}>
                  {tf.name}
                </option>
              ))}
            </select>
          )}
        </div>

        <div className="flex items-center gap-2 shrink-0">
          {hasLastWasmrun && (
            <button
              type="button"
              onClick={() => {
                setZoomNodeId('root');
                setInspectedId(null);
                onLoadLastWasmrun();
              }}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium border border-[var(--anka-border-strong)] bg-[var(--anka-surface)] hover:bg-[var(--anka-surface-elevated)] transition-colors whitespace-nowrap shrink-0"
            >
              <FolderOpen size={13} />
              <span>{tr ? 'Son wasmrun İzini Yükle' : 'Load Last wasmrun'}</span>
            </button>
          )}

          {report && (
            <button
              type="button"
              onClick={onSaveProfile}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium border border-[var(--anka-border-strong)] bg-[var(--anka-surface)] hover:bg-[var(--anka-surface-elevated)] transition-colors whitespace-nowrap shrink-0"
            >
              <Save size={13} />
              <span>{tr ? 'İzi Kaydet' : 'Save Trace'}</span>
            </button>
          )}

          <button
            type="button"
            disabled={isProfiling}
            onClick={() => {
              setZoomNodeId('root');
              setInspectedId(null);
              onRunProfile();
            }}
            className="flex items-center gap-1.5 px-4 py-1.5 rounded-lg text-xs font-medium bg-[var(--anka-accent)] text-[var(--anka-accent-fg)] hover:bg-[var(--anka-accent-hover)] disabled:opacity-50 transition-colors whitespace-nowrap shrink-0"
          >
            <Play size={13} />
            <span>
              {isProfiling
                ? tr
                  ? 'Ölçülüyor...'
                  : 'Profiling...'
                : tr
                  ? 'Profili Çalıştır'
                  : 'Run Profiler'}
            </span>
          </button>
        </div>
      </div>

      {/* Main Scrollable Content */}
      <div className="flex-1 min-h-0 overflow-y-auto os-scroll p-4 space-y-4">
        {!report ? (
          <div className="rounded-xl border border-[var(--anka-border)] bg-[var(--anka-surface)] p-10 flex flex-col items-center justify-center text-center space-y-4">
            <div className="w-12 h-12 rounded-2xl border border-[var(--anka-border-strong)] bg-[var(--anka-surface-muted)] flex items-center justify-center">
              <Flame size={22} className="text-[var(--anka-accent)]" />
            </div>
            <div className="space-y-1 max-w-md">
              <h3 className="text-base font-semibold font-display">
                {tr
                  ? 'WASM Performans Profili & Flamegraph'
                  : 'WASM Performance Profiler & Flamegraph'}
              </h3>
              <p className="text-xs text-[var(--anka-text-muted)] leading-relaxed">
                {tr
                  ? 'Bir WebAssembly modülünü gerçek zamanlı örnekleyerek derleme, başlatma, sıcak döngü ve bellek yükü dağılımını çıkarın ya da uçbirimdeki wasmrun --profile çıktısını yükleyin.'
                  : 'Profile live WASM execution across decode, instantiation, loop hotspots, and linear memory, or load a wasmrun --profile trace.'}
              </p>
            </div>
            <button
              type="button"
              onClick={onRunProfile}
              className="px-4 py-2 rounded-lg text-xs font-medium bg-[var(--anka-accent)] text-[var(--anka-accent-fg)] hover:bg-[var(--anka-accent-hover)] transition-colors whitespace-nowrap"
            >
              {tr ? 'İlk Profili Başlat' : 'Run First Profile'}
            </button>
          </div>
        ) : (
          <>
            {/* Trace Metadata Header */}
            <div className="flex flex-wrap items-center justify-between gap-2 text-xs text-[var(--anka-text-muted)]">
              <div className="flex flex-wrap items-center gap-2">
                <span className="font-semibold text-[var(--anka-text)] font-display">
                  {report.moduleName}
                </span>
                <span aria-hidden="true">·</span>
                <span className="font-mono">
                  {report.entryFn}({report.args.join(', ')}) = {report.resultText}
                </span>
                {report.sourcePath && (
                  <>
                    <span aria-hidden="true">·</span>
                    <span className="font-mono text-[var(--anka-text-subtle)]">{report.sourcePath}</span>
                  </>
                )}
              </div>
              <div className="font-mono tabular-nums text-[11px] text-[var(--anka-text-subtle)]">
                {report.iterations} {tr ? 'iterasyon' : 'iterations'} · {report.byteLength} B
              </div>
            </div>

            {/* 4-Metric KPI Strip */}
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
              <div className="rounded-xl border border-[var(--anka-border)] bg-[var(--anka-surface)] p-3.5 space-y-1">
                <div className="text-[11px] text-[var(--anka-text-subtle)]">
                  {tr ? 'Toplam Pipeline Süresi' : 'Total Pipeline Time'}
                </div>
                <div className="text-lg font-semibold font-mono tabular-nums">
                  {formatDurationUs(report.metrics.totalPipelineUs)}
                </div>
                <div className="text-[11px] text-[var(--anka-text-muted)] font-mono tabular-nums">
                  {tr ? 'Soğuk çağrı' : 'Cold'}: {formatDurationUs(report.metrics.coldCallUs)}
                </div>
              </div>

              <div className="rounded-xl border border-[var(--anka-border)] bg-[var(--anka-surface)] p-3.5 space-y-1">
                <div className="text-[11px] text-[var(--anka-text-subtle)]">
                  {tr ? 'Ortalama Sıcak Çağrı' : 'Avg Hot Invocation'}
                </div>
                <div className="text-lg font-semibold font-mono tabular-nums text-[var(--anka-accent)]">
                  {formatDurationUs(report.metrics.hotAvgUs)}
                </div>
                <div className="text-[11px] text-[var(--anka-text-muted)] font-mono tabular-nums">
                  P50: {formatDurationUs(report.metrics.hotP50Us)} · P95:{' '}
                  {formatDurationUs(report.metrics.hotP95Us)}
                </div>
              </div>

              <div className="rounded-xl border border-[var(--anka-border)] bg-[var(--anka-surface)] p-3.5 space-y-1">
                <div className="text-[11px] text-[var(--anka-text-subtle)]">
                  {tr ? 'Çağrı Verimi (Throughput)' : 'Invocation Throughput'}
                </div>
                <div className="text-lg font-semibold font-mono tabular-nums">
                  {report.metrics.opsPerSec.toLocaleString(tr ? 'tr-TR' : 'en-US')} ops/s
                </div>
                <div className="text-[11px] text-[var(--anka-text-muted)] font-mono tabular-nums">
                  Derleme+Başlat: {formatDurationUs(report.metrics.compileUs + report.metrics.instantiateUs)}
                </div>
              </div>

              <div className="rounded-xl border border-[var(--anka-border)] bg-[var(--anka-surface)] p-3.5 space-y-1">
                <div className="text-[11px] text-[var(--anka-text-subtle)]">
                  {tr ? 'Modül & Lineer Bellek' : 'Binary & Linear Memory'}
                </div>
                <div className="text-lg font-semibold font-mono tabular-nums">
                  {report.byteLength} B
                </div>
                <div className="text-[11px] text-[var(--anka-text-muted)] font-mono tabular-nums">
                  {report.memoryPages > 0
                    ? `${report.memoryPages} sayfa (${report.memoryUsedBytes} B dolu)`
                    : tr
                      ? 'Dışa aktarılan bellek yok'
                      : 'No exported memory'}
                </div>
              </div>
            </div>

            {/* Interactive Flamegraph Canvas Card */}
            <section className="rounded-xl border border-[var(--anka-border)] bg-[var(--anka-surface)] p-4 space-y-3">
              {/* Flamegraph Header & Breadcrumbs */}
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div className="flex flex-wrap items-center gap-1.5 min-w-0">
                  <Flame size={15} className="text-[var(--anka-accent)] shrink-0" />
                  <h3 className="text-sm font-semibold font-display shrink-0">
                    {tr ? 'Çağrı Yığını Flamegraph' : 'Call-Stack Flamegraph'}
                  </h3>
                  <span className="text-[var(--anka-text-subtle)]" aria-hidden="true">
                    /
                  </span>
                  <nav
                    aria-label={tr ? 'Flamegraph yakınlaştırma yolu' : 'Flamegraph zoom path'}
                    className="flex flex-wrap items-center gap-1 text-xs font-mono"
                  >
                    {zoomPath.map((node, idx) => (
                      <React.Fragment key={node.id}>
                        {idx > 0 && <span className="text-[var(--anka-text-subtle)]">&gt;</span>}
                        <button
                          type="button"
                          onClick={() => setZoomNodeId(node.id)}
                          className={`px-1.5 py-0.5 rounded hover:bg-[var(--anka-surface-elevated)] truncate max-w-[160px] ${
                            idx === zoomPath.length - 1
                              ? 'font-semibold text-[var(--anka-text)]'
                              : 'text-[var(--anka-text-muted)]'
                          }`}
                        >
                          {idx === 0 ? (tr ? 'Tümü' : 'All') : node.name}
                        </button>
                      </React.Fragment>
                    ))}
                  </nav>
                </div>

                <div className="flex flex-wrap items-center gap-2 shrink-0">
                  <div className="relative">
                    <Search
                      size={12}
                      className="absolute left-2.5 top-1/2 -translate-y-1/2 text-[var(--anka-text-subtle)]"
                    />
                    <input
                      type="text"
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      placeholder={tr ? 'Çerçeve ara...' : 'Filter frames...'}
                      className="pl-7 pr-2.5 py-1 rounded-lg border border-[var(--anka-border)] bg-[var(--anka-surface-muted)] text-xs font-mono outline-none focus:border-[var(--anka-accent)] w-40"
                    />
                  </div>

                  <button
                    type="button"
                    onClick={() => setLayoutMode((m) => (m === 'flame' ? 'icicle' : 'flame'))}
                    className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs border border-[var(--anka-border)] bg-[var(--anka-surface-muted)] hover:bg-[var(--anka-surface-elevated)] transition-colors whitespace-nowrap"
                  >
                    <ArrowDownUp size={12} />
                    <span>{layoutMode === 'flame' ? 'Flame' : 'Icicle'}</span>
                  </button>

                  {zoomNodeId !== 'root' && (
                    <button
                      type="button"
                      onClick={() => setZoomNodeId('root')}
                      className="flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs border border-[var(--anka-border)] hover:bg-[var(--anka-surface-elevated)] transition-colors whitespace-nowrap"
                    >
                      <RotateCcw size={12} />
                      <span>{tr ? 'Sıfırla' : 'Reset'}</span>
                    </button>
                  )}
                </div>
              </div>

              {/* Explicit Category Legend (Text + Color) */}
              <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-[11px] text-[var(--anka-text-muted)]">
                {(Object.keys(CATEGORY_STYLE) as FlameCategory[]).map((cat) => {
                  const cfg = CATEGORY_STYLE[cat];
                  return (
                    <div key={cat} className="flex items-center gap-1.5">
                      <span className={`w-2.5 h-2.5 rounded-sm ${cfg.bg}`} aria-hidden="true" />
                      <span>{tr ? cfg.labelTr : cfg.labelEn}</span>
                    </div>
                  );
                })}
              </div>

              {/* Flamegraph Coordinate Grid */}
              <div
                className="relative w-full rounded-lg border border-[var(--anka-border)] bg-[var(--anka-surface-muted)] p-2 overflow-hidden"
                style={{ height: `${Math.max(152, (maxRelDepth + 1) * 32 + 20)}px` }}
              >
                {placedNodes.map(({ node, relLeftPct, relWidthPct, relDepth }) => {
                  const styleCfg = CATEGORY_STYLE[node.category];
                  const rowHeight = 28;
                  const gap = 4;
                  const topPx =
                    layoutMode === 'icicle'
                      ? 10 + relDepth * (rowHeight + gap)
                      : 10 + (maxRelDepth - relDepth) * (rowHeight + gap);

                  const isMatch =
                    !cleanSearch ||
                    node.name.toLowerCase().includes(cleanSearch) ||
                    (node.opcodesSummary || '').toLowerCase().includes(cleanSearch);
                  const isActive = inspectedNode?.id === node.id;
                  const sharePct =
                    zoomNode && zoomNode.totalUs > 0
                      ? ((node.totalUs / zoomNode.totalUs) * 100).toFixed(1)
                      : node.widthPct.toFixed(1);

                  return (
                    <button
                      key={node.id}
                      type="button"
                      onClick={() => {
                        setZoomNodeId(node.id);
                        setInspectedId(node.id);
                      }}
                      onMouseEnter={() => setInspectedId(node.id)}
                      onFocus={() => setInspectedId(node.id)}
                      title={`${node.name} · ${formatDurationUs(node.totalUs)} (${sharePct}%)`}
                      style={{
                        left: `calc(${relLeftPct}% + 2px)`,
                        width: `calc(${relWidthPct}% - 4px)`,
                        top: `${topPx}px`,
                        height: `${rowHeight}px`,
                      }}
                      className={`absolute rounded px-2 flex items-center justify-between gap-1 text-[11px] font-mono border transition-opacity overflow-hidden whitespace-nowrap ${
                        styleCfg.bg
                      } ${styleCfg.border} ${
                        isMatch ? 'opacity-100' : 'opacity-25'
                      } ${isActive ? 'ring-2 ring-white/80 dark:ring-white z-10' : 'hover:brightness-110'}`}
                    >
                      <span className="truncate font-medium">{node.name}</span>
                      {relWidthPct >= 14 && (
                        <span className="text-[10px] opacity-90 tabular-nums shrink-0">
                          {formatDurationUs(node.totalUs)} ({sharePct}%)
                        </span>
                      )}
                    </button>
                  );
                })}
              </div>

              {/* Inspected Frame Telemetry Readout */}
              {inspectedNode && (
                <div className="pt-2 border-t border-[var(--anka-border)] flex flex-wrap items-center justify-between gap-3 text-xs">
                  <div className="flex flex-wrap items-center gap-2 min-w-0">
                    <span className="font-mono font-semibold text-[var(--anka-text)]">
                      {inspectedNode.name}
                    </span>
                    <span aria-hidden="true" className="text-[var(--anka-text-subtle)]">
                      ·
                    </span>
                    <span className="text-[var(--anka-text-muted)]">
                      {tr
                        ? CATEGORY_STYLE[inspectedNode.category].labelTr
                        : CATEGORY_STYLE[inspectedNode.category].labelEn}
                    </span>
                    {inspectedNode.opcodesSummary && (
                      <>
                        <span aria-hidden="true" className="text-[var(--anka-text-subtle)]">
                          ·
                        </span>
                        <span className="font-mono text-[11px] text-[var(--anka-text-subtle)]">
                          {inspectedNode.opcodesSummary}
                        </span>
                      </>
                    )}
                  </div>

                  <div className="flex items-center gap-4 font-mono tabular-nums text-[11px]">
                    <span>
                      {tr ? 'Öz' : 'Self'}: <strong>{formatDurationUs(inspectedNode.selfUs)}</strong>
                    </span>
                    <span>
                      {tr ? 'Toplam' : 'Total'}: <strong>{formatDurationUs(inspectedNode.totalUs)}</strong>
                    </span>
                    <span>
                      {tr ? 'Çağrı' : 'Calls'}: <strong>{inspectedNode.calls.toLocaleString()}</strong>
                    </span>
                    <span>
                      {tr ? 'Pay' : 'Share'}:{' '}
                      <strong>
                        {report.metrics.totalPipelineUs > 0
                          ? ((inspectedNode.totalUs / report.metrics.totalPipelineUs) * 100).toFixed(1)
                          : '0.0'}
                        %
                      </strong>
                    </span>
                  </div>
                </div>
              )}
            </section>

            {/* Bottom 2-Column Analytical Breakdown */}
            <div className="grid grid-cols-1 xl:grid-cols-12 gap-4">
              {/* Top Functions Hotspot Table */}
              <section className="xl:col-span-7 rounded-xl border border-[var(--anka-border)] bg-[var(--anka-surface)] overflow-hidden">
                <div className="px-4 py-2.5 border-b border-[var(--anka-border)] flex items-center justify-between">
                  <h3 className="text-xs font-semibold font-display">
                    {tr ? 'Fonksiyon Hotspot Tablosu' : 'Function Hotspots'}
                  </h3>
                  <span className="text-[11px] text-[var(--anka-text-subtle)] font-mono tabular-nums">
                    {report.functionStats.length} {tr ? 'fonksiyon' : 'functions'}
                  </span>
                </div>
                <div className="overflow-x-auto">
                  <table className="w-full text-xs border-collapse">
                    <thead>
                      <tr className="border-b border-[var(--anka-border)] text-[11px] text-[var(--anka-text-subtle)] bg-[var(--anka-surface-muted)]">
                        <th className="text-left font-medium px-4 py-2">{tr ? 'Fonksiyon' : 'Function'}</th>
                        <th className="text-left font-medium px-3 py-2">{tr ? 'Kapsam' : 'Scope'}</th>
                        <th className="text-right font-medium px-3 py-2">{tr ? 'Komut' : 'Instr'}</th>
                        <th className="text-right font-medium px-3 py-2">{tr ? 'Öz µs' : 'Self'}</th>
                        <th className="text-right font-medium px-3 py-2">{tr ? 'Toplam' : 'Total'}</th>
                        <th className="text-right font-medium px-4 py-2">{tr ? 'Pay %' : 'Share'}</th>
                      </tr>
                    </thead>
                    <tbody>
                      {report.functionStats.map((fn) => (
                        <tr
                          key={fn.index}
                          onClick={() => {
                            const match = allNodes.find((n) => n.name.startsWith(`${fn.name}(`));
                            if (match) {
                              setZoomNodeId(match.id);
                              setInspectedId(match.id);
                            }
                          }}
                          className="h-9 border-b border-[var(--anka-border)] last:border-b-0 hover:bg-[var(--anka-surface-muted)] cursor-pointer transition-colors"
                        >
                          <td className="px-4 font-mono font-medium text-[var(--anka-text)]">
                            {fn.name}()
                          </td>
                          <td className="px-3 text-[11px] text-[var(--anka-text-muted)]">
                            {fn.exported ? (tr ? 'Dışa Aktarılan' : 'Exported') : tr ? 'Dahili' : 'Internal'}
                            {fn.loopCount > 0 ? ` · ${fn.loopCount} loop` : ''}
                          </td>
                          <td className="px-3 text-right font-mono tabular-nums text-[var(--anka-text-muted)]">
                            {fn.instructionCount}
                          </td>
                          <td className="px-3 text-right font-mono tabular-nums">
                            {formatDurationUs(fn.selfUs)}
                          </td>
                          <td className="px-3 text-right font-mono tabular-nums font-medium">
                            {formatDurationUs(fn.totalUs)}
                          </td>
                          <td className="px-4 text-right font-mono tabular-nums text-[var(--anka-accent)] font-semibold">
                            {fn.sharePct.toFixed(1)}%
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </section>

              {/* Iteration Latency Histogram + Binary Sections */}
              <section className="xl:col-span-5 rounded-xl border border-[var(--anka-border)] bg-[var(--anka-surface)] p-4 flex flex-col justify-between space-y-4">
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-1.5">
                      <Activity size={13} className="text-[var(--anka-accent)]" />
                      <h3 className="text-xs font-semibold font-display">
                        {tr ? 'İterasyon Gecikme Dağılımı' : 'Iteration Latency Samples'}
                      </h3>
                    </div>
                    <span className="text-[11px] font-mono tabular-nums text-[var(--anka-text-subtle)]">
                      min {formatDurationUs(report.metrics.hotMinUs)} · max{' '}
                      {formatDurationUs(report.metrics.hotMaxUs)}
                    </span>
                  </div>

                  {/* Clean SVG Bar Chart of Real Timing Samples */}
                  <div className="h-28 w-full rounded-lg border border-[var(--anka-border)] bg-[var(--anka-surface-muted)] p-2">
                    <svg
                      viewBox={`0 0 ${Math.max(100, report.timelineSamplesUs.length * 10)} 80`}
                      preserveAspectRatio="none"
                      className="w-full h-full"
                    >
                      {(() => {
                        const samples = report.timelineSamplesUs;
                        const maxVal = Math.max(0.01, ...samples);
                        return samples.map((val, idx) => {
                          const h = Math.max(4, (val / maxVal) * 72);
                          const isSpike = val > report.metrics.hotP95Us;
                          return (
                            <rect
                              key={idx}
                              x={idx * 10 + 1}
                              y={78 - h}
                              width={7}
                              height={h}
                              rx={1.5}
                              fill={isSpike ? '#f43f5e' : 'var(--anka-accent)'}
                              opacity={isSpike ? 0.92 : 0.78}
                            >
                              <title>
                                #{idx + 1}: {val.toFixed(2)} µs
                              </title>
                            </rect>
                          );
                        });
                      })()}
                    </svg>
                  </div>
                </div>

                {/* WASM Section Weight Distribution */}
                <div className="space-y-2 pt-2 border-t border-[var(--anka-border)]">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-semibold font-display">
                      {tr ? 'WASM İkili Bölüm Ağırlığı' : 'Binary Section Footprint'}
                    </span>
                    <span className="font-mono text-[11px] tabular-nums text-[var(--anka-text-subtle)]">
                      {report.byteLength} B
                    </span>
                  </div>
                  <div className="space-y-1.5">
                    {report.sections.map((sec) => (
                      <div key={sec.name} className="space-y-0.5 text-[11px]">
                        <div className="flex items-center justify-between font-mono tabular-nums">
                          <span className="text-[var(--anka-text-muted)]">{sec.name}</span>
                          <span>
                            {sec.bytes} B · {sec.sharePct}%
                          </span>
                        </div>
                        <div className="h-1.5 w-full rounded-full bg-[var(--anka-surface-muted)] overflow-hidden">
                          <div
                            className="h-full rounded-full bg-[var(--anka-accent)]"
                            style={{ width: `${Math.max(3, sec.sharePct)}%` }}
                          />
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </section>
            </div>
          </>
        )}
      </div>
    </div>
  );
};
