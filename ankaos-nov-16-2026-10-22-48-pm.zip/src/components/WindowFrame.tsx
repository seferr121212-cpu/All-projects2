import React, { Component, useRef, useState } from 'react';
import { AlertTriangle, LayoutGrid, Maximize2, Minimize2, Minus, RotateCcw, ShieldAlert, X } from 'lucide-react';
import { AudioRecorderApp } from '../apps/AudioRecorderApp';
import { BrowserApp } from '../apps/BrowserApp';
import { CalculatorApp } from '../apps/CalculatorApp';
import { CalendarApp } from '../apps/CalendarApp';
import { DiffViewerApp } from '../apps/DiffViewerApp';
import { EditorApp } from '../apps/EditorApp';
import { FilesApp } from '../apps/FilesApp';
import { Game2048App } from '../apps/Game2048App';
import { HexViewerApp } from '../apps/HexViewerApp';
import { ImageViewerApp } from '../apps/ImageViewerApp';
import { KanbanApp } from '../apps/KanbanApp';
import { MarkdownViewerApp } from '../apps/MarkdownViewerApp';
import { MediaPlayerApp } from '../apps/MediaPlayerApp';
import { MinesweeperApp } from '../apps/MinesweeperApp';
import { NetToolsApp } from '../apps/NetToolsApp';
import { NotesApp } from '../apps/NotesApp';
import { PackageManagerApp } from '../apps/PackageManagerApp';
import { PaintApp } from '../apps/PaintApp';
import { SettingsApp } from '../apps/SettingsApp';
import { SnakeApp } from '../apps/SnakeApp';
import { SysBenchApp } from '../apps/SysBenchApp';
import { SystemMonitorApp } from '../apps/SystemMonitorApp';
import { TerminalApp } from '../apps/TerminalApp';
import { TimerApp } from '../apps/TimerApp';
import { WasmBuilderApp } from '../apps/WasmBuilderApp';
import { computeWindowRect, detectEdgeSnapZone, WindowRect } from '../os/compositor';
import { t } from '../os/i18n';
import { useOS } from '../os/kernel';
import { OSWindow, WindowSnap, WorkspaceId } from '../os/types';
import { AppIcon } from './AppIcon';

class AppCrashBoundary extends Component<
  {
    children: React.ReactNode;
    onClose: () => void;
    onRestart: () => void;
    onFault: (reason: string) => void;
  },
  { hasError: boolean; message: string }
> {
  constructor(props: {
    children: React.ReactNode;
    onClose: () => void;
    onRestart: () => void;
    onFault: (reason: string) => void;
  }) {
    super(props);
    this.state = { hasError: false, message: '' };
  }

  static getDerivedStateFromError(err: Error) {
    return { hasError: true, message: err.message };
  }

  componentDidCatch(error: Error) {
    this.props.onFault(error.message);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="h-full w-full flex flex-col items-center justify-center p-6 bg-[var(--anka-bg)] text-[var(--anka-text)] text-center space-y-4">
          <div className="w-12 h-12 rounded-2xl bg-rose-500/15 border border-rose-500/30 flex items-center justify-center">
            <AlertTriangle size={26} className="text-rose-500 dark:text-rose-400" />
          </div>
          <div className="space-y-1.5 max-w-sm">
            <div className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded bg-rose-500/15 text-rose-600 dark:text-rose-300 text-[10px] font-mono">
              <ShieldAlert size={11} />
              <span>RING 3 YALITIMI · KERNEL PANIC ÖNLENDİ</span>
            </div>
            <h3 className="text-sm font-semibold">Uygulama Hatası Yakalandı (SIGSEGV)</h3>
            <p className="text-xs font-mono text-[var(--anka-text-subtle)] break-all">{this.state.message}</p>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                this.setState({ hasError: false, message: '' });
                this.props.onRestart();
              }}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium bg-[var(--anka-accent)] hover:bg-[var(--anka-accent-hover)] text-[var(--anka-accent-fg)] transition-colors"
            >
              <RotateCcw size={13} />
              <span>Yeniden Başlat</span>
            </button>
            <button
              onClick={this.props.onClose}
              className="px-3 py-1.5 rounded-lg text-xs font-medium border border-[var(--anka-border)] hover:bg-[var(--anka-surface-elevated)] transition-colors"
            >
              Kapat
            </button>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}

interface WindowFrameProps {
  win: OSWindow;
  compositedRect?: WindowRect;
  onSnapPreview?: (snap: WindowSnap) => void;
}

type DragMode =
  | 'move'
  | 'resize-e'
  | 'resize-w'
  | 'resize-s'
  | 'resize-n'
  | 'resize-se'
  | 'resize-sw'
  | 'resize-ne'
  | 'resize-nw'
  | null;

export const WindowFrame: React.FC<WindowFrameProps> = ({
  win,
  compositedRect,
  onSnapPreview,
}) => {
  const {
    activeWindowId,
    activeWorkspace,
    focusWindow,
    closeWindow,
    minimizeWindow,
    toggleMaximizeWindow,
    snapWindow,
    moveWindow,
    resizeWindow,
    moveWindowToWorkspace,
    reportProcessFault,
    settings,
  } = useOS();

  const [restartKey, setRestartKey] = useState(0);
  const [tileMenuOpen, setTileMenuOpen] = useState(false);
  const lang = settings.language;
  const isActive = activeWindowId === win.id;
  const dragState = useRef<{
    mode: DragMode;
    startX: number;
    startY: number;
    origX: number;
    origY: number;
    origW: number;
    origH: number;
    rafPending: boolean;
  }>({
    mode: null,
    startX: 0,
    startY: 0,
    origX: 0,
    origY: 0,
    origW: 0,
    origH: 0,
    rafPending: false,
  });

  if (win.isMinimized || win.workspace !== activeWorkspace) return null;

  const startDrag = (e: React.PointerEvent, mode: Exclude<DragMode, null>) => {
    if (e.button !== 0) return;
    if ((e.target as HTMLElement).closest('button, select')) return;
    e.preventDefault();
    focusWindow(win.id);

    dragState.current = {
      mode,
      startX: e.clientX,
      startY: e.clientY,
      origX: win.x,
      origY: win.y,
      origW: win.width,
      origH: win.height,
      rafPending: false,
    };

    let latestClientX = e.clientX;
    let latestClientY = e.clientY;
    let pendingSnap: WindowSnap = 'none';

    const applyFrame = () => {
      const st = dragState.current;
      st.rafPending = false;
      if (!st.mode) return;
      const dx = latestClientX - st.startX;
      const dy = latestClientY - st.startY;

      if (st.mode === 'move') {
        moveWindow(win.id, st.origX + dx, Math.max(36, st.origY + dy));
        pendingSnap = detectEdgeSnapZone(
          latestClientX,
          latestClientY,
          window.innerWidth,
          window.innerHeight
        );
        onSnapPreview?.(pendingSnap);
        return;
      }

      let nextW = st.origW;
      let nextH = st.origH;
      let nextX = st.origX;
      let nextY = st.origY;
      const vwLimit = typeof window !== 'undefined' ? window.innerWidth : 1280;
      const vhLimit = typeof window !== 'undefined' ? window.innerHeight : 800;

      if (st.mode.includes('e')) {
        nextW = Math.min(vwLimit - st.origX, Math.max(win.minWidth, st.origW + dx));
      }
      if (st.mode.includes('s')) {
        nextH = Math.min(vhLimit - st.origY, Math.max(win.minHeight, st.origH + dy));
      }
      if (st.mode.includes('w')) {
        const rightEdge = st.origX + st.origW;
        const clampedX = Math.max(0, Math.min(rightEdge - win.minWidth, st.origX + dx));
        nextX = clampedX;
        nextW = rightEdge - clampedX;
      }
      if (st.mode.includes('n')) {
        const bottomEdge = st.origY + st.origH;
        const clampedY = Math.max(36, Math.min(bottomEdge - win.minHeight, st.origY + dy));
        nextY = clampedY;
        nextH = bottomEdge - clampedY;
      }

      resizeWindow(win.id, nextW, nextH, nextX, nextY);
    };

    // Double-buffered rAF throttling prevents mid-frame screen tearing during pointer moves
    const onMove = (ev: PointerEvent) => {
      latestClientX = ev.clientX;
      latestClientY = ev.clientY;
      if (!dragState.current.rafPending) {
        dragState.current.rafPending = true;
        requestAnimationFrame(applyFrame);
      }
    };

    const onUp = () => {
      const wasMove = dragState.current.mode === 'move';
      dragState.current.mode = null;
      if (wasMove && pendingSnap !== 'none') {
        snapWindow(win.id, pendingSnap);
      }
      onSnapPreview?.('none');
      window.removeEventListener('pointermove', onMove);
      window.removeEventListener('pointerup', onUp);
    };

    window.addEventListener('pointermove', onMove);
    window.addEventListener('pointerup', onUp);
  };

  const vw = typeof window !== 'undefined' ? window.innerWidth : 1280;
  const vh = typeof window !== 'undefined' ? window.innerHeight : 800;
  const rect = compositedRect || computeWindowRect(win, vw, vh);

  // GPU-composited translate3d surface avoids layout reflow and screen tearing
  const style: React.CSSProperties = {
    top: 0,
    left: 0,
    transform: `translate3d(${rect.x}px, ${rect.y}px, 0)`,
    width: rect.width,
    height: rect.height,
    zIndex: rect.zIndex,
    willChange: 'transform',
  };

  const renderApp = () => {
    switch (win.appId) {
      case 'terminal':
        return <TerminalApp key={restartKey} windowId={win.id} launchArgs={win.launchArgs} />;
      case 'files':
        return <FilesApp key={restartKey} windowId={win.id} launchArgs={win.launchArgs} />;
      case 'editor':
        return <EditorApp key={restartKey} windowId={win.id} launchArgs={win.launchArgs} />;
      case 'browser':
        return <BrowserApp key={restartKey} windowId={win.id} launchArgs={win.launchArgs} />;
      case 'media':
        return <MediaPlayerApp key={restartKey} windowId={win.id} launchArgs={win.launchArgs} />;
      case 'wasm-builder':
        return <WasmBuilderApp key={restartKey} windowId={win.id} launchArgs={win.launchArgs} />;
      case 'pkg':
        return <PackageManagerApp key={restartKey} windowId={win.id} />;
      case 'monitor':
        return <SystemMonitorApp key={restartKey} windowId={win.id} />;
      case 'paint':
        return <PaintApp key={restartKey} windowId={win.id} />;
      case 'viewer':
        return <ImageViewerApp key={restartKey} windowId={win.id} launchArgs={win.launchArgs} />;
      case 'calculator':
        return <CalculatorApp key={restartKey} windowId={win.id} />;
      case 'notes':
        return <NotesApp key={restartKey} windowId={win.id} />;
      case 'settings':
        return <SettingsApp key={restartKey} windowId={win.id} />;
      case 'pkg-snake':
        return <SnakeApp key={restartKey} windowId={win.id} />;
      case 'pkg-hex':
        return <HexViewerApp key={restartKey} windowId={win.id} launchArgs={win.launchArgs} />;
      case 'pkg-timer':
        return <TimerApp key={restartKey} windowId={win.id} />;
      case 'pkg-mines':
        return <MinesweeperApp key={restartKey} windowId={win.id} />;
      case 'pkg-2048':
        return <Game2048App key={restartKey} windowId={win.id} />;
      case 'pkg-kanban':
        return <KanbanApp key={restartKey} windowId={win.id} />;
      case 'pkg-sysbench':
        return <SysBenchApp key={restartKey} windowId={win.id} />;
      case 'pkg-calendar':
        return <CalendarApp key={restartKey} windowId={win.id} />;
      case 'pkg-markdown':
        return <MarkdownViewerApp key={restartKey} windowId={win.id} launchArgs={win.launchArgs} />;
      case 'pkg-recorder':
        return <AudioRecorderApp key={restartKey} windowId={win.id} />;
      case 'pkg-nettools':
        return <NetToolsApp key={restartKey} windowId={win.id} />;
      case 'pkg-diff':
        return <DiffViewerApp key={restartKey} windowId={win.id} launchArgs={win.launchArgs} />;
    }
  };

  return (
    <div
      style={style}
      onPointerDown={() => focusWindow(win.id)}
      className={`fixed flex flex-col overflow-hidden transition-shadow duration-150 ${
        win.snap === 'maximized' ? 'rounded-none' : 'rounded-xl'
      } ${
        isActive
          ? 'shadow-2xl ring-1 ring-[var(--anka-border-strong)]'
          : 'shadow-lg ring-1 ring-[var(--anka-border)] opacity-95'
      } bg-[var(--anka-surface)] text-[var(--anka-text)]`}
    >
      {/* Title Bar */}
      <div
        onPointerDown={(e) => startDrag(e, 'move')}
        onDoubleClick={() => toggleMaximizeWindow(win.id)}
        className="h-10 shrink-0 px-3 flex items-center justify-between border-b border-[var(--anka-border)] bg-[var(--anka-titlebar)] backdrop-blur-md cursor-grab active:cursor-grabbing select-none anka-theme-transition"
      >
        <div className="flex items-center gap-2 min-w-0">
          <AppIcon appId={win.appId} size={14} withContainer={false} />
          <span className="text-xs font-semibold text-[var(--anka-text)] truncate">
            {win.title}
          </span>
          <span className="text-[10px] font-mono text-[var(--anka-text-subtle)] tabular-nums shrink-0">
            · PID {win.pid} · R3
          </span>
        </div>

        <div className="flex items-center gap-1 shrink-0">
          <select
            value={win.workspace}
            title={t(lang, 'workspace')}
            onChange={(e) =>
              moveWindowToWorkspace(win.id, Number(e.target.value) as WorkspaceId)
            }
            className="mr-1 px-1.5 py-0.5 rounded text-[11px] font-mono bg-[var(--anka-surface-elevated)] text-[var(--anka-text-muted)] outline-none cursor-pointer border border-[var(--anka-border)]"
          >
            <option value={1}>WS1</option>
            <option value={2}>WS2</option>
            <option value={3}>WS3</option>
            <option value={4}>WS4</option>
          </select>

          <div className="relative">
            <button
              onClick={() => setTileMenuOpen((v) => !v)}
              title={lang === 'tr' ? 'Pencere Döşeme Düzeni' : 'Window Tiling Layout'}
              className={`p-1.5 rounded-md transition-colors ${
                tileMenuOpen || (win.snap !== 'none' && win.snap !== 'maximized')
                  ? 'bg-[var(--anka-accent-soft)] text-[var(--anka-accent)]'
                  : 'text-[var(--anka-text-subtle)] hover:bg-[var(--anka-surface-elevated)] hover:text-[var(--anka-text)]'
              }`}
            >
              <LayoutGrid size={13} />
            </button>
            {tileMenuOpen && (
              <div
                onClick={(e) => e.stopPropagation()}
                className="fixed z-50 mt-1.5 right-auto -translate-x-24 w-44 rounded-xl border border-[var(--anka-border)] bg-[var(--anka-glass)] backdrop-blur-xl shadow-2xl p-2 space-y-1.5 text-[11px]"
              >
                <div className="text-[10px] font-medium text-[var(--anka-text-subtle)] px-1">
                  {lang === 'tr' ? 'Pencereyi Döşe (Alt+Ok)' : 'Tile Window (Alt+Arrows)'}
                </div>
                <div className="grid grid-cols-2 gap-1">
                  <button
                    onClick={() => {
                      snapWindow(win.id, 'left');
                      setTileMenuOpen(false);
                    }}
                    className={`px-2 py-1.5 rounded-md border text-left transition-colors ${
                      win.snap === 'left'
                        ? 'border-[var(--anka-accent)] bg-[var(--anka-accent-soft)] text-[var(--anka-accent)] font-medium'
                        : 'border-[var(--anka-border)] hover:bg-[var(--anka-surface-elevated)]'
                    }`}
                  >
                    {t(lang, 'snapLeft')}
                  </button>
                  <button
                    onClick={() => {
                      snapWindow(win.id, 'right');
                      setTileMenuOpen(false);
                    }}
                    className={`px-2 py-1.5 rounded-md border text-left transition-colors ${
                      win.snap === 'right'
                        ? 'border-[var(--anka-accent)] bg-[var(--anka-accent-soft)] text-[var(--anka-accent)] font-medium'
                        : 'border-[var(--anka-border)] hover:bg-[var(--anka-surface-elevated)]'
                    }`}
                  >
                    {t(lang, 'snapRight')}
                  </button>
                  <button
                    onClick={() => {
                      snapWindow(win.id, 'top-left');
                      setTileMenuOpen(false);
                    }}
                    className={`px-2 py-1 rounded-md border text-left transition-colors ${
                      win.snap === 'top-left'
                        ? 'border-[var(--anka-accent)] bg-[var(--anka-accent-soft)] text-[var(--anka-accent)] font-medium'
                        : 'border-[var(--anka-border)] hover:bg-[var(--anka-surface-elevated)]'
                    }`}
                  >
                    {lang === 'tr' ? 'Sol Üst' : 'Top-Left'}
                  </button>
                  <button
                    onClick={() => {
                      snapWindow(win.id, 'top-right');
                      setTileMenuOpen(false);
                    }}
                    className={`px-2 py-1 rounded-md border text-left transition-colors ${
                      win.snap === 'top-right'
                        ? 'border-[var(--anka-accent)] bg-[var(--anka-accent-soft)] text-[var(--anka-accent)] font-medium'
                        : 'border-[var(--anka-border)] hover:bg-[var(--anka-surface-elevated)]'
                    }`}
                  >
                    {lang === 'tr' ? 'Sağ Üst' : 'Top-Right'}
                  </button>
                  <button
                    onClick={() => {
                      snapWindow(win.id, 'bottom-left');
                      setTileMenuOpen(false);
                    }}
                    className={`px-2 py-1 rounded-md border text-left transition-colors ${
                      win.snap === 'bottom-left'
                        ? 'border-[var(--anka-accent)] bg-[var(--anka-accent-soft)] text-[var(--anka-accent)] font-medium'
                        : 'border-[var(--anka-border)] hover:bg-[var(--anka-surface-elevated)]'
                    }`}
                  >
                    {lang === 'tr' ? 'Sol Alt' : 'Bot-Left'}
                  </button>
                  <button
                    onClick={() => {
                      snapWindow(win.id, 'bottom-right');
                      setTileMenuOpen(false);
                    }}
                    className={`px-2 py-1 rounded-md border text-left transition-colors ${
                      win.snap === 'bottom-right'
                        ? 'border-[var(--anka-accent)] bg-[var(--anka-accent-soft)] text-[var(--anka-accent)] font-medium'
                        : 'border-[var(--anka-border)] hover:bg-[var(--anka-surface-elevated)]'
                    }`}
                  >
                    {lang === 'tr' ? 'Sağ Alt' : 'Bot-Right'}
                  </button>
                </div>
                {win.snap !== 'none' && (
                  <button
                    onClick={() => {
                      snapWindow(win.id, 'none');
                      setTileMenuOpen(false);
                    }}
                    className="w-full py-1 rounded-md text-center text-[var(--anka-text-subtle)] hover:bg-[var(--anka-surface-elevated)]"
                  >
                    {t(lang, 'restore')}
                  </button>
                )}
              </div>
            )}
          </div>
          <button
            onClick={() => minimizeWindow(win.id)}
            title={t(lang, 'minimize')}
            className="p-1.5 rounded-md text-[var(--anka-text-subtle)] hover:bg-[var(--anka-surface-elevated)] hover:text-[var(--anka-text)] transition-colors"
          >
            <Minus size={13} />
          </button>
          <button
            onClick={() => toggleMaximizeWindow(win.id)}
            title={win.snap === 'maximized' ? t(lang, 'restore') : t(lang, 'maximize')}
            className="p-1.5 rounded-md text-[var(--anka-text-subtle)] hover:bg-[var(--anka-surface-elevated)] hover:text-[var(--anka-text)] transition-colors"
          >
            {win.snap === 'maximized' ? <Minimize2 size={13} /> : <Maximize2 size={13} />}
          </button>
          <button
            onClick={() => closeWindow(win.id)}
            title={t(lang, 'close')}
            className="p-1.5 rounded-md text-[var(--anka-text-subtle)] hover:bg-rose-500 hover:text-white transition-colors"
          >
            <X size={13} />
          </button>
        </div>
      </div>

      {/* App Content wrapped in Ring 3 OS Crash Guard */}
      <div className="flex-1 min-h-0 overflow-hidden relative">
        <AppCrashBoundary
          onClose={() => closeWindow(win.id)}
          onRestart={() => setRestartKey((k) => k + 1)}
          onFault={(reason) => reportProcessFault(win.pid, win.appId, reason)}
        >
          {renderApp()}
        </AppCrashBoundary>
      </div>

      {/* Full 8-Edge & Corner Resize Handles */}
      {win.snap === 'none' && (
        <>
          <div onPointerDown={(e) => startDrag(e, 'resize-n')} className="absolute top-0 left-3 right-3 h-1.5 cursor-ns-resize z-10" />
          <div onPointerDown={(e) => startDrag(e, 'resize-s')} className="absolute bottom-0 left-3 right-3 h-1.5 cursor-ns-resize z-10" />
          <div onPointerDown={(e) => startDrag(e, 'resize-w')} className="absolute top-3 bottom-3 left-0 w-1.5 cursor-ew-resize z-10" />
          <div onPointerDown={(e) => startDrag(e, 'resize-e')} className="absolute top-3 bottom-3 right-0 w-1.5 cursor-ew-resize z-10" />
          <div onPointerDown={(e) => startDrag(e, 'resize-nw')} className="absolute top-0 left-0 w-3.5 h-3.5 cursor-nwse-resize z-20" />
          <div onPointerDown={(e) => startDrag(e, 'resize-ne')} className="absolute top-0 right-0 w-3.5 h-3.5 cursor-nesw-resize z-20" />
          <div onPointerDown={(e) => startDrag(e, 'resize-sw')} className="absolute bottom-0 left-0 w-3.5 h-3.5 cursor-nesw-resize z-20" />
          <div onPointerDown={(e) => startDrag(e, 'resize-se')} className="absolute bottom-0 right-0 w-4 h-4 cursor-nwse-resize z-20" />
        </>
      )}
    </div>
  );
};
