import React, { useEffect, useState } from 'react';
import { ExternalLink, LayoutGrid, Pin, PinOff, XCircle } from 'lucide-react';
import { APP_LIST, APP_MANIFESTS } from '../os/apps';
import { useOS } from '../os/kernel';
import { AppId, PackageAppId } from '../os/types';
import { AppIcon } from './AppIcon';

export const Dock: React.FC = () => {
  const {
    windows,
    activeWindowId,
    activeWorkspace,
    setActiveWorkspace,
    launchApp,
    closeWindow,
    focusWindow,
    minimizeWindow,
    setLauncherOpen,
    installedPackages,
    settings,
    updateSettings,
  } = useOS();
  const tr = settings.language === 'tr';

  const [dockMenu, setDockMenu] = useState<{
    appId: AppId;
    x: number;
    y: number;
  } | null>(null);

  useEffect(() => {
    if (!dockMenu) return;
    const close = () => setDockMenu(null);
    window.addEventListener('click', close);
    return () => window.removeEventListener('click', close);
  }, [dockMenu]);

  const effectivePinned: AppId[] =
    settings.pinnedApps ??
    APP_LIST.filter(
      (a) => a.pinned || (a.isPackage && installedPackages.includes(a.id as PackageAppId))
    ).map((a) => a.id);

  const dockApps = APP_LIST.filter((app) => {
    const running = windows.some((w) => w.appId === app.id);
    if (app.isPackage) {
      const installed = installedPackages.includes(app.id as PackageAppId);
      return (installed && effectivePinned.includes(app.id)) || running;
    }
    return effectivePinned.includes(app.id) || running;
  });

  const handleDockClick = (appId: AppId) => {
    setDockMenu(null);
    const appWindows = windows.filter((w) => w.appId === appId);
    if (appWindows.length === 0) {
      launchApp(appId);
      return;
    }
    const activeMatch = appWindows.find(
      (w) => w.id === activeWindowId && !w.isMinimized && w.workspace === activeWorkspace
    );
    if (activeMatch) {
      minimizeWindow(activeMatch.id);
    } else {
      const target = appWindows[appWindows.length - 1];
      setActiveWorkspace(target.workspace);
      focusWindow(target.id);
    }
  };

  const togglePinApp = (appId: AppId) => {
    const isPinned = effectivePinned.includes(appId);
    const nextPinned = isPinned
      ? effectivePinned.filter((id) => id !== appId)
      : [...effectivePinned, appId];
    updateSettings({ pinnedApps: nextPinned });
    setDockMenu(null);
  };

  const closeAllAppWindows = (appId: AppId) => {
    windows.filter((w) => w.appId === appId).forEach((w) => closeWindow(w.id));
    setDockMenu(null);
  };

  const menuManifest = dockMenu ? APP_MANIFESTS[dockMenu.appId] : null;
  const menuAppWindows = dockMenu ? windows.filter((w) => w.appId === dockMenu.appId) : [];
  const menuPinned = dockMenu ? effectivePinned.includes(dockMenu.appId) : false;

  return (
    <>
      <div className="fixed bottom-3 left-1/2 -translate-x-1/2 z-50 px-2.5 py-2 rounded-2xl bg-[var(--anka-glass)] backdrop-blur-xl border border-[var(--anka-border)] shadow-2xl flex items-center gap-2 max-w-[95vw] overflow-x-auto os-scroll anka-theme-transition">
        <button
          onClick={() => setLauncherOpen((v) => !v)}
          title={tr ? 'Uygulamalar (Alt+Space)' : 'Applications (Alt+Space)'}
          className="w-10 h-10 shrink-0 rounded-xl flex items-center justify-center bg-[var(--anka-surface-elevated)] text-[var(--anka-text)] hover:scale-105 transition-transform"
        >
          <LayoutGrid size={20} />
        </button>

        <div className="h-7 w-px bg-[var(--anka-border-strong)] mx-0.5 shrink-0" />

        {dockApps.map((app) => {
          const running = windows.some((w) => w.appId === app.id);
          const isFocused = windows.some(
            (w) =>
              w.appId === app.id &&
              w.id === activeWindowId &&
              !w.isMinimized &&
              w.workspace === activeWorkspace
          );
          const label = tr ? app.nameTr : app.nameEn;

          return (
            <button
              key={app.id}
              onClick={() => handleDockClick(app.id)}
              onContextMenu={(e) => {
                e.preventDefault();
                e.stopPropagation();
                setDockMenu({
                  appId: app.id,
                  x: Math.max(12, Math.min(e.clientX - 90, window.innerWidth - 210)),
                  y: Math.max(60, window.innerHeight - 190),
                });
              }}
              title={label}
              className="group relative shrink-0 flex flex-col items-center transition-transform duration-150 hover:-translate-y-1"
            >
              <div
                style={isFocused ? { boxShadow: '0 0 0 2px var(--anka-accent)' } : undefined}
                className="rounded-xl transition-shadow"
              >
                <AppIcon appId={app.id} size={20} />
              </div>
              <span
                style={running ? { backgroundColor: 'var(--anka-accent)' } : undefined}
                className={`mt-1 w-1.5 h-1 rounded-full transition-opacity ${
                  running ? 'opacity-100' : 'opacity-0'
                }`}
              />
            </button>
          );
        })}
      </div>

      {dockMenu && menuManifest && (
        <div
          data-desktop-overlay="true"
          style={{ left: dockMenu.x, top: dockMenu.y }}
          onClick={(e) => e.stopPropagation()}
          className="fixed z-50 w-48 rounded-xl border border-[var(--anka-border)] bg-[var(--anka-glass)] backdrop-blur-xl shadow-2xl p-1.5 text-xs text-[var(--anka-text)] space-y-0.5"
        >
          <div className="px-2.5 py-1 text-[11px] font-semibold text-[var(--anka-text-subtle)] truncate">
            {tr ? menuManifest.nameTr : menuManifest.nameEn}
          </div>
          <div className="h-px bg-[var(--anka-border)] my-0.5" />

          {(!menuManifest.singleton || menuAppWindows.length === 0) && (
            <button
              onClick={() => {
                launchApp(dockMenu.appId);
                setDockMenu(null);
              }}
              className="w-full flex items-center gap-2 px-2.5 py-1.5 rounded-lg hover:bg-[var(--anka-surface-elevated)] text-left"
            >
              <ExternalLink size={13} className="text-[var(--anka-accent)]" />
              <span>{tr ? 'Yeni Pencere' : 'New Window'}</span>
            </button>
          )}

          <button
            onClick={() => togglePinApp(dockMenu.appId)}
            className="w-full flex items-center gap-2 px-2.5 py-1.5 rounded-lg hover:bg-[var(--anka-surface-elevated)] text-left"
          >
            {menuPinned ? <PinOff size={13} /> : <Pin size={13} />}
            <span>
              {menuPinned
                ? tr
                  ? "Dock'tan Kaldır"
                  : 'Unpin from Dock'
                : tr
                  ? "Dock'a Sabitle"
                  : 'Pin to Dock'}
            </span>
          </button>

          {menuAppWindows.length > 0 && (
            <>
              <div className="h-px bg-[var(--anka-border)] my-0.5" />
              <button
                onClick={() => closeAllAppWindows(dockMenu.appId)}
                className="w-full flex items-center gap-2 px-2.5 py-1.5 rounded-lg hover:bg-rose-500/10 text-rose-500 text-left"
              >
                <XCircle size={13} />
                <span>
                  {tr
                    ? `Tüm Pencereleri Kapat (${menuAppWindows.length})`
                    : `Close All Windows (${menuAppWindows.length})`}
                </span>
              </button>
            </>
          )}
        </div>
      )}
    </>
  );
};
