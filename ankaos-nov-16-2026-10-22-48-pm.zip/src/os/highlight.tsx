import React from 'react';

export type HighlightLanguage = 'js' | 'json' | 'html' | 'sh' | 'css' | 'md' | 'wat' | 'text';

export function detectLanguageFromPath(filePath: string): HighlightLanguage {
  const lower = filePath.toLowerCase();
  if (/\.(js|mjs|cjs|ts|tsx|jsx)$/.test(lower)) return 'js';
  if (lower.endsWith('.wat') || lower.endsWith('.wast')) return 'wat';
  if (lower.endsWith('.json') || lower.endsWith('.ankawasm')) return 'json';
  if (/\.(html?|xml|svg)$/.test(lower)) return 'html';
  if (/\.(sh|ankashrc|conf|env)$/.test(lower) || lower.endsWith('os-release')) return 'sh';
  if (lower.endsWith('.css')) return 'css';
  if (lower.endsWith('.md')) return 'md';
  return 'text';
}

interface TokenRule {
  regex: RegExp;
  className: string;
}

const JS_RULES: TokenRule[] = [
  { regex: /\/\/[^\n]*|\/\*[\s\S]*?\*\//, className: 'text-[var(--anka-text-subtle)] italic' },
  { regex: /`(?:\\[\s\S]|[^`\\])*`|"(?:\\.|[^"\\])*"|'(?:\\.|[^'\\])*'/, className: 'text-emerald-600 dark:text-emerald-400' },
  {
    regex: /\b(?:const|let|var|function|return|if|else|for|while|do|switch|case|break|continue|new|try|catch|finally|throw|async|await|import|export|from|default|class|extends|typeof|instanceof|true|false|null|undefined)\b/,
    className: 'text-sky-600 dark:text-sky-400 font-semibold',
  },
  {
    regex: /\b(?:console|Math|JSON|Array|Object|String|Number|Boolean|Promise|WebAssembly|Date|Set|Map)\b/,
    className: 'text-amber-600 dark:text-amber-300',
  },
  { regex: /\b\d+(?:\.\d+)?\b/, className: 'text-rose-600 dark:text-rose-400' },
];

const JSON_RULES: TokenRule[] = [
  { regex: /"(?:\\.|[^"\\])*"(?=\s*:)/, className: 'text-sky-600 dark:text-sky-400 font-medium' },
  { regex: /"(?:\\.|[^"\\])*"/, className: 'text-emerald-600 dark:text-emerald-400' },
  { regex: /\b(?:true|false|null)\b/, className: 'text-amber-600 dark:text-amber-400 font-semibold' },
  { regex: /-?\b\d+(?:\.\d+)?\b/, className: 'text-rose-600 dark:text-rose-400' },
];

const HTML_RULES: TokenRule[] = [
  { regex: /<!--[\s\S]*?-->/, className: 'text-[var(--anka-text-subtle)] italic' },
  { regex: /<\/?[a-zA-Z0-9-]+|\/?>/, className: 'text-sky-600 dark:text-sky-400 font-medium' },
  { regex: /"(?:\\.|[^"\\])*"|'(?:\\.|[^'\\])*'/, className: 'text-emerald-600 dark:text-emerald-400' },
  { regex: /\b[a-zA-Z-:]+(?==)/, className: 'text-amber-600 dark:text-amber-300' },
];

const SH_RULES: TokenRule[] = [
  { regex: /#[^\n]*/, className: 'text-[var(--anka-text-subtle)] italic' },
  { regex: /"(?:\\.|[^"\\])*"|'(?:\\.|[^'\\])*'/, className: 'text-emerald-600 dark:text-emerald-400' },
  {
    regex: /\b(?:echo|alias|unalias|export|cd|ls|cat|mkdir|touch|rm|cp|mv|chmod|sudo|su|if|then|else|fi|for|do|done|run|wasmrun|snapshot|uname|uptime|free|vmstat|ps|kill|pkg|selftest)\b/,
    className: 'text-sky-600 dark:text-sky-400 font-semibold',
  },
  { regex: /\$[A-Za-z_][A-Za-z0-9_]*/, className: 'text-amber-600 dark:text-amber-300' },
  { regex: /&&|\|\||\||>>|>/, className: 'text-rose-600 dark:text-rose-400 font-semibold' },
];

const CSS_RULES: TokenRule[] = [
  { regex: /\/\*[\s\S]*?\*\//, className: 'text-[var(--anka-text-subtle)] italic' },
  { regex: /"(?:\\.|[^"\\])*"|'(?:\\.|[^'\\])*'/, className: 'text-emerald-600 dark:text-emerald-400' },
  { regex: /--[a-zA-Z0-9-]+|#[0-9a-fA-F]{3,8}\b/, className: 'text-amber-600 dark:text-amber-300' },
  { regex: /[.#]?[a-zA-Z_-][a-zA-Z0-9_-]*(?=\s*\{)/, className: 'text-sky-600 dark:text-sky-400 font-semibold' },
];

const MD_RULES: TokenRule[] = [
  { regex: /^#{1,6}[^\n]*/m, className: 'text-sky-600 dark:text-sky-400 font-bold' },
  { regex: /`[^`\n]+`/, className: 'text-emerald-600 dark:text-emerald-400' },
  { regex: /\*\*[^*\n]+\*\*/, className: 'text-amber-600 dark:text-amber-300 font-semibold' },
];

const WAT_RULES: TokenRule[] = [
  { regex: /;;[^\n]*|\(;[\s\S]*?;\)/, className: 'text-[var(--anka-text-subtle)] italic' },
  { regex: /"(?:\\.|[^"\\])*"/, className: 'text-emerald-600 dark:text-emerald-400' },
  {
    regex: /\b(?:module|func|param|result|local|export|import|memory|data|offset|block|loop|if|then|else|end|br|br_if|call|return|drop|select|nop|unreachable)\b/,
    className: 'text-sky-600 dark:text-sky-400 font-semibold',
  },
  {
    regex: /\b(?:i32|i64|f32|f64|local|global)\.[a-z0-9_]+|\b(?:i32|i64|f32|f64)\b/,
    className: 'text-amber-600 dark:text-amber-300 font-medium',
  },
  { regex: /\$[A-Za-z_][A-Za-z0-9_.-]*/, className: 'text-indigo-600 dark:text-indigo-300' },
  { regex: /\b0x[0-9a-fA-F_]+\b|-?\b\d+(?:\.\d+)?\b/, className: 'text-rose-600 dark:text-rose-400' },
];

function getRulesForLang(lang: HighlightLanguage): TokenRule[] {
  switch (lang) {
    case 'js':
      return JS_RULES;
    case 'json':
      return JSON_RULES;
    case 'html':
      return HTML_RULES;
    case 'sh':
      return SH_RULES;
    case 'css':
      return CSS_RULES;
    case 'md':
      return MD_RULES;
    case 'wat':
      return WAT_RULES;
    default:
      return [];
  }
}

export function highlightCode(code: string, lang: HighlightLanguage): React.ReactNode {
  const rules = getRulesForLang(lang);
  if (rules.length === 0 || !code) {
    return code + (code.endsWith('\n') ? ' ' : '');
  }

  const combined = new RegExp(
    rules.map((r, idx) => `(?<t${idx}>${r.regex.source})`).join('|'),
    'gm'
  );

  const nodes: React.ReactNode[] = [];
  let lastIdx = 0;
  let match: RegExpExecArray | null;
  let keyCounter = 0;

  while ((match = combined.exec(code)) !== null) {
    if (match.index > lastIdx) {
      nodes.push(code.slice(lastIdx, match.index));
    }
    const groups = match.groups || {};
    let cls = '';
    for (let i = 0; i < rules.length; i++) {
      if (groups[`t${i}`] !== undefined) {
        cls = rules[i].className;
        break;
      }
    }
    nodes.push(
      <span key={keyCounter++} className={cls}>
        {match[0]}
      </span>
    );
    lastIdx = match.index + match[0].length;
    if (match[0].length === 0) {
      combined.lastIndex++;
    }
  }

  if (lastIdx < code.length) {
    nodes.push(code.slice(lastIdx));
  }
  // Ensure trailing newline renders with full line height inside <pre>
  if (code.endsWith('\n')) {
    nodes.push(' ');
  }
  return nodes;
}
