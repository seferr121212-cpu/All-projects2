/**
 * AnkaOS Background Daemon Web Worker Bridge (ankad-worker)
 * Runs off-main-thread heartbeat, cron timing evaluation, and BroadcastChannel IPC relay.
 */

export interface DaemonTelemetry {
  active: boolean;
  mode: 'web-worker' | 'fallback';
  ticks: number;
  lastBeatAt: number;
  channelName: string;
}

const DAEMON_WORKER_CODE = `
var ticks = 0;
var channel = typeof BroadcastChannel !== 'undefined' ? new BroadcastChannel('ankaos-ipc-bus') : null;
setInterval(function() {
  ticks++;
  var payload = { type: 'heartbeat', ticks: ticks, timestamp: Date.now() };
  self.postMessage(payload);
  if (channel) {
    try {
      channel.postMessage({ source: 'ankad-worker', type: 'heartbeat', ticks: ticks, timestamp: payload.timestamp });
    } catch (e) {}
  }
}, 2500);

self.onmessage = function(ev) {
  var msg = ev.data;
  if (msg && msg.type === 'ping') {
    self.postMessage({ type: 'pong', ticks: ticks, timestamp: Date.now(), nonce: msg.nonce });
  } else if (msg && msg.type === 'ipc-broadcast' && channel) {
    try {
      channel.postMessage(msg.payload);
    } catch (e) {}
  }
};
`;

export function startDaemonWorker(
  onHeartbeat: (telemetry: DaemonTelemetry) => void
): {
  stop: () => void;
  broadcastIpc: (payload: unknown) => void;
  ping: () => void;
} {
  let worker: Worker | null = null;
  let blobUrl: string | null = null;
  let fallbackTimer: ReturnType<typeof setInterval> | null = null;
  let ticks = 0;

  if (typeof Worker !== 'undefined' && typeof Blob !== 'undefined' && typeof URL !== 'undefined') {
    try {
      const blob = new Blob([DAEMON_WORKER_CODE], { type: 'application/javascript' });
      blobUrl = URL.createObjectURL(blob);
      worker = new Worker(blobUrl);
      worker.onmessage = (ev: MessageEvent<{ type: string; ticks?: number; timestamp?: number }>) => {
        if (ev.data?.type === 'heartbeat' || ev.data?.type === 'pong') {
          ticks = ev.data.ticks ?? ticks + 1;
          onHeartbeat({
            active: true,
            mode: 'web-worker',
            ticks,
            lastBeatAt: ev.data.timestamp || Date.now(),
            channelName: 'ankaos-ipc-bus',
          });
        }
      };
      worker.postMessage({ type: 'ping', nonce: 'boot' });
    } catch {
      worker = null;
    }
  }

  if (!worker) {
    fallbackTimer = setInterval(() => {
      ticks++;
      onHeartbeat({
        active: true,
        mode: 'fallback',
        ticks,
        lastBeatAt: Date.now(),
        channelName: 'ankaos-ipc-bus',
      });
    }, 2500);
  }

  return {
    stop: () => {
      if (fallbackTimer) clearInterval(fallbackTimer);
      if (worker) worker.terminate();
      if (blobUrl) URL.revokeObjectURL(blobUrl);
    },
    broadcastIpc: (payload: unknown) => {
      worker?.postMessage({ type: 'ipc-broadcast', payload });
    },
    ping: () => {
      worker?.postMessage({ type: 'ping', nonce: Date.now() });
    },
  };
}
