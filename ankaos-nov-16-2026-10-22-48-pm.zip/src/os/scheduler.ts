import { OSProcess, SchedulerStats } from './types';

export const SCHEDULER_QUANTUM_MS = 100;
const FOREGROUND_PRIORITY_BOOST = -8;

export function createInitialSchedulerStats(): SchedulerStats {
  return {
    quantumMs: SCHEDULER_QUANTUM_MS,
    totalTicks: 0,
    contextSwitches: 0,
    preemptions: 0,
    foregroundBoostActive: false,
    activePid: 1,
    readyQueueCount: 0,
  };
}

/**
 * Computes effective scheduling priority.
 * Active foreground UI windows receive a dynamic priority boost so user interactions
 * preempt lower-priority background workers without starving Ring 0 kernel daemons.
 */
export function getEffectivePriority(proc: OSProcess, activeWindowPid: number | null): number {
  const isForeground = activeWindowPid !== null && proc.pid === activeWindowPid;
  return proc.priority + (isForeground ? FOREGROUND_PRIORITY_BOOST : 0);
}

/**
 * Preemptive Priority Scheduler tick.
 * Preserves existing function signature while upgrading from passive round-robin to
 * preemptive priority dispatch: higher effective-priority runnable tasks (including the
 * foreground UI process) immediately preempt lower-priority tasks on tick boundaries.
 */
export function stepScheduler(
  processes: OSProcess[],
  prevStats: SchedulerStats,
  activeWindowPid: number | null,
  quantumMs = SCHEDULER_QUANTUM_MS
): { processes: OSProcess[]; stats: SchedulerStats } {
  // Bellek sızıntısı önlemi: Geçici kuyruk dizisi yalnızca bu tick kapsamında tutulur, global referans biriktirmez.
  const runnable = processes.filter((p) => p.state === 'running');
  if (runnable.length === 0) {
    return {
      processes,
      stats: {
        ...prevStats,
        quantumMs,
        totalTicks: prevStats.totalTicks + 1,
        foregroundBoostActive: false,
        readyQueueCount: 0,
      },
    };
  }

  // Sort strictly by lowest effective priority first (Unix convention: -20 highest, 19 lowest)
  const prioritized = [...runnable].sort((a, b) => {
    const effA = getEffectivePriority(a, activeWindowPid);
    const effB = getEffectivePriority(b, activeWindowPid);
    return effA - effB || a.pid - b.pid;
  });

  const highestPriority = getEffectivePriority(prioritized[0], activeWindowPid);
  const topPriorityBand = prioritized.filter(
    (p) => getEffectivePriority(p, activeWindowPid) === highestPriority
  );

  // Within the highest priority band, rotate fairly in round-robin order
  const currentInBandIdx = topPriorityBand.findIndex((p) => p.pid === prevStats.activePid);
  const nextProc = topPriorityBand[(currentInBandIdx + 1) % topPriorityBand.length];

  const prevRunning = runnable.find((p) => p.pid === prevStats.activePid);
  const preempted = Boolean(
    prevRunning &&
      nextProc.pid !== prevRunning.pid &&
      getEffectivePriority(nextProc, activeWindowPid) <
        getEffectivePriority(prevRunning, activeWindowPid)
  );
  const switched = nextProc.pid !== prevStats.activePid;
  const foregroundBoostActive = activeWindowPid !== null && nextProc.pid === activeWindowPid;

  // Deterministic CPU load distribution weighted by effective priority & foreground state
  const weights = processes.map((p) => {
    if (p.state === 'stopped') return 0;
    if (p.state !== 'running') return 0.1;
    const eff = getEffectivePriority(p, activeWindowPid);
    const niceFactor = Math.max(0.25, (28 - eff) / 20);
    const focusBoost = p.pid === activeWindowPid ? 2.4 : 1.0;
    const kindFactor = p.isSystem ? 0.35 : 1.25;
    return niceFactor * focusBoost * kindFactor;
  });

  const totalWeight = Math.max(1, weights.reduce((a, b) => a + b, 0));
  const systemLoadBudget = Math.min(86, 4 + runnable.length * 2.8);

  const updatedProcesses = processes.map((p, idx) => {
    if (p.state === 'stopped') {
      return {
        ...p,
        isForeground: false,
        cpu: 0,
      };
    }
    const share = (weights[idx] / totalWeight) * systemLoadBudget;
    const cpuPct = Math.max(0.1, Number(share.toFixed(1)));
    const deltaMs = p.pid === nextProc.pid ? quantumMs : p.state === 'running' ? 16 : 2;
    return {
      ...p,
      isForeground: activeWindowPid !== null && p.pid === activeWindowPid,
      cpu: cpuPct,
      cpuTimeMs: p.cpuTimeMs + deltaMs,
    };
  });

  return {
    processes: updatedProcesses,
    stats: {
      quantumMs,
      totalTicks: prevStats.totalTicks + 1,
      contextSwitches: prevStats.contextSwitches + (switched ? 1 : 0),
      preemptions: prevStats.preemptions + (preempted ? 1 : 0),
      foregroundBoostActive,
      activePid: nextProc.pid,
      readyQueueCount: Math.max(0, runnable.length - 1),
    },
  };
}
