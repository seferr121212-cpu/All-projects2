/**
 * AnkaOS IndexedDB Large Object & Snapshot Persistence Layer
 * Supplements localStorage (~5 MB cap) for large VFS trees, WASM binaries, and snapshots.
 */

const DB_NAME = 'ankaos-idb-v1';
const DB_VERSION = 1;
const STORE_NAME = 'kv';

function openAnkaDB(): Promise<IDBDatabase | null> {
  if (typeof indexedDB === 'undefined') return Promise.resolve(null);
  return new Promise((resolve) => {
    try {
      const req = indexedDB.open(DB_NAME, DB_VERSION);
      req.onupgradeneeded = () => {
        const db = req.result;
        if (!db.objectStoreNames.contains(STORE_NAME)) {
          db.createObjectStore(STORE_NAME);
        }
      };
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => resolve(null);
    } catch {
      resolve(null);
    }
  });
}

export async function idbPut(key: string, value: string): Promise<boolean> {
  const db = await openAnkaDB();
  if (!db) return false;
  return new Promise((resolve) => {
    try {
      const tx = db.transaction(STORE_NAME, 'readwrite');
      tx.objectStore(STORE_NAME).put(value, key);
      tx.oncomplete = () => {
        db.close();
        resolve(true);
      };
      tx.onerror = () => {
        db.close();
        resolve(false);
      };
    } catch {
      db.close();
      resolve(false);
    }
  });
}

export async function idbGet(key: string): Promise<string | null> {
  const db = await openAnkaDB();
  if (!db) return null;
  return new Promise((resolve) => {
    try {
      const tx = db.transaction(STORE_NAME, 'readonly');
      const req = tx.objectStore(STORE_NAME).get(key);
      req.onsuccess = () => {
        const val = typeof req.result === 'string' ? req.result : null;
        db.close();
        resolve(val);
      };
      req.onerror = () => {
        db.close();
        resolve(null);
      };
    } catch {
      db.close();
      resolve(null);
    }
  });
}

export async function idbDelete(key: string): Promise<boolean> {
  const db = await openAnkaDB();
  if (!db) return false;
  return new Promise((resolve) => {
    try {
      const tx = db.transaction(STORE_NAME, 'readwrite');
      tx.objectStore(STORE_NAME).delete(key);
      tx.oncomplete = () => {
        db.close();
        resolve(true);
      };
      tx.onerror = () => {
        db.close();
        resolve(false);
      };
    } catch {
      db.close();
      resolve(false);
    }
  });
}

export async function idbEstimateStorage(): Promise<{
  supported: boolean;
  usedBytes: number;
  quotaBytes: number;
}> {
  const supported = typeof indexedDB !== 'undefined';
  if (typeof navigator !== 'undefined' && navigator.storage?.estimate) {
    try {
      const est = await navigator.storage.estimate();
      return {
        supported,
        usedBytes: est.usage || 0,
        quotaBytes: est.quota || 0,
      };
    } catch {
      // fallback
    }
  }
  return { supported, usedBytes: 0, quotaBytes: 0 };
}
