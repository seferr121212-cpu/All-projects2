import { CronJob, PowerProfile, SystemServiceUnit } from './types';

export const POWER_PROFILE_META: Record<
  PowerProfile,
  { quantumMs: number; labelTr: string; labelEn: string; descTr: string; descEn: string }
> = {
  performance: {
    quantumMs: 25,
    labelTr: 'Yüksek Performans',
    labelEn: 'High Performance',
    descTr: '25 ms zamanlayıcı kuantumu ile maksimum tepki hızı',
    descEn: '25 ms scheduler quantum for peak responsiveness',
  },
  balanced: {
    quantumMs: 50,
    labelTr: 'Dengeli',
    labelEn: 'Balanced',
    descTr: '50 ms zamanlayıcı kuantumu ile verimli denge',
    descEn: '50 ms scheduler quantum for balanced workload',
  },
  powersaver: {
    quantumMs: 100,
    labelTr: 'Güç Tasarrufu',
    labelEn: 'Power Saver',
    descTr: '100 ms kuantum ile daha az bağlam değişimi',
    descEn: '100 ms quantum to reduce context switches',
  },
};

export function createInitialServices(): SystemServiceUnit[] {
  const now = Date.now();
  return [
    {
      name: 'anka-init',
      descriptionTr: 'Çekirdek başlatıcı & süreç gözetmeni (PID 1)',
      descriptionEn: 'Kernel init & process supervisor (PID 1)',
      status: 'active',
      pid: 1,
      essential: true,
      restarts: 0,
      lastChangedAt: now,
    },
    {
      name: 'vfsd',
      descriptionTr: 'Sanal Dosya Sistemi ve Async I/O eşitleyici',
      descriptionEn: 'Virtual Filesystem & Async I/O sync daemon',
      status: 'active',
      pid: 12,
      essential: true,
      restarts: 0,
      lastChangedAt: now,
    },
    {
      name: 'ankawm',
      descriptionTr: 'Double-Buffered Masaüstü Kompozitörü',
      descriptionEn: 'Double-Buffered Desktop Compositor',
      status: 'active',
      pid: 24,
      essential: true,
      restarts: 0,
      lastChangedAt: now,
    },
    {
      name: 'netd',
      descriptionTr: 'AnkaNet Ağ Yığını & DNS/Proxy Köprüsü',
      descriptionEn: 'AnkaNet Stack & DNS/Proxy Bridge',
      status: 'active',
      pid: 72,
      restarts: 0,
      lastChangedAt: now,
    },
    {
      name: 'crond',
      descriptionTr: 'Periyodik Zamanlanmış Görev Yürütücüsü',
      descriptionEn: 'Periodic Scheduled Task Runner',
      status: 'active',
      pid: 80,
      restarts: 0,
      lastChangedAt: now,
    },
    {
      name: 'audiod',
      descriptionTr: 'WebAudio Ses Mikseri Servisi',
      descriptionEn: 'WebAudio Mixer Daemon',
      status: 'active',
      pid: 64,
      restarts: 0,
      lastChangedAt: now,
    },
    {
      name: 'pkgd',
      descriptionTr: 'Paket Merkezi & .ankawasm Doğrulama Servisi',
      descriptionEn: 'Package Center & .ankawasm Verifier',
      status: 'active',
      pid: 88,
      restarts: 0,
      lastChangedAt: now,
    },
  ];
}

export function controlServiceUnit(
  services: SystemServiceUnit[],
  name: string,
  action: 'start' | 'stop' | 'restart'
): { services: SystemServiceUnit[]; ok: boolean; message: string; unit?: SystemServiceUnit } {
  const idx = services.findIndex((s) => s.name === name);
  if (idx === -1) {
    return { services, ok: false, message: `Servis bulunamadı: ${name}` };
  }
  const target = services[idx];
  if (action === 'stop' && target.essential) {
    return {
      services,
      ok: false,
      message: `Kritik çekirdek servisi durdurulamaz: ${target.name}`,
    };
  }

  const now = Date.now();
  let updated: SystemServiceUnit;
  if (action === 'stop') {
    updated = { ...target, status: 'inactive', lastChangedAt: now };
  } else if (action === 'start') {
    updated = {
      ...target,
      status: 'active',
      pid: target.pid ?? 80 + idx * 4,
      lastChangedAt: now,
    };
  } else {
    updated = {
      ...target,
      status: 'active',
      pid: target.pid ?? 80 + idx * 4,
      restarts: target.restarts + 1,
      lastChangedAt: now,
    };
  }

  const next = services.map((s, i) => (i === idx ? updated : s));
  const verb = action === 'start' ? 'başlatıldı' : action === 'stop' ? 'durduruldu' : 'yeniden başlatıldı';
  return {
    services: next,
    ok: true,
    unit: updated,
    message: `[ankactl] ${updated.name} ${verb} (durum: ${updated.status})`,
  };
}

export function createInitialCronJobs(): CronJob[] {
  return [
    {
      id: 'cron-sys-health',
      name: 'Sistem Bellek & VFS Denetimi',
      intervalSec: 60,
      command: 'fsck --quick',
      enabled: true,
      runCount: 0,
      lastRunAt: null,
      lastResult: 'Bekliyor',
    },
    {
      id: 'cron-net-heartbeat',
      name: 'Çekirdek Log Döndürme (/var/log)',
      intervalSec: 120,
      command: 'logrotate /var/log/kernel.log',
      enabled: true,
      runCount: 0,
      lastRunAt: null,
      lastResult: 'Bekliyor',
    },
  ];
}

export function createCronJob(name: string, intervalSec: number, command: string): CronJob {
  return {
    id: `cron-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
    name: name.trim() || command.slice(0, 28),
    intervalSec: Math.max(5, Math.min(3600, Math.round(intervalSec) || 30)),
    command: command.trim(),
    enabled: true,
    runCount: 0,
    lastRunAt: null,
    lastResult: 'Zamanlandı',
  };
}
