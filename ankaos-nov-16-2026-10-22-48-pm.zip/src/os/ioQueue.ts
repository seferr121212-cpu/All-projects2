import { IOQueuePriority, IOQueueStats, IOQueueTask } from './types';

interface InternalQueueEntry {
  task: IOQueueTask;
  work: () => Promise<void> | void;
  resolve: () => void;
  reject: (err: unknown) => void;
}

const PRIORITY_WEIGHT: Record<IOQueuePriority, number> = {
  high: 0,
  normal: 1,
  low: 2,
};

/**
 * Non-blocking prioritized Asynchronous I/O Queue.
 * Decouples disk/IndexedDB/VFS block I/O from the main UI thread so interactive frames never stall.
 */
export class AsyncIOQueue {
  private pending: InternalQueueEntry[] = [];
  private history: IOQueueTask[] = [];
  private isDraining = false;
  private processingCount = 0;
  private completedCount = 0;
  private totalLatencyMs = 0;
  private readonly maxHistory = 32;

  enqueue(
    op: IOQueueTask['op'],
    path: string,
    work: () => Promise<void> | void,
    priority: IOQueuePriority = 'normal'
  ): Promise<void> {
    return new Promise((resolve, reject) => {
      const task: IOQueueTask = {
        id: `io-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
        op,
        path,
        priority,
        status: 'queued',
        enqueuedAt: Date.now(),
      };

      this.pending.push({ task, work, resolve, reject });
      this.pending.sort((a, b) => PRIORITY_WEIGHT[a.task.priority] - PRIORITY_WEIGHT[b.task.priority]);

      // Schedule non-blocking drain on microtask / macrotask boundary
      if (!this.isDraining) {
        this.scheduleDrain();
      }
    });
  }

  private scheduleDrain(): void {
    this.isDraining = true;
    const trigger =
      typeof queueMicrotask === 'function'
        ? queueMicrotask
        : (fn: () => void) => setTimeout(fn, 0);

    trigger(() => {
      void this.drain();
    });
  }

  private async drain(): Promise<void> {
    while (this.pending.length > 0) {
      const entry = this.pending.shift()!;
      entry.task.status = 'processing';
      this.processingCount = 1;
      const start = performance.now ? performance.now() : Date.now();

      try {
        await entry.work();
        const end = performance.now ? performance.now() : Date.now();
        const latency = Math.max(0.1, Number((end - start).toFixed(2)));
        entry.task.status = 'done';
        entry.task.completedAt = Date.now();
        entry.task.latencyMs = latency;
        this.completedCount += 1;
        this.totalLatencyMs += latency;
        entry.resolve();
      } catch (err) {
        entry.task.status = 'error';
        entry.task.completedAt = Date.now();
        entry.reject(err);
      } finally {
        this.processingCount = 0;
        // Bellek sızıntısı önlemi: Tamamlanan görevlerin closure (`work`) referansları kuyruktan çıkarılır
        // ve geçmiş listesi sabit halka tamponu (maxHistory) ile sınırlandırılır.
        this.history.unshift(entry.task);
        if (this.history.length > this.maxHistory) {
          this.history.length = this.maxHistory;
        }
      }
    }
    this.isDraining = false;
  }

  getStats(): IOQueueStats {
    return {
      queuedCount: this.pending.length,
      processingCount: this.processingCount,
      completedCount: this.completedCount,
      avgLatencyMs:
        this.completedCount > 0
          ? Number((this.totalLatencyMs / this.completedCount).toFixed(2))
          : 0,
    };
  }

  getTasks(): IOQueueTask[] {
    return [...this.pending.map((p) => p.task), ...this.history];
  }

  clearCompleted(): void {
    this.history = [];
  }
}

export const systemIOQueue = new AsyncIOQueue();
