import { OSUser, VFSNode } from './types';

const SALT = 'ankaos-v2-salt::';

export async function hashPassword(password: string): Promise<string> {
  if (!password) return '';
  const data = new TextEncoder().encode(SALT + password);
  if (typeof crypto !== 'undefined' && crypto.subtle) {
    const digest = await crypto.subtle.digest('SHA-256', data);
    return Array.from(new Uint8Array(digest))
      .map((b) => b.toString(16).padStart(2, '0'))
      .join('');
  }
  let h = 2166136261;
  for (let i = 0; i < data.length; i++) {
    h ^= data[i];
    h = Math.imul(h, 16777619);
  }
  return (h >>> 0).toString(16).padStart(8, '0');
}

export async function verifyPassword(user: OSUser, candidate: string): Promise<boolean> {
  if (user.passwordHash === null) return true;
  const candidateHash = await hashPassword(candidate);
  return candidateHash === user.passwordHash;
}

export function createInitialUsers(): OSUser[] {
  return [
    {
      uid: 1000,
      username: 'kullanici',
      fullName: 'Kullanıcı',
      homeDir: '/home/kullanici',
      shell: '/bin/ankash',
      isAdmin: true,
      passwordHash: null,
    },
    {
      uid: 0,
      username: 'root',
      fullName: 'Sistem Yöneticisi',
      homeDir: '/root',
      shell: '/bin/ankash',
      isAdmin: true,
      passwordHash: null,
    },
  ];
}

export async function createUserAccount(
  existingUsers: OSUser[],
  username: string,
  fullName: string,
  password: string | null,
  isAdmin = false
): Promise<OSUser> {
  const clean = username.trim().toLowerCase().replace(/[^a-z0-9_-]/g, '');
  const maxUid = existingUsers.reduce((m, u) => Math.max(m, u.uid), 1000);
  return {
    uid: maxUid + 1,
    username: clean || `user${maxUid + 1}`,
    fullName: fullName.trim() || clean,
    homeDir: `/home/${clean}`,
    shell: '/bin/ankash',
    isAdmin,
    passwordHash: password ? await hashPassword(password) : null,
  };
}

export function canWriteNode(
  node: VFSNode | null,
  username: string,
  elevatedRoot = false
): boolean {
  if (elevatedRoot || username === 'root') return true;
  if (!node) return true;
  const perms = node.permissions || '-rw-r--r--';
  if (node.owner === username) {
    return perms[2] === 'w';
  }
  return perms[8] === 'w';
}

export function canReadNode(
  node: VFSNode | null,
  username: string,
  elevatedRoot = false
): boolean {
  if (elevatedRoot || username === 'root') return true;
  if (!node) return false;
  const perms = node.permissions || '-rw-r--r--';
  if (node.owner === username) {
    return perms[1] === 'r';
  }
  return perms[7] === 'r';
}

export function canExecuteNode(
  node: VFSNode | null,
  username: string,
  elevatedRoot = false
): boolean {
  if (elevatedRoot || username === 'root') return true;
  if (!node || node.type === 'dir') return false;
  const perms = node.permissions || '-rw-r--r--';
  if (node.owner === username) {
    return perms[3] === 'x';
  }
  return perms[9] === 'x';
}

export function applyChmod(currentPerms: string, modeArg: string): string | null {
  const isDir = currentPerms.startsWith('d');
  const prefix = isDir ? 'd' : '-';

  if (/^[0-7]{3}$/.test(modeArg)) {
    const mapDigit = (d: string) => {
      const n = Number(d);
      return `${n & 4 ? 'r' : '-'}${n & 2 ? 'w' : '-'}${n & 1 ? 'x' : '-'}`;
    };
    return prefix + mapDigit(modeArg[0]) + mapDigit(modeArg[1]) + mapDigit(modeArg[2]);
  }

  if (modeArg === '+x') {
    const chars = currentPerms.split('');
    chars[3] = 'x';
    chars[6] = 'x';
    chars[9] = 'x';
    return chars.join('');
  }
  if (modeArg === '-x') {
    const chars = currentPerms.split('');
    chars[3] = '-';
    chars[6] = '-';
    chars[9] = '-';
    return chars.join('');
  }
  if (modeArg === '-w') {
    const chars = currentPerms.split('');
    chars[2] = '-';
    chars[5] = '-';
    chars[8] = '-';
    return chars.join('');
  }
  if (modeArg === '+w') {
    const chars = currentPerms.split('');
    chars[2] = 'w';
    return chars.join('');
  }
  return null;
}
