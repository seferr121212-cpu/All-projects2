import React, { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState } from 'react';
import { APP_MANIFESTS } from './apps';
import { createInitialUsers, createUserAccount, hashPassword, verifyPassword } from './auth';
import { DaemonTelemetry, startDaemonWorker } from './daemonWorker';
import { WALLPAPERS } from './i18n';
import { idbGet, idbPut } from './idbStorage';
import { systemIOQueue } from './ioQueue';
import { ipcBus } from './ipc';
import {
  allocateFramesForProcess,
  createInitialFrames,
  createInitialSwap,
  forkFramesCopyOnWrite,
  freeFramesForProcess,
  freeSwapForProcess,
  getMemorySummary,
  handleCowPageFault,
  swapOutLRUFrames,
} from './mmu';
import { createAnkaArchive, extractAnkaArchive, runVfsFsck } from './archive';
import { createInitialNetworkInterfaces, fetchNetStatus, LiveNetStatus } from './net';
import { DEFAULT_INSTALLED_PACKAGES, PACKAGE_REGISTRY } from './packages';
import { createInitialSchedulerStats, stepScheduler } from './scheduler';
import {
  assertKernelAccess,
  checkSandboxSyscall,
  generateASLRLayout,
  getAppSandboxDir,
} from './security';
import {
  controlServiceUnit,
  createCronJob,
  createInitialCronJobs,
  createInitialServices,
  POWER_PROFILE_META,
} from './services';
import { applyThemePalette, ACCENT_PALETTES } from './theme';
import {
  AppId,
  BackgroundJob,
  BootPhase,
  ClipboardItem,
  CompositorStats,
  CronJob,
  FsckReport,
  IOQueueStats,
  IOQueueTask,
  KernelLogEntry,
  MemoryFrame,
  MetricSample,
  NetworkInterface,
  OSNotification,
  OSProcess,
  OSSettings,
  OSUser,
  OSWindow,
  PackageAppId,
  PowerProfile,
  SandboxPermissionRequest,
  SchedulerStats,
  SwapSlot,
  SyscallRecord,
  SystemServiceUnit,
  VFSNode,
  WindowSnap,
  WorkspaceId,
} from './types';
import {
  createInitialVFS,
  getNodeAtPath,
  HOME_PATH,
  loadVFS,
  normalizePath,
  provisionUserHome,
  saveVFS,
  vfsChmod,
  vfsCopy,
  vfsDelete,
  vfsEmptyTrash,
  vfsEnsureDir,
  vfsMkdir,
  vfsMoveNode,
  vfsMoveToTrash,
  vfsRename,
  vfsRestoreFromTrash,
  vfsWriteFile,
} from './vfs';

const SETTINGS_STORAGE_KEY = 'ankaos_settings_v2';
const USERS_STORAGE_KEY = 'ankaos_users_v2';
const PKGS_STORAGE_KEY = 'ankaos_pkgs_v2';
const ACTIVE_USER_STORAGE_KEY = 'ankaos_active_user_v1';

const DEFAULT_SETTINGS: OSSettings = {
  theme: 'dark',
  wallpaperId: WALLPAPERS[0].id,
  accent: 'sky',
  language: 'tr',
  showDesktopIcons: true,
  userName: 'Kullanıcı',
  volume: 65,
  muted: false,
  doNotDisturb: false,
  sandboxGrants: {
    editor: ['docs:rw'],
    paint: ['docs:rw'],
    notes: ['docs:rw'],
    browser: ['docs:rw'],
    'wasm-builder': ['docs:rw'],
  },
};

function loadSettings(): OSSettings {
  try {
    const raw = localStorage.getItem(SETTINGS_STORAGE_KEY);
    if (!raw) return DEFAULT_SETTINGS;
    const parsed = JSON.parse(raw) as Partial<OSSettings>;
    return {
      ...DEFAULT_SETTINGS,
      ...parsed,
      theme: parsed.theme === 'light' ? 'light' : 'dark',
      accent:
        parsed.accent && parsed.accent in ACCENT_PALETTES
          ? parsed.accent
          : DEFAULT_SETTINGS.accent,
      sandboxGrants: {
        ...DEFAULT_SETTINGS.sandboxGrants,
        ...(parsed.sandboxGrants || {}),
      },
    };
  } catch {
    return DEFAULT_SETTINGS;
  }
}

function loadActiveUsername(validUsers: OSUser[]): string {
  try {
    const saved = localStorage.getItem(ACTIVE_USER_STORAGE_KEY);
    if (saved && validUsers.some((u) => u.username === saved)) {
      return saved;
    }
  } catch {
    // ignore
  }
  return validUsers[0]?.username || 'kullanici';
}

function loadUsers(): OSUser[] {
  try {
    const raw = localStorage.getItem(USERS_STORAGE_KEY);
    if (!raw) return createInitialUsers();
    const parsed = JSON.parse(raw) as OSUser[];
    return Array.isArray(parsed) && parsed.length > 0 ? parsed : createInitialUsers();
  } catch {
    return createInitialUsers();
  }
}

function loadInstalledPackages(): PackageAppId[] {
  try {
    const raw = localStorage.getItem(PKGS_STORAGE_KEY);
    if (!raw) return DEFAULT_INSTALLED_PACKAGES;
    return JSON.parse(raw) as PackageAppId[];
  } catch {
    return DEFAULT_INSTALLED_PACKAGES;
  }
}

function bootKernelProcesses(): { processes: OSProcess[]; frames: MemoryFrame[] } {
  const now = Date.now();
  let frames = createInitialFrames();
  const baseDefs = [
    { pid: 1, name: 'anka-init', command: '/sbin/init', user: 'root', mb: 32, priority: -10 },
    { pid: 12, name: 'vfsd', command: '/sbin/vfsd --mount=/', user: 'root', mb: 32, priority: -5 },
    { pid: 24, name: 'ankawm', command: '/usr/bin/ankawm --compositor', user: 'kullanici', mb: 96, priority: 0 },
    { pid: 48, name: 'ankashell-d', command: '/usr/bin/ankashell-daemon', user: 'kullanici', mb: 32, priority: 0 },
    { pid: 64, name: 'audiod', command: '/usr/bin/ankaaudiod', user: 'kullanici', mb: 32, priority: 2 },
    { pid: 72, name: 'netd', command: '/sbin/netd --iface=eth0', user: 'root', mb: 32, priority: 1 },
  ];

  const processes: OSProcess[] = baseDefs.map((d) => {
    const alloc = allocateFramesForProcess(frames, d.pid, d.name, d.mb);
    frames = alloc.frames;
    return {
      pid: d.pid,
      name: d.name,
      command: d.command,
      user: d.user,
      state: d.pid === 1 ? 'sleeping' : 'running',
      priority: d.priority,
      cpu: 0.3,
      cpuTimeMs: 0,
      memoryMB: alloc.actualMB,
      pagesAllocated: alloc.pagesAllocated,
      startedAt: now,
      isSystem: true,
      privilegeRing: 0,
      aslrLayout: generateASLRLayout(0),
    };
  });

  return { processes, frames };
}

interface OSContextValue {
  bootPhase: BootPhase;
  setBootPhase: (phase: BootPhase) => void;
  rebootSystem: () => void;
  uptimeSec: number;
  settings: OSSettings;
  updateSettings: (patch: Partial<OSSettings>) => void;
  toggleTheme: () => void;
  // Multi-user Auth
  users: OSUser[];
  currentUser: OSUser;
  switchUser: (username: string, password?: string) => Promise<{ ok: boolean; error?: string }>;
  createUser: (username: string, fullName: string, password?: string) => Promise<{ ok: boolean; error?: string }>;
  verifyUserPassword: (username: string, password: string) => Promise<boolean>;
  setUserPassword: (username: string, newPassword: string | null) => Promise<void>;
  // VFS & Clipboard
  vfs: VFSNode;
  clipboard: ClipboardItem | null;
  setClipboard: (item: ClipboardItem | null) => void;
  writeFile: (
    path: string,
    content: string,
    mimeType?: string,
    elevatedRoot?: boolean,
    callerAppId?: AppId
  ) => { ok: boolean; error?: string };
  makeDir: (path: string, elevatedRoot?: boolean) => { ok: boolean; error?: string };
  deleteNode: (
    path: string,
    elevatedRoot?: boolean,
    callerAppId?: AppId
  ) => { ok: boolean; error?: string };
  renameNode: (path: string, newName: string) => { ok: boolean; error?: string };
  copyNode: (src: string, dest: string) => { ok: boolean; error?: string };
  moveNode: (src: string, dest: string) => { ok: boolean; error?: string; movedPath?: string };
  trashNode: (path: string, callerAppId?: AppId) => { ok: boolean; error?: string };
  restoreTrashItem: (trashName: string) => { ok: boolean; error?: string; restoredPath?: string };
  emptyTrash: () => { ok: boolean; error?: string };
  chmodNode: (path: string, mode: string, elevatedRoot?: boolean) => { ok: boolean; error?: string };
  resetVFS: () => void;
  exportSystemSnapshot: () => string;
  importSystemSnapshot: (rawJson: string) => { ok: boolean; error?: string };
  openFileWithDefaultApp: (path: string) => void;
  // Workspaces & Window Manager
  activeWorkspace: WorkspaceId;
  setActiveWorkspace: (ws: WorkspaceId) => void;
  windows: OSWindow[];
  activeWindowId: string | null;
  switcherOpen: boolean;
  setSwitcherOpen: React.Dispatch<React.SetStateAction<boolean>>;
  launchApp: (appId: AppId, launchArgs?: Record<string, string>) => string;
  closeWindow: (windowId: string) => void;
  focusWindow: (windowId: string) => void;
  minimizeWindow: (windowId: string) => void;
  toggleMaximizeWindow: (windowId: string) => void;
  snapWindow: (windowId: string, snap: WindowSnap) => void;
  moveWindow: (windowId: string, x: number, y: number) => void;
  resizeWindow: (windowId: string, width: number, height: number, x?: number, y?: number) => void;
  moveWindowToWorkspace: (windowId: string, ws: WorkspaceId) => void;
  updateWindowTitle: (windowId: string, title: string) => void;
  // Kernel MMU (with CoW), Scheduler, Async I/O Queue, Security (Ring 0/3 + ASLR + Sandbox)
  processes: OSProcess[];
  schedulerStats: SchedulerStats;
  ioQueueStats: IOQueueStats;
  ioQueueTasks: IOQueueTask[];
  forkProcess: (parentPid: number) => { ok: boolean; childPid?: number; message: string };
  triggerCowWriteFault: (pid: number) => { ok: boolean; message: string };
  attemptKernelMemoryAccess: (pid: number, addrHex: string) => { ok: boolean; message: string };
  reportProcessFault: (pid: number, appId: AppId, reason: string) => void;
  pendingPermissionRequest: SandboxPermissionRequest | null;
  resolvePermissionRequest: (allow: boolean) => void;
  grantSandboxPermission: (appId: AppId, capability: 'docs:rw') => void;
  revokeSandboxPermission: (appId: AppId, capability: 'docs:rw') => void;
  backgroundJobs: BackgroundJob[];
  spawnBackgroundJob: (command: string, durationMs: number) => BackgroundJob;
  networkInterfaces: NetworkInterface[];
  recordNetworkTraffic: (ifaceName: 'lo' | 'eth0', rxBytes: number, txBytes: number) => void;
  frames: MemoryFrame[];
  swapSlots: SwapSlot[];
  compositorStats: CompositorStats;
  updateCompositorStats: (stats: CompositorStats) => void;
  syscalls: SyscallRecord[];
  killProcess: (pid: number) => { ok: boolean; error?: string };
  signalProcess: (
    pid: number,
    signal: 'SIGSTOP' | 'SIGCONT' | 'SIGTERM' | 'SIGKILL'
  ) => { ok: boolean; message: string };
  reniceProcess: (pid: number, priority: number) => { ok: boolean; error?: string };
  metricsHistory: MetricSample[];
  kernelLogs: KernelLogEntry[];
  addKernelLog: (level: KernelLogEntry['level'], subsystem: string, message: string) => void;
  clearKernelLogs: () => void;
  // Packages
  installedPackages: PackageAppId[];
  installPackage: (pkgNameOrAppId: string) => { ok: boolean; message: string };
  removePackage: (pkgNameOrAppId: string) => { ok: boolean; message: string };
  // Power profile, Daemon services, Cron, VFS fsck & tar, Live Internet Status
  powerProfile: PowerProfile;
  setPowerProfile: (profile: PowerProfile) => void;
  services: SystemServiceUnit[];
  controlService: (
    name: string,
    action: 'start' | 'stop' | 'restart'
  ) => { ok: boolean; message: string };
  cronJobs: CronJob[];
  addCronJob: (name: string, intervalSec: number, command: string) => CronJob;
  removeCronJob: (id: string) => boolean;
  toggleCronJob: (id: string) => void;
  runCronJobNow: (id: string) => string;
  runDiskCheck: (repair?: boolean) => FsckReport;
  createArchiveFromVfs: (
    targetPath: string,
    archiveOutPath: string
  ) => { ok: boolean; message: string };
  extractArchiveToVfs: (
    archivePath: string,
    destDirPath: string
  ) => { ok: boolean; message: string };
  netStatus: LiveNetStatus | null;
  refreshNetStatus: () => Promise<LiveNetStatus>;
  daemonTelemetry: DaemonTelemetry | null;
  captureDesktopScreenshot: () => Promise<{ ok: boolean; path?: string; error?: string }>;
  // Notifications & Launcher
  notifications: OSNotification[];
  activeToasts: OSNotification[];
  dismissToast: (id: string) => void;
  pushNotification: (title: string, body: string, appId?: AppId) => void;
  clearNotifications: () => void;
  markNotificationsRead: () => void;
  launcherOpen: boolean;
  setLauncherOpen: React.Dispatch<React.SetStateAction<boolean>>;
}

const OSContext = createContext<OSContextValue | null>(null);

export const OSProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const initialBoot = useMemo(() => bootKernelProcesses(), []);

  const [bootPhase, setBootPhase] = useState<BootPhase>('booting');
  const [settings, setSettings] = useState<OSSettings>(loadSettings);
  const [users, setUsers] = useState<OSUser[]>(loadUsers);
  const [currentUsername, setCurrentUsername] = useState<string>(() =>
    loadActiveUsername(loadUsers())
  );
  const [vfs, setVfs] = useState<VFSNode>(loadVFS);
  const [clipboard, setClipboard] = useState<ClipboardItem | null>(null);
  const [installedPackages, setInstalledPackages] = useState<PackageAppId[]>(loadInstalledPackages);

  const [activeWorkspace, setActiveWorkspace] = useState<WorkspaceId>(1);
  const [windows, setWindows] = useState<OSWindow[]>([]);
  const [activeWindowId, setActiveWindowId] = useState<string | null>(null);
  const [switcherOpen, setSwitcherOpen] = useState(false);

  const [processes, setProcesses] = useState<OSProcess[]>(initialBoot.processes);
  const [schedulerStats, setSchedulerStats] = useState<SchedulerStats>(createInitialSchedulerStats);
  const [ioQueueStats, setIoQueueStats] = useState<IOQueueStats>(() => systemIOQueue.getStats());
  const [ioQueueTasks, setIoQueueTasks] = useState<IOQueueTask[]>(() => systemIOQueue.getTasks());
  const [pendingPermissionRequest, setPendingPermissionRequest] =
    useState<SandboxPermissionRequest | null>(null);
  const [backgroundJobs, setBackgroundJobs] = useState<BackgroundJob[]>([]);
  const [networkInterfaces, setNetworkInterfaces] = useState<NetworkInterface[]>(
    createInitialNetworkInterfaces
  );
  const [frames, setFrames] = useState<MemoryFrame[]>(initialBoot.frames);
  const [swapSlots, setSwapSlots] = useState<SwapSlot[]>(createInitialSwap);
  const [compositorStats, setCompositorStats] = useState<CompositorStats>({
    frameId: 0,
    vsyncHz: 60,
    surfaceCount: 0,
    lastSwapMs: 0,
  });
  const [powerProfile, setPowerProfileState] = useState<PowerProfile>(() => {
    try {
      const saved = localStorage.getItem('ankaos_power_v1') as PowerProfile | null;
      return saved && saved in POWER_PROFILE_META ? saved : 'balanced';
    } catch {
      return 'balanced';
    }
  });
  const [services, setServices] = useState<SystemServiceUnit[]>(createInitialServices);
  const [cronJobs, setCronJobs] = useState<CronJob[]>(createInitialCronJobs);
  const [netStatus, setNetStatus] = useState<LiveNetStatus | null>(null);
  const [syscalls, setSyscalls] = useState<SyscallRecord[]>([]);
  const [uptimeSec, setUptimeSec] = useState(0);
  const [metricsHistory, setMetricsHistory] = useState<MetricSample[]>(() => {
    const now = Date.now();
    return Array.from({ length: 24 }, (_, idx) => ({
      timestamp: now - (24 - idx) * 1000,
      cpu: 4 + Math.round(Math.sin(idx * 0.5) * 2 + 2),
      ram: 6,
    }));
  });
  const [kernelLogs, setKernelLogs] = useState<KernelLogEntry[]>(() => [
    {
      id: 'log-0',
      timestamp: Date.now(),
      uptimeSec: 0,
      level: 'INFO',
      subsystem: 'kernel',
      message: 'AnkaKernel 6.1.0-ankaos (Ring 0/3 + ASLR + CoW) başlatıldı',
    },
    {
      id: 'log-1',
      timestamp: Date.now(),
      uptimeSec: 0,
      level: 'INFO',
      subsystem: 'sched',
      message: 'Öncelikli Kesintili (Preemptive Priority) Zamanlayıcı (100ms kuantum) etkin',
    },
    {
      id: 'log-2',
      timestamp: Date.now(),
      uptimeSec: 0,
      level: 'INFO',
      subsystem: 'net',
      message: 'Sanal ağ arayüzleri lo (127.0.0.1) ve eth0 (192.168.1.42) hazır',
    },
  ]);

  const [notifications, setNotifications] = useState<OSNotification[]>([
    {
      id: 'notif-welcome',
      title: 'AnkaOS v3.5 Hazır',
      body: '4-köşe pencere döşeme, FFT medya stüdyosu, gelişmiş kod editörü (Bul/Değiştir), AnkaArama ve tam CLI araçları etkin.',
      timestamp: Date.now(),
      read: false,
      appId: 'terminal',
    },
  ]);
  const [activeToasts, setActiveToasts] = useState<OSNotification[]>([]);
  const [daemonTelemetry, setDaemonTelemetry] = useState<DaemonTelemetry | null>(null);
  const [launcherOpen, setLauncherOpen] = useState(false);

  const nextPidRef = useRef(100);
  const nextJobRef = useRef(1);
  const nextZRef = useRef(20);
  const uptimeRef = useRef(0);
  const activeWinPidRef = useRef<number | null>(null);
  const activeWindowIdRef = useRef<string | null>(null);
  const windowsRef = useRef<OSWindow[]>(windows);
  const framesRef = useRef<MemoryFrame[]>(frames);
  const swapRef = useRef<SwapSlot[]>(swapSlots);
  const schedulerStatsRef = useRef<SchedulerStats>(schedulerStats);
  const powerProfileRef = useRef<PowerProfile>(powerProfile);
  const servicesRef = useRef<SystemServiceUnit[]>(services);
  const dndRef = useRef<boolean>(Boolean(settings.doNotDisturb));
  const captureScreenshotRef = useRef<() => Promise<{ ok: boolean; path?: string; error?: string }>>(
    async () => ({ ok: false })
  );

  useEffect(() => {
    dndRef.current = Boolean(settings.doNotDisturb);
  }, [settings.doNotDisturb]);

  useEffect(() => {
    powerProfileRef.current = powerProfile;
  }, [powerProfile]);

  useEffect(() => {
    servicesRef.current = services;
  }, [services]);

  useEffect(() => {
    framesRef.current = frames;
  }, [frames]);

  useEffect(() => {
    swapRef.current = swapSlots;
  }, [swapSlots]);

  useEffect(() => {
    schedulerStatsRef.current = schedulerStats;
  }, [schedulerStats]);

  useEffect(() => {
    windowsRef.current = windows;
    activeWindowIdRef.current = activeWindowId;
    const win = windows.find((w) => w.id === activeWindowId);
    activeWinPidRef.current = win ? win.pid : null;
  }, [windows, activeWindowId]);

  const currentUser = useMemo(
    () => users.find((u) => u.username === currentUsername) || users[0],
    [users, currentUsername]
  );

  useEffect(() => {
    applyThemePalette(settings.theme, settings.accent);
    try {
      localStorage.setItem(SETTINGS_STORAGE_KEY, JSON.stringify(settings));
    } catch {
      // ignore
    }
  }, [settings]);

  useEffect(() => {
    try {
      localStorage.setItem(ACTIVE_USER_STORAGE_KEY, currentUsername);
    } catch {
      // ignore
    }
  }, [currentUsername]);

  // Hydrate VFS from IndexedDB if newer than localStorage fallback
  useEffect(() => {
    let cancelled = false;
    void (async () => {
      const raw = await idbGet('ankaos_vfs_v2');
      if (cancelled || !raw) return;
      let stored: { savedAt?: number; root?: VFSNode } | null = null;
      try {
        stored = JSON.parse(raw) as { savedAt?: number; root?: VFSNode };
      } catch {
        return;
      }
      let lsTs = 0;
      try {
        lsTs = Number(localStorage.getItem('ankaos_vfs_ts_v1') || '0');
      } catch {
        // ignore
      }
      if (stored?.root && stored.root.type === 'dir' && (stored.savedAt || 0) > lsTs) {
        setVfs(stored.root);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  useEffect(() => {
    saveVFS(vfs);
    const now = Date.now();
    try {
      localStorage.setItem('ankaos_vfs_ts_v1', String(now));
    } catch {
      // ignore
    }
    const tId = window.setTimeout(() => {
      try {
        void idbPut('ankaos_vfs_v2', JSON.stringify({ savedAt: now, root: vfs }));
      } catch {
        // ignore
      }
    }, 220);
    setIoQueueStats(systemIOQueue.getStats());
    setIoQueueTasks(systemIOQueue.getTasks());
    return () => window.clearTimeout(tId);
  }, [vfs]);

  // Off-main-thread background daemon Web Worker + BroadcastChannel IPC
  useEffect(() => {
    if (bootPhase === 'shutdown') return;
    const workerCtl = startDaemonWorker((telemetry) => {
      setDaemonTelemetry(telemetry);
    });
    return () => workerCtl.stop();
  }, [bootPhase]);

  useEffect(() => {
    try {
      localStorage.setItem(USERS_STORAGE_KEY, JSON.stringify(users));
    } catch {
      // ignore
    }
  }, [users]);

  useEffect(() => {
    try {
      localStorage.setItem(PKGS_STORAGE_KEY, JSON.stringify(installedPackages));
    } catch {
      // ignore
    }
  }, [installedPackages]);

  const recordSyscall = useCallback(
    (
      pid: number,
      name: string,
      args: string,
      status: 'OK' | 'ERR' = 'OK',
      ring: 0 | 3 = pid < 100 ? 0 : 3
    ) => {
      setSyscalls((prev) => [
        {
          id: `sc-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
          timestamp: Date.now(),
          pid,
          name,
          args,
          status,
          ring,
        },
        ...prev.slice(0, 79),
      ]);
    },
    []
  );

  const addKernelLog = useCallback(
    (level: KernelLogEntry['level'], subsystem: string, message: string) => {
      setKernelLogs((prev) => [
        ...prev.slice(-149),
        {
          id: `log-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
          timestamp: Date.now(),
          uptimeSec: uptimeRef.current,
          level,
          subsystem,
          message,
        },
      ]);
    },
    []
  );

  const clearKernelLogs = useCallback(() => {
    setKernelLogs([
      {
        id: `log-clr-${Date.now()}`,
        timestamp: Date.now(),
        uptimeSec: uptimeRef.current,
        level: 'INFO',
        subsystem: 'dmesg',
        message: 'Çekirdek halka tamponu kullanıcı tarafından temizlendi.',
      },
    ]);
  }, []);

  // Preemptive Priority Scheduler Tick + Background Jobs + Async I/O Telemetry
  useEffect(() => {
    if (bootPhase === 'shutdown') return;
    const timer = window.setInterval(() => {
      uptimeRef.current += 1;
      setUptimeSec(uptimeRef.current);
      const now = Date.now();

      // Finish elapsed background jobs
      setBackgroundJobs((prevJobs) => {
        let changed = false;
        const nextJobs = prevJobs.map((job) => {
          if (job.status === 'running' && now >= job.endsAt) {
            changed = true;
            setProcesses((pList) => pList.filter((p) => p.pid !== job.pid));
            setFrames((fList) => freeFramesForProcess(fList, job.pid));
            return { ...job, status: 'done' as const };
          }
          return job;
        });
        return changed ? nextJobs : prevJobs;
      });

      setProcesses((prevProcs) => {
        const quantum = POWER_PROFILE_META[powerProfileRef.current].quantumMs;
        const result = stepScheduler(
          prevProcs,
          schedulerStatsRef.current,
          activeWinPidRef.current,
          quantum
        );
        schedulerStatsRef.current = result.stats;
        setSchedulerStats(result.stats);
        const totalCpu = Math.min(
          98,
          Math.max(2, Math.round(result.processes.reduce((sum, p) => sum + p.cpu, 0)))
        );
        const memSummary = getMemorySummary(framesRef.current, swapRef.current);
        setMetricsHistory((hist) => [
          ...hist.slice(-39),
          { timestamp: now, cpu: totalCpu, ram: memSummary.usagePct },
        ]);
        return result.processes;
      });

      // Cron scheduler evaluation when crond daemon is active
      const crondActive = servicesRef.current.some(
        (s) => s.name === 'crond' && s.status === 'active'
      );
      if (crondActive) {
        setCronJobs((prevJobs) => {
          let anyTriggered = false;
          const next = prevJobs.map((job) => {
            if (!job.enabled) return job;
            const elapsedSec = job.lastRunAt === null ? job.intervalSec : (now - job.lastRunAt) / 1000;
            if (elapsedSec >= job.intervalSec) {
              anyTriggered = true;
              return {
                ...job,
                runCount: job.runCount + 1,
                lastRunAt: now,
                lastResult: `OK (${new Date(now).toLocaleTimeString('tr-TR')})`,
              };
            }
            return job;
          });
          return anyTriggered ? next : prevJobs;
        });
      }

      setIoQueueStats(systemIOQueue.getStats());
      setIoQueueTasks(systemIOQueue.getTasks());
    }, 1000);

    return () => window.clearInterval(timer);
  }, [bootPhase]);

  // Global Keyboard Shortcuts: Alt+Space / Ctrl+K, Alt+Tab, Alt+1..4, Window Tiling (Alt+Arrows / Alt+F4)
  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if (bootPhase !== 'desktop') return;
      const target = e.target as HTMLElement | null;
      const isEditable =
        target?.tagName === 'INPUT' ||
        target?.tagName === 'TEXTAREA' ||
        target?.tagName === 'SELECT' ||
        target?.isContentEditable;

      if ((e.altKey && e.code === 'Space') || ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k')) {
        e.preventDefault();
        setSwitcherOpen(false);
        setLauncherOpen((prev) => !prev);
      } else if (e.altKey && e.key === 'Tab') {
        e.preventDefault();
        setLauncherOpen(false);
        setSwitcherOpen((prev) => !prev);
      } else if (e.altKey && e.key.toLowerCase() === 'l') {
        e.preventDefault();
        setBootPhase('locked');
      } else if (e.key === 'PrintScreen' || ((e.ctrlKey || e.metaKey) && e.shiftKey && e.key.toLowerCase() === 's')) {
        e.preventDefault();
        void captureScreenshotRef.current();
      } else if (e.altKey && ['1', '2', '3', '4'].includes(e.key)) {
        e.preventDefault();
        setActiveWorkspace(Number(e.key) as WorkspaceId);
      } else if (e.key === 'Escape') {
        setLauncherOpen(false);
        setSwitcherOpen(false);
      } else if (!isEditable && e.altKey && activeWindowIdRef.current) {
        const focusedWin = windowsRef.current.find((w) => w.id === activeWindowIdRef.current);
        if (!focusedWin) return;
        if (e.key === 'ArrowLeft') {
          e.preventDefault();
          nextZRef.current += 1;
          const nextSnap: WindowSnap = e.shiftKey ? 'top-left' : 'left';
          setWindows((prev) =>
            prev.map((w) =>
              w.id === focusedWin.id ? { ...w, snap: nextSnap, zIndex: nextZRef.current } : w
            )
          );
        } else if (e.key === 'ArrowRight') {
          e.preventDefault();
          nextZRef.current += 1;
          const nextSnap: WindowSnap = e.shiftKey ? 'top-right' : 'right';
          setWindows((prev) =>
            prev.map((w) =>
              w.id === focusedWin.id ? { ...w, snap: nextSnap, zIndex: nextZRef.current } : w
            )
          );
        } else if (e.key === 'ArrowUp') {
          e.preventDefault();
          nextZRef.current += 1;
          const nextSnap: WindowSnap = e.shiftKey
            ? focusedWin.snap === 'left'
              ? 'top-left'
              : 'top-right'
            : 'maximized';
          setWindows((prev) =>
            prev.map((w) =>
              w.id === focusedWin.id ? { ...w, snap: nextSnap, zIndex: nextZRef.current } : w
            )
          );
        } else if (e.key === 'ArrowDown') {
          e.preventDefault();
          if (e.shiftKey) {
            nextZRef.current += 1;
            const nextSnap: WindowSnap = focusedWin.snap === 'left' ? 'bottom-left' : 'bottom-right';
            setWindows((prev) =>
              prev.map((w) =>
                w.id === focusedWin.id ? { ...w, snap: nextSnap, zIndex: nextZRef.current } : w
              )
            );
          } else if (focusedWin.snap !== 'none') {
            setWindows((prev) =>
              prev.map((w) => (w.id === focusedWin.id ? { ...w, snap: 'none' } : w))
            );
          } else {
            setWindows((prev) =>
              prev.map((w) => (w.id === focusedWin.id ? { ...w, isMinimized: true } : w))
            );
            setActiveWindowId(null);
          }
        } else if (e.key === 'F4') {
          e.preventDefault();
          setWindows((prev) => prev.filter((w) => w.id !== focusedWin.id));
          setProcesses((prev) => prev.filter((p) => p.pid !== focusedWin.pid));
          setFrames((prev) => freeFramesForProcess(prev, focusedWin.pid));
          setSwapSlots((prev) => freeSwapForProcess(prev, focusedWin.pid));
          setActiveWindowId(null);
        }
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [bootPhase]);

  const updateSettings = useCallback((patch: Partial<OSSettings>) => {
    setSettings((prev) => ({ ...prev, ...patch }));
  }, []);

  const toggleTheme = useCallback(() => {
    setSettings((prev) => ({
      ...prev,
      theme: prev.theme === 'dark' ? 'light' : 'dark',
    }));
  }, []);

  const verifyUserPassword = useCallback(
    async (username: string, password: string) => {
      const target = users.find((u) => u.username === username);
      if (!target) return false;
      return verifyPassword(target, password);
    },
    [users]
  );

  const switchUser = useCallback(
    async (username: string, password = '') => {
      const target = users.find((u) => u.username === username);
      if (!target) return { ok: false, error: `Kullanıcı bulunamadı: ${username}` };
      const valid = await verifyPassword(target, password);
      if (!valid) return { ok: false, error: 'Parola hatalı' };
      setCurrentUsername(target.username);
      setSettings((prev) => ({ ...prev, userName: target.fullName }));
      recordSyscall(1, 'sys_setuid', `${target.username} (${target.uid})`, 'OK');
      addKernelLog('INFO', 'auth', `Oturum kullanıcısı değiştirildi: ${target.username}`);
      return { ok: true };
    },
    [users, recordSyscall, addKernelLog]
  );

  const createUser = useCallback(
    async (username: string, fullName: string, password = '') => {
      const clean = username.trim().toLowerCase().replace(/[^a-z0-9_-]/g, '');
      if (!clean) return { ok: false, error: 'Geçersiz kullanıcı adı' };
      if (users.some((u) => u.username === clean)) {
        return { ok: false, error: `Kullanıcı zaten var: ${clean}` };
      }
      const newUser = await createUserAccount(users, clean, fullName, password || null, false);
      setUsers((prev) => [...prev, newUser]);
      // Provision full /home/<username> tree (Masaüstü, Belgeler, Projeler, Resimler, .sandbox)
      setVfs((prev) => provisionUserHome(prev, newUser.username));
      recordSyscall(1, 'sys_useradd', `${newUser.username} (UID ${newUser.uid})`, 'OK');
      addKernelLog('INFO', 'auth', `Yeni kullanıcı ve ev dizini eklendi: ${newUser.username}`);
      return { ok: true };
    },
    [users, recordSyscall, addKernelLog]
  );

  const setUserPassword = useCallback(
    async (username: string, newPassword: string | null) => {
      const hash = newPassword ? await hashPassword(newPassword) : null;
      setUsers((prev) =>
        prev.map((u) => (u.username === username ? { ...u, passwordHash: hash } : u))
      );
      recordSyscall(1, 'sys_passwd', username, 'OK');
      addKernelLog('INFO', 'auth', `${username} kullanıcısı için parola güncellendi`);
    },
    [recordSyscall, addKernelLog]
  );

  const dismissToast = useCallback((id: string) => {
    setActiveToasts((prev) => prev.filter((t) => t.id !== id));
  }, []);

  const pushNotification = useCallback((title: string, body: string, appId?: AppId) => {
    const entry: OSNotification = {
      id: `notif-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      title,
      body,
      timestamp: Date.now(),
      read: false,
      appId,
    };
    setNotifications((prev) => [entry, ...prev.slice(0, 19)]);
    if (!dndRef.current) {
      setActiveToasts((prev) => [entry, ...prev.slice(0, 2)]);
      window.setTimeout(() => {
        setActiveToasts((prev) => prev.filter((t) => t.id !== entry.id));
      }, 4500);
    }
  }, []);

  const clearNotifications = useCallback(() => setNotifications([]), []);
  const markNotificationsRead = useCallback(() => {
    setNotifications((prev) => prev.map((n) => ({ ...n, read: true })));
  }, []);

  const grantSandboxPermission = useCallback(
    (appId: AppId, capability: 'docs:rw') => {
      setSettings((prev) => {
        const existing = prev.sandboxGrants?.[appId] || [];
        if (existing.includes(capability)) return prev;
        return {
          ...prev,
          sandboxGrants: {
            ...prev.sandboxGrants,
            [appId]: [...existing, capability],
          },
        };
      });
      recordSyscall(1, 'sys_sandbox_grant', `${appId}:${capability}`, 'OK', 0);
      addKernelLog('INFO', 'sandbox', `'${appId}' uygulamasına '${capability}' izni verildi`);
    },
    [recordSyscall, addKernelLog]
  );

  const revokeSandboxPermission = useCallback(
    (appId: AppId, capability: 'docs:rw') => {
      setSettings((prev) => {
        const existing = prev.sandboxGrants?.[appId] || [];
        return {
          ...prev,
          sandboxGrants: {
            ...prev.sandboxGrants,
            [appId]: existing.filter((c) => c !== capability),
          },
        };
      });
      recordSyscall(1, 'sys_sandbox_revoke', `${appId}:${capability}`, 'OK', 0);
      addKernelLog('WARN', 'sandbox', `'${appId}' uygulamasından '${capability}' izni kaldırıldı`);
    },
    [recordSyscall, addKernelLog]
  );

  const resolvePermissionRequest = useCallback(
    (allow: boolean) => {
      if (!pendingPermissionRequest) return;
      if (allow) {
        grantSandboxPermission(pendingPermissionRequest.appId, pendingPermissionRequest.capability);
      } else {
        addKernelLog(
          'WARN',
          'sandbox',
          `Kullanıcı '${pendingPermissionRequest.appId}' için '${pendingPermissionRequest.targetPath}' erişimini reddetti`
        );
      }
      setPendingPermissionRequest(null);
    },
    [pendingPermissionRequest, grantSandboxPermission, addKernelLog]
  );

  // VFS operations (enforcing Sandbox syscall gate + POSIX permissions)
  const writeFile = useCallback(
    (
      path: string,
      content: string,
      mimeType?: string,
      elevatedRoot = false,
      callerAppId?: AppId
    ) => {
      let workingRoot = vfs;
      if (callerAppId) {
        const norm = normalizePath(path, currentUser.homeDir, currentUser.homeDir);
        const decision = checkSandboxSyscall(
          callerAppId,
          'write',
          norm,
          currentUser.username,
          settings.sandboxGrants,
          elevatedRoot
        );
        if (!decision.allowed) {
          recordSyscall(12, 'sys_write_sandbox', `${callerAppId} -> ${norm}`, 'ERR', 3);
          addKernelLog('WARN', 'sandbox', decision.reason || `Sandbox engeli: ${norm}`);
          if (decision.requiresPrompt && decision.capability) {
            setPendingPermissionRequest({
              id: `perm-${Date.now()}`,
              appId: callerAppId,
              pid: activeWinPidRef.current || 100,
              capability: decision.capability,
              targetPath: norm,
              operation: 'write',
            });
          }
          return { ok: false, error: decision.reason };
        }
        const sandboxDir = getAppSandboxDir(currentUser.username, callerAppId);
        if (norm.startsWith(`${sandboxDir}/`)) {
          workingRoot = vfsEnsureDir(workingRoot, sandboxDir, {
            user: currentUser.username,
            elevatedRoot: true,
          });
        }
      }

      const res = vfsWriteFile(workingRoot, path, content, mimeType, {
        user: currentUser.username,
        elevatedRoot,
      });
      recordSyscall(12, 'sys_write', path, res.ok ? 'OK' : 'ERR');
      if (res.ok) {
        setVfs(res.root);
        addKernelLog('INFO', 'vfs', `Yazıldı: ${path}`);
      }
      return { ok: res.ok, error: res.error };
    },
    [vfs, currentUser.username, currentUser.homeDir, settings.sandboxGrants, recordSyscall, addKernelLog]
  );

  const makeDir = useCallback(
    (path: string, elevatedRoot = false) => {
      const res = vfsMkdir(vfs, path, { user: currentUser.username, elevatedRoot });
      recordSyscall(12, 'sys_mkdir', path, res.ok ? 'OK' : 'ERR');
      if (res.ok) {
        setVfs(res.root);
        addKernelLog('INFO', 'vfs', `Klasör oluşturuldu: ${path}`);
      }
      return { ok: res.ok, error: res.error };
    },
    [vfs, currentUser.username, recordSyscall, addKernelLog]
  );

  const deleteNode = useCallback(
    (path: string, elevatedRoot = false, callerAppId?: AppId) => {
      if (callerAppId) {
        const norm = normalizePath(path, currentUser.homeDir, currentUser.homeDir);
        const decision = checkSandboxSyscall(
          callerAppId,
          'delete',
          norm,
          currentUser.username,
          settings.sandboxGrants,
          elevatedRoot
        );
        if (!decision.allowed) {
          recordSyscall(12, 'sys_unlink_sandbox', `${callerAppId} -> ${norm}`, 'ERR', 3);
          if (decision.requiresPrompt && decision.capability) {
            setPendingPermissionRequest({
              id: `perm-${Date.now()}`,
              appId: callerAppId,
              pid: activeWinPidRef.current || 100,
              capability: decision.capability,
              targetPath: norm,
              operation: 'delete',
            });
          }
          return { ok: false, error: decision.reason };
        }
      }

      const res = vfsDelete(vfs, path, { user: currentUser.username, elevatedRoot });
      recordSyscall(12, 'sys_unlink', path, res.ok ? 'OK' : 'ERR');
      if (res.ok) {
        setVfs(res.root);
        addKernelLog('WARN', 'vfs', `Silindi: ${path}`);
      }
      return { ok: res.ok, error: res.error };
    },
    [vfs, currentUser.username, currentUser.homeDir, settings.sandboxGrants, recordSyscall, addKernelLog]
  );

  const renameNode = useCallback(
    (path: string, newName: string) => {
      const res = vfsRename(vfs, path, newName);
      recordSyscall(12, 'sys_rename', `${path} -> ${newName}`, res.ok ? 'OK' : 'ERR');
      if (res.ok) {
        setVfs(res.root);
        addKernelLog('INFO', 'vfs', `Yeniden adlandırıldı: ${path} -> ${newName}`);
      }
      return { ok: res.ok, error: res.error };
    },
    [vfs, recordSyscall, addKernelLog]
  );

  const copyNode = useCallback(
    (src: string, dest: string) => {
      const res = vfsCopy(vfs, src, dest);
      recordSyscall(12, 'sys_copy', `${src} -> ${dest}`, res.ok ? 'OK' : 'ERR');
      if (res.ok) {
        setVfs(res.root);
        addKernelLog('INFO', 'vfs', `Kopyalandı: ${src} -> ${dest}`);
      }
      return { ok: res.ok, error: res.error };
    },
    [vfs, recordSyscall, addKernelLog]
  );

  const moveNode = useCallback(
    (src: string, dest: string) => {
      const res = vfsMoveNode(vfs, src, dest, { user: currentUser.username });
      recordSyscall(12, 'sys_move', `${src} -> ${dest}`, res.ok ? 'OK' : 'ERR');
      if (res.ok) {
        setVfs(res.root);
        addKernelLog('INFO', 'vfs', `Taşındı: ${src} -> ${res.movedPath || dest}`);
      }
      return { ok: res.ok, error: res.error, movedPath: res.movedPath };
    },
    [vfs, currentUser.username, recordSyscall, addKernelLog]
  );

  const trashNode = useCallback(
    (path: string, callerAppId?: AppId) => {
      if (callerAppId) {
        const norm = normalizePath(path, currentUser.homeDir, currentUser.homeDir);
        const decision = checkSandboxSyscall(
          callerAppId,
          'delete',
          norm,
          currentUser.username,
          settings.sandboxGrants,
          false
        );
        if (!decision.allowed) {
          recordSyscall(12, 'sys_trash_sandbox', `${callerAppId} -> ${norm}`, 'ERR', 3);
          return { ok: false, error: decision.reason };
        }
      }
      const res = vfsMoveToTrash(vfs, path, currentUser.homeDir, {
        user: currentUser.username,
      });
      recordSyscall(12, 'sys_trash', path, res.ok ? 'OK' : 'ERR');
      if (res.ok) {
        setVfs(res.root);
        addKernelLog('INFO', 'vfs', `Çöp kutusuna taşındı: ${path}`);
      }
      return { ok: res.ok, error: res.error };
    },
    [vfs, currentUser.homeDir, currentUser.username, settings.sandboxGrants, recordSyscall, addKernelLog]
  );

  const restoreTrashItem = useCallback(
    (trashName: string) => {
      const res = vfsRestoreFromTrash(vfs, trashName, currentUser.homeDir, {
        user: currentUser.username,
      });
      recordSyscall(12, 'sys_trash_restore', trashName, res.ok ? 'OK' : 'ERR');
      if (res.ok) {
        setVfs(res.root);
        addKernelLog('INFO', 'vfs', `Çöp kutusundan geri yüklendi: ${res.restoredPath || trashName}`);
      }
      return { ok: res.ok, error: res.error, restoredPath: res.restoredPath };
    },
    [vfs, currentUser.homeDir, currentUser.username, recordSyscall, addKernelLog]
  );

  const emptyTrash = useCallback(() => {
    const res = vfsEmptyTrash(vfs, currentUser.homeDir, {
      user: currentUser.username,
    });
    recordSyscall(12, 'sys_trash_empty', `${currentUser.homeDir}/.Trash`, res.ok ? 'OK' : 'ERR');
    if (res.ok) {
      setVfs(res.root);
      addKernelLog('WARN', 'vfs', `Çöp kutusu boşaltıldı (${currentUser.username})`);
    }
    return { ok: res.ok, error: res.error };
  }, [vfs, currentUser.homeDir, currentUser.username, recordSyscall, addKernelLog]);

  const chmodNode = useCallback(
    (path: string, mode: string, elevatedRoot = false) => {
      const res = vfsChmod(vfs, path, mode, {
        user: currentUser.username,
        elevatedRoot,
      });
      recordSyscall(12, 'sys_chmod', `${mode} ${path}`, res.ok ? 'OK' : 'ERR');
      if (res.ok) {
        setVfs(res.root);
        addKernelLog('INFO', 'vfs', `İzinler değişti (${mode}): ${path}`);
      }
      return { ok: res.ok, error: res.error };
    },
    [vfs, currentUser.username, recordSyscall, addKernelLog]
  );

  const resetVFS = useCallback(() => {
    const fresh = createInitialVFS();
    setVfs(fresh);
    saveVFS(fresh);
    addKernelLog('WARN', 'vfs', 'Dosya sistemi fabrika ayarlarına sıfırlandı');
    pushNotification(
      settings.language === 'tr' ? 'Dosya Sistemi Sıfırlandı' : 'Filesystem Reset',
      settings.language === 'tr'
        ? 'Tüm sistem dizinleri varsayılan haline getirildi.'
        : 'All directories restored to factory state.',
      'settings'
    );
  }, [addKernelLog, pushNotification, settings.language]);

  const exportSystemSnapshot = useCallback((): string => {
    const snapshot = {
      schema: 'ankaos-snapshot-v1',
      version: '3.5.0',
      exportedAt: new Date().toISOString(),
      currentUsername,
      settings,
      users,
      installedPackages,
      vfs,
    };
    recordSyscall(1, 'sys_snapshot_export', `users=${users.length}, pkgs=${installedPackages.length}`, 'OK', 0);
    addKernelLog('INFO', 'vfs', 'Tam sistem snapshot yedeği JSON olarak dışa aktarıldı');
    return JSON.stringify(snapshot, null, 2);
  }, [currentUsername, settings, users, installedPackages, vfs, recordSyscall, addKernelLog]);

  const importSystemSnapshot = useCallback(
    (rawJson: string): { ok: boolean; error?: string } => {
      try {
        const parsed = JSON.parse(rawJson) as {
          schema?: string;
          vfs?: VFSNode;
          settings?: Partial<OSSettings>;
          users?: OSUser[];
          installedPackages?: PackageAppId[];
          currentUsername?: string;
        };
        if (!parsed || parsed.schema !== 'ankaos-snapshot-v1') {
          return { ok: false, error: 'Geçersiz snapshot şeması (ankaos-snapshot-v1 bekleniyor).' };
        }
        if (!parsed.vfs || parsed.vfs.type !== 'dir' || !parsed.vfs.children) {
          return { ok: false, error: 'Snapshot içinde geçerli bir VFS kök ağacı bulunamadı.' };
        }
        if (!Array.isArray(parsed.users) || parsed.users.length === 0) {
          return { ok: false, error: 'Snapshot içinde geçerli kullanıcı listesi yok.' };
        }

        const nextSettings: OSSettings = {
          ...DEFAULT_SETTINGS,
          ...(parsed.settings || {}),
          theme: parsed.settings?.theme === 'light' ? 'light' : 'dark',
          accent:
            parsed.settings?.accent && parsed.settings.accent in ACCENT_PALETTES
              ? parsed.settings.accent
              : DEFAULT_SETTINGS.accent,
          sandboxGrants: {
            ...DEFAULT_SETTINGS.sandboxGrants,
            ...(parsed.settings?.sandboxGrants || {}),
          },
        };

        const validUsername =
          parsed.currentUsername && parsed.users.some((u) => u.username === parsed.currentUsername)
            ? parsed.currentUsername
            : parsed.users[0].username;

        const nextPkgs = Array.isArray(parsed.installedPackages)
          ? parsed.installedPackages
          : DEFAULT_INSTALLED_PACKAGES;

        setVfs(parsed.vfs);
        saveVFS(parsed.vfs);
        setUsers(parsed.users);
        setCurrentUsername(validUsername);
        setSettings(nextSettings);
        setInstalledPackages(nextPkgs);
        recordSyscall(1, 'sys_snapshot_import', `user=${validUsername}`, 'OK', 0);
        addKernelLog('INFO', 'vfs', `Sistem snapshot yedeğinden geri yüklendi (${validUsername})`);
        pushNotification(
          nextSettings.language === 'tr' ? 'Snapshot Geri Yüklendi' : 'Snapshot Restored',
          nextSettings.language === 'tr'
            ? 'Dosya sistemi, kullanıcılar, paketler ve ayarlar geri yüklendi.'
            : 'Filesystem, users, packages, and settings restored.',
          'settings'
        );
        return { ok: true };
      } catch (err) {
        return {
          ok: false,
          error: `JSON ayrıştırma hatası: ${err instanceof Error ? err.message : String(err)}`,
        };
      }
    },
    [recordSyscall, addKernelLog, pushNotification]
  );

  const spawnBackgroundJob = useCallback(
    (command: string, durationMs: number): BackgroundJob => {
      const pid = ++nextPidRef.current;
      const jobId = nextJobRef.current++;
      const now = Date.now();
      const alloc = allocateFramesForProcess(frames, pid, `job-${jobId}`, 32);
      if (alloc.ok) setFrames(alloc.frames);

      const proc: OSProcess = {
        pid,
        name: command.split(' ')[0] || 'bg-job',
        command,
        user: currentUser.username,
        state: 'running',
        priority: 5,
        cpu: 1.0,
        cpuTimeMs: 0,
        memoryMB: alloc.ok ? alloc.actualMB : 32,
        pagesAllocated: alloc.ok ? alloc.pagesAllocated : 1,
        startedAt: now,
        privilegeRing: 3,
        aslrLayout: generateASLRLayout(3),
      };
      setProcesses((prev) => [...prev, proc]);

      const job: BackgroundJob = {
        jobId,
        pid,
        command,
        status: 'running',
        startedAt: now,
        endsAt: now + durationMs,
      };
      setBackgroundJobs((prev) => [...prev, job]);
      recordSyscall(pid, 'sys_fork_bg', command, 'OK', 3);
      return job;
    },
    [frames, currentUser.username, recordSyscall]
  );

  // Copy-on-Write (CoW) process fork
  const forkProcess = useCallback(
    (parentPid: number) => {
      const parent = processes.find((p) => p.pid === parentPid);
      if (!parent) {
        return { ok: false, message: `PID ${parentPid} bulunamadı` };
      }
      const childPid = ++nextPidRef.current;
      const cow = forkFramesCopyOnWrite(frames, parentPid, childPid);
      if (!cow.ok) {
        return { ok: false, message: `PID ${parentPid} için paylaşılacak bellek çerçevesi yok` };
      }
      setFrames(cow.frames);

      const childProc: OSProcess = {
        pid: childPid,
        parentPid,
        name: `${parent.name}-fork`,
        command: `${parent.command} [CoW]`,
        user: parent.user,
        state: 'running',
        priority: parent.priority + 1,
        cpu: 0.5,
        cpuTimeMs: 0,
        memoryMB: cow.virtualMB,
        pagesAllocated: cow.sharedPages,
        startedAt: Date.now(),
        privilegeRing: 3,
        aslrLayout: generateASLRLayout(3),
      };

      setProcesses((prev) => [...prev, childProc]);
      recordSyscall(
        parentPid,
        'sys_fork_cow',
        `child=${childPid} shared=${cow.sharedPages}p (0 MB ek RAM)`,
        'OK',
        parent.privilegeRing
      );
      addKernelLog(
        'INFO',
        'mmu',
        `CoW fork: PID ${parentPid} -> PID ${childPid} (${cow.sharedPages} sayfa paylaşıldı, ek fiziksel RAM = 0 MB)`
      );
      return {
        ok: true,
        childPid,
        message: `CoW fork başarılı: PID ${childPid} (${cow.sharedPages} ortak sayfa, 0 MB ek fiziksel RAM)`,
      };
    },
    [processes, frames, recordSyscall, addKernelLog]
  );

  const triggerCowWriteFault = useCallback(
    (pid: number) => {
      const proc = processes.find((p) => p.pid === pid);
      if (!proc) return { ok: false, message: `PID ${pid} bulunamadı` };
      const fault = handleCowPageFault(frames, pid, proc.name);
      if (!fault.ok) {
        return { ok: false, message: `PID ${pid} için ortak CoW sayfası bulunamadı veya RAM dolu` };
      }
      setFrames(fault.frames);
      recordSyscall(
        pid,
        'sys_cow_fault',
        `frame #${fault.oldFrameIndex} -> #${fault.newFrameIndex}`,
        'OK',
        proc.privilegeRing
      );
      addKernelLog(
        'INFO',
        'mmu',
        `CoW Sayfa Hatası çözüldü (PID ${pid}): Çerçeve #${fault.oldFrameIndex} yazım için #${fault.newFrameIndex} kopyalandı`
      );
      return {
        ok: true,
        message: `CoW yazma kopyası tamamlandı: #${fault.oldFrameIndex} -> #${fault.newFrameIndex} (32 MB özel sayfa)`,
      };
    },
    [processes, frames, recordSyscall, addKernelLog]
  );

  const attemptKernelMemoryAccess = useCallback(
    (pid: number, addrHex: string) => {
      const proc = processes.find((p) => p.pid === pid);
      if (!proc) return { ok: false, message: `PID ${pid} bulunamadı` };
      const res = assertKernelAccess(proc, addrHex);
      if (!res.allowed) {
        const msg = res.fault?.message || `Ring ${proc.privilegeRing} erişim reddedildi`;
        recordSyscall(pid, 'sys_mem_access', addrHex, 'ERR', proc.privilegeRing);
        addKernelLog('ERR', 'security', msg);
        return { ok: false, message: msg };
      }
      recordSyscall(pid, 'sys_mem_access', addrHex, 'OK', proc.privilegeRing);
      return { ok: true, message: `Ring ${proc.privilegeRing} bellek erişimi onaylandı: ${addrHex}` };
    },
    [processes, recordSyscall, addKernelLog]
  );

  const reportProcessFault = useCallback(
    (pid: number, appId: AppId, reason: string) => {
      recordSyscall(pid, 'sys_fault_sigsegv', `${appId}: ${reason}`, 'ERR', 3);
      addKernelLog(
        'ERR',
        'security',
        `Ring 3 SIGSEGV yalıtımı (${appId}, PID ${pid}): ${reason} — Çekirdek korundu.`
      );
    },
    [recordSyscall, addKernelLog]
  );

  const recordNetworkTraffic = useCallback(
    (ifaceName: 'lo' | 'eth0', rxBytes: number, txBytes: number) => {
      setNetworkInterfaces((prev) =>
        prev.map((ifc) =>
          ifc.name === ifaceName
            ? {
                ...ifc,
                rxBytes: ifc.rxBytes + rxBytes,
                txBytes: ifc.txBytes + txBytes,
                rxPackets: ifc.rxPackets + 1,
                txPackets: ifc.txPackets + 1,
              }
            : ifc
        )
      );
    },
    []
  );

  const launchApp = useCallback(
    (appId: AppId, launchArgs?: Record<string, string>): string => {
      const manifest = APP_MANIFESTS[appId];
      const existingSingleton = manifest.singleton
        ? windows.find((w) => w.appId === appId)
        : undefined;

      if (existingSingleton) {
        nextZRef.current += 1;
        setActiveWorkspace(existingSingleton.workspace);
        setWindows((prev) =>
          prev.map((w) =>
            w.id === existingSingleton.id
              ? {
                  ...w,
                  isMinimized: false,
                  zIndex: nextZRef.current,
                  launchArgs: launchArgs ?? w.launchArgs,
                }
              : w
          )
        );
        setActiveWindowId(existingSingleton.id);
        return existingSingleton.id;
      }

      const pid = ++nextPidRef.current;
      const winId = `win-${appId}-${pid}`;
      nextZRef.current += 1;

      const memReq: Record<AppId, number> = {
        terminal: 64,
        files: 96,
        editor: 128,
        browser: 160,
        media: 96,
        'wasm-builder': 128,
        monitor: 64,
        pkg: 64,
        calculator: 32,
        paint: 160,
        viewer: 96,
        notes: 64,
        settings: 64,
        'pkg-snake': 64,
        'pkg-hex': 64,
        'pkg-timer': 32,
        'pkg-mines': 64,
        'pkg-2048': 64,
        'pkg-kanban': 96,
        'pkg-sysbench': 96,
        'pkg-calendar': 64,
        'pkg-markdown': 64,
        'pkg-recorder': 96,
        'pkg-nettools': 64,
        'pkg-diff': 64,
      };

      const requestedMB = memReq[appId] || 64;
      let activeFrames = frames;
      let alloc = allocateFramesForProcess(activeFrames, pid, appId, requestedMB);
      if (!alloc.ok) {
        // Attempt LRU swap-out of inactive Ring 3 frames before failing with OOM
        const neededFrames = Math.max(1, Math.ceil(requestedMB / 32));
        const swapRes = swapOutLRUFrames(
          activeFrames,
          swapSlots,
          neededFrames,
          activeWinPidRef.current ? [activeWinPidRef.current] : []
        );
        if (swapRes.swappedCount > 0) {
          activeFrames = swapRes.frames;
          setSwapSlots(swapRes.swap);
          addKernelLog(
            'WARN',
            'mmu',
            `LRU Swap: ${swapRes.swappedCount} sayfa (${swapRes.swappedCount * 32} MB) sanal diske alındı`
          );
          alloc = allocateFramesForProcess(activeFrames, pid, appId, requestedMB);
        }
      }
      if (!alloc.ok) {
        addKernelLog('ERR', 'mmu', `Bellek yetersiz: ${appId} için ${requestedMB} MB ayrılmadı`);
        pushNotification(
          'Bellek Yetersiz (OOM)',
          `${appId} başlatılamadı; Sistem Monitörü'nden süreç kapatın.`,
          'monitor'
        );
        return '';
      }
      setFrames(alloc.frames);

      const vw = typeof window !== 'undefined' ? window.innerWidth : 1280;
      const vh = typeof window !== 'undefined' ? window.innerHeight : 800;
      const width = Math.min(manifest.defaultWidth, vw - 48);
      const height = Math.min(manifest.defaultHeight, vh - 120);
      const offset = (windows.length % 6) * 28;
      const x = Math.max(20, Math.round((vw - width) / 2) + offset - 40);
      const y = Math.max(44, Math.round((vh - height) / 2) + offset - 30);

      const title = settings.language === 'tr' ? manifest.nameTr : manifest.nameEn;

      const newWin: OSWindow = {
        id: winId,
        appId,
        pid,
        workspace: activeWorkspace,
        title,
        x,
        y,
        width,
        height,
        minWidth: manifest.minWidth,
        minHeight: manifest.minHeight,
        isMinimized: false,
        snap: 'none',
        zIndex: nextZRef.current,
        launchArgs,
      };

      const newProc: OSProcess = {
        pid,
        name: appId,
        command: `/usr/bin/anka-${appId}`,
        appId,
        windowId: winId,
        user: currentUser.username,
        state: 'running',
        priority: 0,
        cpu: 1.5,
        cpuTimeMs: 0,
        memoryMB: alloc.actualMB,
        pagesAllocated: alloc.pagesAllocated,
        startedAt: Date.now(),
        isForeground: true,
        privilegeRing: 3,
        aslrLayout: generateASLRLayout(3),
      };

      setWindows((prev) => [...prev, newWin]);
      setProcesses((prev) => [...prev, newProc]);
      setActiveWindowId(winId);
      recordSyscall(
        pid,
        'sys_spawn',
        `${appId} (ASLR stack=${newProc.aslrLayout?.stackBase.slice(0, 10)}...)`,
        'OK',
        3
      );
      addKernelLog(
        'INFO',
        'sched',
        `Başlatıldı [Ring 3]: ${appId} (PID ${pid}, ${alloc.actualMB} MB, Stack ${newProc.aslrLayout?.stackBase})`
      );
      ipcBus.publish('process:spawn', pid, { appId, pid });
      return winId;
    },
    [
      windows,
      frames,
      swapSlots,
      activeWorkspace,
      settings.language,
      currentUser.username,
      recordSyscall,
      addKernelLog,
      pushNotification,
    ]
  );

  const closeWindow = useCallback(
    (windowId: string) => {
      const target = windows.find((w) => w.id === windowId);
      setWindows((prev) => prev.filter((w) => w.id !== windowId));
      if (target) {
        setProcesses((prev) => prev.filter((p) => p.pid !== target.pid));
        setFrames((prev) => freeFramesForProcess(prev, target.pid));
        setSwapSlots((prev) => freeSwapForProcess(prev, target.pid));
        recordSyscall(target.pid, 'sys_exit', target.appId, 'OK');
        addKernelLog('INFO', 'sched', `Sonlandırıldı: ${target.appId} (PID ${target.pid})`);
        ipcBus.publish('process:exit', target.pid, { appId: target.appId, pid: target.pid });
      }
      setActiveWindowId((curr) => (curr === windowId ? null : curr));
    },
    [windows, recordSyscall, addKernelLog]
  );

  const killProcess = useCallback(
    (pid: number) => {
      const proc = processes.find((p) => p.pid === pid);
      if (!proc) return { ok: false, error: `PID ${pid} bulunamadı` };
      if (proc.isSystem) {
        return { ok: false, error: `Sistem süreci sonlandırılamaz: ${proc.name} (PID ${pid})` };
      }
      if (proc.windowId) {
        setWindows((prev) => prev.filter((w) => w.id !== proc.windowId));
        setActiveWindowId((curr) => (curr === proc.windowId ? null : curr));
      }
      setBackgroundJobs((prev) =>
        prev.map((j) => (j.pid === pid ? { ...j, status: 'stopped' } : j))
      );
      setProcesses((prev) => prev.filter((p) => p.pid !== pid));
      setFrames((prev) => freeFramesForProcess(prev, pid));
      setSwapSlots((prev) => freeSwapForProcess(prev, pid));
      recordSyscall(pid, 'sys_kill', `SIGKILL PID=${pid}`, 'OK');
      addKernelLog('WARN', 'sched', `SIGKILL: ${proc.name} (PID ${pid}) — MMU & Swap serbest`);
      return { ok: true };
    },
    [processes, recordSyscall, addKernelLog]
  );

  const signalProcess = useCallback(
    (pid: number, signal: 'SIGSTOP' | 'SIGCONT' | 'SIGTERM' | 'SIGKILL') => {
      const proc = processes.find((p) => p.pid === pid);
      if (!proc) return { ok: false, message: `PID ${pid} bulunamadı` };
      if (proc.isSystem && (signal === 'SIGTERM' || signal === 'SIGKILL' || signal === 'SIGSTOP')) {
        return { ok: false, message: `Ring 0 çekirdek sürecine ${signal} engellendi: ${proc.name}` };
      }
      if (signal === 'SIGTERM' || signal === 'SIGKILL') {
        const res = killProcess(pid);
        return { ok: res.ok, message: res.ok ? `${signal} -> PID ${pid} sonlandırıldı` : res.error || 'Hata' };
      }
      const nextState = signal === 'SIGSTOP' ? 'stopped' : 'running';
      setProcesses((prev) => prev.map((p) => (p.pid === pid ? { ...p, state: nextState } : p)));
      recordSyscall(pid, 'sys_signal', `${signal} PID=${pid}`, 'OK', proc.privilegeRing);
      addKernelLog('INFO', 'sched', `${signal} -> PID ${pid} (${proc.name}) durum=${nextState}`);
      return { ok: true, message: `${signal} gönderildi: PID ${pid} (${nextState})` };
    },
    [processes, killProcess, recordSyscall, addKernelLog]
  );

  const reniceProcess = useCallback(
    (pid: number, priority: number) => {
      const clamped = Math.max(-20, Math.min(19, priority));
      const exists = processes.some((p) => p.pid === pid);
      if (!exists) return { ok: false, error: `PID ${pid} bulunamadı` };
      setProcesses((prev) =>
        prev.map((p) => (p.pid === pid ? { ...p, priority: clamped } : p))
      );
      recordSyscall(pid, 'sys_renice', `PID=${pid} pri=${clamped}`, 'OK');
      return { ok: true };
    },
    [processes, recordSyscall]
  );

  const focusWindow = useCallback((windowId: string) => {
    nextZRef.current += 1;
    setWindows((prev) =>
      prev.map((w) =>
        w.id === windowId ? { ...w, isMinimized: false, zIndex: nextZRef.current } : w
      )
    );
    setActiveWindowId(windowId);
  }, []);

  const minimizeWindow = useCallback((windowId: string) => {
    setWindows((prev) =>
      prev.map((w) => (w.id === windowId ? { ...w, isMinimized: true } : w))
    );
    setActiveWindowId((curr) => (curr === windowId ? null : curr));
  }, []);

  const toggleMaximizeWindow = useCallback((windowId: string) => {
    nextZRef.current += 1;
    setWindows((prev) =>
      prev.map((w) =>
        w.id === windowId
          ? {
              ...w,
              snap: w.snap === 'maximized' ? 'none' : 'maximized',
              zIndex: nextZRef.current,
            }
          : w
      )
    );
    setActiveWindowId(windowId);
  }, []);

  const snapWindow = useCallback((windowId: string, snap: WindowSnap) => {
    nextZRef.current += 1;
    setWindows((prev) =>
      prev.map((w) => (w.id === windowId ? { ...w, snap, zIndex: nextZRef.current } : w))
    );
    setActiveWindowId(windowId);
  }, []);

  const moveWindow = useCallback((windowId: string, x: number, y: number) => {
    setWindows((prev) =>
      prev.map((w) => (w.id === windowId ? { ...w, x, y, snap: 'none' } : w))
    );
  }, []);

  const resizeWindow = useCallback(
    (windowId: string, width: number, height: number, x?: number, y?: number) => {
      setWindows((prev) =>
        prev.map((w) =>
          w.id === windowId
            ? {
                ...w,
                width: Math.max(w.minWidth, width),
                height: Math.max(w.minHeight, height),
                x: x !== undefined ? x : w.x,
                y: y !== undefined ? y : w.y,
                snap: 'none',
              }
            : w
        )
      );
    },
    []
  );

  const moveWindowToWorkspace = useCallback((windowId: string, ws: WorkspaceId) => {
    setWindows((prev) =>
      prev.map((w) => (w.id === windowId ? { ...w, workspace: ws } : w))
    );
  }, []);

  const updateWindowTitle = useCallback((windowId: string, title: string) => {
    setWindows((prev) => prev.map((w) => (w.id === windowId ? { ...w, title } : w)));
  }, []);

  const openFileWithDefaultApp = useCallback(
    (rawPath: string) => {
      const path = normalizePath(rawPath, currentUser.homeDir, currentUser.homeDir);
      const node = getNodeAtPath(vfs, path);
      if (!node) return;
      if (node.type === 'dir') {
        launchApp('files', { path });
        return;
      }
      if (
        node.mimeType?.startsWith('image/') ||
        /\.(png|jpg|jpeg|webp|svg)$/i.test(node.name)
      ) {
        launchApp('viewer', { path });
        return;
      }
      if (/\.(html|htm)$/i.test(node.name)) {
        launchApp('browser', { path });
        return;
      }
      if (/\.wasmprof\.json$/i.test(node.name)) {
        launchApp('wasm-builder', { path, tab: 'profiler' });
        return;
      }
      if (/\.(wat|wast|wasm|ankawasm)$/i.test(node.name)) {
        launchApp('wasm-builder', { path });
        return;
      }
      if (/\.(ankasynth|mp3|wav|ogg|m4a|flac|aac|webm)$/i.test(node.name)) {
        launchApp('media', { path });
        return;
      }
      if (/\.(md|markdown)$/i.test(node.name) && installedPackages.includes('pkg-markdown')) {
        launchApp('pkg-markdown', { path });
        return;
      }
      launchApp('editor', { path });
    },
    [vfs, currentUser.homeDir, installedPackages, launchApp]
  );

  const captureDesktopScreenshot = useCallback(async (): Promise<{
    ok: boolean;
    path?: string;
    error?: string;
  }> => {
    try {
      const vw = typeof window !== 'undefined' ? window.innerWidth : 1280;
      const vh = typeof window !== 'undefined' ? window.innerHeight : 720;
      const scale = Math.min(1, 1280 / Math.max(vw, 640));
      const cw = Math.round(vw * scale);
      const ch = Math.round(vh * scale);

      const canvas = document.createElement('canvas');
      canvas.width = cw;
      canvas.height = ch;
      const ctx = canvas.getContext('2d');
      if (!ctx) return { ok: false, error: 'Canvas 2D bağlamı oluşturulamadı.' };

      const dark = settings.theme === 'dark';
      const grad = ctx.createLinearGradient(0, 0, cw, ch);
      grad.addColorStop(0, dark ? '#0b1220' : '#dbeafe');
      grad.addColorStop(0.55, dark ? '#111c33' : '#e0f2fe');
      grad.addColorStop(1, dark ? '#090d16' : '#f1f5f9');
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, cw, ch);

      // Subtle accent glow
      const glow = ctx.createRadialGradient(cw * 0.72, ch * 0.28, 20, cw * 0.72, ch * 0.28, cw * 0.45);
      glow.addColorStop(0, dark ? 'rgba(56,189,248,0.20)' : 'rgba(14,165,233,0.18)');
      glow.addColorStop(1, 'rgba(0,0,0,0)');
      ctx.fillStyle = glow;
      ctx.fillRect(0, 0, cw, ch);

      // Top bar
      ctx.fillStyle = dark ? 'rgba(15,23,42,0.85)' : 'rgba(255,255,255,0.88)';
      ctx.fillRect(0, 0, cw, Math.round(36 * scale));
      ctx.fillStyle = dark ? '#e2e8f0' : '#0f172a';
      ctx.font = `bold ${Math.round(13 * scale)}px sans-serif`;
      ctx.fillText(`AnkaOS 3.5 · ${currentUser.username}@anka`, 14 * scale, 23 * scale);
      ctx.fillText(new Date().toLocaleTimeString('tr-TR'), cw - 82 * scale, 23 * scale);

      // Open windows sorted back-to-front
      const visibleWins = [...windowsRef.current]
        .filter((w) => !w.isMinimized && w.workspace === activeWorkspace)
        .sort((a, b) => a.zIndex - b.zIndex);

      for (const w of visibleWins) {
        const wx = w.snap === 'maximized' ? 0 : Math.round(w.x * scale);
        const wy = w.snap === 'maximized' ? Math.round(36 * scale) : Math.round(w.y * scale);
        const ww = w.snap === 'maximized' ? cw : Math.round(w.width * scale);
        const wh = w.snap === 'maximized' ? ch - Math.round(100 * scale) : Math.round(w.height * scale);

        ctx.fillStyle = dark ? 'rgba(15,23,42,0.94)' : 'rgba(255,255,255,0.95)';
        ctx.strokeStyle = dark ? 'rgba(148,163,184,0.35)' : 'rgba(15,23,42,0.18)';
        ctx.lineWidth = 1.5;
        ctx.fillRect(wx, wy, ww, wh);
        ctx.strokeRect(wx, wy, ww, wh);

        ctx.fillStyle = dark ? '#1e293b' : '#f1f5f9';
        ctx.fillRect(wx, wy, ww, Math.round(30 * scale));
        ctx.fillStyle = dark ? '#f8fafc' : '#0f172a';
        ctx.font = `600 ${Math.round(12 * scale)}px sans-serif`;
        ctx.fillText(`${w.title} (PID ${w.pid})`, wx + 12 * scale, wy + 20 * scale);
      }

      // Bottom Dock bar representation
      const dockW = Math.min(cw - 40, Math.round(460 * scale));
      const dockH = Math.round(48 * scale);
      const dockX = Math.round((cw - dockW) / 2);
      const dockY = ch - dockH - Math.round(12 * scale);
      ctx.fillStyle = dark ? 'rgba(15,23,42,0.82)' : 'rgba(255,255,255,0.82)';
      ctx.fillRect(dockX, dockY, dockW, dockH);
      ctx.strokeStyle = dark ? 'rgba(148,163,184,0.28)' : 'rgba(15,23,42,0.14)';
      ctx.strokeRect(dockX, dockY, dockW, dockH);

      const dataUrl = canvas.toDataURL('image/png');
      const now = new Date();
      const stamp = `${now.getFullYear()}${String(now.getMonth() + 1).padStart(2, '0')}${String(now.getDate()).padStart(2, '0')}_${String(now.getHours()).padStart(2, '0')}${String(now.getMinutes()).padStart(2, '0')}${String(now.getSeconds()).padStart(2, '0')}`;
      const targetPath = `${currentUser.homeDir}/Resimler/ekran_goruntusu_${stamp}.png`;
      const res = writeFile(targetPath, dataUrl, 'image/png', false);
      if (!res.ok) return { ok: false, error: res.error || 'Ekran görüntüsü kaydedilemedi.' };

      pushNotification(
        settings.language === 'tr' ? 'Ekran Görüntüsü Kaydedildi' : 'Screenshot Saved',
        targetPath,
        'viewer'
      );
      return { ok: true, path: targetPath };
    } catch (err) {
      return { ok: false, error: err instanceof Error ? err.message : 'Ekran görüntüsü hatası' };
    }
  }, [settings.theme, settings.language, currentUser.username, currentUser.homeDir, activeWorkspace, writeFile, pushNotification]);

  captureScreenshotRef.current = captureDesktopScreenshot;

  const installPackage = useCallback(
    (pkgNameOrAppId: string) => {
      const pkg = PACKAGE_REGISTRY.find(
        (p) => p.pkgName === pkgNameOrAppId || p.appId === pkgNameOrAppId
      );
      if (!pkg) return { ok: false, message: `Paket bulunamadı: ${pkgNameOrAppId}` };
      if (installedPackages.includes(pkg.appId)) {
        return { ok: false, message: `${pkg.pkgName} zaten kurulu.` };
      }
      setInstalledPackages((prev) => [...prev, pkg.appId]);
      setVfs((prev) =>
        vfsWriteFile(
          prev,
          `/bin/${pkg.pkgName}`,
          `#!/bin/ankash\n# AnkaOS Paket İkilisi: ${pkg.pkgName} v${pkg.version}\n`,
          'text/plain',
          { user: 'root', elevatedRoot: true }
        ).root
      );
      recordSyscall(1, 'sys_pkg_install', pkg.pkgName, 'OK');
      addKernelLog('INFO', 'pkg', `Paket kuruldu: ${pkg.pkgName} (${pkg.version})`);
      return { ok: true, message: `${pkg.pkgName} v${pkg.version} başarıyla kuruldu.` };
    },
    [installedPackages, recordSyscall, addKernelLog]
  );

  const removePackage = useCallback(
    (pkgNameOrAppId: string) => {
      const pkg = PACKAGE_REGISTRY.find(
        (p) => p.pkgName === pkgNameOrAppId || p.appId === pkgNameOrAppId
      );
      if (!pkg) return { ok: false, message: `Paket bulunamadı: ${pkgNameOrAppId}` };
      if (!installedPackages.includes(pkg.appId)) {
        return { ok: false, message: `${pkg.pkgName} kurulu değil.` };
      }
      windows
        .filter((w) => w.appId === pkg.appId)
        .forEach((w) => closeWindow(w.id));

      setInstalledPackages((prev) => prev.filter((id) => id !== pkg.appId));
      setVfs((prev) =>
        vfsDelete(prev, `/bin/${pkg.pkgName}`, { user: 'root', elevatedRoot: true }).root
      );
      recordSyscall(1, 'sys_pkg_remove', pkg.pkgName, 'OK');
      addKernelLog('WARN', 'pkg', `Paket kaldırıldı: ${pkg.pkgName}`);
      return { ok: true, message: `${pkg.pkgName} sistemden kaldırıldı.` };
    },
    [installedPackages, windows, closeWindow, recordSyscall, addKernelLog]
  );

  const setPowerProfile = useCallback(
    (profile: PowerProfile) => {
      setPowerProfileState(profile);
      try {
        localStorage.setItem('ankaos_power_v1', profile);
      } catch {
        // ignore
      }
      const meta = POWER_PROFILE_META[profile];
      recordSyscall(1, 'sys_power_profile', `${profile} (${meta.quantumMs}ms)`, 'OK', 0);
      addKernelLog('INFO', 'power', `Güç profili güncellendi: ${meta.labelTr} (kuantum=${meta.quantumMs} ms)`);
    },
    [recordSyscall, addKernelLog]
  );

  const controlService = useCallback(
    (name: string, action: 'start' | 'stop' | 'restart') => {
      const res = controlServiceUnit(servicesRef.current, name, action);
      if (!res.ok) return { ok: false, message: res.message };
      setServices(res.services);
      if (name === 'netd' && res.unit) {
        const nextStatus = res.unit.status === 'active' ? 'UP' : 'DOWN';
        setNetworkInterfaces((prev) =>
          prev.map((ifc) => (ifc.name === 'eth0' ? { ...ifc, status: nextStatus } : ifc))
        );
      }
      recordSyscall(1, 'sys_ankactl', `${action} ${name}`, 'OK', 0);
      addKernelLog('INFO', 'ankactl', res.message);
      return { ok: true, message: res.message };
    },
    [recordSyscall, addKernelLog]
  );

  const addCronJob = useCallback(
    (name: string, intervalSec: number, command: string) => {
      const job = createCronJob(name, intervalSec, command);
      setCronJobs((prev) => [...prev, job]);
      recordSyscall(80, 'sys_cron_add', `${job.intervalSec}s: ${job.command}`, 'OK', 0);
      addKernelLog('INFO', 'cron', `Yeni zamanlanmış görev eklendi: ${job.name} (${job.intervalSec}sn)`);
      return job;
    },
    [recordSyscall, addKernelLog]
  );

  const removeCronJob = useCallback(
    (id: string) => {
      let existed = false;
      setCronJobs((prev) => {
        existed = prev.some((j) => j.id === id);
        return prev.filter((j) => j.id !== id);
      });
      if (existed) {
        recordSyscall(80, 'sys_cron_del', id, 'OK', 0);
      }
      return existed;
    },
    [recordSyscall]
  );

  const toggleCronJob = useCallback((id: string) => {
    setCronJobs((prev) =>
      prev.map((j) => (j.id === id ? { ...j, enabled: !j.enabled } : j))
    );
  }, []);

  const runCronJobNow = useCallback(
    (id: string) => {
      const target = cronJobs.find((j) => j.id === id);
      if (!target) return `Görev bulunamadı: ${id}`;
      const now = Date.now();
      const stamp = new Date(now).toLocaleTimeString('tr-TR');
      if (target.command.startsWith('fsck')) {
        const check = runVfsFsck(vfs, currentUser.homeDir, currentUser.username, true);
        setVfs(check.root);
      }
      setCronJobs((prev) =>
        prev.map((j) =>
          j.id === id
            ? { ...j, runCount: j.runCount + 1, lastRunAt: now, lastResult: `Elle OK (${stamp})` }
            : j
        )
      );
      addKernelLog('INFO', 'cron', `Görev çalıştırıldı: ${target.command}`);
      return `Görev çalıştırıldı: ${target.name} (${stamp})`;
    },
    [cronJobs, vfs, currentUser.homeDir, currentUser.username, addKernelLog]
  );

  const runDiskCheck = useCallback(
    (repair = true): FsckReport => {
      const res = runVfsFsck(vfs, currentUser.homeDir, currentUser.username, repair);
      if (repair && res.report.repairedCount > 0) {
        setVfs(res.root);
      }
      recordSyscall(
        12,
        'sys_fsck',
        `nodes=${res.report.checkedNodes} fixed=${res.report.repairedCount}`,
        'OK',
        0
      );
      addKernelLog(
        res.report.issuesFound > 0 ? 'WARN' : 'INFO',
        'fsck',
        `VFS denetimi: ${res.report.checkedNodes} düğüm kontrol edildi, ${res.report.repairedCount} onarıldı`
      );
      return res.report;
    },
    [vfs, currentUser.homeDir, currentUser.username, recordSyscall, addKernelLog]
  );

  const createArchiveFromVfs = useCallback(
    (targetPath: string, archiveOutPath: string) => {
      const built = createAnkaArchive(vfs, targetPath);
      if (!built.ok || !built.json || !built.bundle) {
        return { ok: false, message: built.error || 'Arşiv oluşturulamadı' };
      }
      const wRes = vfsWriteFile(
        vfs,
        archiveOutPath,
        built.json,
        'application/vnd.ankaos.archive+json',
        { user: currentUser.username }
      );
      if (!wRes.ok) return { ok: false, message: wRes.error || 'Arşiv yazılamadı' };
      setVfs(wRes.root);
      recordSyscall(12, 'sys_tar_pack', `${targetPath} -> ${archiveOutPath}`, 'OK');
      addKernelLog('INFO', 'vfs', `Arşiv oluşturuldu: ${archiveOutPath} (${built.bundle.entryCount} öğe)`);
      return {
        ok: true,
        message: `Arşiv oluşturuldu: ${archiveOutPath} (${built.bundle.entryCount} öğe, ${built.bundle.totalBytes} B)`,
      };
    },
    [vfs, currentUser.username, recordSyscall, addKernelLog]
  );

  const extractArchiveToVfs = useCallback(
    (archivePath: string, destDirPath: string) => {
      const node = getNodeAtPath(vfs, archivePath);
      if (!node || node.type !== 'file' || !node.content) {
        return { ok: false, message: `Arşiv bulunamadı: ${archivePath}` };
      }
      const res = extractAnkaArchive(vfs, node.content, destDirPath, {
        user: currentUser.username,
      });
      if (!res.ok) return { ok: false, message: res.error || 'Arşiv açılamadı' };
      setVfs(res.root);
      recordSyscall(12, 'sys_tar_extract', `${archivePath} -> ${destDirPath}`, 'OK');
      addKernelLog('INFO', 'vfs', `Arşiv açıldı: ${res.extractedPath}`);
      return {
        ok: true,
        message: `Arşiv açıldı: ${res.extractedPath} (${res.entryCount || 1} öğe)`,
      };
    },
    [vfs, currentUser.username, recordSyscall, addKernelLog]
  );

  const refreshNetStatus = useCallback(async () => {
    const status = await fetchNetStatus();
    setNetStatus(status);
    return status;
  }, []);

  useEffect(() => {
    if (bootPhase === 'desktop') {
      void refreshNetStatus();
    }
  }, [bootPhase, refreshNetStatus]);

  const rebootSystem = useCallback(() => {
    const freshBoot = bootKernelProcesses();
    setWindows([]);
    setActiveWindowId(null);
    setProcesses(freshBoot.processes);
    setFrames(freshBoot.frames);
    setSwapSlots(createInitialSwap());
    setSchedulerStats(createInitialSchedulerStats());
    setBackgroundJobs([]);
    setServices(createInitialServices());
    setActiveWorkspace(1);
    uptimeRef.current = 0;
    setUptimeSec(0);
    setLauncherOpen(false);
    setSwitcherOpen(false);
    setBootPhase('booting');
    addKernelLog('INFO', 'kernel', 'Sistem yeniden başlatılıyor...');
  }, [addKernelLog]);

  const value = useMemo<OSContextValue>(
    () => ({
      bootPhase,
      setBootPhase,
      rebootSystem,
      uptimeSec,
      settings,
      updateSettings,
      toggleTheme,
      users,
      currentUser,
      switchUser,
      createUser,
      verifyUserPassword,
      setUserPassword,
      vfs,
      clipboard,
      setClipboard,
      writeFile,
      makeDir,
      deleteNode,
      renameNode,
      copyNode,
      moveNode,
      trashNode,
      restoreTrashItem,
      emptyTrash,
      chmodNode,
      resetVFS,
      exportSystemSnapshot,
      importSystemSnapshot,
      openFileWithDefaultApp,
      activeWorkspace,
      setActiveWorkspace,
      windows,
      activeWindowId,
      switcherOpen,
      setSwitcherOpen,
      launchApp,
      closeWindow,
      focusWindow,
      minimizeWindow,
      toggleMaximizeWindow,
      snapWindow,
      moveWindow,
      resizeWindow,
      moveWindowToWorkspace,
      updateWindowTitle,
      processes,
      schedulerStats,
      ioQueueStats,
      ioQueueTasks,
      forkProcess,
      triggerCowWriteFault,
      attemptKernelMemoryAccess,
      reportProcessFault,
      pendingPermissionRequest,
      resolvePermissionRequest,
      grantSandboxPermission,
      revokeSandboxPermission,
      backgroundJobs,
      spawnBackgroundJob,
      networkInterfaces,
      recordNetworkTraffic,
      frames,
      swapSlots,
      compositorStats,
      updateCompositorStats: setCompositorStats,
      syscalls,
      killProcess,
      signalProcess,
      reniceProcess,
      metricsHistory,
      kernelLogs,
      addKernelLog,
      clearKernelLogs,
      installedPackages,
      installPackage,
      removePackage,
      powerProfile,
      setPowerProfile,
      services,
      controlService,
      cronJobs,
      addCronJob,
      removeCronJob,
      toggleCronJob,
      runCronJobNow,
      runDiskCheck,
      createArchiveFromVfs,
      extractArchiveToVfs,
      netStatus,
      refreshNetStatus,
      daemonTelemetry,
      captureDesktopScreenshot,
      notifications,
      activeToasts,
      dismissToast,
      pushNotification,
      clearNotifications,
      markNotificationsRead,
      launcherOpen,
      setLauncherOpen,
    }),
    [
      bootPhase,
      rebootSystem,
      uptimeSec,
      settings,
      updateSettings,
      toggleTheme,
      users,
      currentUser,
      switchUser,
      createUser,
      verifyUserPassword,
      setUserPassword,
      vfs,
      clipboard,
      writeFile,
      makeDir,
      deleteNode,
      renameNode,
      copyNode,
      moveNode,
      trashNode,
      restoreTrashItem,
      emptyTrash,
      chmodNode,
      resetVFS,
      exportSystemSnapshot,
      importSystemSnapshot,
      openFileWithDefaultApp,
      activeWorkspace,
      windows,
      activeWindowId,
      switcherOpen,
      launchApp,
      closeWindow,
      focusWindow,
      minimizeWindow,
      toggleMaximizeWindow,
      snapWindow,
      moveWindow,
      resizeWindow,
      moveWindowToWorkspace,
      updateWindowTitle,
      processes,
      schedulerStats,
      ioQueueStats,
      ioQueueTasks,
      forkProcess,
      triggerCowWriteFault,
      attemptKernelMemoryAccess,
      reportProcessFault,
      pendingPermissionRequest,
      resolvePermissionRequest,
      grantSandboxPermission,
      revokeSandboxPermission,
      backgroundJobs,
      spawnBackgroundJob,
      networkInterfaces,
      recordNetworkTraffic,
      frames,
      swapSlots,
      compositorStats,
      syscalls,
      killProcess,
      signalProcess,
      reniceProcess,
      metricsHistory,
      kernelLogs,
      addKernelLog,
      clearKernelLogs,
      installedPackages,
      installPackage,
      removePackage,
      powerProfile,
      setPowerProfile,
      services,
      controlService,
      cronJobs,
      addCronJob,
      removeCronJob,
      toggleCronJob,
      runCronJobNow,
      runDiskCheck,
      createArchiveFromVfs,
      extractArchiveToVfs,
      netStatus,
      refreshNetStatus,
      daemonTelemetry,
      captureDesktopScreenshot,
      notifications,
      activeToasts,
      dismissToast,
      pushNotification,
      clearNotifications,
      markNotificationsRead,
      launcherOpen,
    ]
  );

  return <OSContext.Provider value={value}>{children}</OSContext.Provider>;
};

export function useOS(): OSContextValue {
  const ctx = useContext(OSContext);
  if (!ctx) throw new Error('useOS must be used within OSProvider');
  return ctx;
}
