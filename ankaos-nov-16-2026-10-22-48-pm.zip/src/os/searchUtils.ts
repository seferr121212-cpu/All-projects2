import { VFSNode } from './types';
import { listDir } from './vfs';

export type SearchCategory = 'all' | 'wiki' | 'dev' | 'news' | 'images' | 'files';

export interface SmartInstantResult {
  kind: 'math' | 'color' | 'unit' | 'dns' | 'bang';
  title: string;
  value: string;
  subtitle?: string;
  hex?: string;
  dnsHost?: string;
  categoryOverride?: SearchCategory;
  cleanedQuery?: string;
}

export interface LocalVfsMatch {
  path: string;
  name: string;
  type: 'file' | 'dir';
  size: number;
  snippet: string;
}

const UNIT_FACTORS_TO_BASE: Record<string, { group: 'len' | 'mass' | 'data'; factor: number; label: string }> = {
  km: { group: 'len', factor: 1000, label: 'km' },
  m: { group: 'len', factor: 1, label: 'm' },
  cm: { group: 'len', factor: 0.01, label: 'cm' },
  mm: { group: 'len', factor: 0.001, label: 'mm' },
  mi: { group: 'len', factor: 1609.344, label: 'mil' },
  mil: { group: 'len', factor: 1609.344, label: 'mil' },
  mile: { group: 'len', factor: 1609.344, label: 'mil' },
  ft: { group: 'len', factor: 0.3048, label: 'ft' },
  in: { group: 'len', factor: 0.0254, label: 'inç' },
  kg: { group: 'mass', factor: 1000, label: 'kg' },
  g: { group: 'mass', factor: 1, label: 'g' },
  lb: { group: 'mass', factor: 453.59237, label: 'lb' },
  oz: { group: 'mass', factor: 28.3495, label: 'oz' },
  tb: { group: 'data', factor: 1024 * 1024 * 1024 * 1024, label: 'TB' },
  gb: { group: 'data', factor: 1024 * 1024 * 1024, label: 'GB' },
  mb: { group: 'data', factor: 1024 * 1024, label: 'MB' },
  kb: { group: 'data', factor: 1024, label: 'KB' },
  b: { group: 'data', factor: 1, label: 'B' },
};

function hexToRgbHsl(hex: string): { rgb: string; hsl: string } | null {
  const clean = hex.replace('#', '');
  const full = clean.length === 3 ? clean.split('').map((c) => c + c).join('') : clean;
  if (!/^[0-9a-f]{6}$/i.test(full)) return null;
  const r = parseInt(full.slice(0, 2), 16);
  const g = parseInt(full.slice(2, 4), 16);
  const b = parseInt(full.slice(4, 6), 16);

  const rn = r / 255;
  const gn = g / 255;
  const bn = b / 255;
  const max = Math.max(rn, gn, bn);
  const min = Math.min(rn, gn, bn);
  const l = (max + min) / 2;
  let h = 0;
  let s = 0;
  if (max !== min) {
    const d = max - min;
    s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
    switch (max) {
      case rn:
        h = (gn - bn) / d + (gn < bn ? 6 : 0);
        break;
      case gn:
        h = (bn - rn) / d + 2;
        break;
      case bn:
        h = (rn - gn) / d + 4;
        break;
    }
    h /= 6;
  }
  return {
    rgb: `rgb(${r}, ${g}, ${b})`,
    hsl: `hsl(${Math.round(h * 360)}, ${Math.round(s * 100)}%, ${Math.round(l * 100)}%)`,
  };
}

/**
 * Parses smart search intents (math, hex color, unit conversions, bangs, dns:host).
 */
export function parseSmartQuery(rawQuery: string): SmartInstantResult | null {
  const trimmed = rawQuery.trim();
  if (!trimmed) return null;

  // 1. Bangs (!viki, !wiki, !gh, !dev, !haber, !news, !gorsel, !img, !dosya)
  const bangMatch = trimmed.match(/^!(viki|wiki|gh|dev|haber|news|gorsel|görsel|img|dosya|files)\s+(.+)$/i);
  if (bangMatch) {
    const tag = bangMatch[1].toLowerCase();
    const rest = bangMatch[2].trim();
    const map: Record<string, SearchCategory> = {
      viki: 'wiki',
      wiki: 'wiki',
      gh: 'dev',
      dev: 'dev',
      haber: 'news',
      news: 'news',
      gorsel: 'images',
      görsel: 'images',
      img: 'images',
      dosya: 'files',
      files: 'files',
    };
    const cat = map[tag] || 'all';
    return {
      kind: 'bang',
      title: `Kategori Kısayolu (!${tag})`,
      value: rest,
      categoryOverride: cat,
      cleanedQuery: rest,
    };
  }

  // 2. DNS quick lookup: dns:example.com
  const dnsMatch = trimmed.match(/^dns:([a-z0-9.-]+)$/i);
  if (dnsMatch) {
    return {
      kind: 'dns',
      title: 'AnkaNet DNS Sorgusu',
      value: dnsMatch[1].toLowerCase(),
      dnsHost: dnsMatch[1].toLowerCase(),
    };
  }

  // 3. Hex color preview: #0ea5e9 or #38f
  if (/^#([0-9a-f]{3}|[0-9a-f]{6})$/i.test(trimmed)) {
    const info = hexToRgbHsl(trimmed);
    if (info) {
      return {
        kind: 'color',
        title: 'Renk Dönüştürücü',
        value: trimmed.toUpperCase(),
        subtitle: `${info.rgb} · ${info.hsl}`,
        hex: trimmed,
      };
    }
  }

  // 4. Unit conversion: "100 km to mil", "25 c -> f", "2 gb mb"
  const unitMatch = trimmed.match(
    /^(-?\d+(?:[.,]\d+)?)\s*([a-zA-Z]+)\s*(?:->|to|in|ila|kaç|kac)?\s*([a-zA-Z]+)$/i
  );
  if (unitMatch) {
    const num = Number(unitMatch[1].replace(',', '.'));
    const from = unitMatch[2].toLowerCase();
    const to = unitMatch[3].toLowerCase();
    if (Number.isFinite(num)) {
      if ((from === 'c' || from === 'celsius') && (to === 'f' || to === 'fahrenheit')) {
        const res = (num * 9) / 5 + 32;
        return {
          kind: 'unit',
          title: 'Sıcaklık Dönüşümü',
          value: `${Number(res.toFixed(2))} °F`,
          subtitle: `${num} °C`,
        };
      }
      if ((from === 'f' || from === 'fahrenheit') && (to === 'c' || to === 'celsius')) {
        const res = ((num - 32) * 5) / 9;
        return {
          kind: 'unit',
          title: 'Sıcaklık Dönüşümü',
          value: `${Number(res.toFixed(2))} °C`,
          subtitle: `${num} °F`,
        };
      }
      const fSpec = UNIT_FACTORS_TO_BASE[from];
      const tSpec = UNIT_FACTORS_TO_BASE[to];
      if (fSpec && tSpec && fSpec.group === tSpec.group) {
        const converted = (num * fSpec.factor) / tSpec.factor;
        const formatted = converted >= 0.01 ? Number(converted.toFixed(4)) : Number(converted.toExponential(3));
        return {
          kind: 'unit',
          title: 'Birim Dönüşümü',
          value: `${formatted} ${tSpec.label}`,
          subtitle: `${num} ${fSpec.label}`,
        };
      }
    }
  }

  // 5. Math expression (supports +, -, *, /, ^, %, sqrt(), abs())
  const mathExpr = trimmed.replace(/^=\s*/, '');
  const safeCheck = mathExpr
    .replace(/\b(sqrt|abs|round|floor|ceil|sin|cos|tan|log|pi|e)\b/gi, '')
    .trim();
  if (
    /[+\-*/%^]|sqrt|sin|cos|log/i.test(mathExpr) &&
    /^[0-9+\-*/().%\s^,]*$/.test(safeCheck)
  ) {
    try {
      const prepared = mathExpr
        .replace(/\^/g, '**')
        .replace(/\bsqrt\(/gi, 'Math.sqrt(')
        .replace(/\babs\(/gi, 'Math.abs(')
        .replace(/\bround\(/gi, 'Math.round(')
        .replace(/\bfloor\(/gi, 'Math.floor(')
        .replace(/\bceil\(/gi, 'Math.ceil(')
        .replace(/\bsin\(/gi, 'Math.sin(')
        .replace(/\bcos\(/gi, 'Math.cos(')
        .replace(/\btan\(/gi, 'Math.tan(')
        .replace(/\blog\(/gi, 'Math.log10(')
        .replace(/\bpi\b/gi, 'Math.PI')
        .replace(/\be\b/gi, 'Math.E');
      const val = Function(`"use strict"; return (${prepared})`)();
      if (typeof val === 'number' && Number.isFinite(val)) {
        return {
          kind: 'math',
          title: 'Hesaplayıcı',
          value: `= ${Number(val.toFixed(6))}`,
          subtitle: mathExpr,
        };
      }
    } catch {
      // Fall through to web search
    }
  }

  return null;
}

/**
 * Recursively searches local AnkaOS VFS under userHome & /etc for filename or text matches.
 */
export function searchLocalVfs(vfs: VFSNode, userHome: string, query: string): LocalVfsMatch[] {
  const q = query.trim().toLowerCase();
  if (!q) return [];
  const matches: LocalVfsMatch[] = [];

  const walk = (dirPath: string, depth: number) => {
    if (depth > 6 || matches.length >= 25) return;
    const children = listDir(vfs, dirPath);
    for (const node of children) {
      if (node.name.startsWith('.')) continue;
      const fullPath = dirPath === '/' ? `/${node.name}` : `${dirPath}/${node.name}`;
      const nameMatch = node.name.toLowerCase().includes(q);
      let contentSnippet = '';
      if (node.type === 'file' && node.content && node.mimeType !== 'image/data') {
        const idx = node.content.toLowerCase().indexOf(q);
        if (idx !== -1) {
          const start = Math.max(0, idx - 32);
          const end = Math.min(node.content.length, idx + q.length + 72);
          contentSnippet = node.content.slice(start, end).replace(/\s+/g, ' ').trim();
        }
      }
      if (nameMatch || contentSnippet) {
        matches.push({
          path: fullPath,
          name: node.name,
          type: node.type,
          size: node.size,
          snippet: contentSnippet || (node.type === 'dir' ? 'Klasör' : `${node.mimeType || 'metin'} dosyası`),
        });
      }
      if (node.type === 'dir') {
        walk(fullPath, depth + 1);
      }
    }
  };

  walk(userHome, 0);
  return matches;
}
