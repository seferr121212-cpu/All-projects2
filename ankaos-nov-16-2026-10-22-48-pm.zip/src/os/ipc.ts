import { IPCMessage } from './types';

type IPCHandler = (msg: IPCMessage) => void;

class KernelIPCBus {
  private listeners = new Map<string, Set<IPCHandler>>();
  private history: IPCMessage[] = [];

  subscribe(channel: string, handler: IPCHandler): () => void {
    if (!this.listeners.has(channel)) {
      this.listeners.set(channel, new Set());
    }
    this.listeners.get(channel)!.add(handler);
    return () => {
      this.listeners.get(channel)?.delete(handler);
    };
  }

  publish(channel: string, fromPid: number, payload: unknown): IPCMessage {
    const msg: IPCMessage = {
      id: `ipc-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      channel,
      fromPid,
      payload,
      timestamp: Date.now(),
    };
    this.history = [...this.history.slice(-49), msg];
    this.listeners.get(channel)?.forEach((fn) => fn(msg));
    this.listeners.get('*')?.forEach((fn) => fn(msg));
    return msg;
  }

  getHistory(): IPCMessage[] {
    return this.history;
  }
}

export const ipcBus = new KernelIPCBus();
