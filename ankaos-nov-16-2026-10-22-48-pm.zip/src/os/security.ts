import { AppId, ASLRMemoryLayout, OSProcess, PrivilegeRing } from './types';

/**
 * Virtual memory boundary separating Ring 3 User Space from Ring 0 Kernel Space.
 * Any address >= 0xffff800000000000 belongs strictly to Ring 0 Kernel Space.
 */
export const KERNEL_SPACE_BOUNDARY_HEX = '0xffff800000000000';
const KERNEL_SPACE_BOUNDARY = 0xffff800000000000n;

export class RingProtectionFault extends Error {
  readonly pid: number;
  readonly ring: PrivilegeRing;
  readonly faultAddress: string;

  constructor(pid: number, ring: PrivilegeRing, faultAddress: string, message: string) {
    super(message);
    this.name = 'RingProtectionFault';
    this.pid = pid;
    this.ring = ring;
    this.faultAddress = faultAddress;
  }
}

function getRandomUint32(): number {
  if (typeof crypto !== 'undefined' && typeof crypto.getRandomValues === 'function') {
    const buf = new Uint32Array(1);
    crypto.getRandomValues(buf);
    return buf[0];
  }
  return Math.floor(Math.random() * 0xffffffff);
}

function formatHex64(val: bigint): string {
  return '0x' + val.toString(16).padStart(16, '0');
}

/**
 * Generates an ASLR (Address Space Layout Randomization) virtual memory map
 * for newly spawned processes. Randomizes Code, Heap, and Stack bases within User Space
 * strictly below the Ring 0 kernel boundary.
 */
export function generateASLRLayout(ring: PrivilegeRing = 3): ASLRMemoryLayout {
  if (ring === 0) {
    return {
      codeBase: '0xffffffff81000000',
      heapBase: '0xffff888000000000',
      stackBase: '0xffffc90000000000',
      aslrSlide: '0x0000000000000000',
      kernelBoundary: KERNEL_SPACE_BOUNDARY_HEX,
    };
  }

  // Page-aligned (4 KB = 0x1000) random slides in User Space
  const codeSlide = BigInt(getRandomUint32() & 0x0fff) * 0x1000n;
  const heapSlide = BigInt(getRandomUint32() & 0xffff) * 0x1000n;
  const stackSlide = BigInt(getRandomUint32() & 0xffff) * 0x1000n;

  const codeBase = 0x000000400000n + codeSlide;
  const heapBase = 0x000010000000n + heapSlide;
  const stackBase = 0x00007fff00000000n - stackSlide;

  return {
    codeBase: formatHex64(codeBase),
    heapBase: formatHex64(heapBase),
    stackBase: formatHex64(stackBase),
    aslrSlide: formatHex64(codeSlide + heapSlide),
    kernelBoundary: KERNEL_SPACE_BOUNDARY_HEX,
  };
}

/**
 * Enforces strict Ring 0 / Ring 3 memory isolation.
 * Prevents Ring 3 user applications from reading/writing Ring 0 kernel memory,
 * containing faults to the offending user process instead of triggering a Kernel Panic.
 */
export function assertKernelAccess(
  proc: Pick<OSProcess, 'pid' | 'name' | 'privilegeRing'>,
  targetAddressHex: string
): { allowed: boolean; fault?: RingProtectionFault } {
  const cleanHex = targetAddressHex.trim().toLowerCase();
  let parsed: bigint;
  try {
    parsed = BigInt(cleanHex.startsWith('0x') ? cleanHex : `0x${cleanHex}`);
  } catch {
    return {
      allowed: false,
      fault: new RingProtectionFault(
        proc.pid,
        proc.privilegeRing,
        targetAddressHex,
        `Geçersiz sanal bellek adresi: ${targetAddressHex}`
      ),
    };
  }

  if (parsed >= KERNEL_SPACE_BOUNDARY && proc.privilegeRing !== 0) {
    return {
      allowed: false,
      fault: new RingProtectionFault(
        proc.pid,
        proc.privilegeRing,
        formatHex64(parsed),
        `SIGSEGV (Ring 3 İhlali): '${proc.name}' (PID ${proc.pid}) çekirdek adresi ${formatHex64(parsed)} erişimi engellendi — Kernel Panic önlendi.`
      ),
    };
  }

  return { allowed: true };
}

// --- Sandbox / İzin Yöneticisi (Syscall-level directory isolation) ---

const CORE_TRUSTED_APPS: ReadonlySet<AppId> = new Set(['terminal', 'files', 'settings', 'monitor']);

export function getAppSandboxDir(username: string, appId: AppId): string {
  return `/home/${username}/.sandbox/${appId}`;
}

export function isProtectedUserDocumentPath(targetPath: string, username: string): boolean {
  const home = `/home/${username}`;
  const protectedRoots = [
    `${home}/Belgeler`,
    `${home}/Masaüstü`,
    `${home}/Projeler`,
    `${home}/Resimler`,
    `${home}/Müzik`,
    `${home}/İndirilenler`,
  ];
  return protectedRoots.some(
    (prefix) => targetPath === prefix || targetPath.startsWith(`${prefix}/`)
  );
}

export interface SandboxDecision {
  allowed: boolean;
  requiresPrompt: boolean;
  reason?: string;
  capability?: 'docs:rw';
}

/**
 * Intercepts VFS syscalls from Ring 3 applications.
 * - Apps can always write to their own sandbox directory (/home/<user>/.sandbox/<appId>) and /tmp.
 * - Trusted system tools (Files, Terminal, Settings) or elevated root calls pass POSIX checks directly.
 * - Other apps accessing protected user document directories require explicit 'docs:rw' capability grant.
 */
export function checkSandboxSyscall(
  appId: AppId | 'kernel',
  operation: 'read' | 'write' | 'delete',
  targetPath: string,
  username: string,
  sandboxGrants: Record<string, string[]>,
  elevatedRoot = false
): SandboxDecision {
  if (elevatedRoot || appId === 'kernel' || CORE_TRUSTED_APPS.has(appId)) {
    return { allowed: true, requiresPrompt: false };
  }

  const sandboxDir = getAppSandboxDir(username, appId);
  if (
    targetPath === sandboxDir ||
    targetPath.startsWith(`${sandboxDir}/`) ||
    targetPath === '/tmp' ||
    targetPath.startsWith('/tmp/')
  ) {
    return { allowed: true, requiresPrompt: false };
  }

  if (isProtectedUserDocumentPath(targetPath, username)) {
    const grants = sandboxGrants[appId] || [];
    if (grants.includes('docs:rw')) {
      return { allowed: true, requiresPrompt: false };
    }
    return {
      allowed: false,
      requiresPrompt: true,
      capability: 'docs:rw',
      reason: `Sandbox Koruması: '${appId}' uygulaması '${targetPath}' (${operation}) için kullanıcı belgeleri iznine ('docs:rw') sahip değil.`,
    };
  }

  // System files (/etc, /bin, /var) cannot be written by sandboxed Ring 3 apps
  if (operation !== 'read') {
    return {
      allowed: false,
      requiresPrompt: false,
      reason: `Sandbox Koruması: '${appId}' yalnızca kendi çalışma dizinine (${sandboxDir}) yazabilir.`,
    };
  }

  return { allowed: true, requiresPrompt: false };
}
