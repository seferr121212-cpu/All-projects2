import { applyChmod, canWriteNode } from './auth';
import { systemIOQueue } from './ioQueue';
import { getMemorySummary } from './mmu';
import { buildSampleMathWasmContent } from './sandboxRuntime';
import { MemoryFrame, OSProcess, SwapSlot, VFSNode } from './types';
import { WASM_TEMPLATES } from './wasmCompiler';

export const TRASH_INDEX_FILENAME = '.trash_index.json';

export interface TrashIndexEntry {
  trashName: string;
  originalPath: string;
  originalName: string;
  deletedAt: number;
}

export const VFS_STORAGE_KEY = 'ankaos_vfs_v2';
export const HOME_PATH = '/home/kullanici';

const IDB_NAME = 'AnkaOS_BlockDevice';
const IDB_STORE = 'vfs_blocks';

function writeIDBMirror(root: VFSNode): void {
  if (typeof indexedDB === 'undefined') return;
  // Asenkron G/Ç Kuyruğu: IndexedDB yazma işlemi arayüz karelerini (UI) kilitlememesi için arka plan kuyruğuna atılır.
  void systemIOQueue
    .enqueue(
      'sync',
      '/dev/sda1 (rootfs)',
      () =>
        new Promise<void>((resolve) => {
          try {
            const req = indexedDB.open(IDB_NAME, 1);
            req.onupgradeneeded = () => {
              const db = req.result;
              if (!db.objectStoreNames.contains(IDB_STORE)) {
                db.createObjectStore(IDB_STORE);
              }
            };
            req.onsuccess = () => {
              const db = req.result;
              const tx = db.transaction(IDB_STORE, 'readwrite');
              tx.objectStore(IDB_STORE).put(root, 'rootfs');
              tx.oncomplete = () => resolve();
              tx.onerror = () => resolve();
            };
            req.onerror = () => resolve();
          } catch {
            resolve();
          }
        }),
      'low'
    )
    .catch(() => {});
}

function makeFile(
  name: string,
  content: string,
  mimeType = 'text/plain',
  permissions = '-rw-r--r--',
  owner = 'kullanici'
): VFSNode {
  const now = Date.now();
  return {
    id: `${name}-${Math.random().toString(36).slice(2, 8)}`,
    name,
    type: 'file',
    content,
    mimeType,
    permissions,
    owner,
    size: typeof Blob !== 'undefined' ? new Blob([content]).size : content.length,
    createdAt: now,
    updatedAt: now,
  };
}

function makeDir(
  name: string,
  children: Record<string, VFSNode> = {},
  permissions = 'drwxr-xr-x',
  owner = 'kullanici'
): VFSNode {
  const now = Date.now();
  return {
    id: `${name}-${Math.random().toString(36).slice(2, 8)}`,
    name,
    type: 'dir',
    permissions,
    owner,
    size: Object.keys(children).length * 4096,
    createdAt: now,
    updatedAt: now,
    children,
  };
}

export function createInitialVFS(): VFSNode {
  const readmeText = `# AnkaOS v3.5 — Bağımsız Çekirdek ve Masaüstü Sistemi

AnkaOS, modüler çekirdek mimarisi üzerine inşa edilmiş bağımsız bir sanal işletim sistemidir:
- Ring 3 Web Worker Watchdog JS Sandbox & Gerçek WebAssembly (.wasm) Çalıştırıcısı
- Preemptive Priority Zamanlayıcı & POSIX sinyalleri (SIGSTOP / SIGCONT / SIGTERM)
- MMU Copy-on-Write (CoW) + LRU Swap (128 x 32 MB RAM + 64 x 32 MB Swap)
- Ring 0 / Ring 3 Bellek Yalıtımı, ASLR ve Syscall düzeyinde Sandbox İzin Yöneticisi
- AnkaArama Canlı Web Arama Köprüsü, ankactl/crond, du/fsck/tar & Güç Profilleri
- 4-Köşe + 2-Yarım Pencere Döşeme, Gerçek FFT Ses Oynatıcı & Gelişmiş Editör (Bul/Değiştir)
`;

  const helloJs = `// AnkaOS Betik Örneği (Ring 3 Web Worker Watchdog ile çalışır)
const sistem = "AnkaOS 3.5 (Kuzgun)";
console.log("Merhaba! " + sistem + " üzerinde izole Web Worker çalışıyor.");

function fibonacci(n) {
  const seri = [0, 1];
  for (let i = 2; i < n; i++) seri.push(seri[i - 1] + seri[i - 2]);
  return seri;
}

console.log("İlk 10 Fibonacci sayısı:", fibonacci(10).join(", "));
`;

  const defaultAnkashRc = `# AnkaOS ankash başlangıç betiği (~/.ankashrc)
alias ll='ls -la'
alias la='ls -a'
alias cls='clear'
alias sys='neofetch'
`;

  const siteHtml = `<!doctype html>
<html lang="tr">
<head>
  <meta charset="utf-8" />
  <title>AnkaOS Yerel Web Sayfası</title>
  <style>
    body { font-family: system-ui, sans-serif; margin: 40px; background: #0f172a; color: #f8fafc; line-height: 1.6; }
    .card { max-width: 640px; margin: 0 auto; padding: 28px; border: 1px solid #334155; border-radius: 14px; background: #1e293b; }
    h1 { margin-top: 0; color: #38bdf8; }
    code { background: #0f172a; padding: 2px 6px; border-radius: 6px; color: #34d399; }
  </style>
</head>
<body>
  <div class="card">
    <h1>AnkaOS Yerel HTML Önizleme</h1>
    <p>Bu sayfa doğrudan sanal dosya sistemindeki <code>~/Projeler/site.html</code> dosyasından okunuyor.</p>
    <p>Kod Düzenleyici ile bu dosyayı düzenleyip kaydederek sayfayı güncelleyebilirsiniz.</p>
  </div>
</body>
</html>
`;

  const sampleScript = `#!/bin/ankash
echo "AnkaOS Sistem Raporu Oluşturuluyor..."
uname -a
uptime
free
echo "Tamamlandı."
`;

  const sampleNote = `AnkaOS v2.0 Hızlı Rehber

1. Uçbirimde "selftest" yazarak tüm çekirdek ve VFS birim testlerini çalıştırın.
2. "cat /proc/meminfo" veya "vmstat" ile MMU sayfa çerçevelerini inceleyin.
3. "pkg install yilan-oyunu" ile Paket Merkezinden yeni uygulama kurun.
4. "~/Projeler/site.html" dosyasına çift tıklayıp AnkaTarayıcı'da açın.
5. Ayarlar -> Güvenlik bölümünden oturum açma parolası belirleyebilirsiniz.
`;

  return makeDir(
    '/',
    {
      bin: makeDir(
        'bin',
        {
          ankash: makeFile('ankash', '#!/bin/ankash\n# AnkaOS Etkileşimli Kabuk', 'text/plain', '-rwxr-xr-x', 'root'),
          sysmon: makeFile('sysmon', '#!/bin/ankash\n# Sistem İzleme', 'text/plain', '-rwxr-xr-x', 'root'),
          pkg: makeFile('pkg', '#!/bin/ankash\n# AnkaOS Paket Yöneticisi', 'text/plain', '-rwxr-xr-x', 'root'),
          wasmc: makeFile('wasmc', '#!/bin/ankash\n# AnkaOS WAT -> WASM Derleyici', 'text/plain', '-rwxr-xr-x', 'root'),
          wasmpkg: makeFile('wasmpkg', '#!/bin/ankash\n# AnkaOS WASM Modül Paketleyici', 'text/plain', '-rwxr-xr-x', 'root'),
          'wasm-builder': makeFile('wasm-builder', '#!/bin/ankash\n# AnkaOS WASM Studio', 'text/plain', '-rwxr-xr-x', 'root'),
        },
        'drwxr-xr-x',
        'root'
      ),
      dev: makeDir(
        'dev',
        {
          null: makeFile('null', '', 'inode/chardevice', 'crw-rw-rw-', 'root'),
          zero: makeFile('zero', '\0\0\0\0\0\0\0\0', 'inode/chardevice', 'crw-rw-rw-', 'root'),
          random: makeFile('random', '0x8f4a21c9', 'inode/chardevice', 'cr--r--r--', 'root'),
        },
        'drwxr-xr-x',
        'root'
      ),
      proc: makeDir(
        'proc',
        {
          cpuinfo: makeFile('cpuinfo', 'processor: 0..3\nmodel name: AnkaCore Virtual x86_64\n', 'text/plain', '-r--r--r--', 'root'),
          meminfo: makeFile('meminfo', 'MemTotal: 4096 MB\n', 'text/plain', '-r--r--r--', 'root'),
          uptime: makeFile('uptime', '0.00 0.00\n', 'text/plain', '-r--r--r--', 'root'),
          version: makeFile('version', 'AnkaKernel version 6.1.0-ankaos (ankacc 13.2)\n', 'text/plain', '-r--r--r--', 'root'),
        },
        'dr-xr-xr-x',
        'root'
      ),
      etc: makeDir(
        'etc',
        {
          'os-release': makeFile(
            'os-release',
            'NAME="AnkaOS"\nVERSION="3.5.0 (Kuzgun)"\nID=ankaos\nKERNEL="AnkaKernel 6.1.0"\nSHELL="/bin/ankash"\n',
            'text/plain',
            '-rw-r--r--',
            'root'
          ),
          hostname: makeFile('hostname', 'anka-is-istasyonu\n', 'text/plain', '-rw-r--r--', 'root'),
          passwd: makeFile(
            'passwd',
            'root:x:0:0:Sistem Yöneticisi:/root:/bin/ankash\nkullanici:x:1000:1000:Kullanıcı:/home/kullanici:/bin/ankash\n',
            'text/plain',
            '-rw-r--r--',
            'root'
          ),
          hosts: makeFile('hosts', '127.0.0.1\tlocalhost\n127.0.1.1\tanka-is-istasyonu\n', 'text/plain', '-rw-r--r--', 'root'),
        },
        'drwxr-xr-x',
        'root'
      ),
      var: makeDir(
        'var',
        {
          log: makeDir(
            'log',
            {
              'kernel.log': makeFile(
                'kernel.log',
                '[0.000] AnkaKernel 6.1.0 başlatıldı\n[0.140] MMU: 128 sayfa çerçevesi (4096 MB) hazır\n[0.310] VFS & BlockDevice bağlandı\n',
                'text/plain',
                '-rw-r--r--',
                'root'
              ),
            },
            'drwxr-xr-x',
            'root'
          ),
        },
        'drwxr-xr-x',
        'root'
      ),
      tmp: makeDir('tmp', {}, 'drwxrwxrwt', 'root'),
      home: makeDir('home', {
        kullanici: makeDir('kullanici', {
          Masaüstü: makeDir('Masaüstü', {
            'Beni_Oku.md': makeFile('Beni_Oku.md', readmeText, 'text/markdown'),
            'site.html': makeFile('site.html', siteHtml, 'text/html'),
          }),
          Belgeler: makeDir('Belgeler', {
            'Beni_Oku.md': makeFile('Beni_Oku.md', readmeText, 'text/markdown'),
            Notlar: makeDir('Notlar', {
              'Hoş_Geldiniz.txt': makeFile('Hoş_Geldiniz.txt', sampleNote, 'text/plain'),
            }),
          }),
          Projeler: makeDir('Projeler', {
            'merhaba.js': makeFile('merhaba.js', helloJs, 'application/javascript'),
            'site.html': makeFile('site.html', siteHtml, 'text/html'),
            'rapor.sh': makeFile('rapor.sh', sampleScript, 'text/x-shellscript', '-rwxr-xr-x'),
            'merhaba.wat': makeFile('merhaba.wat', WASM_TEMPLATES[0].wat, 'text/wat'),
            'topla.wasm': makeFile('topla.wasm', buildSampleMathWasmContent(), 'application/wasm', '-rwxr-xr-x'),
          }),
          Resimler: makeDir('Resimler', {
            'Alpler_Gece.jpg': makeFile(
              'Alpler_Gece.jpg',
              '/src/assets/images/wallpaper_alpine_night_1794844229998.jpg',
              'image/url'
            ),
            'Altin_Kumlar.jpg': makeFile(
              'Altin_Kumlar.jpg',
              '/src/assets/images/wallpaper_warm_dunes_1794844231117.jpg',
              'image/url'
            ),
            'Mimari_Kirectasi.jpg': makeFile(
              'Mimari_Kirectasi.jpg',
              '/src/assets/images/wallpaper_studio_concrete_1794844231640.jpg',
              'image/url'
            ),
          }),
          İndirilenler: makeDir('İndirilenler', {}),
          Müzik: makeDir('Müzik', {
            'Kuzgun_Ambiyans.ankasynth': makeFile(
              'Kuzgun_Ambiyans.ankasynth',
              JSON.stringify(
                {
                  schema: 'ankaos-synth-v1',
                  id: 'kuzgun-vfs-starter',
                  title: 'Kuzgun VFS Ambiyansı',
                  bpm: 108,
                  waveform: 'triangle',
                  notes: [220, 261.63, 329.63, 392.0, 440.0, 392.0, 329.63, 261.63],
                },
                null,
                2
              ),
              'application/vnd.ankaos.synth+json'
            ),
          }),
          '.bookmarks.json': makeFile(
            '.bookmarks.json',
            JSON.stringify(
              [
                { title: 'Vikipedi (TR)', url: 'https://tr.wikipedia.org' },
                { title: 'MDN Web Docs', url: 'https://developer.mozilla.org' },
                { title: 'Hacker News', url: 'https://news.ycombinator.com' },
                { title: 'Example.com', url: 'https://example.com' },
              ],
              null,
              2
            ),
            'application/json'
          ),
          '.Trash': makeDir('.Trash', {}),
          '.ankashrc': makeFile('.ankashrc', defaultAnkashRc, 'text/x-shellscript'),
          '.sandbox': makeDir('.sandbox', {
            notes: makeDir('notes', {}),
            editor: makeDir('editor', {}),
            paint: makeDir('paint', {}),
            browser: makeDir('browser', {}),
            'wasm-builder': makeDir('wasm-builder', {}),
          }),
        }),
      }),
    },
    'drwxr-xr-x',
    'root'
  );
}

export function loadVFS(): VFSNode {
  try {
    if (typeof localStorage === 'undefined') return createInitialVFS();
    const raw = localStorage.getItem(VFS_STORAGE_KEY);
    if (!raw) {
      const initial = createInitialVFS();
      saveVFS(initial);
      return initial;
    }
    const parsed = JSON.parse(raw) as VFSNode;
    if (!parsed || parsed.type !== 'dir' || !parsed.children) {
      return createInitialVFS();
    }
    return parsed;
  } catch {
    return createInitialVFS();
  }
}

export function saveVFS(root: VFSNode): void {
  try {
    if (typeof localStorage !== 'undefined') {
      localStorage.setItem(VFS_STORAGE_KEY, JSON.stringify(root));
    }
    writeIDBMirror(root);
  } catch {
    // Storage unavailable
  }
}

export function cloneVFS(node: VFSNode): VFSNode {
  return JSON.parse(JSON.stringify(node)) as VFSNode;
}

export function normalizePath(
  inputPath: string,
  cwd = HOME_PATH,
  homePath = HOME_PATH
): string {
  let path = inputPath.trim();
  if (!path || path === '~') {
    return homePath;
  }
  if (path.startsWith('~/')) {
    path = homePath + '/' + path.slice(2);
  } else if (!path.startsWith('/')) {
    path = (cwd === '/' ? '' : cwd) + '/' + path;
  }

  const parts = path.split('/').filter(Boolean);
  const stack: string[] = [];
  for (const part of parts) {
    if (part === '.') continue;
    if (part === '..') {
      stack.pop();
    } else {
      stack.push(part);
    }
  }
  return '/' + stack.join('/');
}

export function getParentAndName(fullPath: string): { parentPath: string; name: string } {
  const norm = normalizePath(fullPath, '/');
  if (norm === '/') return { parentPath: '/', name: '' };
  const parts = norm.split('/').filter(Boolean);
  const name = parts.pop() || '';
  const parentPath = '/' + parts.join('/');
  return { parentPath, name };
}

export function getNodeAtPath(root: VFSNode, targetPath: string): VFSNode | null {
  const norm = normalizePath(targetPath, '/');
  if (norm === '/') return root;
  const parts = norm.split('/').filter(Boolean);
  let curr: VFSNode = root;
  for (const part of parts) {
    if (curr.type !== 'dir' || !curr.children || !curr.children[part]) {
      return null;
    }
    curr = curr.children[part];
  }
  return curr;
}

// Dynamic /proc and /dev reader
export function readDynamicNodeContent(
  root: VFSNode,
  targetPath: string,
  ctx?: { frames: MemoryFrame[]; swapSlots?: SwapSlot[]; processes: OSProcess[]; uptimeSec: number }
): string | null {
  const norm = normalizePath(targetPath, '/');
  if (norm === '/dev/null') return '';
  if (norm === '/dev/zero') return '\0'.repeat(32);
  if (norm === '/dev/random') {
    return Array.from({ length: 16 }, () =>
      Math.floor(Math.random() * 256)
        .toString(16)
        .padStart(2, '0')
    ).join('');
  }
  if (norm === '/proc/uptime' && ctx) {
    return `${ctx.uptimeSec}.00 ${Math.max(0, ctx.uptimeSec - 1)}.42\n`;
  }
  if (norm === '/proc/meminfo' && ctx) {
    const s = getMemorySummary(ctx.frames, ctx.swapSlots || []);
    return [
      `MemTotal:       ${s.totalMB} MB`,
      `MemFree:        ${s.freeMB} MB`,
      `MemUsed:        ${s.usedMB} MB`,
      `CoWSaved:       ${s.cowSavedMB} MB`,
      `SwapTotal:      ${s.swapTotalMB} MB`,
      `SwapUsed:       ${s.swapUsedMB} MB`,
      `SwapFree:       ${s.swapTotalMB - s.swapUsedMB} MB`,
      `PageFrames:     ${s.usedFrames} / ${s.totalFrames} (${s.frameSizeMB} MB/frame)`,
      `Processes:      ${ctx.processes.length}`,
    ].join('\n');
  }
  if (norm === '/proc/cpuinfo') {
    return [
      'processor\t: 0..3',
      'vendor_id\t: AnkaSilicon',
      'model name\t: AnkaCore Virtual x86_64 @ 3.40GHz',
      'cpu cores\t: 4',
      'cache size\t: 8192 KB',
    ].join('\n');
  }

  const node = getNodeAtPath(root, norm);
  if (!node || node.type !== 'file') return null;
  return node.content ?? '';
}

export function listDir(root: VFSNode, dirPath: string): VFSNode[] {
  const node = getNodeAtPath(root, dirPath);
  if (!node || node.type !== 'dir' || !node.children) return [];
  return Object.values(node.children).sort((a, b) => {
    if (a.type !== b.type) return a.type === 'dir' ? -1 : 1;
    return a.name.localeCompare(b.name, 'tr');
  });
}

export function vfsWriteFile(
  root: VFSNode,
  filePath: string,
  content: string,
  mimeType?: string,
  options?: { user?: string; elevatedRoot?: boolean }
): { root: VFSNode; ok: boolean; error?: string } {
  const norm = normalizePath(filePath, '/');
  if (norm === '/dev/null') {
    return { root, ok: true }; // /dev/null discards writes cleanly
  }
  if (norm.startsWith('/proc/') || norm.startsWith('/dev/')) {
    return { root, ok: false, error: `Salt okunur çekirdek yolu: ${norm}` };
  }

  const user = options?.user || 'kullanici';
  const elevated = Boolean(options?.elevatedRoot);
  const next = cloneVFS(root);
  const { parentPath, name } = getParentAndName(norm);
  if (!name) return { root, ok: false, error: 'Geçersiz dosya adı' };
  const parent = getNodeAtPath(next, parentPath);
  if (!parent || parent.type !== 'dir') {
    return { root, ok: false, error: `Klasör bulunamadı: ${parentPath}` };
  }
  if (!canWriteNode(parent, user, elevated)) {
    return {
      root,
      ok: false,
      error: `Erişim reddedildi (izin yok): ${parentPath} — 'sudo' gerekebilir`,
    };
  }
  if (!parent.children) parent.children = {};
  const existing = parent.children[name];
  if (existing && existing.type === 'dir') {
    return { root, ok: false, error: `Hedef bir klasör: ${name}` };
  }
  if (existing && !canWriteNode(existing, user, elevated)) {
    return {
      root,
      ok: false,
      error: `Yazma izni reddedildi: ${norm} — 'sudo' gerekebilir`,
    };
  }

  const now = Date.now();
  const inferredMime =
    mimeType ||
    existing?.mimeType ||
    (name.endsWith('.js')
      ? 'application/javascript'
      : name.endsWith('.json')
        ? 'application/json'
        : name.endsWith('.ankatar')
          ? 'application/vnd.ankaos.archive+json'
          : name.endsWith('.ankawasm')
            ? 'application/vnd.ankaos.wasm-pkg+json'
            : name.endsWith('.wat') || name.endsWith('.wast')
              ? 'text/wat'
              : name.endsWith('.wasm')
                ? 'application/wasm'
                : name.endsWith('.html')
                  ? 'text/html'
                  : name.endsWith('.sh') || name === '.ankashrc'
                    ? 'text/x-shellscript'
                    : name.endsWith('.md')
                      ? 'text/markdown'
                      : name.endsWith('.png') || name.endsWith('.jpg') || name.endsWith('.jpeg') || name.endsWith('.webp')
                        ? 'image/data'
                        : name.endsWith('.webm')
                          ? 'audio/webm'
                          : name.endsWith('.wav')
                            ? 'audio/wav'
                            : name.endsWith('.mp3')
                              ? 'audio/mpeg'
                              : name.endsWith('.ogg')
                                ? 'audio/ogg'
                                : 'text/plain');

  parent.children[name] = {
    id: existing?.id || `${name}-${Math.random().toString(36).slice(2, 8)}`,
    name,
    type: 'file',
    content,
    mimeType: inferredMime,
    permissions: existing?.permissions || '-rw-r--r--',
    owner: existing?.owner || user,
    size: typeof Blob !== 'undefined' ? new Blob([content]).size : content.length,
    createdAt: existing?.createdAt || now,
    updatedAt: now,
  };
  parent.updatedAt = now;
  return { root: next, ok: true };
}

export function vfsChmod(
  root: VFSNode,
  targetPath: string,
  mode: string,
  options?: { user?: string; elevatedRoot?: boolean }
): { root: VFSNode; ok: boolean; error?: string } {
  const norm = normalizePath(targetPath, '/');
  const next = cloneVFS(root);
  const node = getNodeAtPath(next, norm);
  if (!node) return { root, ok: false, error: `Öğe bulunamadı: ${norm}` };
  const user = options?.user || 'kullanici';
  if (!options?.elevatedRoot && user !== 'root' && node.owner !== user) {
    return { root, ok: false, error: `İzin reddedildi: '${norm}' sahibi ${node.owner}` };
  }
  const updated = applyChmod(node.permissions, mode);
  if (!updated) return { root, ok: false, error: `Geçersiz izin biçimi: ${mode}` };
  node.permissions = updated;
  node.updatedAt = Date.now();
  return { root: next, ok: true };
}

export function vfsMkdir(
  root: VFSNode,
  dirPath: string,
  options?: { user?: string; elevatedRoot?: boolean }
): { root: VFSNode; ok: boolean; error?: string } {
  const user = options?.user || 'kullanici';
  const elevated = Boolean(options?.elevatedRoot);
  const next = cloneVFS(root);
  const { parentPath, name } = getParentAndName(dirPath);
  if (!name) return { root, ok: false, error: 'Geçersiz klasör adı' };
  const parent = getNodeAtPath(next, parentPath);
  if (!parent || parent.type !== 'dir') {
    return { root, ok: false, error: `Üst klasör bulunamadı: ${parentPath}` };
  }
  if (!canWriteNode(parent, user, elevated)) {
    return { root, ok: false, error: `İzin reddedildi: ${parentPath}` };
  }
  if (!parent.children) parent.children = {};
  if (parent.children[name]) {
    return { root, ok: false, error: `Zaten mevcut: ${name}` };
  }
  parent.children[name] = makeDir(name, {}, 'drwxr-xr-x', user);
  parent.updatedAt = Date.now();
  return { root: next, ok: true };
}

/**
 * Recursively ensures a directory path exists in the VFS (equivalent to `mkdir -p`).
 * Used by syscall handlers to provision `.sandbox/<appId>` directories on demand.
 */
export function vfsEnsureDir(
  root: VFSNode,
  dirPath: string,
  options?: { user?: string; elevatedRoot?: boolean }
): VFSNode {
  const norm = normalizePath(dirPath, '/');
  if (norm === '/' || getNodeAtPath(root, norm)) return root;
  const parts = norm.split('/').filter(Boolean);
  let currRoot = root;
  let acc = '';
  for (const part of parts) {
    acc += '/' + part;
    if (!getNodeAtPath(currRoot, acc)) {
      const mk = vfsMkdir(currRoot, acc, options);
      if (!mk.ok) break;
      currRoot = mk.root;
    }
  }
  return currRoot;
}

export function provisionUserHome(root: VFSNode, username: string): VFSNode {
  const clean = username.trim().toLowerCase().replace(/[^a-z0-9_-]/g, '');
  if (!clean) return root;
  const next = cloneVFS(root);
  const homeParent = getNodeAtPath(next, '/home');
  if (!homeParent || homeParent.type !== 'dir') return root;
  if (!homeParent.children) homeParent.children = {};
  if (!homeParent.children[clean]) {
    homeParent.children[clean] = makeDir(
      clean,
      {
        Masaüstü: makeDir('Masaüstü', {}, 'drwxr-xr-x', clean),
        Belgeler: makeDir(
          'Belgeler',
          {
            Notlar: makeDir(
              'Notlar',
              {
                'Hoş_Geldiniz.txt': makeFile(
                  'Hoş_Geldiniz.txt',
                  `AnkaOS v3.2 — ${clean} kullanıcısının kişisel not alanı.`,
                  'text/plain',
                  '-rw-r--r--',
                  clean
                ),
              },
              'drwxr-xr-x',
              clean
            ),
          },
          'drwxr-xr-x',
          clean
        ),
        Projeler: makeDir(
          'Projeler',
          {
            'merhaba.wat': makeFile('merhaba.wat', WASM_TEMPLATES[0].wat, 'text/wat', '-rw-r--r--', clean),
            'topla.wasm': makeFile(
              'topla.wasm',
              buildSampleMathWasmContent(),
              'application/wasm',
              '-rwxr-xr-x',
              clean
            ),
          },
          'drwxr-xr-x',
          clean
        ),
        Resimler: makeDir('Resimler', {}, 'drwxr-xr-x', clean),
        İndirilenler: makeDir('İndirilenler', {}, 'drwxr-xr-x', clean),
        Müzik: makeDir('Müzik', {}, 'drwxr-xr-x', clean),
        '.bookmarks.json': makeFile(
          '.bookmarks.json',
          JSON.stringify(
            [
              { title: 'Vikipedi (TR)', url: 'https://tr.wikipedia.org' },
              { title: 'MDN Web Docs', url: 'https://developer.mozilla.org' },
              { title: 'Example.com', url: 'https://example.com' },
            ],
            null,
            2
          ),
          'application/json',
          '-rw-r--r--',
          clean
        ),
        '.Trash': makeDir('.Trash', {}, 'drwxr-xr-x', clean),
        '.ankashrc': makeFile(
          '.ankashrc',
          `# ${clean} için ankash başlangıç betiği\nalias ll='ls -la'\nalias la='ls -a'\nalias cls='clear'\nalias sys='neofetch'\n`,
          'text/x-shellscript',
          '-rw-r--r--',
          clean
        ),
        '.sandbox': makeDir(
          '.sandbox',
          {
            notes: makeDir('notes', {}, 'drwxr-xr-x', clean),
            editor: makeDir('editor', {}, 'drwxr-xr-x', clean),
            paint: makeDir('paint', {}, 'drwxr-xr-x', clean),
            browser: makeDir('browser', {}, 'drwxr-xr-x', clean),
            'wasm-builder': makeDir('wasm-builder', {}, 'drwxr-xr-x', clean),
            'pkg-kanban': makeDir('pkg-kanban', {}, 'drwxr-xr-x', clean),
            'pkg-sysbench': makeDir('pkg-sysbench', {}, 'drwxr-xr-x', clean),
          },
          'drwxr-xr-x',
          clean
        ),
      },
      'drwxr-xr-x',
      clean
    );
  }
  return next;
}

export function vfsDelete(
  root: VFSNode,
  targetPath: string,
  options?: { user?: string; elevatedRoot?: boolean }
): { root: VFSNode; ok: boolean; error?: string } {
  const norm = normalizePath(targetPath, '/');
  if (norm === '/') return { root, ok: false, error: 'Kök dizin silinemez' };
  if (norm.startsWith('/proc') || norm.startsWith('/dev')) {
    return { root, ok: false, error: `Çekirdek dizini silinemez: ${norm}` };
  }
  const user = options?.user || 'kullanici';
  const elevated = Boolean(options?.elevatedRoot);
  const next = cloneVFS(root);
  const { parentPath, name } = getParentAndName(norm);
  const parent = getNodeAtPath(next, parentPath);
  if (!parent || parent.type !== 'dir' || !parent.children || !parent.children[name]) {
    return { root, ok: false, error: `Öğe bulunamadı: ${norm}` };
  }
  if (!canWriteNode(parent, user, elevated)) {
    return { root, ok: false, error: `Silme izni reddedildi: ${norm}` };
  }
  delete parent.children[name];
  parent.updatedAt = Date.now();
  return { root: next, ok: true };
}

export function vfsRename(
  root: VFSNode,
  targetPath: string,
  newName: string
): { root: VFSNode; ok: boolean; error?: string } {
  const cleanName = newName.trim().replace(/\//g, '');
  if (!cleanName) return { root, ok: false, error: 'Geçersiz ad' };
  const norm = normalizePath(targetPath, '/');
  if (norm === '/') return { root, ok: false, error: 'Kök dizin yeniden adlandırılamaz' };
  const next = cloneVFS(root);
  const { parentPath, name } = getParentAndName(norm);
  const parent = getNodeAtPath(next, parentPath);
  if (!parent || parent.type !== 'dir' || !parent.children || !parent.children[name]) {
    return { root, ok: false, error: `Öğe bulunamadı: ${norm}` };
  }
  if (parent.children[cleanName]) {
    return { root, ok: false, error: `Bu isimde bir öğe zaten var: ${cleanName}` };
  }
  const node = parent.children[name];
  delete parent.children[name];
  node.name = cleanName;
  node.updatedAt = Date.now();
  parent.children[cleanName] = node;
  parent.updatedAt = Date.now();
  return { root: next, ok: true };
}

export function vfsCopy(
  root: VFSNode,
  srcPath: string,
  destPath: string
): { root: VFSNode; ok: boolean; error?: string } {
  const srcNode = getNodeAtPath(root, srcPath);
  if (!srcNode) return { root, ok: false, error: `Kaynak bulunamadı: ${srcPath}` };
  const destNode = getNodeAtPath(root, destPath);
  const next = cloneVFS(root);
  const copyObj = cloneVFS(srcNode);

  if (destNode && destNode.type === 'dir') {
    const targetParent = getNodeAtPath(next, destPath)!;
    if (!targetParent.children) targetParent.children = {};
    targetParent.children[srcNode.name] = copyObj;
    return { root: next, ok: true };
  }

  const { parentPath, name } = getParentAndName(destPath);
  const parent = getNodeAtPath(next, parentPath);
  if (!parent || parent.type !== 'dir') {
    return { root, ok: false, error: `Hedef klasör bulunamadı: ${parentPath}` };
  }
  if (!parent.children) parent.children = {};
  copyObj.name = name;
  parent.children[name] = copyObj;
  return { root: next, ok: true };
}

export function vfsMoveNode(
  root: VFSNode,
  srcPath: string,
  destDirOrPath: string,
  options?: { user?: string; elevatedRoot?: boolean }
): { root: VFSNode; ok: boolean; error?: string; movedPath?: string } {
  const srcNorm = normalizePath(srcPath, '/');
  const destNorm = normalizePath(destDirOrPath, '/');
  if (srcNorm === '/' || srcNorm.startsWith('/proc') || srcNorm.startsWith('/dev')) {
    return { root, ok: false, error: `Sistem dizini taşınamaz: ${srcNorm}` };
  }
  if (destNorm === srcNorm || destNorm.startsWith(`${srcNorm}/`)) {
    return { root, ok: false, error: 'Bir klasör kendisinin veya alt klasörünün içine taşınamaz' };
  }

  const user = options?.user || 'kullanici';
  const elevated = Boolean(options?.elevatedRoot);
  const srcNode = getNodeAtPath(root, srcNorm);
  if (!srcNode) return { root, ok: false, error: `Kaynak bulunamadı: ${srcNorm}` };

  const { parentPath: srcParentPath, name: srcName } = getParentAndName(srcNorm);
  const next = cloneVFS(root);
  const srcParent = getNodeAtPath(next, srcParentPath);
  if (!srcParent || srcParent.type !== 'dir' || !srcParent.children || !srcParent.children[srcName]) {
    return { root, ok: false, error: `Kaynak ebeveyn bulunamadı: ${srcParentPath}` };
  }
  if (!canWriteNode(srcParent, user, elevated)) {
    return { root, ok: false, error: `Taşıma izni reddedildi: ${srcParentPath}` };
  }

  const destExisting = getNodeAtPath(next, destNorm);
  let targetParentPath = destNorm;
  let targetName = srcName;

  if (!destExisting || destExisting.type !== 'dir') {
    const parsedDest = getParentAndName(destNorm);
    targetParentPath = parsedDest.parentPath;
    targetName = parsedDest.name;
  }

  const targetParent = getNodeAtPath(next, targetParentPath);
  if (!targetParent || targetParent.type !== 'dir') {
    return { root, ok: false, error: `Hedef klasör bulunamadı: ${targetParentPath}` };
  }
  if (!canWriteNode(targetParent, user, elevated)) {
    return { root, ok: false, error: `Hedef yazma izni reddedildi: ${targetParentPath}` };
  }
  if (!targetParent.children) targetParent.children = {};

  const finalPath = targetParentPath === '/' ? `/${targetName}` : `${targetParentPath}/${targetName}`;
  if (finalPath === srcNorm) {
    return { root, ok: true, movedPath: srcNorm };
  }
  if (targetParent.children[targetName]) {
    return { root, ok: false, error: `Hedefte aynı adda öğe zaten var: ${targetName}` };
  }

  const movedObj = cloneVFS(srcParent.children[srcName]);
  movedObj.name = targetName;
  movedObj.updatedAt = Date.now();
  delete srcParent.children[srcName];
  srcParent.updatedAt = Date.now();
  targetParent.children[targetName] = movedObj;
  targetParent.updatedAt = Date.now();
  return { root: next, ok: true, movedPath: finalPath };
}

function readTrashIndex(root: VFSNode, trashDir: string): Record<string, TrashIndexEntry> {
  const indexNode = getNodeAtPath(root, `${trashDir}/${TRASH_INDEX_FILENAME}`);
  if (!indexNode || indexNode.type !== 'file' || !indexNode.content) return {};
  try {
    return JSON.parse(indexNode.content) as Record<string, TrashIndexEntry>;
  } catch {
    return {};
  }
}

export function vfsMoveToTrash(
  root: VFSNode,
  targetPath: string,
  userHome: string,
  options?: { user?: string; elevatedRoot?: boolean }
): { root: VFSNode; ok: boolean; error?: string; trashName?: string } {
  const norm = normalizePath(targetPath, '/');
  const trashDir = `${normalizePath(userHome, '/')}/.Trash`;
  if (norm === trashDir || norm.startsWith(`${trashDir}/`)) {
    return vfsDelete(root, norm, options);
  }
  if (norm === '/' || norm.startsWith('/proc') || norm.startsWith('/dev') || norm === userHome) {
    return { root, ok: false, error: `Bu sistem konumu çöp kutusuna taşınamaz: ${norm}` };
  }

  const user = options?.user || 'kullanici';
  const ensured = vfsEnsureDir(root, trashDir, { user, elevatedRoot: true });
  const srcNode = getNodeAtPath(ensured, norm);
  if (!srcNode) return { root, ok: false, error: `Öğe bulunamadı: ${norm}` };

  const trashFolder = getNodeAtPath(ensured, trashDir);
  let trashName = srcNode.name;
  if (trashFolder?.children?.[trashName]) {
    trashName = `${srcNode.name}__${Date.now()}`;
  }

  const moved = vfsMoveNode(ensured, norm, `${trashDir}/${trashName}`, options);
  if (!moved.ok) return { root, ok: false, error: moved.error };

  const index = readTrashIndex(moved.root, trashDir);
  index[trashName] = {
    trashName,
    originalPath: norm,
    originalName: srcNode.name,
    deletedAt: Date.now(),
  };
  const withIndex = vfsWriteFile(
    moved.root,
    `${trashDir}/${TRASH_INDEX_FILENAME}`,
    JSON.stringify(index, null, 2),
    'application/json',
    { user, elevatedRoot: true }
  );
  return { root: withIndex.root, ok: true, trashName };
}

export function vfsRestoreFromTrash(
  root: VFSNode,
  trashName: string,
  userHome: string,
  options?: { user?: string; elevatedRoot?: boolean }
): { root: VFSNode; ok: boolean; error?: string; restoredPath?: string } {
  const trashDir = `${normalizePath(userHome, '/')}/.Trash`;
  const itemPath = `${trashDir}/${trashName}`;
  const itemNode = getNodeAtPath(root, itemPath);
  if (!itemNode) return { root, ok: false, error: `Çöp kutusunda bulunamadı: ${trashName}` };

  const user = options?.user || 'kullanici';
  const index = readTrashIndex(root, trashDir);
  const meta = index[trashName];
  const fallbackDest = `${normalizePath(userHome, '/')}/${trashName}`;
  let targetDest = meta?.originalPath || fallbackDest;

  const { parentPath } = getParentAndName(targetDest);
  let working = vfsEnsureDir(root, parentPath, { user, elevatedRoot: true });
  if (getNodeAtPath(working, targetDest)) {
    const parsed = getParentAndName(targetDest);
    const parentPrefix = parsed.parentPath === '/' ? '' : parsed.parentPath;
    targetDest = `${parentPrefix}/${parsed.name}_geri_${Date.now()}`;
  }

  const moved = vfsMoveNode(working, itemPath, targetDest, options);
  if (!moved.ok) return { root, ok: false, error: moved.error };

  delete index[trashName];
  const updated = vfsWriteFile(
    moved.root,
    `${trashDir}/${TRASH_INDEX_FILENAME}`,
    JSON.stringify(index, null, 2),
    'application/json',
    { user, elevatedRoot: true }
  );
  return { root: updated.root, ok: true, restoredPath: moved.movedPath || targetDest };
}

export function vfsEmptyTrash(
  root: VFSNode,
  userHome: string,
  options?: { user?: string; elevatedRoot?: boolean }
): { root: VFSNode; ok: boolean; error?: string } {
  const trashDir = `${normalizePath(userHome, '/')}/.Trash`;
  const node = getNodeAtPath(root, trashDir);
  if (!node || node.type !== 'dir') {
    return { root, ok: true };
  }
  const user = options?.user || 'kullanici';
  const next = cloneVFS(root);
  const target = getNodeAtPath(next, trashDir);
  if (!target || target.type !== 'dir') return { root, ok: false, error: 'Çöp kutusu bulunamadı' };
  if (!canWriteNode(target, user, Boolean(options?.elevatedRoot))) {
    return { root, ok: false, error: 'Çöp kutusu boşaltma izni yok' };
  }
  target.children = {};
  target.updatedAt = Date.now();
  return { root: next, ok: true };
}

export function searchVFS(
  root: VFSNode,
  query: string,
  basePath = '/',
  results: Array<{ path: string; node: VFSNode }> = []
): Array<{ path: string; node: VFSNode }> {
  const q = query.toLowerCase();
  if (!q) return results;
  const node = getNodeAtPath(root, basePath);
  if (!node || node.type !== 'dir' || !node.children) return results;

  for (const child of Object.values(node.children)) {
    const childPath = basePath === '/' ? `/${child.name}` : `${basePath}/${child.name}`;
    if (child.name.toLowerCase().includes(q)) {
      results.push({ path: childPath, node: child });
    }
    if (child.type === 'dir') {
      searchVFS(root, query, childPath, results);
    }
  }
  return results;
}

export function formatBytes(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}
