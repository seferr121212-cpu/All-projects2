import { NetworkInterface, VFSNode } from './types';
import { getNodeAtPath } from './vfs';

export interface LiveNetStatus {
  online: boolean;
  rttMs: number;
  dnsOk: boolean;
  gatewayIp?: string;
  provider: string;
  checkedAt: number;
  error?: string;
}

export interface LiveSearchHit {
  title: string;
  url: string;
  domain: string;
  snippet: string;
  source: string;
  thumbUrl?: string;
  publishedAt?: string;
  meta?: {
    stars?: number;
    language?: string;
    answers?: number;
    width?: number;
    height?: number;
    version?: string;
  };
}

export interface LiveKnowledgeCard {
  title: string;
  subtitle?: string;
  summary: string;
  url: string;
  source: string;
  imageUrl?: string;
}

export interface LiveSearchResponse {
  ok: boolean;
  query: string;
  lang: 'tr' | 'en';
  category?: string;
  engine: string;
  tookMs: number;
  cached?: boolean;
  instantAnswer: {
    heading: string;
    abstract: string;
    url: string;
    source: string;
  } | null;
  knowledgeCard?: LiveKnowledgeCard | null;
  results: LiveSearchHit[];
  sourceStatus?: Record<string, string>;
  error?: string;
}

export interface LivePageFetchResponse {
  ok: boolean;
  url: string;
  finalUrl?: string;
  status?: number;
  contentType?: string;
  bytes?: number;
  title?: string;
  description?: string;
  textPreview?: string;
  rawText?: string;
  error?: string;
}

export interface LiveDnsResponse {
  ok: boolean;
  host: string;
  tookMs?: number;
  addresses?: Array<{ address: string; family: number }>;
  v4?: string[];
  v6?: string[];
  mx?: Array<{ exchange: string; priority: number }>;
  ns?: string[];
  error?: string;
}

export function createInitialNetworkInterfaces(): NetworkInterface[] {
  return [
    {
      name: 'lo',
      ip: '127.0.0.1',
      netmask: '255.0.0.0',
      mac: '00:00:00:00:00:00',
      status: 'UP',
      rxBytes: 1280,
      txBytes: 1280,
      rxPackets: 16,
      txPackets: 16,
    },
    {
      name: 'eth0',
      ip: '192.168.1.42',
      netmask: '255.255.255.0',
      mac: '02:42:ac:11:00:2a',
      status: 'UP',
      rxBytes: 24576,
      txBytes: 8192,
      rxPackets: 42,
      txPackets: 28,
    },
  ];
}

export function validateExternalUrl(rawUrl: string): { ok: true; url: string } | { ok: false; error: string } {
  const trimmed = rawUrl.trim();
  if (!trimmed) return { ok: false, error: 'Boş URL.' };
  let parsed: URL;
  try {
    parsed = new URL(trimmed);
  } catch {
    return { ok: false, error: 'Geçersiz URL biçimi.' };
  }
  if (parsed.protocol !== 'http:' && parsed.protocol !== 'https:') {
    return { ok: false, error: 'Yalnızca http:// ve https:// desteklenir.' };
  }
  const h = parsed.hostname.toLowerCase().replace(/^\[|\]$/g, '');
  if (
    h === 'localhost' ||
    h === '::1' ||
    h === '0.0.0.0' ||
    h.endsWith('.local') ||
    h.endsWith('.internal') ||
    /^127\./.test(h) ||
    /^10\./.test(h) ||
    /^192\.168\./.test(h) ||
    /^169\.254\./.test(h) ||
    /^172\.(1[6-9]|2\d|3[0-1])\./.test(h)
  ) {
    return { ok: false, error: 'Özel ağ / loopback adresleri proxy için engellendi.' };
  }
  return { ok: true, url: parsed.toString() };
}

export function resolveHost(vfs: VFSNode, host: string): string {
  const clean = host.trim().toLowerCase();
  if (/^\d{1,3}(\.\d{1,3}){3}$/.test(clean)) return clean;

  const hostsNode = getNodeAtPath(vfs, '/etc/hosts');
  if (hostsNode?.type === 'file' && hostsNode.content) {
    for (const line of hostsNode.content.split('\n')) {
      const parts = line.trim().split(/\s+/);
      if (parts.length >= 2 && parts.slice(1).some((h) => h.toLowerCase() === clean)) {
        return parts[0];
      }
    }
  }
  return clean === 'localhost' ? '127.0.0.1' : '192.168.1.1';
}

export function measureLoopbackPing(host: string, vfs: VFSNode) {
  const ip = resolveHost(vfs, host);
  const t0 = typeof performance !== 'undefined' ? performance.now() : Date.now();
  let acc = 0;
  for (let i = 0; i < 4000; i++) acc = (acc + i * 13) % 65535;
  const t1 = typeof performance !== 'undefined' ? performance.now() : Date.now();
  const rttMs = Math.max(0.08, Number((t1 - t0 + (ip === '127.0.0.1' ? 0.05 : 1.4)).toFixed(2)));
  return { ip, rttMs, ttl: ip === '127.0.0.1' ? 64 : 56, checksum: acc };
}

export async function fetchNetStatus(): Promise<LiveNetStatus> {
  try {
    const resp = await fetch('/api/net/status');
    return (await resp.json()) as LiveNetStatus;
  } catch (err) {
    return {
      online: false,
      rttMs: 0,
      dnsOk: false,
      provider: 'AnkaNet Express Bridge',
      checkedAt: Date.now(),
      error: err instanceof Error ? err.message : 'Sunucu erişilemedi',
    };
  }
}

export async function searchWebLive(
  query: string,
  lang: 'tr' | 'en' = 'tr',
  category: 'all' | 'wiki' | 'dev' | 'news' | 'images' = 'all'
): Promise<LiveSearchResponse> {
  const resp = await fetch(
    `/api/search?q=${encodeURIComponent(query)}&lang=${lang}&category=${encodeURIComponent(category)}`
  );
  return (await resp.json()) as LiveSearchResponse;
}

export async function fetchSearchSuggestions(
  query: string,
  lang: 'tr' | 'en' = 'tr'
): Promise<string[]> {
  if (!query.trim()) return [];
  try {
    const resp = await fetch(
      `/api/suggest?q=${encodeURIComponent(query.trim())}&lang=${lang}`
    );
    const data = (await resp.json()) as { ok?: boolean; suggestions?: string[] };
    return Array.isArray(data.suggestions) ? data.suggestions : [];
  } catch {
    return [];
  }
}

export async function fetchPageLive(targetUrl: string): Promise<LivePageFetchResponse> {
  const resp = await fetch(`/api/fetch?url=${encodeURIComponent(targetUrl)}`);
  return (await resp.json()) as LivePageFetchResponse;
}

export async function resolveDnsLive(host: string): Promise<LiveDnsResponse> {
  const resp = await fetch(`/api/dns?host=${encodeURIComponent(host)}`);
  return (await resp.json()) as LiveDnsResponse;
}

export async function pingHostLive(host: string): Promise<{
  ok: boolean;
  host: string;
  ip?: string;
  port?: number;
  rttMs?: number;
  error?: string;
}> {
  const resp = await fetch(`/api/net/ping?host=${encodeURIComponent(host)}`);
  return (await resp.json()) as {
    ok: boolean;
    host: string;
    ip?: string;
    port?: number;
    rttMs?: number;
    error?: string;
  };
}

export async function uploadSnapshotSync(
  syncKey: string,
  snapshotJson: string
): Promise<{ ok: boolean; syncKey?: string; savedAt?: number; bytes?: number; error?: string }> {
  try {
    const resp = await fetch('/api/sync/snapshot', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ syncKey, snapshotJson }),
    });
    return (await resp.json()) as {
      ok: boolean;
      syncKey?: string;
      savedAt?: number;
      bytes?: number;
      error?: string;
    };
  } catch (err) {
    return { ok: false, error: err instanceof Error ? err.message : 'Sunucu eşitleme hatası' };
  }
}

export async function downloadSnapshotSync(syncKey: string): Promise<{
  ok: boolean;
  syncKey?: string;
  savedAt?: number;
  bytes?: number;
  snapshotJson?: string;
  error?: string;
}> {
  try {
    const resp = await fetch(`/api/sync/snapshot?key=${encodeURIComponent(syncKey.trim())}`);
    return (await resp.json()) as {
      ok: boolean;
      syncKey?: string;
      savedAt?: number;
      bytes?: number;
      snapshotJson?: string;
      error?: string;
    };
  } catch (err) {
    return { ok: false, error: err instanceof Error ? err.message : 'Sunucudan yedek indirilemedi' };
  }
}
