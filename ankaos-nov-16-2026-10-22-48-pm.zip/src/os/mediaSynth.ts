export interface SynthTrack {
  id: string;
  title: string;
  bpm: number;
  notes: number[];
  waveform: OscillatorType;
}

const VALID_WAVEFORMS: OscillatorType[] = ['sine', 'triangle', 'square', 'sawtooth'];

export function serializeAnkaSynthTrack(track: SynthTrack): string {
  return JSON.stringify(
    {
      schema: 'ankaos-synth-v1',
      id: track.id,
      title: track.title,
      bpm: Math.max(40, Math.min(240, Math.round(track.bpm))),
      waveform: VALID_WAVEFORMS.includes(track.waveform) ? track.waveform : 'sine',
      notes: track.notes.slice(0, 16).map((n) => (Number.isFinite(n) && n > 20 ? Number(n.toFixed(2)) : 261.63)),
    },
    null,
    2
  );
}

export function parseAnkaSynthTrack(rawJson: string): {
  ok: boolean;
  track?: SynthTrack;
  error?: string;
} {
  try {
    const parsed = JSON.parse(rawJson) as {
      schema?: string;
      id?: string;
      title?: string;
      bpm?: number;
      waveform?: string;
      notes?: unknown[];
    };
    if (!parsed || parsed.schema !== 'ankaos-synth-v1') {
      return { ok: false, error: 'Geçersiz .ankasynth şeması (ankaos-synth-v1 bekleniyor).' };
    }
    if (!Array.isArray(parsed.notes) || parsed.notes.length === 0) {
      return { ok: false, error: 'Parça nota dizisi boş veya geçersiz.' };
    }
    const notes = parsed.notes
      .map((n) => Number(n))
      .filter((n) => Number.isFinite(n) && n >= 40 && n <= 4000);
    if (notes.length === 0) {
      return { ok: false, error: 'Geçerli frekans notası bulunamadı.' };
    }
    const waveform = VALID_WAVEFORMS.includes(parsed.waveform as OscillatorType)
      ? (parsed.waveform as OscillatorType)
      : 'sine';
    const bpm = Number.isFinite(parsed.bpm)
      ? Math.max(40, Math.min(240, Math.round(Number(parsed.bpm))))
      : 110;
    return {
      ok: true,
      track: {
        id: (parsed.id || `synth-${Date.now()}`).trim(),
        title: (parsed.title || 'Özel Sentez Parçası').trim(),
        bpm,
        waveform,
        notes,
      },
    };
  } catch (err) {
    return {
      ok: false,
      error: `JSON ayrıştırma hatası: ${err instanceof Error ? err.message : String(err)}`,
    };
  }
}
