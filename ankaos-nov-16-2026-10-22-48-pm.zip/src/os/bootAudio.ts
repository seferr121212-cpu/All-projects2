/**
 * Synthesizes clean AnkaOS startup & unlock audio chimes via WebAudio API
 * without external assets. Cleans up audio nodes cleanly after playback.
 */
function playNotes(
  notes: Array<{ freq: number; delay: number; duration: number; gain: number }>,
  volumePct: number,
  muted: boolean
): void {
  if (muted || volumePct <= 0 || typeof window === 'undefined') return;
  const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
  if (!AudioCtx) return;

  try {
    const ctx = new AudioCtx();
    if (ctx.state === 'suspended') {
      void ctx.resume().catch(() => undefined);
    }

    const masterGain = ctx.createGain();
    const filter = ctx.createBiquadFilter();
    filter.type = 'lowpass';
    filter.frequency.setValueAtTime(2400, ctx.currentTime);

    const volScale = Math.max(0.02, Math.min(1, volumePct / 100)) * 0.22;
    masterGain.gain.setValueAtTime(volScale, ctx.currentTime);

    filter.connect(masterGain);
    masterGain.connect(ctx.destination);

    const now = ctx.currentTime;
    let maxEnd = 0;

    for (const n of notes) {
      const osc = ctx.createOscillator();
      const env = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(n.freq, now + n.delay);

      env.gain.setValueAtTime(0.0001, now + n.delay);
      env.gain.exponentialRampToValueAtTime(n.gain, now + n.delay + 0.04);
      env.gain.exponentialRampToValueAtTime(0.0001, now + n.delay + n.duration);

      osc.connect(env);
      env.connect(filter);
      osc.start(now + n.delay);
      osc.stop(now + n.delay + n.duration + 0.02);

      maxEnd = Math.max(maxEnd, n.delay + n.duration + 0.05);
    }

    window.setTimeout(() => {
      void ctx.close().catch(() => undefined);
    }, Math.ceil(maxEnd * 1000) + 120);
  } catch {
    // Ignore autoplay restrictions before user gesture
  }
}

export function playBootChime(volumePct = 70, muted = false): void {
  playNotes(
    [
      { freq: 293.66, delay: 0.0, duration: 0.48, gain: 0.45 }, // D4
      { freq: 440.0, delay: 0.09, duration: 0.52, gain: 0.4 }, // A4
      { freq: 587.33, delay: 0.18, duration: 0.65, gain: 0.42 }, // D5
      { freq: 739.99, delay: 0.28, duration: 0.8, gain: 0.32 }, // F#5
    ],
    volumePct,
    muted
  );
}

export function playUnlockChime(volumePct = 70, muted = false): void {
  playNotes(
    [
      { freq: 523.25, delay: 0.0, duration: 0.26, gain: 0.35 }, // C5
      { freq: 659.25, delay: 0.07, duration: 0.32, gain: 0.35 }, // E5
      { freq: 783.99, delay: 0.14, duration: 0.42, gain: 0.3 }, // G5
    ],
    volumePct,
    muted
  );
}
