import {
  createWasiPreview1Imports,
  decodeWasmBytes,
  runWasmBinary,
  WASM_B64_PREFIX,
  WasiExitSignal,
} from './sandboxRuntime';

export type WasmValType = 'i32' | 'i64' | 'f32' | 'f64';

export interface WasmExportMeta {
  name: string;
  kind: 'func' | 'memory';
  params: WasmValType[];
  results: WasmValType[];
}

export interface WasmCompileResult {
  ok: boolean;
  bytes?: Uint8Array<ArrayBuffer>;
  base64Content?: string;
  exports: WasmExportMeta[];
  memoryPages: number;
  dataSegments: number;
  compileTimeMs: number;
  sizeBytes: number;
  sectionSummary: Array<{ name: string; bytes: number }>;
  error?: string;
}

export interface AnkaWasmPackageManifest {
  schema: 'ankaos-wasm-pkg-v1';
  name: string;
  version: string;
  author: string;
  description: string;
  createdAt: string;
  entryFn: string;
  exports: WasmExportMeta[];
  wasmBase64: string;
  watSource?: string;
  byteLength: number;
  sha256: string;
  hasMemory: boolean;
}

export const WASM_TEMPLATES: Array<{
  id: string;
  labelTr: string;
  labelEn: string;
  fileName: string;
  wat: string;
}> = [
  {
    id: 'math',
    labelTr: 'Matematik & Faktöriyel',
    labelEn: 'Math & Factorial',
    fileName: 'matematik.wat',
    wat: `(module
  ;; AnkaOS WASM Matematik Modülü
  (func $add (export "add") (param $a i32) (param $b i32) (result i32)
    (i32.add (local.get $a) (local.get $b))
  )

  (func $square (export "square") (param $x i32) (result i32)
    (i32.mul (local.get $x) (local.get $x))
  )

  (func $factorial (export "factorial") (param $n i32) (result i32)
    (local $res i32)
    (local $i i32)
    (local.set $res (i32.const 1))
    (local.set $i (i32.const 2))
    (block $break
      (loop $top
        (br_if $break (i32.gt_s (local.get $i) (local.get $n)))
        (local.set $res (i32.mul (local.get $res) (local.get $i)))
        (local.set $i (i32.add (local.get $i) (i32.const 1)))
        (br $top)
      )
    )
    (local.get $res)
  )
)`,
  },
  {
    id: 'fib',
    labelTr: 'Fibonacci Motoru',
    labelEn: 'Fibonacci Engine',
    fileName: 'fibonacci.wat',
    wat: `(module
  ;; İteratif hızlı Fibonacci hesaplayıcısı
  (func $fibonacci (export "fibonacci") (param $n i32) (result i32)
    (local $a i32)
    (local $b i32)
    (local $tmp i32)
    (local $i i32)
    (if (i32.le_s (local.get $n) (i32.const 0))
      (then (return (i32.const 0)))
    )
    (local.set $a (i32.const 0))
    (local.set $b (i32.const 1))
    (local.set $i (i32.const 1))
    (block $done
      (loop $next
        (br_if $done (i32.ge_s (local.get $i) (local.get $n)))
        (local.set $tmp (i32.add (local.get $a) (local.get $b)))
        (local.set $a (local.get $b))
        (local.set $b (local.get $tmp))
        (local.set $i (i32.add (local.get $i) (i32.const 1)))
        (br $next)
      )
    )
    (local.get $b)
  )
)`,
  },
  {
    id: 'memory',
    labelTr: 'Lineer Bellek & Dize',
    labelEn: 'Linear Memory & String',
    fileName: 'bellek_dize.wat',
    wat: `(module
  ;; 1 sayfa (64 KB) dışa aktarılan lineer bellek ve statik veri segmenti
  (memory (export "mem") 1)
  (data (i32.const 0) "AnkaOS Ring 3 WebAssembly Bellek Tamponu\\00")

  (func $read_byte (export "read_byte") (param $addr i32) (result i32)
    (i32.load8_u (local.get $addr))
  )

  (func $strlen (export "strlen") (param $ptr i32) (result i32)
    (local $len i32)
    (local.set $len (i32.const 0))
    (block $end
      (loop $scan
        (br_if $end (i32.eqz (i32.load8_u (i32.add (local.get $ptr) (local.get $len)))))
        (local.set $len (i32.add (local.get $len) (i32.const 1)))
        (br $scan)
      )
    )
    (local.get $len)
  )
)`,
  },
  {
    id: 'hash',
    labelTr: 'Bitwise Hash Çekirdeği',
    labelEn: 'Bitwise Hash Kernel',
    fileName: 'hash32.wat',
    wat: `(module
  ;; 32-bit karıştırma ve bit kaydırma çekirdeği
  (func $mix32 (export "mix32") (param $x i32) (result i32)
    (local.set $x (i32.xor (local.get $x) (i32.shr_u (local.get $x) (i32.const 16))))
    (local.set $x (i32.mul (local.get $x) (i32.const 0x45d9f3b)))
    (local.set $x (i32.xor (local.get $x) (i32.shr_u (local.get $x) (i32.const 16))))
    (local.get $x)
  )

  (func $rotl (export "rotl") (param $val i32) (param $shift i32) (result i32)
    (i32.or
      (i32.shl (local.get $val) (local.get $shift))
      (i32.shr_u (local.get $val) (i32.sub (i32.const 32) (local.get $shift)))
    )
  )
)`,
  },
  {
    id: 'wasi',
    labelTr: 'WASI Preview 1 (fd_write)',
    labelEn: 'WASI Preview 1 (stdout)',
    fileName: 'wasi_merhaba.wat',
    wat: `(module
  ;; WASI Preview 1 Standart Çıkış (fd_write) Modülü
  (import "wasi_snapshot_preview1" "fd_write"
    (func $fd_write (param i32 i32 i32 i32) (result i32)))

  (memory (export "memory") 1)
  ;; Bellek adresi 16'ya yazılacak metin
  (data (i32.const 16) "AnkaOS WASI Preview 1 Merhaba Dunya!\\n")

  (func $_start (export "_start")
    ;; iovec[0] = { ptr: 16, len: 37 } bellek 0 ve 4 adreslerine yaz
    (i32.store (i32.const 0) (i32.const 16))
    (i32.store (i32.const 4) (i32.const 37))
    ;; fd_write(fd=1 stdout, iovs=0, iovs_len=1, nwritten=8)
    (drop (call $fd_write (i32.const 1) (i32.const 0) (i32.const 1) (i32.const 8)))
  )
)`,
  },
];

// --- Binary Encoding Helpers ---

function encodeULEB128(value: number): number[] {
  let v = value >>> 0;
  const out: number[] = [];
  do {
    let byte = v & 0x7f;
    v >>>= 7;
    if (v !== 0) byte |= 0x80;
    out.push(byte);
  } while (v !== 0);
  return out;
}

function encodeSLEB128(value: bigint): number[] {
  let v = value;
  const out: number[] = [];
  while (true) {
    const byte = Number(v & 0x7fn);
    v >>= 7n;
    const done =
      (v === 0n && (byte & 0x40) === 0) ||
      (v === -1n && (byte & 0x40) !== 0);
    out.push(done ? byte : byte | 0x80);
    if (done) break;
  }
  return out;
}

function encodeF32(num: number): number[] {
  const buf = new ArrayBuffer(4);
  new DataView(buf).setFloat32(0, num, true);
  return Array.from(new Uint8Array(buf));
}

function encodeF64(num: number): number[] {
  const buf = new ArrayBuffer(8);
  new DataView(buf).setFloat64(0, num, true);
  return Array.from(new Uint8Array(buf));
}

function encodeUTF8String(str: string): number[] {
  const bytes = new TextEncoder().encode(str);
  return [...encodeULEB128(bytes.length), ...bytes];
}

function makeSection(id: number, payload: number[]): number[] {
  return [id, ...encodeULEB128(payload.length), ...payload];
}

function valTypeByte(t: WasmValType): number {
  switch (t) {
    case 'i32':
      return 0x7f;
    case 'i64':
      return 0x7e;
    case 'f32':
      return 0x7d;
    case 'f64':
      return 0x7c;
  }
}

function isValType(s: string): s is WasmValType {
  return s === 'i32' || s === 'i64' || s === 'f32' || s === 'f64';
}

function bytesToBase64(bytes: Uint8Array): string {
  if (typeof Buffer !== 'undefined') {
    return Buffer.from(bytes).toString('base64');
  }
  let bin = '';
  for (let i = 0; i < bytes.length; i++) {
    bin += String.fromCharCode(bytes[i]);
  }
  return btoa(bin);
}

// --- S-Expression Tokenizer & Parser ---

interface StrToken {
  kind: 'str';
  rawBytes: number[];
  text: string;
}

interface AtomToken {
  kind: 'atom';
  value: string;
}

type SExprNode = AtomToken | StrToken | SExprList;
interface SExprList {
  kind: 'list';
  items: SExprNode[];
}

function parseStringLiteral(src: string, startIdx: number): { token: StrToken; nextIdx: number } {
  let i = startIdx + 1;
  const rawBytes: number[] = [];
  let text = '';
  while (i < src.length) {
    const ch = src[i];
    if (ch === '"') {
      return { token: { kind: 'str', rawBytes, text }, nextIdx: i + 1 };
    }
    if (ch === '\\') {
      const next = src[i + 1];
      if (next === undefined) throw new Error('Kapanmamış dize sabiti');
      if (next === 'n') {
        rawBytes.push(10);
        text += '\n';
        i += 2;
      } else if (next === 'r') {
        rawBytes.push(13);
        text += '\r';
        i += 2;
      } else if (next === 't') {
        rawBytes.push(9);
        text += '\t';
        i += 2;
      } else if (next === '"' || next === "'" || next === '\\') {
        const b = next.charCodeAt(0);
        rawBytes.push(b);
        text += next;
        i += 2;
      } else if (/^[0-9a-fA-F]{2}$/.test(src.slice(i + 1, i + 3))) {
        const byteVal = parseInt(src.slice(i + 1, i + 3), 16);
        rawBytes.push(byteVal);
        text += String.fromCharCode(byteVal);
        i += 3;
      } else {
        const b = next.charCodeAt(0);
        rawBytes.push(b);
        text += next;
        i += 2;
      }
      continue;
    }
    const encoded = new TextEncoder().encode(ch);
    encoded.forEach((b) => rawBytes.push(b));
    text += ch;
    i++;
  }
  throw new Error('Kapanmamış tırnak (") hatası');
}

function parseSExpressions(src: string): SExprNode[] {
  const tokens: Array<AtomToken | StrToken | { kind: 'lparen' } | { kind: 'rparen' }> = [];
  let i = 0;

  while (i < src.length) {
    const ch = src[i];
    if (/\s/.test(ch)) {
      i++;
      continue;
    }
    // Line comment ;;
    if (ch === ';' && src[i + 1] === ';') {
      while (i < src.length && src[i] !== '\n') i++;
      continue;
    }
    // Nested block comment (; ... ;)
    if (ch === '(' && src[i + 1] === ';') {
      let depth = 1;
      i += 2;
      while (i < src.length && depth > 0) {
        if (src[i] === '(' && src[i + 1] === ';') {
          depth++;
          i += 2;
        } else if (src[i] === ';' && src[i + 1] === ')') {
          depth--;
          i += 2;
        } else {
          i++;
        }
      }
      if (depth > 0) throw new Error('Kapanmamış blok yorum (; ... ;)');
      continue;
    }
    if (ch === '(') {
      tokens.push({ kind: 'lparen' });
      i++;
      continue;
    }
    if (ch === ')') {
      tokens.push({ kind: 'rparen' });
      i++;
      continue;
    }
    if (ch === '"') {
      const parsed = parseStringLiteral(src, i);
      tokens.push(parsed.token);
      i = parsed.nextIdx;
      continue;
    }
    let start = i;
    while (
      i < src.length &&
      !/\s/.test(src[i]) &&
      src[i] !== '(' &&
      src[i] !== ')' &&
      src[i] !== '"' &&
      !(src[i] === ';' && src[i + 1] === ';')
    ) {
      i++;
    }
    tokens.push({ kind: 'atom', value: src.slice(start, i) });
  }

  let cursor = 0;
  function readNode(): SExprNode {
    const tok = tokens[cursor++];
    if (!tok) throw new Error('Beklenmeyen dosya sonu');
    if (tok.kind === 'lparen') {
      const items: SExprNode[] = [];
      while (cursor < tokens.length && tokens[cursor].kind !== 'rparen') {
        items.push(readNode());
      }
      if (!tokens[cursor] || tokens[cursor].kind !== 'rparen') {
        throw new Error('Eksik kapanış parantezi ")"');
      }
      cursor++;
      return { kind: 'list', items };
    }
    if (tok.kind === 'rparen') {
      throw new Error('Fazladan kapanış parantezi ")"');
    }
    return tok;
  }

  const out: SExprNode[] = [];
  while (cursor < tokens.length) {
    out.push(readNode());
  }
  return out;
}

function asAtom(node: SExprNode | undefined): string | null {
  return node && node.kind === 'atom' ? node.value : null;
}

function listHead(node: SExprNode | undefined): string | null {
  if (!node || node.kind !== 'list' || node.items.length === 0) return null;
  return asAtom(node.items[0]);
}

// --- Instruction Opcode Map ---

const SIMPLE_OPCODES: Record<string, number> = {
  unreachable: 0x00,
  nop: 0x01,
  return: 0x0f,
  drop: 0x1a,
  select: 0x1b,

  'i32.eqz': 0x45,
  'i32.eq': 0x46,
  'i32.ne': 0x47,
  'i32.lt_s': 0x48,
  'i32.lt_u': 0x49,
  'i32.gt_s': 0x4a,
  'i32.gt_u': 0x4b,
  'i32.le_s': 0x4c,
  'i32.le_u': 0x4d,
  'i32.ge_s': 0x4e,
  'i32.ge_u': 0x4f,

  'i64.eqz': 0x50,
  'i64.eq': 0x51,
  'i64.ne': 0x52,
  'i64.lt_s': 0x53,
  'i64.lt_u': 0x54,
  'i64.gt_s': 0x55,
  'i64.gt_u': 0x56,
  'i64.le_s': 0x57,
  'i64.le_u': 0x58,
  'i64.ge_s': 0x59,
  'i64.ge_u': 0x5a,

  'f32.eq': 0x5b,
  'f32.ne': 0x5c,
  'f32.lt': 0x5d,
  'f32.gt': 0x5e,
  'f32.le': 0x5f,
  'f32.ge': 0x60,

  'f64.eq': 0x61,
  'f64.ne': 0x62,
  'f64.lt': 0x63,
  'f64.gt': 0x64,
  'f64.le': 0x65,
  'f64.ge': 0x66,

  'i32.clz': 0x67,
  'i32.ctz': 0x68,
  'i32.popcnt': 0x69,
  'i32.add': 0x6a,
  'i32.sub': 0x6b,
  'i32.mul': 0x6c,
  'i32.div_s': 0x6d,
  'i32.div_u': 0x6e,
  'i32.rem_s': 0x6f,
  'i32.rem_u': 0x70,
  'i32.and': 0x71,
  'i32.or': 0x72,
  'i32.xor': 0x73,
  'i32.shl': 0x74,
  'i32.shr_s': 0x75,
  'i32.shr_u': 0x76,
  'i32.rotl': 0x77,
  'i32.rotr': 0x78,

  'i64.add': 0x7c,
  'i64.sub': 0x7d,
  'i64.mul': 0x7e,
  'i64.div_s': 0x7f,
  'i64.div_u': 0x80,
  'i64.rem_s': 0x81,
  'i64.rem_u': 0x82,
  'i64.and': 0x83,
  'i64.or': 0x84,
  'i64.xor': 0x85,
  'i64.shl': 0x86,
  'i64.shr_s': 0x87,
  'i64.shr_u': 0x88,

  'f32.abs': 0x8b,
  'f32.neg': 0x8c,
  'f32.sqrt': 0x91,
  'f32.add': 0x92,
  'f32.sub': 0x93,
  'f32.mul': 0x94,
  'f32.div': 0x95,

  'f64.abs': 0x99,
  'f64.neg': 0x9a,
  'f64.sqrt': 0x9f,
  'f64.add': 0xa0,
  'f64.sub': 0xa1,
  'f64.mul': 0xa2,
  'f64.div': 0xa3,

  'i32.wrap_i64': 0xa7,
  'i32.trunc_f32_s': 0xa8,
  'i32.trunc_f64_s': 0xaa,
  'i64.extend_i32_s': 0xac,
  'i64.extend_i32_u': 0xad,
  'f32.convert_i32_s': 0xb2,
  'f64.convert_i32_s': 0xb7,
};

const MEMORY_OPCODES: Record<string, { opcode: number; defaultAlign: number }> = {
  'i32.load': { opcode: 0x28, defaultAlign: 2 },
  'i64.load': { opcode: 0x29, defaultAlign: 3 },
  'f32.load': { opcode: 0x2a, defaultAlign: 2 },
  'f64.load': { opcode: 0x2b, defaultAlign: 3 },
  'i32.load8_s': { opcode: 0x2c, defaultAlign: 0 },
  'i32.load8_u': { opcode: 0x2d, defaultAlign: 0 },
  'i32.load16_s': { opcode: 0x2e, defaultAlign: 1 },
  'i32.load16_u': { opcode: 0x2f, defaultAlign: 1 },
  'i32.store': { opcode: 0x36, defaultAlign: 2 },
  'i64.store': { opcode: 0x37, defaultAlign: 3 },
  'f32.store': { opcode: 0x38, defaultAlign: 2 },
  'f64.store': { opcode: 0x39, defaultAlign: 3 },
  'i32.store8': { opcode: 0x3a, defaultAlign: 0 },
  'i32.store16': { opcode: 0x3b, defaultAlign: 1 },
};

interface ParsedFunc {
  name?: string;
  params: WasmValType[];
  results: WasmValType[];
  paramNames: Map<string, number>;
  locals: WasmValType[];
  localNames: Map<string, number>;
  inlineExports: string[];
  bodyNodes: SExprNode[];
}

function parseIntLiteral(raw: string): bigint {
  const clean = raw.replace(/_/g, '');
  return BigInt(clean);
}

/**
 * Compiles WebAssembly Text (.wat) source code into a real, spec-compliant
 * WebAssembly binary (.wasm) and validates it via `WebAssembly.validate`.
 */
export function compileWatToWasm(source: string): WasmCompileResult {
  const t0 = typeof performance !== 'undefined' ? performance.now() : Date.now();
  try {
    const topNodes = parseSExpressions(source);
    let moduleItems: SExprNode[] = topNodes;
    if (topNodes.length === 1 && listHead(topNodes[0]) === 'module') {
      moduleItems = (topNodes[0] as SExprList).items.slice(1);
    } else if (topNodes.length === 0) {
      return {
        ok: false,
        exports: [],
        memoryPages: 0,
        dataSegments: 0,
        compileTimeMs: 0,
        sizeBytes: 0,
        sectionSummary: [],
        error: 'Boş WAT kaynağı.',
      };
    }

    interface ParsedImportFunc {
      module: string;
      field: string;
      name?: string;
      params: WasmValType[];
      results: WasmValType[];
    }

    const importedFuncs: ParsedImportFunc[] = [];
    const funcs: ParsedFunc[] = [];
    const funcNameToLocalIndex = new Map<string, number>();
    const importNameToIndex = new Map<string, number>();
    const standaloneExports: Array<{ name: string; kind: 'func' | 'memory'; target: string }> = [];
    let memorySpec: { initial: number; max?: number; exports: string[] } | null = null;
    const dataSegmentsList: Array<{ offset: number; bytes: number[] }> = [];

    for (const item of moduleItems) {
      const head = listHead(item);
      if (!head) continue;
      const list = item as SExprList;

      if (head === 'import') {
        const modNode = list.items[1];
        const fieldNode = list.items[2];
        const descNode = list.items[3];
        if (
          modNode?.kind === 'str' &&
          fieldNode?.kind === 'str' &&
          descNode?.kind === 'list' &&
          listHead(descNode) === 'func'
        ) {
          const imp: ParsedImportFunc = {
            module: modNode.text,
            field: fieldNode.text,
            params: [],
            results: [],
          };
          let dIdx = 1;
          const maybeName = asAtom(descNode.items[dIdx]);
          if (maybeName && maybeName.startsWith('$')) {
            imp.name = maybeName;
            dIdx++;
          }
          while (dIdx < descNode.items.length) {
            const sub = descNode.items[dIdx++];
            const subHead = listHead(sub);
            if (subHead === 'param') {
              const pItems = (sub as SExprList).items.slice(1);
              if (pItems.length >= 2 && asAtom(pItems[0])?.startsWith('$')) {
                const pType = asAtom(pItems[1]);
                if (!pType || !isValType(pType)) throw new Error(`Geçersiz import param tipi: ${pType}`);
                imp.params.push(pType);
              } else {
                for (const tNode of pItems) {
                  const tStr = asAtom(tNode);
                  if (!tStr || !isValType(tStr)) throw new Error(`Geçersiz import param tipi: ${tStr}`);
                  imp.params.push(tStr);
                }
              }
            } else if (subHead === 'result') {
              for (const rNode of (sub as SExprList).items.slice(1)) {
                const rStr = asAtom(rNode);
                if (!rStr || !isValType(rStr)) throw new Error(`Geçersiz import result tipi: ${rStr}`);
                imp.results.push(rStr);
              }
            }
          }
          const iIdx = importedFuncs.length;
          if (imp.name) importNameToIndex.set(imp.name, iIdx);
          importedFuncs.push(imp);
        }
      } else if (head === 'func') {
        const pf: ParsedFunc = {
          params: [],
          results: [],
          paramNames: new Map(),
          locals: [],
          localNames: new Map(),
          inlineExports: [],
          bodyNodes: [],
        };
        let idx = 1;
        if (idx < list.items.length) {
          const maybeName = asAtom(list.items[idx]);
          if (maybeName && maybeName.startsWith('$')) {
            pf.name = maybeName;
            idx++;
          }
        }
        while (idx < list.items.length) {
          const sub = list.items[idx];
          const subHead = listHead(sub);
          if (subHead === 'export') {
            const expList = (sub as SExprList).items;
            const expStr = expList[1];
            if (expStr && expStr.kind === 'str') {
              pf.inlineExports.push(expStr.text);
            }
            idx++;
            continue;
          }
          if (subHead === 'param') {
            const pItems = (sub as SExprList).items.slice(1);
            if (pItems.length >= 2 && asAtom(pItems[0])?.startsWith('$')) {
              const pName = asAtom(pItems[0])!;
              const pType = asAtom(pItems[1]);
              if (!pType || !isValType(pType)) throw new Error(`Geçersiz param tipi: ${pType}`);
              pf.paramNames.set(pName, pf.params.length);
              pf.params.push(pType);
            } else {
              for (const tNode of pItems) {
                const tStr = asAtom(tNode);
                if (!tStr || !isValType(tStr)) throw new Error(`Geçersiz param tipi: ${tStr}`);
                pf.params.push(tStr);
              }
            }
            idx++;
            continue;
          }
          if (subHead === 'result') {
            for (const rNode of (sub as SExprList).items.slice(1)) {
              const rStr = asAtom(rNode);
              if (!rStr || !isValType(rStr)) throw new Error(`Geçersiz result tipi: ${rStr}`);
              pf.results.push(rStr);
            }
            idx++;
            continue;
          }
          if (subHead === 'local') {
            const lItems = (sub as SExprList).items.slice(1);
            if (lItems.length >= 2 && asAtom(lItems[0])?.startsWith('$')) {
              const lName = asAtom(lItems[0])!;
              const lType = asAtom(lItems[1]);
              if (!lType || !isValType(lType)) throw new Error(`Geçersiz local tipi: ${lType}`);
              pf.localNames.set(lName, pf.params.length + pf.locals.length);
              pf.locals.push(lType);
            } else {
              for (const tNode of lItems) {
                const tStr = asAtom(tNode);
                if (!tStr || !isValType(tStr)) throw new Error(`Geçersiz local tipi: ${tStr}`);
                pf.locals.push(tStr);
              }
            }
            idx++;
            continue;
          }
          break;
        }
        pf.bodyNodes = list.items.slice(idx);
        const fIdx = funcs.length;
        if (pf.name) funcNameToLocalIndex.set(pf.name, fIdx);
        funcs.push(pf);
      } else if (head === 'memory') {
        const exports: string[] = [];
        const nums: number[] = [];
        for (const sub of list.items.slice(1)) {
          if (listHead(sub) === 'export') {
            const s = (sub as SExprList).items[1];
            if (s && s.kind === 'str') exports.push(s.text);
          } else {
            const a = asAtom(sub);
            if (a && !a.startsWith('$')) nums.push(Number(a));
          }
        }
        memorySpec = {
          initial: Number.isFinite(nums[0]) ? nums[0] : 1,
          max: Number.isFinite(nums[1]) ? nums[1] : undefined,
          exports,
        };
      } else if (head === 'data') {
        let offset = 0;
        const bytes: number[] = [];
        for (const sub of list.items.slice(1)) {
          if (listHead(sub) === 'i32.const') {
            const valAtom = asAtom((sub as SExprList).items[1]);
            if (valAtom) offset = Number(parseIntLiteral(valAtom));
          } else if (listHead(sub) === 'offset') {
            const inner = (sub as SExprList).items[1];
            if (listHead(inner) === 'i32.const') {
              const valAtom = asAtom((inner as SExprList).items[1]);
              if (valAtom) offset = Number(parseIntLiteral(valAtom));
            }
          } else if (sub.kind === 'str') {
            bytes.push(...sub.rawBytes);
          }
        }
        dataSegmentsList.push({ offset, bytes });
      } else if (head === 'export') {
        const expName = list.items[1];
        const desc = list.items[2];
        if (expName?.kind === 'str' && desc?.kind === 'list') {
          const kind = asAtom(desc.items[0]);
          const target = asAtom(desc.items[1]);
          if ((kind === 'func' || kind === 'memory') && target) {
            standaloneExports.push({ name: expName.text, kind, target });
          }
        }
      }
    }

    if (dataSegmentsList.length > 0 && !memorySpec) {
      memorySpec = { initial: 1, exports: [] };
    }

    // Build Type Section (deduplicate signatures for both imports & local funcs)
    const sigKeys = new Map<string, number>();
    const typeEntries: number[][] = [];
    const ensureType = (params: WasmValType[], results: WasmValType[]): number => {
      const key = `${params.join(',')}->${results.join(',')}`;
      let tIdx = sigKeys.get(key);
      if (tIdx === undefined) {
        tIdx = typeEntries.length;
        sigKeys.set(key, tIdx);
        typeEntries.push([
          0x60,
          ...encodeULEB128(params.length),
          ...params.map(valTypeByte),
          ...encodeULEB128(results.length),
          ...results.map(valTypeByte),
        ]);
      }
      return tIdx;
    };

    const importEntries: number[][] = importedFuncs.map((imp) => {
      const tIdx = ensureType(imp.params, imp.results);
      return [...encodeUTF8String(imp.module), ...encodeUTF8String(imp.field), 0x00, ...encodeULEB128(tIdx)];
    });

    const funcTypeIndices: number[] = funcs.map((f) => ensureType(f.params, f.results));
    const importCount = importedFuncs.length;

    const resolveFuncIndex = (ref: string): number => {
      if (ref.startsWith('$')) {
        const impFound = importNameToIndex.get(ref);
        if (impFound !== undefined) return impFound;
        const localFound = funcNameToLocalIndex.get(ref);
        if (localFound !== undefined) return importCount + localFound;
        throw new Error(`Tanımsız fonksiyon referansı: ${ref}`);
      }
      const n = Number(ref);
      if (Number.isNaN(n) || n < 0 || n >= importCount + funcs.length) {
        throw new Error(`Geçersiz fonksiyon indeksi: ${ref}`);
      }
      return n;
    };

    const resolveLocalIndex = (pf: ParsedFunc, ref: string): number => {
      if (ref.startsWith('$')) {
        const pIdx = pf.paramNames.get(ref);
        if (pIdx !== undefined) return pIdx;
        const lIdx = pf.localNames.get(ref);
        if (lIdx !== undefined) return lIdx;
        throw new Error(`Tanımsız yerel değişken: ${ref}`);
      }
      const n = Number(ref);
      if (Number.isNaN(n) || n < 0 || n >= pf.params.length + pf.locals.length) {
        throw new Error(`Geçersiz local indeksi: ${ref}`);
      }
      return n;
    };

    // Compile each function body
    const codeBodies: number[][] = funcs.map((pf) => {
      const code: number[] = [];
      const labelStack: Array<string | null> = [];

      const resolveBranchDepth = (ref: string): number => {
        if (ref.startsWith('$')) {
          for (let k = labelStack.length - 1; k >= 0; k--) {
            if (labelStack[k] === ref) return labelStack.length - 1 - k;
          }
          throw new Error(`Tanımsız blok etiketi: ${ref}`);
        }
        return Number(ref);
      };

      const emitFolded = (node: SExprList): void => {
        const op = asAtom(node.items[0]);
        if (!op) throw new Error('Geçersiz ifade');
        const rest = node.items.slice(1);

        if (op === 'block' || op === 'loop') {
          let i = 0;
          let label: string | null = null;
          if (asAtom(rest[i])?.startsWith('$')) {
            label = asAtom(rest[i])!;
            i++;
          }
          let blockType = 0x40; // empty
          if (listHead(rest[i]) === 'result') {
            const rt = asAtom((rest[i] as SExprList).items[1]);
            if (rt && isValType(rt)) blockType = valTypeByte(rt);
            i++;
          }
          code.push(op === 'block' ? 0x02 : 0x03, blockType);
          labelStack.push(label);
          emitLinear(rest.slice(i));
          labelStack.pop();
          code.push(0x0b);
          return;
        }

        if (op === 'if') {
          let i = 0;
          let blockType = 0x40;
          if (asAtom(rest[i])?.startsWith('$')) i++;
          if (listHead(rest[i]) === 'result') {
            const rt = asAtom((rest[i] as SExprList).items[1]);
            if (rt && isValType(rt)) blockType = valTypeByte(rt);
            i++;
          }
          let thenNode: SExprList | null = null;
          let elseNode: SExprList | null = null;
          const condNodes: SExprNode[] = [];
          for (const item of rest.slice(i)) {
            const h = listHead(item);
            if (h === 'then') thenNode = item as SExprList;
            else if (h === 'else') elseNode = item as SExprList;
            else condNodes.push(item);
          }
          emitLinear(condNodes);
          code.push(0x04, blockType);
          labelStack.push(null);
          if (thenNode) emitLinear(thenNode.items.slice(1));
          if (elseNode) {
            code.push(0x05);
            emitLinear(elseNode.items.slice(1));
          }
          labelStack.pop();
          code.push(0x0b);
          return;
        }

        // Handle folded operands (skip immediate atoms belonging to instruction itself)
        if (op === 'i32.const' || op === 'i64.const') {
          const valAtom = asAtom(rest[0]);
          if (!valAtom) throw new Error(`${op} sayısal sabit bekliyor`);
          code.push(op === 'i32.const' ? 0x41 : 0x42, ...encodeSLEB128(parseIntLiteral(valAtom)));
          return;
        }
        if (op === 'f32.const') {
          const valAtom = asAtom(rest[0]);
          if (!valAtom) throw new Error('f32.const sayısal sabit bekliyor');
          code.push(0x43, ...encodeF32(Number(valAtom)));
          return;
        }
        if (op === 'f64.const') {
          const valAtom = asAtom(rest[0]);
          if (!valAtom) throw new Error('f64.const sayısal sabit bekliyor');
          code.push(0x44, ...encodeF64(Number(valAtom)));
          return;
        }
        if (op === 'local.get' || op === 'get_local') {
          const ref = asAtom(rest[0]);
          if (!ref) throw new Error('local.get hedef bekliyor');
          code.push(0x20, ...encodeULEB128(resolveLocalIndex(pf, ref)));
          return;
        }
        if (op === 'local.set' || op === 'set_local') {
          const ref = asAtom(rest[0]);
          if (!ref) throw new Error('local.set hedef bekliyor');
          for (const child of rest.slice(1)) {
            if (child.kind === 'list') emitFolded(child);
          }
          code.push(0x21, ...encodeULEB128(resolveLocalIndex(pf, ref)));
          return;
        }
        if (op === 'local.tee' || op === 'tee_local') {
          const ref = asAtom(rest[0]);
          if (!ref) throw new Error('local.tee hedef bekliyor');
          for (const child of rest.slice(1)) {
            if (child.kind === 'list') emitFolded(child);
          }
          code.push(0x22, ...encodeULEB128(resolveLocalIndex(pf, ref)));
          return;
        }
        if (op === 'br' || op === 'br_if') {
          const lbl = asAtom(rest[0]);
          if (!lbl) throw new Error(`${op} etiket bekliyor`);
          for (const child of rest.slice(1)) {
            if (child.kind === 'list') emitFolded(child);
          }
          code.push(op === 'br' ? 0x0c : 0x0d, ...encodeULEB128(resolveBranchDepth(lbl)));
          return;
        }
        if (op === 'call') {
          const fnRef = asAtom(rest[0]);
          if (!fnRef) throw new Error('call fonksiyon adı/indeksi bekliyor');
          for (const child of rest.slice(1)) {
            if (child.kind === 'list') emitFolded(child);
          }
          code.push(0x10, ...encodeULEB128(resolveFuncIndex(fnRef)));
          return;
        }
        if (op in MEMORY_OPCODES) {
          const spec = MEMORY_OPCODES[op];
          let offset = 0;
          let align = spec.defaultAlign;
          const exprArgs: SExprList[] = [];
          for (const arg of rest) {
            const a = asAtom(arg);
            if (a && a.startsWith('offset=')) offset = Number(a.slice(7));
            else if (a && a.startsWith('align=')) {
              const al = Number(a.slice(6));
              align = al > 0 ? Math.round(Math.log2(al)) : 0;
            } else if (arg.kind === 'list') {
              exprArgs.push(arg);
            }
          }
          exprArgs.forEach(emitFolded);
          code.push(spec.opcode, ...encodeULEB128(align), ...encodeULEB128(offset));
          return;
        }

        // General folded instruction: emit nested child S-expressions first, then opcode
        for (const child of rest) {
          if (child.kind === 'list') emitFolded(child);
        }
        const opc = SIMPLE_OPCODES[op];
        if (opc === undefined) {
          throw new Error(`Desteklenmeyen WAT komutu: ${op}`);
        }
        code.push(opc);
      };

      const emitLinear = (nodes: SExprNode[]): void => {
        let i = 0;
        while (i < nodes.length) {
          const node = nodes[i];
          if (node.kind === 'list') {
            emitFolded(node);
            i++;
            continue;
          }
          const op = asAtom(node);
          if (!op) {
            i++;
            continue;
          }

          if (op === 'block' || op === 'loop') {
            let label: string | null = null;
            if (asAtom(nodes[i + 1])?.startsWith('$')) {
              label = asAtom(nodes[i + 1])!;
              i++;
            }
            let blockType = 0x40;
            if (listHead(nodes[i + 1]) === 'result') {
              const rt = asAtom((nodes[i + 1] as SExprList).items[1]);
              if (rt && isValType(rt)) blockType = valTypeByte(rt);
              i++;
            }
            code.push(op === 'block' ? 0x02 : 0x03, blockType);
            labelStack.push(label);
            i++;
            continue;
          }
          if (op === 'if') {
            let blockType = 0x40;
            if (listHead(nodes[i + 1]) === 'result') {
              const rt = asAtom((nodes[i + 1] as SExprList).items[1]);
              if (rt && isValType(rt)) blockType = valTypeByte(rt);
              i++;
            }
            code.push(0x04, blockType);
            labelStack.push(null);
            i++;
            continue;
          }
          if (op === 'else') {
            code.push(0x05);
            i++;
            continue;
          }
          if (op === 'end') {
            labelStack.pop();
            code.push(0x0b);
            i++;
            continue;
          }
          if (op === 'i32.const' || op === 'i64.const') {
            const valAtom = asAtom(nodes[i + 1]);
            if (!valAtom) throw new Error(`${op} sabit bekliyor`);
            code.push(op === 'i32.const' ? 0x41 : 0x42, ...encodeSLEB128(parseIntLiteral(valAtom)));
            i += 2;
            continue;
          }
          if (op === 'f32.const') {
            const valAtom = asAtom(nodes[i + 1]);
            if (!valAtom) throw new Error('f32.const sabit bekliyor');
            code.push(0x43, ...encodeF32(Number(valAtom)));
            i += 2;
            continue;
          }
          if (op === 'f64.const') {
            const valAtom = asAtom(nodes[i + 1]);
            if (!valAtom) throw new Error('f64.const sabit bekliyor');
            code.push(0x44, ...encodeF64(Number(valAtom)));
            i += 2;
            continue;
          }
          if (op === 'local.get' || op === 'get_local') {
            const ref = asAtom(nodes[i + 1]);
            if (!ref) throw new Error('local.get hedef bekliyor');
            code.push(0x20, ...encodeULEB128(resolveLocalIndex(pf, ref)));
            i += 2;
            continue;
          }
          if (op === 'local.set' || op === 'set_local') {
            const ref = asAtom(nodes[i + 1]);
            if (!ref) throw new Error('local.set hedef bekliyor');
            code.push(0x21, ...encodeULEB128(resolveLocalIndex(pf, ref)));
            i += 2;
            continue;
          }
          if (op === 'local.tee' || op === 'tee_local') {
            const ref = asAtom(nodes[i + 1]);
            if (!ref) throw new Error('local.tee hedef bekliyor');
            code.push(0x22, ...encodeULEB128(resolveLocalIndex(pf, ref)));
            i += 2;
            continue;
          }
          if (op === 'br' || op === 'br_if') {
            const lbl = asAtom(nodes[i + 1]);
            if (!lbl) throw new Error(`${op} etiket bekliyor`);
            code.push(op === 'br' ? 0x0c : 0x0d, ...encodeULEB128(resolveBranchDepth(lbl)));
            i += 2;
            continue;
          }
          if (op === 'call') {
            const fnRef = asAtom(nodes[i + 1]);
            if (!fnRef) throw new Error('call fonksiyon bekliyor');
            code.push(0x10, ...encodeULEB128(resolveFuncIndex(fnRef)));
            i += 2;
            continue;
          }
          if (op in MEMORY_OPCODES) {
            const spec = MEMORY_OPCODES[op];
            let offset = 0;
            let align = spec.defaultAlign;
            while (i + 1 < nodes.length) {
              const nextAtom = asAtom(nodes[i + 1]);
              if (nextAtom && nextAtom.startsWith('offset=')) {
                offset = Number(nextAtom.slice(7));
                i++;
              } else if (nextAtom && nextAtom.startsWith('align=')) {
                const al = Number(nextAtom.slice(6));
                align = al > 0 ? Math.round(Math.log2(al)) : 0;
                i++;
              } else {
                break;
              }
            }
            code.push(spec.opcode, ...encodeULEB128(align), ...encodeULEB128(offset));
            i++;
            continue;
          }

          const opc = SIMPLE_OPCODES[op];
          if (opc === undefined) {
            throw new Error(`Desteklenmeyen WAT komutu: ${op}`);
          }
          code.push(opc);
          i++;
        }
      };

      emitLinear(pf.bodyNodes);
      code.push(0x0b); // function end

      // Encode compressed local declarations (run-length encoded by type)
      const localRuns: Array<{ count: number; type: WasmValType }> = [];
      for (const lt of pf.locals) {
        const last = localRuns[localRuns.length - 1];
        if (last && last.type === lt) last.count++;
        else localRuns.push({ count: 1, type: lt });
      }
      const localsHeader: number[] = [...encodeULEB128(localRuns.length)];
      for (const run of localRuns) {
        localsHeader.push(...encodeULEB128(run.count), valTypeByte(run.type));
      }
      const fullBody = [...localsHeader, ...code];
      return [...encodeULEB128(fullBody.length), ...fullBody];
    });

    // Build Exports Section & Export Metadata
    const exportEntries: number[][] = [];
    const exportMeta: WasmExportMeta[] = [];

    funcs.forEach((pf, fIdx) => {
      const absIdx = importCount + fIdx;
      for (const expName of pf.inlineExports) {
        exportEntries.push([...encodeUTF8String(expName), 0x00, ...encodeULEB128(absIdx)]);
        exportMeta.push({ name: expName, kind: 'func', params: pf.params, results: pf.results });
      }
    });

    if (memorySpec) {
      for (const memExp of memorySpec.exports) {
        exportEntries.push([...encodeUTF8String(memExp), 0x02, 0x00]);
        exportMeta.push({ name: memExp, kind: 'memory', params: [], results: [] });
      }
    }

    for (const se of standaloneExports) {
      if (se.kind === 'func') {
        const absIdx = resolveFuncIndex(se.target);
        const pf = absIdx >= importCount ? funcs[absIdx - importCount] : importedFuncs[absIdx];
        exportEntries.push([...encodeUTF8String(se.name), 0x00, ...encodeULEB128(absIdx)]);
        exportMeta.push({ name: se.name, kind: 'func', params: pf.params, results: pf.results });
      } else if (se.kind === 'memory' && memorySpec) {
        exportEntries.push([...encodeUTF8String(se.name), 0x02, 0x00]);
        exportMeta.push({ name: se.name, kind: 'memory', params: [], results: [] });
      }
    }

    // Assemble WASM Sections
    const sections: number[] = [0x00, 0x61, 0x73, 0x6d, 0x01, 0x00, 0x00, 0x00];
    const sectionSummary: Array<{ name: string; bytes: number }> = [];

    if (typeEntries.length > 0) {
      const sec = makeSection(1, [...encodeULEB128(typeEntries.length), ...typeEntries.flat()]);
      sections.push(...sec);
      sectionSummary.push({ name: 'Type', bytes: sec.length });
    }
    if (importEntries.length > 0) {
      const sec = makeSection(2, [...encodeULEB128(importEntries.length), ...importEntries.flat()]);
      sections.push(...sec);
      sectionSummary.push({ name: 'Import', bytes: sec.length });
    }
    if (funcTypeIndices.length > 0) {
      const sec = makeSection(3, [
        ...encodeULEB128(funcTypeIndices.length),
        ...funcTypeIndices.flatMap((idx) => encodeULEB128(idx)),
      ]);
      sections.push(...sec);
      sectionSummary.push({ name: 'Function', bytes: sec.length });
    }
    if (memorySpec) {
      const limits =
        memorySpec.max !== undefined
          ? [0x01, ...encodeULEB128(memorySpec.initial), ...encodeULEB128(memorySpec.max)]
          : [0x00, ...encodeULEB128(memorySpec.initial)];
      const sec = makeSection(5, [1, ...limits]);
      sections.push(...sec);
      sectionSummary.push({ name: 'Memory', bytes: sec.length });
    }
    if (exportEntries.length > 0) {
      const sec = makeSection(7, [...encodeULEB128(exportEntries.length), ...exportEntries.flat()]);
      sections.push(...sec);
      sectionSummary.push({ name: 'Export', bytes: sec.length });
    }
    if (codeBodies.length > 0) {
      const sec = makeSection(10, [...encodeULEB128(codeBodies.length), ...codeBodies.flat()]);
      sections.push(...sec);
      sectionSummary.push({ name: 'Code', bytes: sec.length });
    }
    if (dataSegmentsList.length > 0) {
      const segPayloads = dataSegmentsList.flatMap((seg) => [
        0x00, // active segment, memory 0
        0x41, // i32.const
        ...encodeSLEB128(BigInt(seg.offset)),
        0x0b, // end
        ...encodeULEB128(seg.bytes.length),
        ...seg.bytes,
      ]);
      const sec = makeSection(11, [...encodeULEB128(dataSegmentsList.length), ...segPayloads]);
      sections.push(...sec);
      sectionSummary.push({ name: 'Data', bytes: sec.length });
    }

    const bytes = new Uint8Array(new ArrayBuffer(sections.length));
    bytes.set(sections);

    if (!WebAssembly.validate(bytes)) {
      return {
        ok: false,
        exports: exportMeta,
        memoryPages: memorySpec?.initial || 0,
        dataSegments: dataSegmentsList.length,
        compileTimeMs: Math.max(0.1, Number(((typeof performance !== 'undefined' ? performance.now() : Date.now()) - t0).toFixed(2))),
        sizeBytes: bytes.length,
        sectionSummary,
        error: 'Derlenen ikili WebAssembly.validate() doğrulamasından geçemedi.',
      };
    }

    const elapsed =
      typeof performance !== 'undefined' ? performance.now() - t0 : Date.now() - t0;

    return {
      ok: true,
      bytes,
      base64Content: `${WASM_B64_PREFIX}${bytesToBase64(bytes)}`,
      exports: exportMeta,
      memoryPages: memorySpec?.initial || 0,
      dataSegments: dataSegmentsList.length,
      compileTimeMs: Math.max(0.1, Number(elapsed.toFixed(2))),
      sizeBytes: bytes.length,
      sectionSummary,
    };
  } catch (err) {
    return {
      ok: false,
      exports: [],
      memoryPages: 0,
      dataSegments: 0,
      compileTimeMs: 0,
      sizeBytes: 0,
      sectionSummary: [],
      error: err instanceof Error ? err.message : String(err),
    };
  }
}

export async function sha256BytesHex(bytes: Uint8Array<ArrayBuffer>): Promise<string> {
  if (typeof crypto !== 'undefined' && crypto.subtle) {
    const digest = await crypto.subtle.digest('SHA-256', bytes);
    return Array.from(new Uint8Array(digest))
      .map((b) => b.toString(16).padStart(2, '0'))
      .join('');
  }
  let h = 2166136261;
  for (let i = 0; i < bytes.length; i++) {
    h ^= bytes[i];
    h = Math.imul(h, 16777619);
  }
  return (h >>> 0).toString(16).padStart(8, '0');
}

export async function packageWasmModule(params: {
  name: string;
  version?: string;
  author?: string;
  description?: string;
  wasmContentOrBytes: string | Uint8Array<ArrayBuffer>;
  watSource?: string;
  exports?: WasmExportMeta[];
  entryFn?: string;
}): Promise<{ ok: boolean; json?: string; manifest?: AnkaWasmPackageManifest; error?: string }> {
  let bytes: Uint8Array<ArrayBuffer>;
  let base64WithPrefix: string;

  if (typeof params.wasmContentOrBytes === 'string') {
    bytes = decodeWasmBytes(params.wasmContentOrBytes);
    base64WithPrefix = `${WASM_B64_PREFIX}${bytesToBase64(bytes)}`;
  } else {
    bytes = params.wasmContentOrBytes;
    base64WithPrefix = `${WASM_B64_PREFIX}${bytesToBase64(bytes)}`;
  }

  if (bytes.length < 8 || !WebAssembly.validate(bytes)) {
    return { ok: false, error: 'Paketlenecek ikili geçerli bir WebAssembly modülü değil.' };
  }

  let exportsMeta = params.exports || [];
  let hasMemory = exportsMeta.some((e) => e.kind === 'memory');
  if (exportsMeta.length === 0) {
    const memoryRef: { current: WebAssembly.Memory | null } = { current: null };
    const wasi = createWasiPreview1Imports(memoryRef);
    const inst = (await WebAssembly.instantiate(bytes, wasi.imports)) as unknown as WebAssembly.WebAssemblyInstantiatedSource;
    const rawExports = inst.instance.exports as Record<string, unknown>;
    exportsMeta = Object.entries(rawExports).map(([name, val]) => {
      if (val instanceof WebAssembly.Memory) {
        hasMemory = true;
        return { name, kind: 'memory' as const, params: [], results: [] };
      }
      const fnLen = typeof val === 'function' ? val.length : 0;
      return {
        name,
        kind: 'func' as const,
        params: Array.from({ length: fnLen }, () => 'i32' as const),
        results: ['i32' as const],
      };
    });
  }

  const funcExports = exportsMeta.filter((e) => e.kind === 'func');
  const entryFn = params.entryFn || funcExports[0]?.name || 'main';
  const sha256 = await sha256BytesHex(bytes);

  const manifest: AnkaWasmPackageManifest = {
    schema: 'ankaos-wasm-pkg-v1',
    name: params.name.trim() || 'anka-wasm-modul',
    version: params.version?.trim() || '1.0.0',
    author: params.author?.trim() || 'kullanici',
    description: params.description?.trim() || 'AnkaOS paketlenmiş WebAssembly modülü',
    createdAt: new Date().toISOString(),
    entryFn,
    exports: exportsMeta,
    wasmBase64: base64WithPrefix,
    watSource: params.watSource,
    byteLength: bytes.length,
    sha256,
    hasMemory,
  };

  return {
    ok: true,
    manifest,
    json: JSON.stringify(manifest, null, 2),
  };
}

export async function runWasmOrPackageFromVfsContent(
  rawContent: string,
  fnName?: string,
  args: number[] = []
) {
  const trimmed = rawContent.trim();
  if (trimmed.startsWith('{') && trimmed.includes('"ankaos-wasm-pkg-v1"')) {
    try {
      const pkg = JSON.parse(trimmed) as AnkaWasmPackageManifest;
      if (pkg.schema === 'ankaos-wasm-pkg-v1' && pkg.wasmBase64) {
        const res = await runWasmBinary(pkg.wasmBase64, fnName || pkg.entryFn, args);
        return { ...res, packageMeta: pkg };
      }
    } catch {
      // fall through to raw wasm
    }
  }
  return await runWasmBinary(rawContent, fnName, args);
}

/**
 * Runs a WASM module and also reads a UTF-8 memory preview slice if memory is exported.
 */
export async function runWasmWithMemoryPreview(
  content: string,
  fnName?: string,
  args: number[] = []
): Promise<{
  ok: boolean;
  exportsList: string[];
  invoked?: { fn: string; args: number[]; result: number | bigint | undefined };
  stdoutText?: string;
  durationMs: number;
  byteLength: number;
  memoryText?: string;
  memoryHex?: string;
  error?: string;
}> {
  const start = Date.now();
  try {
    const trimmed = content.trim();
    let wasmPayload = content;
    let preferredFn = fnName;
    if (trimmed.startsWith('{') && trimmed.includes('"ankaos-wasm-pkg-v1"')) {
      const pkg = JSON.parse(trimmed) as AnkaWasmPackageManifest;
      wasmPayload = pkg.wasmBase64;
      if (!preferredFn) preferredFn = pkg.entryFn;
    }

    const bytes = decodeWasmBytes(wasmPayload);
    if (bytes.length < 8 || !WebAssembly.validate(bytes)) {
      return {
        ok: false,
        exportsList: [],
        durationMs: Date.now() - start,
        byteLength: bytes.length,
        error: 'Geçersiz WebAssembly (\\0asm) modülü.',
      };
    }

    const memoryRef: { current: WebAssembly.Memory | null } = { current: null };
    const wasi = createWasiPreview1Imports(memoryRef, {
      args: ['ankaos-wasm', ...args.map(String)],
    });

    const instantiated = (await WebAssembly.instantiate(bytes, wasi.imports)) as unknown as WebAssembly.WebAssemblyInstantiatedSource;
    const exportsObj = instantiated.instance.exports as Record<string, unknown>;
    const memExport = Object.values(exportsObj).find((v) => v instanceof WebAssembly.Memory) as
      | WebAssembly.Memory
      | undefined;
    if (memExport) memoryRef.current = memExport;

    const fnNames = Object.entries(exportsObj)
      .filter(([, v]) => typeof v === 'function')
      .map(([k]) => k);

    let invoked: { fn: string; args: number[]; result: number | bigint | undefined } | undefined;
    const target = preferredFn || (fnNames.includes('_start') ? '_start' : fnNames[0]);
    if (target) {
      const fn = exportsObj[target];
      if (typeof fn !== 'function') {
        return {
          ok: false,
          exportsList: fnNames,
          durationMs: Date.now() - start,
          byteLength: bytes.length,
          error: `Fonksiyon bulunamadı: ${target}`,
        };
      }
      const arity = fn.length;
      const callArgs =
        args.length > 0
          ? args.slice(0, Math.max(arity, args.length))
          : arity === 2
            ? [19, 23]
            : arity === 1
              ? [7]
              : [];
      try {
        const result = (fn as (...p: number[]) => number | bigint | undefined)(...callArgs);
        invoked = { fn: target, args: callArgs, result };
      } catch (callErr) {
        if (callErr instanceof WasiExitSignal) {
          invoked = { fn: target, args: callArgs, result: callErr.exitCode };
          if (callErr.exitCode !== 0) {
            return {
              ok: false,
              exportsList: fnNames,
              invoked,
              stdoutText: wasi.getStdout() || undefined,
              durationMs: Date.now() - start,
              byteLength: bytes.length,
              error: `WASI süreç çıkışı: kod ${callErr.exitCode}`,
            };
          }
        } else {
          throw callErr;
        }
      }
    }

    let memoryText: string | undefined;
    let memoryHex: string | undefined;
    if (memExport) {
      const slice = new Uint8Array(memExport.buffer, 0, Math.min(64, memExport.buffer.byteLength));
      const nonZeroEnd = slice.findIndex((b, idx) => b === 0 && idx > 0 && slice[idx - 1] === 0);
      const view = slice.slice(0, nonZeroEnd > 0 ? nonZeroEnd : 64);
      memoryText = new TextDecoder('utf-8', { fatal: false })
        .decode(view)
        .replace(/\0+$/g, '');
      memoryHex = Array.from(view.slice(0, 32))
        .map((b) => b.toString(16).padStart(2, '0'))
        .join(' ');
    }

    const stdoutCombined = [wasi.getStdout(), wasi.getStderr()].filter(Boolean).join('');
    return {
      ok: true,
      exportsList: fnNames,
      invoked,
      stdoutText: stdoutCombined || undefined,
      durationMs: Math.max(0.1, Date.now() - start),
      byteLength: bytes.length,
      memoryText,
      memoryHex,
    };
  } catch (err) {
    return {
      ok: false,
      exportsList: [],
      durationMs: Date.now() - start,
      byteLength: 0,
      error: err instanceof Error ? err.message : String(err),
    };
  }
}
