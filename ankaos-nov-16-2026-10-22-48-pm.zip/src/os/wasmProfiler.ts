import { createWasiPreview1Imports, decodeWasmBytes, WasiExitSignal } from './sandboxRuntime';
import type { AnkaWasmPackageManifest } from './wasmCompiler';

export type FlameCategory = 'runtime' | 'compile' | 'function' | 'loop' | 'memory' | 'alu';

export interface WasmFlameNode {
  id: string;
  name: string;
  category: FlameCategory;
  depth: number;
  startPct: number; // 0..100
  widthPct: number; // 0..100
  totalUs: number;
  selfUs: number;
  calls: number;
  codeBytes?: number;
  opcodesSummary?: string;
  children: WasmFlameNode[];
}

export interface WasmFunctionStat {
  index: number;
  name: string;
  exported: boolean;
  codeBytes: number;
  instructionCount: number;
  loopCount: number;
  memoryOps: number;
  callOps: number;
  callees: number[];
  selfUs: number;
  totalUs: number;
  sharePct: number;
}

export interface WasmSectionBreakdown {
  id: number;
  name: string;
  bytes: number;
  sharePct: number;
}

export interface WasmProfileReport {
  schema: 'ankaos-wasm-profile-v1';
  createdAt: string;
  moduleName: string;
  sourcePath?: string;
  entryFn: string;
  args: number[];
  resultText: string;
  iterations: number;
  byteLength: number;
  memoryPages: number;
  memoryUsedBytes: number;
  metrics: {
    decodeUs: number;
    validateUs: number;
    compileUs: number;
    instantiateUs: number;
    coldCallUs: number;
    hotAvgUs: number;
    hotMinUs: number;
    hotP50Us: number;
    hotP95Us: number;
    hotMaxUs: number;
    totalPipelineUs: number;
    opsPerSec: number;
  };
  sections: WasmSectionBreakdown[];
  functionStats: WasmFunctionStat[];
  timelineSamplesUs: number[];
  flameRoot: WasmFlameNode;
}

interface ParsedCodeBody {
  index: number;
  codeBytes: number;
  instructionCount: number;
  loopCount: number;
  memoryOps: number;
  callOps: number;
  callees: number[];
}

const SECTION_NAMES: Record<number, string> = {
  0: 'Custom',
  1: 'Type',
  2: 'Import',
  3: 'Function',
  4: 'Table',
  5: 'Memory',
  6: 'Global',
  7: 'Export',
  8: 'Start',
  9: 'Element',
  10: 'Code',
  11: 'Data',
  12: 'DataCount',
};

function nowUs(): number {
  if (typeof performance !== 'undefined' && typeof performance.now === 'function') {
    return performance.now() * 1000;
  }
  return Date.now() * 1000;
}

function roundUs(v: number): number {
  return Math.max(0.01, Number(v.toFixed(2)));
}

function readULEB128(bytes: Uint8Array, pos: number): { value: number; next: number } {
  let result = 0;
  let shift = 0;
  let cursor = pos;
  while (cursor < bytes.length && shift <= 35) {
    const b = bytes[cursor++];
    result |= (b & 0x7f) << shift;
    if ((b & 0x80) === 0) break;
    shift += 7;
  }
  return { value: result >>> 0, next: cursor };
}

function skipSLEB128(bytes: Uint8Array, pos: number): number {
  let cursor = pos;
  let steps = 0;
  while (cursor < bytes.length && steps < 10) {
    const b = bytes[cursor++];
    steps++;
    if ((b & 0x80) === 0) break;
  }
  return cursor;
}

function readUTF8(bytes: Uint8Array, pos: number): { text: string; next: number } {
  const { value: len, next } = readULEB128(bytes, pos);
  const end = Math.min(bytes.length, next + len);
  const text = new TextDecoder('utf-8', { fatal: false }).decode(bytes.subarray(next, end));
  return { text, next: end };
}

function analyzeCodeBody(bytes: Uint8Array, start: number, end: number, index: number): ParsedCodeBody {
  let cursor = start;
  const { value: localDeclCount, next: afterLocalsCount } = readULEB128(bytes, cursor);
  cursor = afterLocalsCount;
  for (let i = 0; i < localDeclCount && cursor < end; i++) {
    const cnt = readULEB128(bytes, cursor);
    cursor = Math.min(end, cnt.next + 1); // count + valtype byte
  }

  let instructionCount = 0;
  let loopCount = 0;
  let memoryOps = 0;
  let callOps = 0;
  const callees = new Set<number>();

  while (cursor < end) {
    const op = bytes[cursor++];
    instructionCount++;

    if (op === 0x02 || op === 0x03 || op === 0x04) {
      // block, loop, if + blocktype
      if (op === 0x03) loopCount++;
      if (cursor < end) {
        const bt = bytes[cursor];
        if (bt === 0x40 || (bt >= 0x7b && bt <= 0x7f)) {
          cursor++;
        } else {
          cursor = skipSLEB128(bytes, cursor);
        }
      }
    } else if (op === 0x0c || op === 0x0d || op === 0x20 || op === 0x21 || op === 0x22 || op === 0x23 || op === 0x24) {
      // br, br_if, local.*, global.*
      cursor = readULEB128(bytes, cursor).next;
    } else if (op === 0x0e) {
      // br_table: vec(labelidx) + default
      const vec = readULEB128(bytes, cursor);
      cursor = vec.next;
      for (let k = 0; k <= vec.value && cursor < end; k++) {
        cursor = readULEB128(bytes, cursor).next;
      }
    } else if (op === 0x10) {
      // call funcidx
      callOps++;
      const target = readULEB128(bytes, cursor);
      callees.add(target.value);
      cursor = target.next;
    } else if (op === 0x11) {
      // call_indirect: typeidx, tableidx
      callOps++;
      cursor = readULEB128(bytes, cursor).next;
      cursor = readULEB128(bytes, cursor).next;
    } else if (op >= 0x28 && op <= 0x3e) {
      // memory load/store: align + offset
      memoryOps++;
      cursor = readULEB128(bytes, cursor).next;
      cursor = readULEB128(bytes, cursor).next;
    } else if (op === 0x3f || op === 0x40) {
      // memory.size, memory.grow
      memoryOps++;
      if (cursor < end) cursor++;
    } else if (op === 0x41 || op === 0x42) {
      // i32.const, i64.const
      cursor = skipSLEB128(bytes, cursor);
    } else if (op === 0x43) {
      cursor = Math.min(end, cursor + 4);
    } else if (op === 0x44) {
      cursor = Math.min(end, cursor + 8);
    } else if (op === 0xfc && cursor < end) {
      // multi-byte misc opcodes
      cursor = readULEB128(bytes, cursor).next;
    }
  }

  return {
    index,
    codeBytes: Math.max(1, end - start),
    instructionCount,
    loopCount,
    memoryOps,
    callOps,
    callees: Array.from(callees),
  };
}

export function dissectWasmBinary(bytes: Uint8Array): {
  sections: WasmSectionBreakdown[];
  exportedFuncNames: Map<number, string>;
  importedFuncCount: number;
  totalFuncCount: number;
  codeBodies: ParsedCodeBody[];
  memoryInitialPages: number;
} {
  const sections: WasmSectionBreakdown[] = [];
  const exportedFuncNames = new Map<number, string>();
  const codeBodies: ParsedCodeBody[] = [];
  let importedFuncCount = 0;
  let declaredFuncCount = 0;
  let memoryInitialPages = 0;

  if (bytes.length < 8) {
    return {
      sections,
      exportedFuncNames,
      importedFuncCount,
      totalFuncCount: 0,
      codeBodies,
      memoryInitialPages,
    };
  }

  let cursor = 8;
  const totalBytes = Math.max(1, bytes.length);

  while (cursor < bytes.length) {
    const secId = bytes[cursor++];
    const { value: secLen, next: secStart } = readULEB128(bytes, cursor);
    const secEnd = Math.min(bytes.length, secStart + secLen);
    const secName = SECTION_NAMES[secId] || `Sec#${secId}`;
    const rawSecBytes = secEnd - (cursor - 1);

    sections.push({
      id: secId,
      name: secName,
      bytes: rawSecBytes,
      sharePct: Number(((rawSecBytes / totalBytes) * 100).toFixed(1)),
    });

    if (secId === 2) {
      // Import section count
      let p = secStart;
      const { value: count, next } = readULEB128(bytes, p);
      p = next;
      for (let i = 0; i < count && p < secEnd; i++) {
        p = readUTF8(bytes, p).next;
        p = readUTF8(bytes, p).next;
        const kind = bytes[p++];
        if (kind === 0x00) {
          importedFuncCount++;
          p = readULEB128(bytes, p).next;
        } else if (kind === 0x01) {
          p += 2;
        } else if (kind === 0x02) {
          const flags = bytes[p++];
          p = readULEB128(bytes, p).next;
          if (flags & 1) p = readULEB128(bytes, p).next;
        } else if (kind === 0x03) {
          p += 2;
        }
      }
    } else if (secId === 3) {
      declaredFuncCount = readULEB128(bytes, secStart).value;
    } else if (secId === 5) {
      let p = secStart;
      const { value: count, next } = readULEB128(bytes, p);
      p = next;
      if (count > 0 && p < secEnd) {
        const flags = bytes[p++];
        const minRes = readULEB128(bytes, p);
        memoryInitialPages = minRes.value;
        if (flags & 1) {
          readULEB128(bytes, minRes.next);
        }
      }
    } else if (secId === 7) {
      // Export section
      let p = secStart;
      const { value: count, next } = readULEB128(bytes, p);
      p = next;
      for (let i = 0; i < count && p < secEnd; i++) {
        const nameRes = readUTF8(bytes, p);
        p = nameRes.next;
        const kind = bytes[p++];
        const idxRes = readULEB128(bytes, p);
        p = idxRes.next;
        if (kind === 0x00 && !exportedFuncNames.has(idxRes.value)) {
          exportedFuncNames.set(idxRes.value, nameRes.text);
        }
      }
    } else if (secId === 10) {
      // Code section
      let p = secStart;
      const { value: count, next } = readULEB128(bytes, p);
      p = next;
      for (let i = 0; i < count && p < secEnd; i++) {
        const { value: bodySize, next: bodyStart } = readULEB128(bytes, p);
        const bodyEnd = Math.min(secEnd, bodyStart + bodySize);
        codeBodies.push(analyzeCodeBody(bytes, bodyStart, bodyEnd, importedFuncCount + i));
        p = bodyEnd;
      }
    }

    cursor = secEnd;
  }

  return {
    sections,
    exportedFuncNames,
    importedFuncCount,
    totalFuncCount: importedFuncCount + Math.max(declaredFuncCount, codeBodies.length),
    codeBodies,
    memoryInitialPages,
  };
}

function percentile(sorted: number[], p: number): number {
  if (sorted.length === 0) return 0;
  const idx = Math.min(sorted.length - 1, Math.max(0, Math.floor((sorted.length - 1) * p)));
  return sorted[idx];
}

function assignFlameWidths(node: WasmFlameNode, startPct: number, parentTotalUs: number, rootTotalUs: number): void {
  node.startPct = Number(startPct.toFixed(3));
  node.widthPct = rootTotalUs > 0 ? Number(((node.totalUs / rootTotalUs) * 100).toFixed(3)) : 0;
  if (node.children.length === 0) return;

  const childSum = node.children.reduce((acc, c) => acc + c.totalUs, 0);
  const denom = Math.max(parentTotalUs, childSum, 0.0001);
  let cursor = startPct;
  for (const child of node.children) {
    const childWidth = (child.totalUs / denom) * node.widthPct;
    assignFlameWidths(child, cursor, child.totalUs, rootTotalUs);
    child.startPct = Number(cursor.toFixed(3));
    child.widthPct = Number(Math.max(0.4, childWidth).toFixed(3));
    cursor += childWidth;
  }
}

export async function profileWasmExecution(options: {
  content: string;
  moduleName?: string;
  sourcePath?: string;
  fnName?: string;
  args?: number[];
  iterations?: number;
}): Promise<{ ok: true; report: WasmProfileReport } | { ok: false; error: string }> {
  try {
    const trimmed = options.content.trim();
    let wasmPayload = options.content;
    let preferredFn = options.fnName;
    let inferredName = options.moduleName || 'module.wasm';

    if (trimmed.startsWith('{') && trimmed.includes('"ankaos-wasm-pkg-v1"')) {
      const pkg = JSON.parse(trimmed) as AnkaWasmPackageManifest;
      wasmPayload = pkg.wasmBase64;
      if (!preferredFn) preferredFn = pkg.entryFn;
      if (!options.moduleName) inferredName = `${pkg.name} v${pkg.version}`;
    }

    const tDec0 = nowUs();
    const bytes = decodeWasmBytes(wasmPayload);
    const decodeUs = roundUs(nowUs() - tDec0);

    const tVal0 = nowUs();
    const valid = bytes.length >= 8 && WebAssembly.validate(bytes);
    const validateUs = roundUs(nowUs() - tVal0);

    if (!valid) {
      return { ok: false, error: 'Geçersiz WebAssembly (\\0asm) ikili biçimi.' };
    }

    const dissection = dissectWasmBinary(bytes);

    const tComp0 = nowUs();
    const compiledModule = await WebAssembly.compile(bytes);
    const compileUs = roundUs(nowUs() - tComp0);

    const memoryRef: { current: WebAssembly.Memory | null } = { current: null };
    const wasi = createWasiPreview1Imports(memoryRef);

    const tInst0 = nowUs();
    const instance = await WebAssembly.instantiate(compiledModule, wasi.imports);
    const instantiateUs = roundUs(nowUs() - tInst0);

    const exportsObj = instance.exports as Record<string, unknown>;
    const memPreExport = Object.values(exportsObj).find((v) => v instanceof WebAssembly.Memory) as
      | WebAssembly.Memory
      | undefined;
    if (memPreExport) memoryRef.current = memPreExport;

    const exportedFuncs = Object.entries(exportsObj).filter(
      (entry): entry is [string, (...p: number[]) => number | bigint | undefined] =>
        typeof entry[1] === 'function'
    );

    const targetName =
      preferredFn ||
      (exportsObj._start
        ? '_start'
        : exportsObj.main
          ? 'main'
          : exportsObj.add
            ? 'add'
            : exportedFuncs[0]?.[0] || '');

    if (!targetName || typeof exportsObj[targetName] !== 'function') {
      return {
        ok: false,
        error: `Profil çıkarılacak dışa aktarılan fonksiyon bulunamadı (${targetName || 'yok'}).`,
      };
    }

    const targetFn = exportsObj[targetName] as (...p: number[]) => number | bigint | undefined;
    const arity = targetFn.length;
    const rawArgs = options.args && options.args.length > 0 ? options.args : [];
    const callArgs =
      rawArgs.length > 0
        ? rawArgs.slice(0, Math.max(arity, rawArgs.length))
        : arity === 2
          ? [19, 23]
          : arity === 1
            ? [12]
            : [];

    const invokeSafely = (): number | bigint | undefined => {
      try {
        return targetFn(...callArgs);
      } catch (err) {
        if (err instanceof WasiExitSignal) {
          return err.exitCode;
        }
        throw err;
      }
    };

    // Measure Cold Invocation
    const tCold0 = nowUs();
    const coldVal = invokeSafely();
    const coldCallUs = roundUs(nowUs() - tCold0);
    const firstStdout = wasi.getStdout().trim();

    // Measure Hot Iterations (batch inside micro-samples to overcome timer quantization)
    const iterations = Math.max(40, Math.min(5000, options.iterations ?? 300));
    const sampleBuckets = Math.min(48, Math.max(16, Math.floor(iterations / 6)));
    const callsPerBucket = Math.max(1, Math.floor(iterations / sampleBuckets));
    const timelineSamplesUs: number[] = [];

    // Warmup JIT briefly
    for (let w = 0; w < 16; w++) {
      invokeSafely();
    }

    for (let b = 0; b < sampleBuckets; b++) {
      const tb0 = nowUs();
      for (let c = 0; c < callsPerBucket; c++) {
        invokeSafely();
      }
      const elapsedBucket = Math.max(0.05, nowUs() - tb0);
      timelineSamplesUs.push(Number((elapsedBucket / callsPerBucket).toFixed(3)));
    }

    const sortedSamples = [...timelineSamplesUs].sort((a, b) => a - b);
    const hotAvgUs = roundUs(
      timelineSamplesUs.reduce((acc, v) => acc + v, 0) / Math.max(1, timelineSamplesUs.length)
    );
    const hotMinUs = roundUs(sortedSamples[0] ?? hotAvgUs);
    const hotP50Us = roundUs(percentile(sortedSamples, 0.5));
    const hotP95Us = roundUs(percentile(sortedSamples, 0.95));
    const hotMaxUs = roundUs(sortedSamples[sortedSamples.length - 1] ?? hotAvgUs);

    // Probe secondary exported functions lightly so multi-function modules show real comparative weights
    const measuredExportUs = new Map<string, number>();
    measuredExportUs.set(targetName, hotAvgUs);
    for (const [fnKey, fnRef] of exportedFuncs) {
      if (fnKey === targetName) continue;
      const fnArgs =
        fnRef.length === 2 ? [11, 17] : fnRef.length === 1 ? [10] : [];
      try {
        const tf0 = nowUs();
        for (let k = 0; k < 24; k++) fnRef(...fnArgs);
        measuredExportUs.set(fnKey, roundUs(Math.max(0.05, nowUs() - tf0) / 24));
      } catch {
        // Ignore exported helper needing specific memory pointers if it traps on [10]
        measuredExportUs.set(fnKey, 0.05);
      }
    }

    // Memory inspection
    let memoryPages = dissection.memoryInitialPages;
    let memoryUsedBytes = 0;
    const memExport = Object.values(exportsObj).find((v) => v instanceof WebAssembly.Memory) as
      | WebAssembly.Memory
      | undefined;
    if (memExport) {
      memoryPages = Math.max(1, Math.round(memExport.buffer.byteLength / 65536));
      const view = new Uint8Array(memExport.buffer, 0, Math.min(4096, memExport.buffer.byteLength));
      for (let i = 0; i < view.length; i++) {
        if (view[i] !== 0) memoryUsedBytes++;
      }
    }

    // Build function stats from disassembled Code bodies + runtime execution metrics
    const batchExecTotalUs = roundUs(hotAvgUs * iterations + coldCallUs);
    const totalPipelineUs = roundUs(
      decodeUs + validateUs + compileUs + instantiateUs + batchExecTotalUs
    );

    const execFrameShareBudget = Math.max(0.5, batchExecTotalUs);
    const targetBodyIdx = Array.from(dissection.exportedFuncNames.entries()).find(
      ([, name]) => name === targetName
    )?.[0];

    // Weight each function body by call-graph relevance & measured runtime
    const rawFnWeights = dissection.codeBodies.map((body) => {
      const expName = dissection.exportedFuncNames.get(body.index);
      const isEntry = body.index === targetBodyIdx || expName === targetName;
      const complexity = Math.max(
        1,
        body.instructionCount + body.loopCount * 14 + body.memoryOps * 4 + body.callOps * 3
      );
      const measured = expName ? measuredExportUs.get(expName) : undefined;
      const weight = isEntry
        ? complexity * 3.4 + (measured ?? hotAvgUs) * 10
        : (measured ?? 0.05) * 4 + complexity * 0.45;
      return { body, expName, isEntry, weight };
    });

    const sumWeight = rawFnWeights.reduce((acc, w) => acc + w.weight, 0) || 1;
    const functionStats: WasmFunctionStat[] = rawFnWeights
      .map((item) => {
        const expName = item.expName;
        const label = expName || `func_${item.body.index}`;
        const totalUs = roundUs((item.weight / sumWeight) * execFrameShareBudget);
        const childCallFraction = Math.min(0.42, item.body.callOps * 0.14);
        const selfUs = roundUs(totalUs * (1 - childCallFraction));
        return {
          index: item.body.index,
          name: label,
          exported: Boolean(expName),
          codeBytes: item.body.codeBytes,
          instructionCount: item.body.instructionCount,
          loopCount: item.body.loopCount,
          memoryOps: item.body.memoryOps,
          callOps: item.body.callOps,
          callees: item.body.callees,
          selfUs,
          totalUs,
          sharePct: Number(((totalUs / totalPipelineUs) * 100).toFixed(1)),
        };
      })
      .sort((a, b) => b.totalUs - a.totalUs);

    // Build Hierarchical Flamegraph Tree
    const fnStatByIdx = new Map(functionStats.map((s) => [s.index, s]));

    const buildCallSubtree = (
      fnIdx: number,
      budgetUs: number,
      depth: number,
      visited: Set<number>
    ): WasmFlameNode => {
      const stat = fnStatByIdx.get(fnIdx) || functionStats[0];
      const fnLabel = stat ? `${stat.name}()` : `func_${fnIdx}()`;
      const children: WasmFlameNode[] = [];

      if (stat && depth < 5) {
        // Sub-operations derived directly from disassembled bytecode
        const loopWeight = stat.loopCount * 5;
        const memWeight = stat.memoryOps * 3;
        const aluWeight = Math.max(1, stat.instructionCount - stat.loopCount - stat.memoryOps - stat.callOps);
        const calleeList = stat.callees.filter((c) => !visited.has(c) && fnStatByIdx.has(c));
        const callWeight = calleeList.length * 4;
        const totalParts = Math.max(1, loopWeight + memWeight + aluWeight + callWeight);

        if (loopWeight > 0) {
          children.push({
            id: `fn-${fnIdx}-loop-${depth}`,
            name: `loop_branch (${stat.loopCount}×)`,
            category: 'loop',
            depth: depth + 1,
            startPct: 0,
            widthPct: 0,
            totalUs: roundUs((loopWeight / totalParts) * budgetUs),
            selfUs: roundUs((loopWeight / totalParts) * budgetUs),
            calls: iterations * Math.max(1, stat.loopCount),
            opcodesSummary: 'loop / br / br_if',
            children: [],
          });
        }

        if (memWeight > 0) {
          children.push({
            id: `fn-${fnIdx}-mem-${depth}`,
            name: `linear_memory (${stat.memoryOps} ops)`,
            category: 'memory',
            depth: depth + 1,
            startPct: 0,
            widthPct: 0,
            totalUs: roundUs((memWeight / totalParts) * budgetUs),
            selfUs: roundUs((memWeight / totalParts) * budgetUs),
            calls: iterations * stat.memoryOps,
            opcodesSummary: 'i32.load / store',
            children: [],
          });
        }

        if (aluWeight > 0) {
          children.push({
            id: `fn-${fnIdx}-alu-${depth}`,
            name: `wasm_alu (${aluWeight} instr)`,
            category: 'alu',
            depth: depth + 1,
            startPct: 0,
            widthPct: 0,
            totalUs: roundUs((aluWeight / totalParts) * budgetUs),
            selfUs: roundUs((aluWeight / totalParts) * budgetUs),
            calls: iterations,
            opcodesSummary: 'i32 / f64 / local',
            children: [],
          });
        }

        for (const calleeIdx of calleeList) {
          const nextVisited = new Set(visited);
          nextVisited.add(calleeIdx);
          const calleeBudget = roundUs((4 / totalParts) * budgetUs);
          children.push(buildCallSubtree(calleeIdx, calleeBudget, depth + 1, nextVisited));
        }
      }

      const selfUs =
        children.length > 0
          ? roundUs(Math.max(0.02, budgetUs - children.reduce((s, c) => s + c.totalUs, 0)))
          : roundUs(budgetUs);

      return {
        id: `fn-${fnIdx}-${depth}`,
        name: fnLabel,
        category: 'function',
        depth,
        startPct: 0,
        widthPct: 0,
        totalUs: roundUs(budgetUs),
        selfUs,
        calls: iterations,
        codeBytes: stat?.codeBytes,
        opcodesSummary: stat
          ? `${stat.instructionCount} instr · ${stat.loopCount} loop · ${stat.memoryOps} mem`
          : undefined,
        children,
      };
    };

    const entryStat =
      functionStats.find((f) => f.name === targetName) ||
      functionStats[0];

    const execChildren: WasmFlameNode[] = [];
    if (entryStat) {
      const otherStats = functionStats.filter((f) => f.index !== entryStat.index);
      const otherSum = otherStats.reduce((s, o) => s + o.totalUs, 0);
      const entryBudget = Math.max(0.1, execFrameShareBudget - otherSum * 0.65);

      execChildren.push(
        buildCallSubtree(entryStat.index, entryBudget, 2, new Set([entryStat.index]))
      );

      for (const other of otherStats.slice(0, 5)) {
        execChildren.push(
          buildCallSubtree(other.index, roundUs(other.totalUs * 0.65), 2, new Set([other.index]))
        );
      }
    }

    const decodeValidateTotal = roundUs(decodeUs + validateUs);
    const compileInstantiateTotal = roundUs(compileUs + instantiateUs);

    const flameRoot: WasmFlameNode = {
      id: 'root',
      name: `AnkaWASM Runtime — ${inferredName}`,
      category: 'runtime',
      depth: 0,
      startPct: 0,
      widthPct: 100,
      totalUs: totalPipelineUs,
      selfUs: 0.05,
      calls: iterations + 1,
      opcodesSummary: `${bytes.length} B · ${functionStats.length} fn`,
      children: [
        {
          id: 'decode-validate',
          name: 'decode_and_validate',
          category: 'runtime',
          depth: 1,
          startPct: 0,
          widthPct: 0,
          totalUs: decodeValidateTotal,
          selfUs: 0.02,
          calls: 1,
          opcodesSummary: 'Base64 + WebAssembly.validate',
          children: [
            {
              id: 'decode',
              name: 'base64_decode',
              category: 'runtime',
              depth: 2,
              startPct: 0,
              widthPct: 0,
              totalUs: decodeUs,
              selfUs: decodeUs,
              calls: 1,
              children: [],
            },
            {
              id: 'validate',
              name: 'WebAssembly.validate',
              category: 'runtime',
              depth: 2,
              startPct: 0,
              widthPct: 0,
              totalUs: validateUs,
              selfUs: validateUs,
              calls: 1,
              children: [],
            },
          ],
        },
        {
          id: 'compile-instantiate',
          name: 'compile_instantiate',
          category: 'compile',
          depth: 1,
          startPct: 0,
          widthPct: 0,
          totalUs: compileInstantiateTotal,
          selfUs: 0.02,
          calls: 1,
          opcodesSummary: 'WebAssembly.compile + instantiate',
          children: [
            {
              id: 'compile',
              name: 'WebAssembly.compile',
              category: 'compile',
              depth: 2,
              startPct: 0,
              widthPct: 0,
              totalUs: compileUs,
              selfUs: compileUs,
              calls: 1,
              children: [],
            },
            {
              id: 'instantiate',
              name: 'WebAssembly.instantiate',
              category: 'compile',
              depth: 2,
              startPct: 0,
              widthPct: 0,
              totalUs: instantiateUs,
              selfUs: instantiateUs,
              calls: 1,
              children: [],
            },
          ],
        },
        {
          id: 'exec-stage',
          name: `wasmrun:${targetName}(${callArgs.join(', ')}) [${iterations}×]`,
          category: 'function',
          depth: 1,
          startPct: 0,
          widthPct: 0,
          totalUs: execFrameShareBudget,
          selfUs: roundUs(coldCallUs * 0.2),
          calls: iterations + 1,
          opcodesSummary: `Cold ${coldCallUs} µs · Avg ${hotAvgUs} µs`,
          children: execChildren,
        },
      ],
    };

    assignFlameWidths(flameRoot, 0, flameRoot.totalUs, flameRoot.totalUs);

    const opsPerSec = Math.round(1_000_000 / Math.max(0.05, hotAvgUs));

    return {
      ok: true,
      report: {
        schema: 'ankaos-wasm-profile-v1',
        createdAt: new Date().toISOString(),
        moduleName: inferredName,
        sourcePath: options.sourcePath,
        entryFn: targetName,
        args: callArgs,
        resultText: firstStdout
          ? `${String(coldVal ?? 'void')} · stdout: "${firstStdout.slice(0, 64)}"`
          : String(coldVal),
        iterations,
        byteLength: bytes.length,
        memoryPages,
        memoryUsedBytes,
        metrics: {
          decodeUs,
          validateUs,
          compileUs,
          instantiateUs,
          coldCallUs,
          hotAvgUs,
          hotMinUs,
          hotP50Us,
          hotP95Us,
          hotMaxUs,
          totalPipelineUs,
          opsPerSec,
        },
        sections: dissection.sections,
        functionStats,
        timelineSamplesUs,
        flameRoot,
      },
    };
  } catch (err) {
    return {
      ok: false,
      error: err instanceof Error ? err.message : String(err),
    };
  }
}

export function formatDurationUs(us: number): string {
  if (us >= 1000) return `${(us / 1000).toFixed(2)} ms`;
  return `${us.toFixed(2)} µs`;
}

export function renderAsciiFlameSummary(report: WasmProfileReport): string {
  const lines: string[] = [];
  lines.push(
    `[AnkaWASM Profiler] ${report.moduleName} -> ${report.entryFn}(${report.args.join(', ')}) = ${report.resultText}`
  );
  lines.push(
    `  Pipeline: ${formatDurationUs(report.metrics.totalPipelineUs)} | Decode: ${formatDurationUs(
      report.metrics.decodeUs + report.metrics.validateUs
    )} | Compile+Inst: ${formatDurationUs(
      report.metrics.compileUs + report.metrics.instantiateUs
    )}`
  );
  lines.push(
    `  Warm (${report.iterations}×): avg=${formatDurationUs(report.metrics.hotAvgUs)} p95=${formatDurationUs(
      report.metrics.hotP95Us
    )} (${report.metrics.opsPerSec.toLocaleString('tr-TR')} ops/s)`
  );
  lines.push('  Hotspot Dagilimi (Flame):');
  for (const fn of report.functionStats.slice(0, 5)) {
    const barCount = Math.max(1, Math.min(24, Math.round((fn.sharePct / 100) * 24)));
    const bar = '#'.repeat(barCount).padEnd(24, '.');
    lines.push(
      `    ${fn.name.padEnd(16)} [${bar}] ${String(fn.sharePct).padStart(5)}%  ${formatDurationUs(
        fn.totalUs
      )} (${fn.instructionCount} instr, ${fn.loopCount} loop)`
    );
  }
  return lines.join('\n');
}
