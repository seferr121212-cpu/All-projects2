/**
 * AnkaOS Ring 3 Isolated Execution Runtime
 * 1) Web Worker JavaScript Sandbox with Watchdog termination (prevents UI freeze & DOM/storage access)
 * 2) Real WebAssembly (.wasm) binary decoder & executor via WebAssembly.instantiate
 */

export const WASM_B64_PREFIX = '__WASM_B64__:';

export interface SandboxJSResult {
  ok: boolean;
  logs: string[];
  durationMs: number;
  timedOut?: boolean;
  killed?: boolean;
  runtime: 'web-worker' | 'node-fallback';
  error?: string;
}

export interface WasmRunResult {
  ok: boolean;
  exportsList: string[];
  invoked?: { fn: string; args: number[]; result: number | bigint | undefined };
  stdoutText?: string;
  wasiExitCode?: number;
  durationMs: number;
  byteLength: number;
  error?: string;
}

export class WasiExitSignal extends Error {
  exitCode: number;
  constructor(code: number) {
    super(`WASI proc_exit(${code})`);
    this.exitCode = code;
  }
}

export function createWasiPreview1Imports(
  memoryRef: { current: WebAssembly.Memory | null },
  options?: {
    args?: string[];
    env?: Record<string, string>;
    onStdout?: (chunk: string) => void;
    onStderr?: (chunk: string) => void;
  }
) {
  const decoder = new TextDecoder('utf-8', { fatal: false });
  const encoder = new TextEncoder();
  const stdoutParts: string[] = [];
  const stderrParts: string[] = [];
  const argv = options?.args && options.args.length > 0 ? options.args : ['ankaos-wasm'];
  const envEntries = Object.entries(options?.env || { OS: 'AnkaOS', SHELL: '/bin/ankash' }).map(
    ([k, v]) => `${k}=${v}`
  );

  const getView = (): DataView | null => {
    const mem = memoryRef.current;
    return mem ? new DataView(mem.buffer) : null;
  };
  const getU8 = (): Uint8Array | null => {
    const mem = memoryRef.current;
    return mem ? new Uint8Array(mem.buffer) : null;
  };

  const api = {
    fd_write(fd: number, iovsPtr: number, iovsLen: number, nwrittenPtr: number): number {
      const view = getView();
      const u8 = getU8();
      if (!view || !u8) return 8; // EBADF
      let written = 0;
      for (let i = 0; i < iovsLen; i++) {
        const ptr = view.getUint32(iovsPtr + i * 8, true);
        const len = view.getUint32(iovsPtr + i * 8 + 4, true);
        if (len > 0 && ptr + len <= u8.byteLength) {
          const text = decoder.decode(u8.subarray(ptr, ptr + len));
          if (fd === 1) {
            stdoutParts.push(text);
            options?.onStdout?.(text);
          } else if (fd === 2) {
            stderrParts.push(text);
            options?.onStderr?.(text);
          }
          written += len;
        }
      }
      view.setUint32(nwrittenPtr, written, true);
      return 0;
    },
    fd_read(_fd: number, _iovsPtr: number, _iovsLen: number, nreadPtr: number): number {
      const view = getView();
      if (view) view.setUint32(nreadPtr, 0, true);
      return 0;
    },
    fd_close(): number {
      return 0;
    },
    fd_seek(_fd: number, _offset: bigint, _whence: number, newOffsetPtr: number): number {
      const view = getView();
      if (view && newOffsetPtr + 8 <= view.byteLength) {
        view.setBigUint64(newOffsetPtr, 0n, true);
      }
      return 0;
    },
    fd_fdstat_get(fd: number, bufPtr: number): number {
      const view = getView();
      if (!view) return 8;
      if (fd > 2) return 8;
      view.setUint8(bufPtr, 2); // filetype character device
      view.setUint16(bufPtr + 2, 0, true);
      view.setBigUint64(bufPtr + 8, 0xffffn, true);
      view.setBigUint64(bufPtr + 16, 0xffffn, true);
      return 0;
    },
    fd_prestat_get(): number {
      return 8; // EBADF (no preopened dirs)
    },
    fd_prestat_dir_name(): number {
      return 8;
    },
    args_sizes_get(argcPtr: number, argvBufSizePtr: number): number {
      const view = getView();
      if (!view) return 0;
      view.setUint32(argcPtr, argv.length, true);
      const total = argv.reduce((sum, a) => sum + encoder.encode(a).length + 1, 0);
      view.setUint32(argvBufSizePtr, total, true);
      return 0;
    },
    args_get(argvPtr: number, argvBufPtr: number): number {
      const view = getView();
      const u8 = getU8();
      if (!view || !u8) return 0;
      let bufOffset = argvBufPtr;
      for (let i = 0; i < argv.length; i++) {
        view.setUint32(argvPtr + i * 4, bufOffset, true);
        const bytes = encoder.encode(argv[i]);
        u8.set(bytes, bufOffset);
        u8[bufOffset + bytes.length] = 0;
        bufOffset += bytes.length + 1;
      }
      return 0;
    },
    environ_sizes_get(countPtr: number, bufSizePtr: number): number {
      const view = getView();
      if (!view) return 0;
      view.setUint32(countPtr, envEntries.length, true);
      const total = envEntries.reduce((sum, e) => sum + encoder.encode(e).length + 1, 0);
      view.setUint32(bufSizePtr, total, true);
      return 0;
    },
    environ_get(environPtr: number, environBufPtr: number): number {
      const view = getView();
      const u8 = getU8();
      if (!view || !u8) return 0;
      let bufOffset = environBufPtr;
      for (let i = 0; i < envEntries.length; i++) {
        view.setUint32(environPtr + i * 4, bufOffset, true);
        const bytes = encoder.encode(envEntries[i]);
        u8.set(bytes, bufOffset);
        u8[bufOffset + bytes.length] = 0;
        bufOffset += bytes.length + 1;
      }
      return 0;
    },
    clock_time_get(_id: number, _precision: bigint, timePtr: number): number {
      const view = getView();
      if (view) {
        view.setBigUint64(timePtr, BigInt(Date.now()) * 1_000_000n, true);
      }
      return 0;
    },
    clock_res_get(_id: number, resPtr: number): number {
      const view = getView();
      if (view) view.setBigUint64(resPtr, 1_000_000n, true);
      return 0;
    },
    random_get(bufPtr: number, bufLen: number): number {
      const u8 = getU8();
      if (!u8 || bufLen <= 0) return 0;
      const tmp = new Uint8Array(bufLen);
      if (typeof crypto !== 'undefined' && crypto.getRandomValues) {
        crypto.getRandomValues(tmp);
      } else {
        for (let i = 0; i < tmp.length; i++) tmp[i] = Math.floor(Math.random() * 256);
      }
      u8.set(tmp, bufPtr);
      return 0;
    },
    proc_exit(code: number): never {
      throw new WasiExitSignal(code);
    },
  };

  return {
    imports: {
      wasi_snapshot_preview1: api,
      wasi_unstable: api,
      env: {
        abort: () => {
          throw new Error('WASM abort() çağrıldı');
        },
      },
    },
    getStdout: () => stdoutParts.join(''),
    getStderr: () => stderrParts.join(''),
  };
}

function bytesToBase64(bytes: Uint8Array): string {
  if (typeof Buffer !== 'undefined') {
    return Buffer.from(bytes).toString('base64');
  }
  let bin = '';
  for (let i = 0; i < bytes.length; i++) {
    bin += String.fromCharCode(bytes[i]);
  }
  return btoa(bin);
}

function base64ToBytes(b64: string): Uint8Array<ArrayBuffer> {
  const clean = b64.trim();
  if (typeof Buffer !== 'undefined') {
    const buf = Buffer.from(clean, 'base64');
    const out = new Uint8Array(new ArrayBuffer(buf.length));
    out.set(buf);
    return out;
  }
  const bin = atob(clean);
  const out = new Uint8Array(new ArrayBuffer(bin.length));
  for (let i = 0; i < bin.length; i++) {
    out[i] = bin.charCodeAt(i);
  }
  return out;
}

function pushTextBytes(arr: number[], str: string): void {
  arr.push(str.length);
  for (let i = 0; i < str.length; i++) {
    arr.push(str.charCodeAt(i));
  }
}

function wrapSection(id: number, payload: number[]): number[] {
  // Assumes payload length < 128 bytes (single-byte ULEB128)
  return [id, payload.length, ...payload];
}

/**
 * Generates a real, spec-compliant WebAssembly binary module exporting:
 * - add(i32, i32) -> i32
 * - square(i32) -> i32
 * - sub(i32, i32) -> i32
 */
export function buildSampleMathWasmBytes(): Uint8Array<ArrayBuffer> {
  const magicAndVersion = [0x00, 0x61, 0x73, 0x6d, 0x01, 0x00, 0x00, 0x00];

  // Type section: 2 signatures
  // type 0: (i32, i32) -> i32
  // type 1: (i32) -> i32
  const typeSection = wrapSection(1, [
    2,
    0x60, 2, 0x7f, 0x7f, 1, 0x7f,
    0x60, 1, 0x7f, 1, 0x7f,
  ]);

  // Function section: 3 functions using type indices [0, 1, 0]
  const funcSection = wrapSection(3, [3, 0, 1, 0]);

  // Export section: "add"->0, "square"->1, "sub"->2
  const exportPayload: number[] = [3];
  pushTextBytes(exportPayload, 'add');
  exportPayload.push(0x00, 0);
  pushTextBytes(exportPayload, 'square');
  exportPayload.push(0x00, 1);
  pushTextBytes(exportPayload, 'sub');
  exportPayload.push(0x00, 2);
  const exportSection = wrapSection(7, exportPayload);

  // Code section: 3 function bodies (each with 0 local declarations)
  const addBody = [0x00, 0x20, 0x00, 0x20, 0x01, 0x6a, 0x0b]; // local.get 0; local.get 1; i32.add; end
  const squareBody = [0x00, 0x20, 0x00, 0x20, 0x00, 0x6c, 0x0b]; // local.get 0; local.get 0; i32.mul; end
  const subBody = [0x00, 0x20, 0x00, 0x20, 0x01, 0x6b, 0x0b]; // local.get 0; local.get 1; i32.sub; end
  const codeSection = wrapSection(10, [
    3,
    addBody.length, ...addBody,
    squareBody.length, ...squareBody,
    subBody.length, ...subBody,
  ]);

  const raw = [
    ...magicAndVersion,
    ...typeSection,
    ...funcSection,
    ...exportSection,
    ...codeSection,
  ];
  const out = new Uint8Array(new ArrayBuffer(raw.length));
  out.set(raw);
  return out;
}

export function buildSampleMathWasmContent(): string {
  return `${WASM_B64_PREFIX}${bytesToBase64(buildSampleMathWasmBytes())}`;
}

export function decodeWasmBytes(content: string): Uint8Array<ArrayBuffer> {
  if (content.startsWith(WASM_B64_PREFIX)) {
    return base64ToBytes(content.slice(WASM_B64_PREFIX.length));
  }
  if (content.startsWith('data:application/wasm;base64,')) {
    return base64ToBytes(content.slice('data:application/wasm;base64,'.length));
  }
  // Check raw binary string starting with \0asm
  if (content.startsWith('\u0000asm')) {
    const out = new Uint8Array(new ArrayBuffer(content.length));
    for (let i = 0; i < content.length; i++) out[i] = content.charCodeAt(i) & 0xff;
    return out;
  }
  // Try plain base64 fallback
  try {
    const candidate = base64ToBytes(content);
    if (candidate.length >= 8 && candidate[0] === 0x00 && candidate[1] === 0x61) {
      return candidate;
    }
  } catch {
    // fallback below
  }
  const encoded = new TextEncoder().encode(content);
  const out = new Uint8Array(new ArrayBuffer(encoded.length));
  out.set(encoded);
  return out;
}

export async function runWasmBinary(
  content: string,
  fnName?: string,
  args: number[] = []
): Promise<WasmRunResult> {
  const start = Date.now();
  try {
    const bytes = decodeWasmBytes(content);
    if (bytes.length < 8 || !WebAssembly.validate(bytes)) {
      return {
        ok: false,
        exportsList: [],
        durationMs: Date.now() - start,
        byteLength: bytes.length,
        error: 'Geçersiz WebAssembly (\\0asm) ikili biçimi.',
      };
    }

    const memoryRef: { current: WebAssembly.Memory | null } = { current: null };
    const wasi = createWasiPreview1Imports(memoryRef, {
      args: ['ankaos-wasm', ...args.map(String)],
    });

    const instantiated = (await WebAssembly.instantiate(bytes, wasi.imports)) as unknown as WebAssembly.WebAssemblyInstantiatedSource;
    const exportsObj = instantiated.instance.exports as Record<string, unknown>;
    const exportedMem = Object.values(exportsObj).find((v) => v instanceof WebAssembly.Memory) as
      | WebAssembly.Memory
      | undefined;
    if (exportedMem) memoryRef.current = exportedMem;

    const fnNames = Object.entries(exportsObj)
      .filter(([, val]) => typeof val === 'function')
      .map(([k]) => k);

    let invoked: WasmRunResult['invoked'];
    let wasiExitCode: number | undefined;
    const targetFn =
      fnName ||
      (fnNames.includes('_start')
        ? '_start'
        : fnNames.includes('main')
          ? 'main'
          : fnNames.includes('add')
            ? 'add'
            : fnNames[0]);

    if (targetFn) {
      const fn = exportsObj[targetFn];
      if (typeof fn !== 'function') {
        return {
          ok: false,
          exportsList: fnNames,
          durationMs: Date.now() - start,
          byteLength: bytes.length,
          error: `Dışa aktarılan fonksiyon bulunamadı: ${targetFn} (Mevcut: ${fnNames.join(', ') || 'yok'})`,
        };
      }
      const expectedArity = fn.length;
      const callArgs =
        args.length > 0
          ? args.slice(0, Math.max(expectedArity, args.length))
          : expectedArity === 2
            ? [19, 23]
            : expectedArity === 1
              ? [7]
              : [];
      try {
        const result = (fn as (...params: number[]) => number | bigint | undefined)(...callArgs);
        invoked = { fn: targetFn, args: callArgs, result };
      } catch (callErr) {
        if (callErr instanceof WasiExitSignal) {
          wasiExitCode = callErr.exitCode;
          invoked = { fn: targetFn, args: callArgs, result: callErr.exitCode };
          if (callErr.exitCode !== 0) {
            return {
              ok: false,
              exportsList: fnNames,
              invoked,
              stdoutText: wasi.getStdout() || undefined,
              wasiExitCode,
              durationMs: Date.now() - start,
              byteLength: bytes.length,
              error: `WASI süreç çıkışı: kod ${callErr.exitCode}`,
            };
          }
        } else {
          throw callErr;
        }
      }
    }

    const stdoutCombined = [wasi.getStdout(), wasi.getStderr()].filter(Boolean).join('');
    return {
      ok: true,
      exportsList: fnNames,
      invoked,
      stdoutText: stdoutCombined || undefined,
      wasiExitCode,
      durationMs: Date.now() - start,
      byteLength: bytes.length,
    };
  } catch (err) {
    return {
      ok: false,
      exportsList: [],
      durationMs: Date.now() - start,
      byteLength: 0,
      error: err instanceof Error ? err.message : String(err),
    };
  }
}

const WORKER_BOOTSTRAP_SOURCE = `
self.onmessage = function(e) {
  var code = e.data && e.data.code ? String(e.data.code) : '';
  var logCount = 0;
  function sendLog(prefix, args) {
    if (logCount >= 400) {
      if (logCount === 400) {
        logCount++;
        self.postMessage({ type: 'log', text: '[UYARI] Çıktı sınırı (400 satır) aşıldı.' });
      }
      return;
    }
    logCount++;
    var msg = [];
    for (var i = 0; i < args.length; i++) {
      try {
        msg.push(typeof args[i] === 'object' ? JSON.stringify(args[i]) : String(args[i]));
      } catch (err) {
        msg.push(String(args[i]));
      }
    }
    self.postMessage({ type: 'log', text: prefix + msg.join(' ') });
  }
  var sandboxConsole = {
    log: function() { sendLog('', arguments); },
    info: function() { sendLog('', arguments); },
    warn: function() { sendLog('[UYARI] ', arguments); },
    error: function() { sendLog('[HATA] ', arguments); }
  };
  try {
    // Ring 3 Global Isolation: Shadow host/network/storage APIs inside strict scope
    var runner = new Function(
      'console',
      'window',
      'document',
      'localStorage',
      'sessionStorage',
      'indexedDB',
      'fetch',
      'XMLHttpRequest',
      'WebSocket',
      'importScripts',
      'Worker',
      'self',
      'globalThis',
      '"use strict";\\n' + code
    );
    runner(
      sandboxConsole,
      undefined,
      undefined,
      undefined,
      undefined,
      undefined,
      undefined,
      undefined,
      undefined,
      undefined,
      undefined,
      undefined,
      undefined
    );
    self.postMessage({ type: 'done' });
  } catch (err) {
    self.postMessage({
      type: 'error',
      error: err && err.message ? err.message : String(err)
    });
  }
};
`;

export function executeSandboxedJS(
  code: string,
  options?: { timeoutMs?: number; onLog?: (line: string) => void }
): { promise: Promise<SandboxJSResult>; abort: () => void } {
  const timeoutMs = options?.timeoutMs ?? 2000;
  const start = Date.now();
  const logs: string[] = [];

  if (typeof Worker === 'undefined' || typeof Blob === 'undefined' || typeof URL === 'undefined') {
    // Headless Node test fallback
    let aborted = false;
    const promise = (async (): Promise<SandboxJSResult> => {
      if (aborted) {
        return {
          ok: false,
          logs,
          durationMs: Date.now() - start,
          killed: true,
          runtime: 'node-fallback',
          error: 'SIGKILL ile durduruldu',
        };
      }
      const sandboxConsole = {
        log: (...vals: unknown[]) => {
          const line = vals.map(String).join(' ');
          logs.push(line);
          options?.onLog?.(line);
        },
        info: (...vals: unknown[]) => {
          const line = vals.map(String).join(' ');
          logs.push(line);
          options?.onLog?.(line);
        },
        warn: (...vals: unknown[]) => {
          const line = `[UYARI] ${vals.map(String).join(' ')}`;
          logs.push(line);
          options?.onLog?.(line);
        },
        error: (...vals: unknown[]) => {
          const line = `[HATA] ${vals.map(String).join(' ')}`;
          logs.push(line);
          options?.onLog?.(line);
        },
      };
      try {
        const fn = new Function(
          'console',
          'window',
          'document',
          'localStorage',
          'sessionStorage',
          'indexedDB',
          'fetch',
          'XMLHttpRequest',
          'WebSocket',
          'importScripts',
          'Worker',
          'self',
          'globalThis',
          `"use strict";\n${code}`
        );
        fn(
          sandboxConsole,
          undefined,
          undefined,
          undefined,
          undefined,
          undefined,
          undefined,
          undefined,
          undefined,
          undefined,
          undefined,
          undefined,
          undefined
        );
        return {
          ok: true,
          logs,
          durationMs: Date.now() - start,
          runtime: 'node-fallback',
        };
      } catch (err) {
        return {
          ok: false,
          logs,
          durationMs: Date.now() - start,
          runtime: 'node-fallback',
          error: err instanceof Error ? err.message : String(err),
        };
      }
    })();
    return {
      promise,
      abort: () => {
        aborted = true;
      },
    };
  }

  let worker: Worker | null = null;
  let blobUrl: string | null = null;
  let timer: ReturnType<typeof setTimeout> | null = null;
  let settled = false;
  let resolvePromise!: (res: SandboxJSResult) => void;

  const cleanup = () => {
    if (timer !== null) {
      clearTimeout(timer);
      timer = null;
    }
    if (worker) {
      worker.terminate();
      worker = null;
    }
    if (blobUrl) {
      URL.revokeObjectURL(blobUrl);
      blobUrl = null;
    }
  };

  const promise = new Promise<SandboxJSResult>((resolve) => {
    resolvePromise = resolve;
    try {
      const blob = new Blob([WORKER_BOOTSTRAP_SOURCE], { type: 'application/javascript' });
      blobUrl = URL.createObjectURL(blob);
      worker = new Worker(blobUrl);

      worker.onmessage = (ev: MessageEvent<{ type: string; text?: string; error?: string }>) => {
        if (settled) return;
        const msg = ev.data;
        if (msg.type === 'log' && typeof msg.text === 'string') {
          logs.push(msg.text);
          options?.onLog?.(msg.text);
          return;
        }
        if (msg.type === 'done') {
          settled = true;
          cleanup();
          resolve({
            ok: true,
            logs,
            durationMs: Date.now() - start,
            runtime: 'web-worker',
          });
          return;
        }
        if (msg.type === 'error') {
          settled = true;
          cleanup();
          resolve({
            ok: false,
            logs,
            durationMs: Date.now() - start,
            runtime: 'web-worker',
            error: msg.error || 'Bilinmeyen çalışma hatası',
          });
        }
      };

      worker.onerror = (ev) => {
        if (settled) return;
        settled = true;
        cleanup();
        resolve({
          ok: false,
          logs,
          durationMs: Date.now() - start,
          runtime: 'web-worker',
          error: ev.message || 'Worker sözdizimi/çalışma hatası',
        });
      };

      timer = setTimeout(() => {
        if (settled) return;
        settled = true;
        cleanup();
        resolve({
          ok: false,
          logs,
          durationMs: Date.now() - start,
          timedOut: true,
          killed: true,
          runtime: 'web-worker',
          error: `WATCHDOG SIGKILL: Çalışma süresi sınırı (${timeoutMs} ms) aşıldı (olası sonsuz döngü sonlandırıldı).`,
        });
      }, timeoutMs);

      worker.postMessage({ code });
    } catch (err) {
      if (!settled) {
        settled = true;
        cleanup();
        resolve({
          ok: false,
          logs,
          durationMs: Date.now() - start,
          runtime: 'web-worker',
          error: err instanceof Error ? err.message : String(err),
        });
      }
    }
  });

  const abort = () => {
    if (settled) return;
    settled = true;
    cleanup();
    resolvePromise({
      ok: false,
      logs,
      durationMs: Date.now() - start,
      killed: true,
      runtime: 'web-worker',
      error: 'Kullanıcı tarafından SIGKILL ile durduruldu.',
    });
  };

  return { promise, abort };
}
