import { AccentColor, ThemeMode } from './types';

export interface ThemePalette {
  mode: ThemeMode;
  bg: string;
  surface: string;
  surfaceMuted: string;
  surfaceElevated: string;
  titlebar: string;
  glass: string;
  border: string;
  borderStrong: string;
  text: string;
  textMuted: string;
  textSubtle: string;
  terminalBg: string;
  terminalFg: string;
  terminalMuted: string;
  terminalBorder: string;
  accent: string;
}

export interface AccentSpec {
  id: AccentColor;
  labelTr: string;
  labelEn: string;
  light: { hex: string; hover: string; soft: string };
  dark: { hex: string; hover: string; soft: string };
}

export const ACCENT_PALETTES: Record<AccentColor, AccentSpec> = {
  sky: {
    id: 'sky',
    labelTr: 'Gök Mavisi',
    labelEn: 'Sky Blue',
    light: { hex: '#0284c7', hover: '#0369a1', soft: 'rgba(2, 132, 199, 0.12)' },
    dark: { hex: '#0ea5e9', hover: '#38bdf8', soft: 'rgba(14, 165, 233, 0.16)' },
  },
  emerald: {
    id: 'emerald',
    labelTr: 'Zümrüt Yeşili',
    labelEn: 'Emerald',
    light: { hex: '#059669', hover: '#047857', soft: 'rgba(5, 150, 105, 0.14)' },
    dark: { hex: '#10b981', hover: '#34d399', soft: 'rgba(16, 185, 129, 0.16)' },
  },
  amber: {
    id: 'amber',
    labelTr: 'Kehribar',
    labelEn: 'Amber',
    light: { hex: '#d97706', hover: '#b45309', soft: 'rgba(217, 119, 6, 0.14)' },
    dark: { hex: '#f59e0b', hover: '#fbbf24', soft: 'rgba(245, 158, 11, 0.16)' },
  },
  rose: {
    id: 'rose',
    labelTr: 'Yakut Gül',
    labelEn: 'Ruby Rose',
    light: { hex: '#e11d48', hover: '#be123c', soft: 'rgba(225, 29, 72, 0.14)' },
    dark: { hex: '#f43f5e', hover: '#fb7185', soft: 'rgba(244, 63, 94, 0.16)' },
  },
  slate: {
    id: 'slate',
    labelTr: 'Grafit',
    labelEn: 'Graphite',
    light: { hex: '#334155', hover: '#1e293b', soft: 'rgba(51, 65, 85, 0.14)' },
    dark: { hex: '#64748b', hover: '#94a3b8', soft: 'rgba(148, 163, 184, 0.18)' },
  },
};

/**
 * Tekil sistem yapılandırma paleti: Tüm Karanlık Mod / Aydınlık Mod renk değişkenleri
 * merkezi olarak buradan yönetilir ve kök belgeye CSS token'ları olarak enjekte edilir.
 */
export const THEME_PALETTES: Record<ThemeMode, ThemePalette> = {
  dark: {
    mode: 'dark',
    bg: '#020617',
    surface: '#0f172a',
    surfaceMuted: '#0b1222',
    surfaceElevated: '#1e293b',
    titlebar: 'rgba(15, 23, 42, 0.95)',
    glass: 'rgba(15, 23, 42, 0.86)',
    border: '#1e293b',
    borderStrong: '#334155',
    text: '#f8fafc',
    textMuted: '#cbd5e1',
    textSubtle: '#94a3b8',
    terminalBg: '#020617',
    terminalFg: '#f1f5f9',
    terminalMuted: '#94a3b8',
    terminalBorder: '#1e293b',
    accent: '#0ea5e9',
  },
  light: {
    mode: 'light',
    bg: '#f1f5f9',
    surface: '#ffffff',
    surfaceMuted: '#f8fafc',
    surfaceElevated: '#e2e8f0',
    titlebar: 'rgba(248, 250, 252, 0.92)',
    glass: 'rgba(255, 255, 255, 0.84)',
    border: '#e2e8f0',
    borderStrong: '#cbd5e1',
    text: '#0f172a',
    textMuted: '#475569',
    textSubtle: '#64748b',
    terminalBg: '#f8fafc',
    terminalFg: '#0f172a',
    terminalMuted: '#475569',
    terminalBorder: '#e2e8f0',
    accent: '#0284c7',
  },
};

// Tek global yapılandırma değişkenleri üzerinden aktif tema paleti & vurgu rengi seçilir
export let ACTIVE_THEME_CONFIG: ThemeMode = 'dark';
export let ACTIVE_ACCENT_CONFIG: AccentColor = 'sky';

export function applyThemePalette(
  mode: ThemeMode,
  accent: AccentColor = ACTIVE_ACCENT_CONFIG
): ThemePalette {
  const safeMode: ThemeMode = mode === 'light' ? 'light' : 'dark';
  const safeAccent: AccentColor = accent in ACCENT_PALETTES ? accent : 'sky';

  ACTIVE_THEME_CONFIG = safeMode;
  ACTIVE_ACCENT_CONFIG = safeAccent;

  const palette = THEME_PALETTES[safeMode];
  const accentSpec = ACCENT_PALETTES[safeAccent][safeMode];

  if (typeof document !== 'undefined') {
    const root = document.documentElement;
    if (safeMode === 'dark') {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }
    root.dataset.theme = safeMode;
    root.dataset.accent = safeAccent;
    root.style.colorScheme = safeMode;

    root.style.setProperty('--anka-bg', palette.bg);
    root.style.setProperty('--anka-surface', palette.surface);
    root.style.setProperty('--anka-surface-muted', palette.surfaceMuted);
    root.style.setProperty('--anka-surface-elevated', palette.surfaceElevated);
    root.style.setProperty('--anka-titlebar', palette.titlebar);
    root.style.setProperty('--anka-glass', palette.glass);
    root.style.setProperty('--anka-border', palette.border);
    root.style.setProperty('--anka-border-strong', palette.borderStrong);
    root.style.setProperty('--anka-text', palette.text);
    root.style.setProperty('--anka-text-muted', palette.textMuted);
    root.style.setProperty('--anka-text-subtle', palette.textSubtle);
    root.style.setProperty('--anka-terminal-bg', palette.terminalBg);
    root.style.setProperty('--anka-terminal-fg', palette.terminalFg);
    root.style.setProperty('--anka-terminal-muted', palette.terminalMuted);
    root.style.setProperty('--anka-terminal-border', palette.terminalBorder);
    root.style.setProperty('--anka-accent', accentSpec.hex);
    root.style.setProperty('--anka-accent-hover', accentSpec.hover);
    root.style.setProperty('--anka-accent-soft', accentSpec.soft);
  }

  return {
    ...palette,
    accent: accentSpec.hex,
  };
}

export function hydrateThemeFromStorage(storageKey = 'ankaos_settings_v2'): {
  theme: ThemeMode;
  accent: AccentColor;
} {
  try {
    if (typeof localStorage !== 'undefined') {
      const raw = localStorage.getItem(storageKey);
      if (raw) {
        const parsed = JSON.parse(raw) as { theme?: unknown; accent?: unknown };
        const theme: ThemeMode = parsed.theme === 'light' ? 'light' : 'dark';
        const accent: AccentColor =
          typeof parsed.accent === 'string' && parsed.accent in ACCENT_PALETTES
            ? (parsed.accent as AccentColor)
            : 'sky';
        applyThemePalette(theme, accent);
        return { theme, accent };
      }
    }
  } catch {
    // ignore storage errors
  }
  applyThemePalette('dark', 'sky');
  return { theme: 'dark', accent: 'sky' };
}
