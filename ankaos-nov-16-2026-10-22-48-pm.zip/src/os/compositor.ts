import { OSWindow, WindowSnap, WorkspaceId } from './types';

export interface WindowRect {
  x: number;
  y: number;
  width: number;
  height: number;
  zIndex: number;
}

export interface CompositorSurface {
  windowId: string;
  appId: OSWindow['appId'];
  workspace: WorkspaceId;
  rect: WindowRect;
  snap: WindowSnap;
  visible: boolean;
}

export interface CompositorBufferSnapshot {
  frameId: number;
  swapTimestamp: number;
  vsyncHz: number;
  surfaces: CompositorSurface[];
}

export const TOP_BAR_HEIGHT = 36;
export const DOCK_RESERVED_HEIGHT = 76;

/**
 * Computes exact pixel coordinates for a window according to its snap mode
 * and active virtual workspace viewport dimensions.
 */
export function computeWindowRect(
  win: Pick<OSWindow, 'x' | 'y' | 'width' | 'height' | 'snap' | 'zIndex'>,
  viewportW = 1280,
  viewportH = 800
): WindowRect {
  const usableTop = TOP_BAR_HEIGHT + 4;
  const usableHeight = Math.max(240, viewportH - TOP_BAR_HEIGHT - DOCK_RESERVED_HEIGHT - 8);
  const halfW = Math.floor(viewportW / 2);
  const halfH = Math.floor((usableHeight - 6) / 2);

  if (win.snap === 'maximized') {
    return {
      x: 0,
      y: TOP_BAR_HEIGHT,
      width: viewportW,
      height: Math.max(240, viewportH - TOP_BAR_HEIGHT - DOCK_RESERVED_HEIGHT),
      zIndex: win.zIndex,
    };
  }
  if (win.snap === 'left') {
    return {
      x: 8,
      y: usableTop,
      width: Math.max(300, halfW - 12),
      height: usableHeight,
      zIndex: win.zIndex,
    };
  }
  if (win.snap === 'right') {
    return {
      x: halfW + 4,
      y: usableTop,
      width: Math.max(300, viewportW - halfW - 12),
      height: usableHeight,
      zIndex: win.zIndex,
    };
  }
  if (win.snap === 'top-left') {
    return {
      x: 8,
      y: usableTop,
      width: Math.max(280, halfW - 12),
      height: Math.max(180, halfH),
      zIndex: win.zIndex,
    };
  }
  if (win.snap === 'top-right') {
    return {
      x: halfW + 4,
      y: usableTop,
      width: Math.max(280, viewportW - halfW - 12),
      height: Math.max(180, halfH),
      zIndex: win.zIndex,
    };
  }
  if (win.snap === 'bottom-left') {
    return {
      x: 8,
      y: usableTop + halfH + 6,
      width: Math.max(280, halfW - 12),
      height: Math.max(180, usableHeight - halfH - 6),
      zIndex: win.zIndex,
    };
  }
  if (win.snap === 'bottom-right') {
    return {
      x: halfW + 4,
      y: usableTop + halfH + 6,
      width: Math.max(280, viewportW - halfW - 12),
      height: Math.max(180, usableHeight - halfH - 6),
      zIndex: win.zIndex,
    };
  }
  return {
    x: win.x,
    y: win.y,
    width: win.width,
    height: win.height,
    zIndex: win.zIndex,
  };
}

/**
 * Detects pointer proximity to screen corners and edges for interactive Window Snapping.
 */
export function detectEdgeSnapZone(
  pointerX: number,
  pointerY: number,
  viewportW: number,
  viewportH = 800
): WindowSnap {
  const cornerMargin = 52;
  if (pointerX <= cornerMargin && pointerY <= TOP_BAR_HEIGHT + cornerMargin) return 'top-left';
  if (pointerX >= viewportW - cornerMargin && pointerY <= TOP_BAR_HEIGHT + cornerMargin) return 'top-right';
  if (pointerX <= cornerMargin && pointerY >= viewportH - DOCK_RESERVED_HEIGHT - 36) return 'bottom-left';
  if (pointerX >= viewportW - cornerMargin && pointerY >= viewportH - DOCK_RESERVED_HEIGHT - 36) return 'bottom-right';
  if (pointerY <= TOP_BAR_HEIGHT + 8) return 'maximized';
  if (pointerX <= 18) return 'left';
  if (pointerX >= viewportW - 18) return 'right';
  return 'none';
}

/**
 * Double-Buffered Compositor Engine.
 * Prepares sorted surface geometry into backBuffer off-frame and atomically swaps
 * frontBuffer <-> backBuffer inside requestAnimationFrame to prevent screen tearing.
 */
export class DoubleBufferedCompositor {
  private frontBuffer: CompositorBufferSnapshot = {
    frameId: 0,
    swapTimestamp: 0,
    vsyncHz: 60,
    surfaces: [],
  };
  private backBuffer: CompositorBufferSnapshot = {
    frameId: 0,
    swapTimestamp: 0,
    vsyncHz: 60,
    surfaces: [],
  };
  private rafId: number | null = null;
  private dirty = false;

  prepareBackBuffer(
    windows: OSWindow[],
    activeWorkspace: WorkspaceId,
    viewportW: number,
    viewportH: number
  ): void {
    const surfaces: CompositorSurface[] = windows
      .filter((w) => !w.isMinimized && w.workspace === activeWorkspace)
      .sort((a, b) => a.zIndex - b.zIndex)
      .map((w) => ({
        windowId: w.id,
        appId: w.appId,
        workspace: w.workspace,
        rect: computeWindowRect(w, viewportW, viewportH),
        snap: w.snap,
        visible: true,
      }));

    this.backBuffer = {
      frameId: this.frontBuffer.frameId + 1,
      swapTimestamp: typeof performance !== 'undefined' ? performance.now() : Date.now(),
      vsyncHz: 60,
      surfaces,
    };
    this.dirty = true;
  }

  swapBuffers(): CompositorBufferSnapshot {
    if (!this.dirty) return this.frontBuffer;
    // Atomic double-buffer pointer swap
    const prevFront = this.frontBuffer;
    this.frontBuffer = this.backBuffer;
    this.backBuffer = prevFront;
    this.dirty = false;
    return this.frontBuffer;
  }

  startLoop(
    getScene: () => {
      windows: OSWindow[];
      activeWorkspace: WorkspaceId;
      viewportW: number;
      viewportH: number;
    },
    onSwap: (snapshot: CompositorBufferSnapshot) => void
  ): () => void {
    let cancelled = false;
    const tick = () => {
      if (cancelled) return;
      const scene = getScene();
      this.prepareBackBuffer(
        scene.windows,
        scene.activeWorkspace,
        scene.viewportW,
        scene.viewportH
      );
      const committed = this.swapBuffers();
      onSwap(committed);
      if (typeof requestAnimationFrame === 'function') {
        this.rafId = requestAnimationFrame(tick);
      }
    };

    if (typeof requestAnimationFrame === 'function') {
      this.rafId = requestAnimationFrame(tick);
    }

    // Bellek sızıntısı önlemi: Bileşen unmount olduğunda aktif rAF döngüsü iptal edilir.
    return () => {
      cancelled = true;
      if (this.rafId !== null && typeof cancelAnimationFrame === 'function') {
        cancelAnimationFrame(this.rafId);
        this.rafId = null;
      }
    };
  }

  getFrontBuffer(): CompositorBufferSnapshot {
    return this.frontBuffer;
  }
}
