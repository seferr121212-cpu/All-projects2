export type CoreAppId =
  | 'terminal'
  | 'files'
  | 'editor'
  | 'monitor'
  | 'calculator'
  | 'paint'
  | 'viewer'
  | 'notes'
  | 'browser'
  | 'media'
  | 'wasm-builder'
  | 'pkg'
  | 'settings';

export type PackageAppId =
  | 'pkg-snake'
  | 'pkg-hex'
  | 'pkg-timer'
  | 'pkg-mines'
  | 'pkg-2048'
  | 'pkg-kanban'
  | 'pkg-sysbench'
  | 'pkg-calendar'
  | 'pkg-markdown'
  | 'pkg-recorder'
  | 'pkg-nettools'
  | 'pkg-diff';

export type AppId = CoreAppId | PackageAppId;

export type Language = 'tr' | 'en';

export type ThemeMode = 'dark' | 'light';

export type AccentColor = 'sky' | 'amber' | 'emerald' | 'rose' | 'slate';

export type BootPhase = 'booting' | 'locked' | 'desktop' | 'shutdown';

export type WindowSnap =
  | 'none'
  | 'left'
  | 'right'
  | 'top-left'
  | 'top-right'
  | 'bottom-left'
  | 'bottom-right'
  | 'maximized';

export type WorkspaceId = 1 | 2 | 3 | 4;

export interface VFSNode {
  id: string;
  name: string;
  type: 'file' | 'dir';
  content?: string;
  mimeType?: string;
  permissions: string;
  owner: string;
  size: number;
  createdAt: number;
  updatedAt: number;
  children?: Record<string, VFSNode>;
}

export interface OSUser {
  uid: number;
  username: string;
  fullName: string;
  homeDir: string;
  shell: string;
  isAdmin: boolean;
  passwordHash: string | null;
}

export type PrivilegeRing = 0 | 3;

export interface ASLRMemoryLayout {
  codeBase: string;
  heapBase: string;
  stackBase: string;
  aslrSlide: string;
  kernelBoundary: string;
}

export interface MemoryFrame {
  frameIndex: number;
  pid: number | null;
  processName: string | null;
  sizeMB: number;
  allocatedAt: number | null;
  refCount: number;
  isCopyOnWrite: boolean;
  cowSharedWith: number[];
}

export interface SwapSlot {
  slotIndex: number;
  pid: number | null;
  processName: string | null;
  originalFrameIndex: number | null;
  sizeMB: number;
  swappedAt: number | null;
}

export interface CompositorStats {
  frameId: number;
  vsyncHz: number;
  surfaceCount: number;
  lastSwapMs: number;
}

export interface SyscallRecord {
  id: string;
  timestamp: number;
  pid: number;
  name: string;
  args: string;
  status: 'OK' | 'ERR';
  ring?: PrivilegeRing;
}

export interface IPCMessage {
  id: string;
  channel: string;
  fromPid: number;
  payload: unknown;
  timestamp: number;
}

export interface SchedulerStats {
  quantumMs: number;
  totalTicks: number;
  contextSwitches: number;
  preemptions: number;
  foregroundBoostActive: boolean;
  activePid: number | null;
  readyQueueCount: number;
}

export type IOQueuePriority = 'high' | 'normal' | 'low';

export interface IOQueueTask {
  id: string;
  op: 'read' | 'write' | 'sync';
  path: string;
  priority: IOQueuePriority;
  status: 'queued' | 'processing' | 'done' | 'error';
  enqueuedAt: number;
  completedAt?: number;
  latencyMs?: number;
}

export interface IOQueueStats {
  queuedCount: number;
  processingCount: number;
  completedCount: number;
  avgLatencyMs: number;
}

export interface BackgroundJob {
  jobId: number;
  pid: number;
  command: string;
  status: 'running' | 'done' | 'stopped';
  startedAt: number;
  endsAt: number;
  output?: string;
}

export interface NetworkInterface {
  name: string;
  ip: string;
  netmask: string;
  mac: string;
  status: 'UP' | 'DOWN';
  rxBytes: number;
  txBytes: number;
  rxPackets: number;
  txPackets: number;
}

export interface OSProcess {
  pid: number;
  parentPid?: number;
  name: string;
  command: string;
  appId?: AppId;
  windowId?: string;
  user: string;
  state: 'running' | 'sleeping' | 'stopped';
  priority: number; // -20 to 19
  cpu: number;
  cpuTimeMs: number;
  memoryMB: number;
  pagesAllocated: number;
  startedAt: number;
  isSystem?: boolean;
  isForeground?: boolean;
  privilegeRing: PrivilegeRing;
  aslrLayout?: ASLRMemoryLayout;
}

export interface OSWindow {
  id: string;
  appId: AppId;
  pid: number;
  workspace: WorkspaceId;
  title: string;
  x: number;
  y: number;
  width: number;
  height: number;
  minWidth: number;
  minHeight: number;
  isMinimized: boolean;
  snap: WindowSnap;
  zIndex: number;
  launchArgs?: Record<string, string>;
}

export interface KernelLogEntry {
  id: string;
  timestamp: number;
  uptimeSec: number;
  level: 'INFO' | 'WARN' | 'ERR';
  subsystem: string;
  message: string;
}

export interface MetricSample {
  timestamp: number;
  cpu: number;
  ram: number;
}

export interface OSNotification {
  id: string;
  title: string;
  body: string;
  timestamp: number;
  read: boolean;
  appId?: AppId;
}

export interface ClipboardItem {
  kind: 'vfs' | 'text';
  mode?: 'copy' | 'cut';
  path?: string;
  text?: string;
}

export interface WallpaperOption {
  id: string;
  nameTr: string;
  nameEn: string;
  url: string;
  tone: 'dark' | 'light';
}

export interface SandboxPermissionRequest {
  id: string;
  appId: AppId;
  pid: number;
  capability: 'docs:rw';
  targetPath: string;
  operation: 'read' | 'write' | 'delete';
}

export interface OSSettings {
  theme: ThemeMode;
  wallpaperId: string;
  customWallpaperUrl?: string | null;
  accent: AccentColor;
  language: Language;
  showDesktopIcons: boolean;
  userName: string;
  volume: number;
  muted: boolean;
  doNotDisturb?: boolean;
  pinnedApps?: AppId[];
  desktopIconPositions?: Record<string, { x: number; y: number }>;
  sandboxGrants: Record<string, string[]>;
}

export interface AppManifest {
  id: AppId;
  nameTr: string;
  nameEn: string;
  descriptionTr: string;
  descriptionEn: string;
  defaultWidth: number;
  defaultHeight: number;
  minWidth: number;
  minHeight: number;
  singleton?: boolean;
  pinned?: boolean;
  isPackage?: boolean;
}

export interface PackageManifest {
  pkgName: string;
  appId: PackageAppId;
  version: string;
  sizeKB: number;
  author: string;
  nameTr: string;
  nameEn: string;
  descriptionTr: string;
  descriptionEn: string;
  categoryTr: string;
  categoryEn: string;
}

export type PowerProfile = 'performance' | 'balanced' | 'powersaver';

export interface SystemServiceUnit {
  name: string;
  descriptionTr: string;
  descriptionEn: string;
  status: 'active' | 'inactive' | 'failed';
  pid: number | null;
  essential?: boolean;
  restarts: number;
  lastChangedAt: number;
}

export interface CronJob {
  id: string;
  name: string;
  intervalSec: number;
  command: string;
  enabled: boolean;
  runCount: number;
  lastRunAt: number | null;
  lastResult?: string;
}

export interface DiskUsageEntry {
  path: string;
  name: string;
  type: 'file' | 'dir';
  bytes: number;
  fileCount: number;
}

export interface DiskUsageReport {
  targetPath: string;
  totalBytes: number;
  totalFiles: number;
  totalDirs: number;
  entries: DiskUsageEntry[];
}

export interface FsckReport {
  checkedNodes: number;
  issuesFound: number;
  repairedCount: number;
  details: string[];
  healthy: boolean;
}

