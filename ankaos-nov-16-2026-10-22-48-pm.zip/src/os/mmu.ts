import { MemoryFrame, SwapSlot } from './types';

// 128 physical page frames * 32 MB each = 4096 MB virtualized physical RAM
export const TOTAL_FRAMES = 128;
export const FRAME_SIZE_MB = 32;
export const TOTAL_RAM_MB = TOTAL_FRAMES * FRAME_SIZE_MB;

// 64 disk swap slots * 32 MB each = 2048 MB virtual swap space
export const TOTAL_SWAP_SLOTS = 64;
export const TOTAL_SWAP_MB = TOTAL_SWAP_SLOTS * FRAME_SIZE_MB;

export function createInitialFrames(): MemoryFrame[] {
  return Array.from({ length: TOTAL_FRAMES }, (_, idx) => ({
    frameIndex: idx,
    pid: null,
    processName: null,
    sizeMB: FRAME_SIZE_MB,
    allocatedAt: null,
    refCount: 0,
    isCopyOnWrite: false,
    cowSharedWith: [],
  }));
}

export function createInitialSwap(): SwapSlot[] {
  return Array.from({ length: TOTAL_SWAP_SLOTS }, (_, idx) => ({
    slotIndex: idx,
    pid: null,
    processName: null,
    originalFrameIndex: null,
    sizeMB: FRAME_SIZE_MB,
    swappedAt: null,
  }));
}

export function allocateFramesForProcess(
  frames: MemoryFrame[],
  pid: number,
  processName: string,
  requestedMB: number
): { frames: MemoryFrame[]; pagesAllocated: number; actualMB: number; ok: boolean } {
  const neededFrames = Math.max(1, Math.ceil(requestedMB / FRAME_SIZE_MB));
  const freeIndices: number[] = [];

  for (let i = 0; i < frames.length; i++) {
    if (frames[i].pid === null && frames[i].refCount === 0) {
      freeIndices.push(i);
      if (freeIndices.length === neededFrames) break;
    }
  }

  if (freeIndices.length < neededFrames) {
    return { frames, pagesAllocated: 0, actualMB: 0, ok: false };
  }

  const now = Date.now();
  const next = frames.slice();
  for (const idx of freeIndices) {
    next[idx] = {
      frameIndex: idx,
      pid,
      processName,
      sizeMB: FRAME_SIZE_MB,
      allocatedAt: now,
      refCount: 1,
      isCopyOnWrite: false,
      cowSharedWith: [],
    };
  }

  return {
    frames: next,
    pagesAllocated: neededFrames,
    actualMB: neededFrames * FRAME_SIZE_MB,
    ok: true,
  };
}

/**
 * LRU Page Replacement (Swap-Out): Evicts oldest Ring 3 non-shared user frames
 * into virtual disk swap space when physical RAM is exhausted.
 */
export function swapOutLRUFrames(
  frames: MemoryFrame[],
  swap: SwapSlot[],
  neededCount: number,
  protectedPids: number[] = []
): { frames: MemoryFrame[]; swap: SwapSlot[]; swappedCount: number } {
  // Ring 0 kernel frames (< 100) and CoW-shared pages are pinned and never swapped out
  const candidates = frames
    .filter(
      (f) =>
        f.pid !== null &&
        f.pid >= 100 &&
        !f.isCopyOnWrite &&
        !protectedPids.includes(f.pid)
    )
    .sort((a, b) => (a.allocatedAt ?? 0) - (b.allocatedAt ?? 0));

  const nextFrames = frames.slice();
  const nextSwap = swap.slice();
  let swappedCount = 0;

  for (const cand of candidates) {
    if (swappedCount >= neededCount) break;
    const freeSlotIdx = nextSwap.findIndex((s) => s.pid === null);
    if (freeSlotIdx === -1) break;

    nextSwap[freeSlotIdx] = {
      slotIndex: freeSlotIdx,
      pid: cand.pid,
      processName: cand.processName,
      originalFrameIndex: cand.frameIndex,
      sizeMB: FRAME_SIZE_MB,
      swappedAt: Date.now(),
    };

    // Bellek sızıntısı önlemi: Swap'a taşınan fiziksel çerçeve sıfırlanarak yeni sürece tahsis edilebilir hale getirilir.
    nextFrames[cand.frameIndex] = {
      frameIndex: cand.frameIndex,
      pid: null,
      processName: null,
      sizeMB: FRAME_SIZE_MB,
      allocatedAt: null,
      refCount: 0,
      isCopyOnWrite: false,
      cowSharedWith: [],
    };
    swappedCount += 1;
  }

  return { frames: nextFrames, swap: nextSwap, swappedCount };
}

/**
 * Frees swap slots when a process exits so disk swap space never leaks.
 */
export function freeSwapForProcess(swap: SwapSlot[], pid: number): SwapSlot[] {
  return swap.map((s) =>
    s.pid === pid
      ? {
          ...s,
          pid: null,
          processName: null,
          originalFrameIndex: null,
          swappedAt: null,
        }
      : s
  );
}

/**
 * Copy-on-Write (CoW) fork: Child process shares parent's existing physical frames
 * read-only with refCount++, avoiding immediate physical page duplication (0 MB extra RAM).
 */
export function forkFramesCopyOnWrite(
  frames: MemoryFrame[],
  parentPid: number,
  childPid: number
): { frames: MemoryFrame[]; sharedPages: number; virtualMB: number; ok: boolean } {
  let sharedPages = 0;
  const next = frames.map((f) => {
    const ownedByParent = f.pid === parentPid || f.cowSharedWith.includes(parentPid);
    if (!ownedByParent) return f;
    sharedPages += 1;
    // Bellek sızıntısı önlemi: Aynı childPid birden fazla eklenmez; refCount yalnızca benzersiz paylaşım sayısını tutar.
    const nextShared = f.cowSharedWith.includes(childPid)
      ? f.cowSharedWith
      : [...f.cowSharedWith, childPid];
    return {
      ...f,
      isCopyOnWrite: true,
      refCount: 1 + nextShared.length,
      cowSharedWith: nextShared,
    };
  });

  if (sharedPages === 0) {
    return { frames, sharedPages: 0, virtualMB: 0, ok: false };
  }

  return {
    frames: next,
    sharedPages,
    virtualMB: sharedPages * FRAME_SIZE_MB,
    ok: true,
  };
}

/**
 * Handles a Copy-on-Write page fault when a process attempts to write to a shared CoW frame.
 * Allocates one private physical frame for the writer and decrements the shared frame's refCount.
 */
export function handleCowPageFault(
  frames: MemoryFrame[],
  pid: number,
  processName: string,
  targetFrameIndex?: number
): {
  frames: MemoryFrame[];
  ok: boolean;
  oldFrameIndex: number | null;
  newFrameIndex: number | null;
} {
  const sharedIdx =
    targetFrameIndex !== undefined
      ? targetFrameIndex
      : frames.findIndex(
          (f) => f.isCopyOnWrite && (f.pid === pid || f.cowSharedWith.includes(pid))
        );

  if (sharedIdx < 0 || !frames[sharedIdx] || !frames[sharedIdx].isCopyOnWrite) {
    return { frames, ok: false, oldFrameIndex: null, newFrameIndex: null };
  }

  const sharedFrame = frames[sharedIdx];
  if (sharedFrame.refCount <= 1) {
    const next = frames.slice();
    next[sharedIdx] = {
      ...sharedFrame,
      pid,
      processName,
      isCopyOnWrite: false,
      cowSharedWith: [],
      refCount: 1,
    };
    return { frames: next, ok: true, oldFrameIndex: sharedIdx, newFrameIndex: sharedIdx };
  }

  const freeIdx = frames.findIndex((f) => f.pid === null && f.refCount === 0);
  if (freeIdx === -1) {
    return { frames, ok: false, oldFrameIndex: sharedIdx, newFrameIndex: null };
  }

  const next = frames.slice();
  const remainingSharers = sharedFrame.cowSharedWith.filter((id) => id !== pid);

  // Bellek sızıntısı önlemi: Yazan süreç ayrıldığında eski ortak çerçevenin refCount değeri düşürülür;
  // son kalan sahibin sahipliği korunarak askıda (orphaned) sayfa bırakılmaz.
  if (sharedFrame.pid === pid) {
    const promotedPid = remainingSharers[0] ?? null;
    const rest = remainingSharers.slice(1);
    next[sharedIdx] = {
      ...sharedFrame,
      pid: promotedPid,
      cowSharedWith: rest,
      refCount: promotedPid !== null ? 1 + rest.length : 0,
      isCopyOnWrite: rest.length > 0,
      allocatedAt: promotedPid !== null ? sharedFrame.allocatedAt : null,
    };
  } else {
    next[sharedIdx] = {
      ...sharedFrame,
      cowSharedWith: remainingSharers,
      refCount: 1 + remainingSharers.length,
      isCopyOnWrite: remainingSharers.length > 0,
    };
  }

  next[freeIdx] = {
    frameIndex: freeIdx,
    pid,
    processName,
    sizeMB: FRAME_SIZE_MB,
    allocatedAt: Date.now(),
    refCount: 1,
    isCopyOnWrite: false,
    cowSharedWith: [],
  };

  return { frames: next, ok: true, oldFrameIndex: sharedIdx, newFrameIndex: freeIdx };
}

/**
 * Frees all frames belonging to a terminating process.
 * Respects Copy-on-Write reference counts so shared pages are only reclaimed when refCount reaches 0.
 */
export function freeFramesForProcess(frames: MemoryFrame[], pid: number): MemoryFrame[] {
  return frames.map((f) => {
    const isPrimary = f.pid === pid;
    const isSharer = f.cowSharedWith.includes(pid);
    if (!isPrimary && !isSharer) return f;

    const remainingSharers = f.cowSharedWith.filter((id) => id !== pid);

    if (isPrimary) {
      if (remainingSharers.length > 0) {
        const nextOwner = remainingSharers[0];
        const rest = remainingSharers.slice(1);
        return {
          ...f,
          pid: nextOwner,
          cowSharedWith: rest,
          refCount: 1 + rest.length,
          isCopyOnWrite: rest.length > 0,
        };
      }
      return {
        ...f,
        pid: null,
        processName: null,
        allocatedAt: null,
        refCount: 0,
        isCopyOnWrite: false,
        cowSharedWith: [],
      };
    }

    return {
      ...f,
      cowSharedWith: remainingSharers,
      refCount: f.pid !== null ? 1 + remainingSharers.length : remainingSharers.length,
      isCopyOnWrite: remainingSharers.length > 0,
    };
  });
}

export function getMemorySummary(frames: MemoryFrame[], swap: SwapSlot[] = []) {
  const usedFrames = frames.filter((f) => f.pid !== null).length;
  const cowSharedFrames = frames.filter((f) => f.isCopyOnWrite && f.cowSharedWith.length > 0).length;
  const cowSavedFrames = frames.reduce((sum, f) => sum + f.cowSharedWith.length, 0);
  const freeFrames = TOTAL_FRAMES - usedFrames;
  const usedMB = usedFrames * FRAME_SIZE_MB;
  const freeMB = freeFrames * FRAME_SIZE_MB;
  const cowSavedMB = cowSavedFrames * FRAME_SIZE_MB;
  const swapUsedSlots = swap.filter((s) => s.pid !== null).length;
  const swapUsedMB = swapUsedSlots * FRAME_SIZE_MB;
  const usagePct = Math.round((usedFrames / TOTAL_FRAMES) * 100);
  return {
    totalFrames: TOTAL_FRAMES,
    frameSizeMB: FRAME_SIZE_MB,
    usedFrames,
    freeFrames,
    cowSharedFrames,
    cowSavedMB,
    totalMB: TOTAL_RAM_MB,
    usedMB,
    freeMB,
    swapUsedSlots,
    swapUsedMB,
    swapTotalMB: TOTAL_SWAP_MB,
    usagePct,
  };
}
