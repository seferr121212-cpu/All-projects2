import { DiskUsageEntry, DiskUsageReport, FsckReport, VFSNode } from './types';
import { cloneVFS, getNodeAtPath, normalizePath, vfsEnsureDir, vfsWriteFile } from './vfs';

export const ANKA_ARCHIVE_SCHEMA = 'ankaos-archive-v1';

export interface AnkaArchiveBundle {
  schema: typeof ANKA_ARCHIVE_SCHEMA;
  createdAt: string;
  rootName: string;
  node: VFSNode;
  entryCount: number;
  totalBytes: number;
}

function measureSubtree(node: VFSNode): { bytes: number; files: number; dirs: number } {
  if (node.type === 'file') {
    const byteLen = node.size || (node.content ? node.content.length : 0);
    return { bytes: byteLen, files: 1, dirs: 0 };
  }
  let bytes = 0;
  let files = 0;
  let dirs = 1;
  for (const child of Object.values(node.children || {})) {
    const sub = measureSubtree(child);
    bytes += sub.bytes;
    files += sub.files;
    dirs += sub.dirs;
  }
  return { bytes, files, dirs };
}

export function computeDiskUsage(root: VFSNode, targetPath: string): DiskUsageReport | null {
  const norm = normalizePath(targetPath, '/');
  const target = getNodeAtPath(root, norm);
  if (!target) return null;

  if (target.type === 'file') {
    const bytes = target.size || (target.content ? target.content.length : 0);
    return {
      targetPath: norm,
      totalBytes: bytes,
      totalFiles: 1,
      totalDirs: 0,
      entries: [
        {
          path: norm,
          name: target.name,
          type: 'file',
          bytes,
          fileCount: 1,
        },
      ],
    };
  }

  const entries: DiskUsageEntry[] = [];
  let totalBytes = 0;
  let totalFiles = 0;
  let totalDirs = 0;

  for (const child of Object.values(target.children || {})) {
    const stats = measureSubtree(child);
    totalBytes += stats.bytes;
    totalFiles += stats.files;
    totalDirs += stats.dirs;
    entries.push({
      path: norm === '/' ? `/${child.name}` : `${norm}/${child.name}`,
      name: child.name,
      type: child.type,
      bytes: stats.bytes,
      fileCount: stats.files,
    });
  }

  entries.sort((a, b) => b.bytes - a.bytes);

  return {
    targetPath: norm,
    totalBytes,
    totalFiles,
    totalDirs,
    entries,
  };
}

export function runVfsFsck(
  root: VFSNode,
  userHome: string,
  username: string,
  repair = true
): { root: VFSNode; report: FsckReport } {
  let working = repair ? cloneVFS(root) : root;
  let checkedNodes = 0;
  let issuesFound = 0;
  let repairedCount = 0;
  const details: string[] = [];

  const inspect = (node: VFSNode, currentPath: string) => {
    checkedNodes += 1;
    if (node.type === 'file') {
      const actualSize =
        typeof Blob !== 'undefined' && node.content !== undefined
          ? new Blob([node.content]).size
          : (node.content || '').length;
      if (node.size !== actualSize) {
        issuesFound += 1;
        details.push(`Boyut tutarsızlığı: ${currentPath} (${node.size} != ${actualSize} B)`);
        if (repair) {
          node.size = actualSize;
          repairedCount += 1;
        }
      }
      if (!node.permissions) {
        issuesFound += 1;
        details.push(`Eksik izin maskesi: ${currentPath}`);
        if (repair) {
          node.permissions = '-rw-r--r--';
          repairedCount += 1;
        }
      }
      return;
    }

    if (!node.children) {
      issuesFound += 1;
      details.push(`Bozuk klasör haritası: ${currentPath}`);
      if (repair) {
        node.children = {};
        repairedCount += 1;
      }
    }
    for (const [key, child] of Object.entries(node.children || {})) {
      const childPath = currentPath === '/' ? `/${key}` : `${currentPath}/${key}`;
      if (child.name !== key) {
        issuesFound += 1;
        details.push(`Ad uyuşmazlığı: ${childPath} (${child.name})`);
        if (repair) {
          child.name = key;
          repairedCount += 1;
        }
      }
      inspect(child, childPath);
    }
  };

  inspect(working, '/');

  const requiredDirs = [
    '/tmp',
    '/var/log',
    `${userHome}/.Trash`,
    `${userHome}/İndirilenler`,
    `${userHome}/Müzik`,
    `${userHome}/.sandbox`,
  ];

  for (const dirPath of requiredDirs) {
    if (!getNodeAtPath(working, dirPath)) {
      issuesFound += 1;
      details.push(`Eksik sistem dizini: ${dirPath}`);
      if (repair) {
        working = vfsEnsureDir(working, dirPath, { user: username, elevatedRoot: true });
        repairedCount += 1;
      }
    }
  }

  return {
    root: working,
    report: {
      checkedNodes,
      issuesFound,
      repairedCount,
      details,
      healthy: issuesFound === 0 || (repair && repairedCount === issuesFound),
    },
  };
}

export function createAnkaArchive(
  root: VFSNode,
  targetPath: string
): { ok: boolean; json?: string; bundle?: AnkaArchiveBundle; error?: string } {
  const norm = normalizePath(targetPath, '/');
  const node = getNodeAtPath(root, norm);
  if (!node) {
    return { ok: false, error: `Arşivlenecek öğe bulunamadı: ${norm}` };
  }
  const metrics = measureSubtree(node);
  const bundle: AnkaArchiveBundle = {
    schema: ANKA_ARCHIVE_SCHEMA,
    createdAt: new Date().toISOString(),
    rootName: node.name === '/' ? 'rootfs' : node.name,
    node: cloneVFS(node),
    entryCount: metrics.files + metrics.dirs,
    totalBytes: metrics.bytes,
  };
  return {
    ok: true,
    bundle,
    json: JSON.stringify(bundle, null, 2),
  };
}

export function extractAnkaArchive(
  root: VFSNode,
  archiveJson: string,
  destDirPath: string,
  options?: { user?: string; elevatedRoot?: boolean }
): { ok: boolean; root: VFSNode; extractedPath?: string; entryCount?: number; error?: string } {
  try {
    const parsed = JSON.parse(archiveJson) as Partial<AnkaArchiveBundle>;
    if (!parsed || parsed.schema !== ANKA_ARCHIVE_SCHEMA || !parsed.node) {
      return { ok: false, root, error: 'Geçersiz .ankatar arşiv biçimi.' };
    }
    const user = options?.user || 'kullanici';
    const elevatedRoot = Boolean(options?.elevatedRoot);
    const destNorm = normalizePath(destDirPath, '/');
    let working = vfsEnsureDir(root, destNorm, { user, elevatedRoot });

    const insertNode = (baseDir: string, node: VFSNode): { ok: boolean; error?: string } => {
      const target = baseDir === '/' ? `/${node.name}` : `${baseDir}/${node.name}`;
      if (node.type === 'file') {
        const res = vfsWriteFile(working, target, node.content || '', node.mimeType, {
          user,
          elevatedRoot,
        });
        if (!res.ok) return { ok: false, error: res.error };
        working = res.root;
        return { ok: true };
      }
      working = vfsEnsureDir(working, target, { user, elevatedRoot });
      for (const child of Object.values(node.children || {})) {
        const childRes = insertNode(target, child);
        if (!childRes.ok) return childRes;
      }
      return { ok: true };
    };

    const res = insertNode(destNorm, parsed.node);
    if (!res.ok) return { ok: false, root, error: res.error };

    const extractedPath =
      destNorm === '/' ? `/${parsed.node.name}` : `${destNorm}/${parsed.node.name}`;
    return {
      ok: true,
      root: working,
      extractedPath,
      entryCount: parsed.entryCount || 1,
    };
  } catch (err) {
    return {
      ok: false,
      root,
      error: `Arşiv ayrıştırılamadı: ${err instanceof Error ? err.message : String(err)}`,
    };
  }
}
