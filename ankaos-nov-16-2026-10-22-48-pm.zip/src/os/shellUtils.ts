import { VFSNode } from './types';
import { getNodeAtPath, listDir, normalizePath } from './vfs';

export interface ChainSegment {
  cmd: string;
  opAfter: '&&' | '||' | ';' | null;
}

/**
 * Splits a shell command line by `&&`, `||`, and `;` while respecting
 * single and double quotes (`'...'`, `"..."`).
 */
export function splitCommandChain(raw: string): ChainSegment[] {
  const segments: ChainSegment[] = [];
  let buf = '';
  let quote: '"' | "'" | null = null;

  for (let i = 0; i < raw.length; i++) {
    const ch = raw[i];
    if (quote) {
      if (ch === quote) quote = null;
      buf += ch;
      continue;
    }
    if (ch === '"' || ch === "'") {
      quote = ch;
      buf += ch;
      continue;
    }
    if (ch === '&' && raw[i + 1] === '&') {
      if (buf.trim()) segments.push({ cmd: buf.trim(), opAfter: '&&' });
      buf = '';
      i++;
      continue;
    }
    if (ch === '|' && raw[i + 1] === '|') {
      if (buf.trim()) segments.push({ cmd: buf.trim(), opAfter: '||' });
      buf = '';
      i++;
      continue;
    }
    if (ch === ';') {
      if (buf.trim()) segments.push({ cmd: buf.trim(), opAfter: ';' });
      buf = '';
      continue;
    }
    buf += ch;
  }

  if (buf.trim()) {
    segments.push({ cmd: buf.trim(), opAfter: null });
  }
  return segments;
}

/**
 * Tokenizes a single shell command honoring single and double quotes.
 */
export function tokenizeArgs(raw: string): string[] {
  const tokens: string[] = [];
  let current = '';
  let quote: '"' | "'" | null = null;
  for (let i = 0; i < raw.length; i++) {
    const ch = raw[i];
    if (quote) {
      if (ch === quote) quote = null;
      else current += ch;
    } else if (ch === '"' || ch === "'") {
      quote = ch;
    } else if (/\s/.test(ch)) {
      if (current.length > 0) {
        tokens.push(current);
        current = '';
      }
    } else {
      current += ch;
    }
  }
  if (current.length > 0) tokens.push(current);
  return tokens;
}

/**
 * Splits a command segment by single pipe `|` outside quotes (preserving `||`? Wait: `||` already handled by splitCommandChain).
 */
export function splitPipes(raw: string): string[] {
  const parts: string[] = [];
  let buf = '';
  let quote: '"' | "'" | null = null;
  for (let i = 0; i < raw.length; i++) {
    const ch = raw[i];
    if (quote) {
      if (ch === quote) quote = null;
      buf += ch;
      continue;
    }
    if (ch === '"' || ch === "'") {
      quote = ch;
      buf += ch;
      continue;
    }
    if (ch === '|') {
      parts.push(buf.trim());
      buf = '';
      continue;
    }
    buf += ch;
  }
  if (buf.trim()) parts.push(buf.trim());
  return parts;
}

/**
 * LCS-based unified line diff between two texts.
 */
export function computeLineDiff(
  textA: string,
  textB: string,
  labelA = 'dosya1',
  labelB = 'dosya2'
): { identical: boolean; diffText: string; added: number; removed: number } {
  const a = textA.split('\n');
  const b = textB.split('\n');
  const m = a.length;
  const n = b.length;

  // Guard huge files cleanly
  if (m * n > 250000) {
    return {
      identical: textA === textB,
      diffText: textA === textB ? 'Dosyalar birebir aynı.' : `--- ${labelA}\n+++ ${labelB}\nDosyalar farklı (${m} vs ${n} satır).`,
      added: 0,
      removed: 0,
    };
  }

  const dp: number[][] = Array.from({ length: m + 1 }, () => Array(n + 1).fill(0));
  for (let i = m - 1; i >= 0; i--) {
    for (let j = n - 1; j >= 0; j--) {
      dp[i][j] = a[i] === b[j] ? dp[i + 1][j + 1] + 1 : Math.max(dp[i + 1][j], dp[i][j + 1]);
    }
  }

  const out: string[] = [`--- ${labelA}`, `+++ ${labelB}`];
  let i = 0;
  let j = 0;
  let added = 0;
  let removed = 0;

  while (i < m && j < n) {
    if (a[i] === b[j]) {
      out.push(`  ${a[i]}`);
      i++;
      j++;
    } else if (dp[i + 1][j] >= dp[i][j + 1]) {
      out.push(`- ${a[i]}`);
      removed++;
      i++;
    } else {
      out.push(`+ ${b[j]}`);
      added++;
      j++;
    }
  }
  while (i < m) {
    out.push(`- ${a[i++]}`);
    removed++;
  }
  while (j < n) {
    out.push(`+ ${b[j++]}`);
    added++;
  }

  const identical = added === 0 && removed === 0;
  return {
    identical,
    diffText: identical ? 'Dosyalar birebir aynı (fark yok).' : out.join('\n'),
    added,
    removed,
  };
}

/**
 * Resolves Tab autocomplete for both shell commands/aliases and nested VFS paths
 * (e.g. `cat ~/Proj...`, `cd /etc/os...`, `open Belgeler/Not...`).
 */
export function resolveTabCompletion(
  input: string,
  cwd: string,
  userHome: string,
  vfs: VFSNode,
  knownCommands: string[],
  aliases: Record<string, string>
): string | null {
  const parts = input.split(' ');
  const last = parts[parts.length - 1] ?? '';

  if (parts.length === 1 && !last.includes('/')) {
    const pool = [...knownCommands, ...Object.keys(aliases)];
    const match = pool.find((c) => c.toLowerCase().startsWith(last.toLowerCase()));
    return match ? `${match} ` : null;
  }

  const slashIdx = last.lastIndexOf('/');
  const dirPart = slashIdx === -1 ? '' : last.slice(0, slashIdx + 1);
  const partialName = slashIdx === -1 ? last : last.slice(slashIdx + 1);

  const dirToInspect =
    dirPart === ''
      ? cwd
      : dirPart === '/'
        ? '/'
        : normalizePath(dirPart.replace(/\/$/, ''), cwd, userHome);

  const dirNode = getNodeAtPath(vfs, dirToInspect);
  if (!dirNode || dirNode.type !== 'dir') return null;

  const entries = listDir(vfs, dirToInspect);
  const match = entries.find((entry) =>
    entry.name.toLowerCase().startsWith(partialName.toLowerCase())
  );
  if (!match) return null;

  const completedToken = `${dirPart}${match.name}${match.type === 'dir' ? '/' : ''}`;
  parts[parts.length - 1] = completedToken;
  return parts.join(' ');
}

/**
 * Expands $VAR, ${VAR}, $?, $PWD, $HOME, $USER outside single quotes.
 */
export function expandShellVariables(
  raw: string,
  env: Record<string, string>,
  context: { cwd: string; user: string; homeDir: string; lastExit?: number }
): string {
  const lookup = (name: string): string => {
    if (name === '?') return String(context.lastExit ?? 0);
    if (name === 'PWD') return context.cwd;
    if (name === 'USER') return context.user;
    if (name === 'HOME') return context.homeDir;
    return env[name] ?? '';
  };

  let out = '';
  let inSingle = false;
  let inDouble = false;

  for (let i = 0; i < raw.length; i++) {
    const ch = raw[i];
    if (ch === "'" && !inDouble) {
      inSingle = !inSingle;
      out += ch;
      continue;
    }
    if (ch === '"' && !inSingle) {
      inDouble = !inDouble;
      out += ch;
      continue;
    }
    if (ch === '$' && !inSingle) {
      if (raw[i + 1] === '?') {
        out += lookup('?');
        i++;
        continue;
      }
      if (raw[i + 1] === '{') {
        const close = raw.indexOf('}', i + 2);
        if (close !== -1) {
          const varName = raw.slice(i + 2, close).trim();
          out += lookup(varName);
          i = close;
          continue;
        }
      }
      const match = raw.slice(i + 1).match(/^[A-Za-z_][A-Za-z0-9_]*/);
      if (match) {
        out += lookup(match[0]);
        i += match[0].length;
        continue;
      }
    }
    out += ch;
  }

  return out;
}

/**
 * Evaluates simple POSIX `[ ... ]` or `test ...` conditions as well as truthy commands.
 */
export function evaluateShellCondition(
  condRaw: string,
  vfs: VFSNode,
  env: Record<string, string>,
  context: { cwd: string; user: string; homeDir: string; lastExit?: number }
): boolean {
  const expanded = expandShellVariables(condRaw.trim(), env, context);
  let inner = expanded;
  if (inner.startsWith('[') && inner.endsWith(']')) {
    inner = inner.slice(1, -1).trim();
  } else if (inner.startsWith('test ')) {
    inner = inner.slice(5).trim();
  }
  const tokens = tokenizeArgs(inner);
  if (tokens.length === 0) return false;

  if (tokens.length === 2 && (tokens[0] === '-f' || tokens[0] === '-d' || tokens[0] === '-e')) {
    const target = normalizePath(tokens[1], context.cwd, context.homeDir);
    const node = getNodeAtPath(vfs, target);
    if (!node) return false;
    if (tokens[0] === '-f') return node.type === 'file';
    if (tokens[0] === '-d') return node.type === 'dir';
    return true;
  }
  if (tokens.length === 2 && tokens[0] === '-n') return tokens[1].length > 0;
  if (tokens.length === 2 && tokens[0] === '-z') return tokens[1].length === 0;
  if (tokens.length === 3) {
    const [left, op, right] = tokens;
    if (op === '=' || op === '==') return left === right;
    if (op === '!=') return left !== right;
    if (op === '-eq') return Number(left) === Number(right);
    if (op === '-ne') return Number(left) !== Number(right);
    if (op === '-gt') return Number(left) > Number(right);
    if (op === '-lt') return Number(left) < Number(right);
    if (op === '-ge') return Number(left) >= Number(right);
    if (op === '-le') return Number(left) <= Number(right);
  }
  if (expanded === 'true' || expanded === '0') return true;
  if (expanded === 'false' || expanded === '1') return false;
  return Boolean(tokens[0]);
}

/**
 * Parses and flattens `if ...; then ...; [else ...;] fi` and
 * `for VAR in ...; do ...; done` into ordered executable lines.
 */
export function evaluateIfForScript(
  scriptText: string,
  vfs: VFSNode,
  initialEnv: Record<string, string>,
  context: { cwd: string; user: string; homeDir: string; lastExit?: number }
): { ok: boolean; commands: string[]; env: Record<string, string>; error?: string } {
  const localEnv = { ...initialEnv };
  // Split lines and semicolons cleanly (preserving quoted semicolons)
  const rawStmts: string[] = [];
  for (const line of scriptText.split('\n')) {
    const trimmedLine = line.trim();
    if (!trimmedLine || trimmedLine.startsWith('#')) continue;
    for (const seg of splitCommandChain(trimmedLine)) {
      if (seg.opAfter === ';') {
        rawStmts.push(seg.cmd);
      } else if (seg.opAfter) {
        // Rejoin non-semicolon chain operators so && and || survive inside blocks
        const lastIdx = rawStmts.length;
        void lastIdx;
        rawStmts.push(`${seg.cmd} ${seg.opAfter}`);
      } else {
        rawStmts.push(seg.cmd);
      }
    }
  }

  // Collapse inline `&&` / `||` continuation into single statements
  const stmts: string[] = [];
  for (let i = 0; i < rawStmts.length; i++) {
    let cur = rawStmts[i];
    while ((cur.endsWith('&&') || cur.endsWith('||')) && i + 1 < rawStmts.length) {
      i++;
      cur = `${cur} ${rawStmts[i]}`;
    }
    stmts.push(cur);
  }

  const output: string[] = [];

  const runBlock = (startIdx: number, endTokens: string[]): { nextIdx: number; matchedEnd: string } => {
    let i = startIdx;
    while (i < stmts.length) {
      const s = stmts[i].trim();
      if (endTokens.includes(s)) {
        return { nextIdx: i, matchedEnd: s };
      }

      if (s.startsWith('if ')) {
        const condExpr = s.slice(3).trim();
        let thenStart = i + 1;
        if (stmts[thenStart]?.trim() === 'then') thenStart++;

        // Collect branches manually to skip execution of untaken branch
        const condOk = evaluateShellCondition(condExpr, vfs, localEnv, context);
        let depth = 1;
        let scan = thenStart;
        const thenStmts: string[] = [];
        const elseStmts: string[] = [];
        let inElse = false;

        while (scan < stmts.length && depth > 0) {
          const cur = stmts[scan].trim();
          if (cur.startsWith('if ')) depth++;
          else if (cur === 'fi') {
            depth--;
            if (depth === 0) break;
          } else if (cur === 'else' && depth === 1) {
            inElse = true;
            scan++;
            continue;
          }
          if (inElse) elseStmts.push(cur);
          else thenStmts.push(cur);
          scan++;
        }

        const branchText = (condOk ? thenStmts : elseStmts).join('\n');
        if (branchText.trim()) {
          const sub = evaluateIfForScript(branchText, vfs, localEnv, context);
          if (!sub.ok) throw new Error(sub.error || 'if bloğu hatası');
          output.push(...sub.commands);
          Object.assign(localEnv, sub.env);
        }
        i = scan + 1;
        continue;
      }

      if (s.startsWith('for ')) {
        const match = s.match(/^for\s+([A-Za-z_][A-Za-z0-9_]*)\s+in\s+(.+)$/);
        if (!match) throw new Error(`Sözdizimi hatası: '${s}'`);
        const varName = match[1];
        const listRaw = expandShellVariables(match[2], localEnv, context);
        const items = tokenizeArgs(listRaw);

        let bodyStart = i + 1;
        if (stmts[bodyStart]?.trim() === 'do') bodyStart++;

        let depth = 1;
        let scan = bodyStart;
        const bodyStmts: string[] = [];
        while (scan < stmts.length && depth > 0) {
          const cur = stmts[scan].trim();
          if (cur.startsWith('for ')) depth++;
          else if (cur === 'done') {
            depth--;
            if (depth === 0) break;
          }
          bodyStmts.push(cur);
          scan++;
        }

        const bodyText = bodyStmts.join('\n');
        for (const itemVal of items) {
          localEnv[varName] = itemVal;
          const sub = evaluateIfForScript(bodyText, vfs, localEnv, context);
          if (!sub.ok) throw new Error(sub.error || 'for bloğu hatası');
          output.push(...sub.commands);
          Object.assign(localEnv, sub.env);
        }
        i = scan + 1;
        continue;
      }

      // Simple local assignment VAR=VAL inside script
      const assignMatch = s.match(/^([A-Za-z_][A-Za-z0-9_]*)=(.*)$/);
      if (assignMatch && !s.startsWith('alias ')) {
        let val = assignMatch[2].trim();
        if ((val.startsWith('"') && val.endsWith('"')) || (val.startsWith("'") && val.endsWith("'"))) {
          val = val.slice(1, -1);
        }
        localEnv[assignMatch[1]] = expandShellVariables(val, localEnv, context);
        i++;
        continue;
      }

      output.push(expandShellVariables(s, localEnv, context));
      i++;
    }
    return { nextIdx: i, matchedEnd: '' };
  };

  try {
    runBlock(0, []);
    return { ok: true, commands: output, env: localEnv };
  } catch (err) {
    return {
      ok: false,
      commands: [],
      env: localEnv,
      error: err instanceof Error ? err.message : String(err),
    };
  }
}
