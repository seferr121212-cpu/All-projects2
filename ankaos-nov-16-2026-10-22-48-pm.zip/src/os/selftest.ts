import { APP_MANIFESTS } from './apps';
import { computeDiskUsage, createAnkaArchive, extractAnkaArchive, runVfsFsck } from './archive';
import {
  canExecuteNode,
  createInitialUsers,
  createUserAccount,
  hashPassword,
  verifyPassword,
} from './auth';
import { computeWindowRect, detectEdgeSnapZone, DoubleBufferedCompositor } from './compositor';
import { startDaemonWorker } from './daemonWorker';
import { idbGet, idbPut } from './idbStorage';
import { AsyncIOQueue } from './ioQueue';
import { ipcBus } from './ipc';
import {
  allocateFramesForProcess,
  createInitialFrames,
  createInitialSwap,
  forkFramesCopyOnWrite,
  freeFramesForProcess,
  freeSwapForProcess,
  getMemorySummary,
  handleCowPageFault,
  swapOutLRUFrames,
} from './mmu';
import { detectLanguageFromPath } from './highlight';
import { parseAnkaSynthTrack, serializeAnkaSynthTrack } from './mediaSynth';
import { measureLoopbackPing, resolveHost, validateExternalUrl } from './net';
import { PACKAGE_REGISTRY } from './packages';
import {
  buildSampleMathWasmBytes,
  executeSandboxedJS,
  runWasmBinary,
} from './sandboxRuntime';
import { parseSmartQuery, searchLocalVfs } from './searchUtils';
import { getEffectivePriority, createInitialSchedulerStats, stepScheduler } from './scheduler';
import {
  assertKernelAccess,
  checkSandboxSyscall,
  generateASLRLayout,
  KERNEL_SPACE_BOUNDARY_HEX,
} from './security';
import {
  controlServiceUnit,
  createCronJob,
  createInitialServices,
  POWER_PROFILE_META,
} from './services';
import {
  computeLineDiff,
  evaluateIfForScript,
  expandShellVariables,
  resolveTabCompletion,
  splitCommandChain,
} from './shellUtils';
import { ACCENT_PALETTES, applyThemePalette, hydrateThemeFromStorage, THEME_PALETTES } from './theme';
import { AccentColor, OSProcess } from './types';
import {
  createInitialVFS,
  getNodeAtPath,
  normalizePath,
  provisionUserHome,
  readDynamicNodeContent,
  vfsChmod,
  vfsDelete,
  vfsEmptyTrash,
  vfsEnsureDir,
  vfsMkdir,
  vfsMoveNode,
  vfsMoveToTrash,
  vfsRestoreFromTrash,
  vfsWriteFile,
} from './vfs';
import {
  AnkaWasmPackageManifest,
  compileWatToWasm,
  packageWasmModule,
  runWasmOrPackageFromVfsContent,
  runWasmWithMemoryPreview,
  WASM_TEMPLATES,
} from './wasmCompiler';
import { profileWasmExecution, renderAsciiFlameSummary } from './wasmProfiler';

export interface SelfTestResult {
  name: string;
  passed: boolean;
  detail: string;
}

export async function runKernelSelfTests(): Promise<SelfTestResult[]> {
  const results: SelfTestResult[] = [];
  const check = (name: string, cond: boolean, detail: string) => {
    results.push({ name, passed: cond, detail });
  };

  // 1. VFS Path Normalization
  check(
    'VFS Yol Çözümleme',
    normalizePath('~/Projeler/../Belgeler/./Notlar', '/home/kullanici') ===
      '/home/kullanici/Belgeler/Notlar',
    'normalizePath(. / .. / ~) doğrulandı'
  );

  // 2. VFS Read/Write/Delete + Permission enforcement
  let root = createInitialVFS();
  const denyEtc = vfsWriteFile(root, '/etc/hack.txt', 'test', 'text/plain', {
    user: 'kullanici',
    elevatedRoot: false,
  });
  check(
    'POSIX Yazma Koruması (/etc)',
    denyEtc.ok === false,
    'Normal kullanıcı /etc dizinine izinsiz yazamadı'
  );

  const allowSudo = vfsWriteFile(root, '/etc/custom.conf', 'mode=1', 'text/plain', {
    user: 'kullanici',
    elevatedRoot: true,
  });
  check(
    'Sudo Yetki Yükseltme (/etc)',
    allowSudo.ok === true && getNodeAtPath(allowSudo.root, '/etc/custom.conf') !== null,
    'sudo ile /etc/custom.conf oluşturuldu'
  );
  root = allowSudo.root;

  // 3. chmod & mkdir & delete
  const mk = vfsMkdir(root, '/home/kullanici/test_dir');
  check('VFS Klasör Oluşturma', mk.ok === true, '/home/kullanici/test_dir oluşturuldu');
  root = mk.root;

  const ch = vfsChmod(root, '/home/kullanici/test_dir', '700');
  check(
    'POSIX chmod (700)',
    ch.ok && getNodeAtPath(ch.root, '/home/kullanici/test_dir')?.permissions === 'drwx------',
    'İzinler drwx------ olarak güncellendi'
  );
  root = ch.root;

  const del = vfsDelete(root, '/home/kullanici/test_dir');
  check(
    'VFS Silme İşlemi',
    del.ok && getNodeAtPath(del.root, '/home/kullanici/test_dir') === null,
    'test_dir silindi'
  );

  // 4. Execute bit check (+x / -x)
  const shFile = vfsWriteFile(root, '/home/kullanici/runme.sh', 'echo ok');
  root = shFile.root;
  const nonExecNode = getNodeAtPath(root, '/home/kullanici/runme.sh');
  const blockedExec = !canExecuteNode(nonExecNode, 'kullanici');
  const chmodExec = vfsChmod(root, '/home/kullanici/runme.sh', '+x');
  root = chmodExec.root;
  const allowedExec = canExecuteNode(getNodeAtPath(root, '/home/kullanici/runme.sh'), 'kullanici');
  check(
    'POSIX Çalıştırma İzni (+x)',
    blockedExec && allowedExec,
    'İzinsiz betik engellendi, chmod +x sonrası çalıştırılabilir oldu'
  );

  // 5. Virtual /proc and /dev devices
  let frames = createInitialFrames();
  const alloc = allocateFramesForProcess(frames, 101, 'test-proc', 128);
  frames = alloc.frames;
  const procMem = readDynamicNodeContent(root, '/proc/meminfo', {
    frames,
    processes: [],
    uptimeSec: 42,
  });
  check(
    'Sanal /proc/meminfo & MMU',
    Boolean(procMem && procMem.includes('128 MB') && alloc.pagesAllocated === 4),
    '4 sayfa çerçevesi (128 MB) tahsis edildi ve /proc/meminfo okundu'
  );

  const devNullWrite = vfsWriteFile(root, '/dev/null', 'discard me');
  const devRandomRead = readDynamicNodeContent(root, '/dev/random');
  check(
    'Karakter Aygıtları (/dev/null & /dev/random)',
    devNullWrite.ok && Boolean(devRandomRead && devRandomRead.length === 32),
    `/dev/random 16 bayt üretti: ${devRandomRead?.slice(0, 12)}...`
  );

  // 6. Copy-on-Write (CoW) Paging & Leak-Free Deallocation
  const cowFork = forkFramesCopyOnWrite(frames, 101, 102);
  frames = cowFork.frames;
  const memAfterFork = getMemorySummary(frames);
  const cowFault = handleCowPageFault(frames, 102, 'test-child');
  frames = cowFault.frames;
  const memAfterFault = getMemorySummary(frames);
  frames = freeFramesForProcess(frames, 101);
  frames = freeFramesForProcess(frames, 102);
  const memAfterFreeAll = getMemorySummary(frames);
  check(
    'Copy-on-Write (CoW) & Sızıntısız Bellek İadesi',
    cowFork.ok &&
      memAfterFork.usedFrames === 4 &&
      memAfterFork.cowSavedMB === 128 &&
      cowFault.ok &&
      memAfterFault.usedFrames === 5 &&
      memAfterFreeAll.usedFrames === 0,
    'CoW fork 0 MB ek RAM kullandı, yazma hatasında 1 sayfa kopyaladı, çıkışta tüm 128 çerçeve iade edildi'
  );

  // 7. Preemptive Priority Scheduler (Foreground UI preemption)
  const mockProcs: OSProcess[] = [
    {
      pid: 1,
      name: 'bg-worker',
      command: '/bin/worker',
      user: 'kullanici',
      state: 'running',
      priority: 0,
      cpu: 0,
      cpuTimeMs: 0,
      memoryMB: 32,
      pagesAllocated: 1,
      startedAt: Date.now(),
      privilegeRing: 3,
    },
    {
      pid: 2,
      name: 'ui-foreground',
      command: '/usr/bin/anka-editor',
      user: 'kullanici',
      state: 'running',
      priority: 0,
      cpu: 0,
      cpuTimeMs: 0,
      memoryMB: 32,
      pagesAllocated: 1,
      startedAt: Date.now(),
      privilegeRing: 3,
    },
  ];
  const initSched = { ...createInitialSchedulerStats(), activePid: 1 };
  const schedStep = stepScheduler(mockProcs, initSched, 2);
  check(
    'Preemptive Priority Zamanlayıcı',
    schedStep.stats.activePid === 2 &&
      schedStep.stats.preemptions === 1 &&
      schedStep.stats.foregroundBoostActive,
    'Ön plandaki UI süreci (PID 2) arka plan sürecini (PID 1) kesintiye uğrattı'
  );

  // 8. Async I/O Queue
  const ioQ = new AsyncIOQueue();
  const order: string[] = [];
  await Promise.all([
    ioQ.enqueue('write', '/tmp/low.log', () => {
      order.push('low');
    }, 'low'),
    ioQ.enqueue('write', '/tmp/high.db', () => {
      order.push('high');
    }, 'high'),
  ]);
  const ioStats = ioQ.getStats();
  check(
    'Asenkron G/Ç Kuyruğu (Async I/O)',
    ioStats.completedCount === 2 && order.length === 2,
    `${ioStats.completedCount} G/Ç görevi bloklamadan tamamlandı (öncelik: ${order.join(' -> ')})`
  );

  // 9. Ring 0 / Ring 3 Isolation & ASLR
  const aslrA = generateASLRLayout(3);
  const aslrB = generateASLRLayout(3);
  const ring3Deny = assertKernelAccess(
    { pid: 105, name: 'rogue-app', privilegeRing: 3 },
    KERNEL_SPACE_BOUNDARY_HEX
  );
  const ring0Allow = assertKernelAccess(
    { pid: 1, name: 'anka-init', privilegeRing: 0 },
    KERNEL_SPACE_BOUNDARY_HEX
  );
  check(
    'Ring 0/3 Yetki Ayrımı & ASLR',
    !ring3Deny.allowed && ring0Allow.allowed && aslrA.stackBase !== aslrB.stackBase,
    `Ring 3 çekirdek erişimi engellendi; ASLR Stack ${aslrA.stackBase} != ${aslrB.stackBase}`
  );

  // 10. Sandbox / İzin Yöneticisi
  const sandboxAllowOwn = checkSandboxSyscall(
    'paint',
    'write',
    '/home/kullanici/.sandbox/paint/canvas.png',
    'kullanici',
    {}
  );
  const sandboxBlockDocs = checkSandboxSyscall(
    'paint',
    'write',
    '/home/kullanici/Belgeler/gizli.txt',
    'kullanici',
    {}
  );
  const sandboxAllowGrant = checkSandboxSyscall(
    'paint',
    'write',
    '/home/kullanici/Belgeler/gizli.txt',
    'kullanici',
    { paint: ['docs:rw'] }
  );
  check(
    'Sandbox / İzin Yöneticisi',
    sandboxAllowOwn.allowed &&
      !sandboxBlockDocs.allowed &&
      sandboxBlockDocs.requiresPrompt &&
      sandboxAllowGrant.allowed,
    'Uygulama sadece ~/.sandbox içine serbest yazdı; Belgeler için izin istendi'
  );

  // 11. Double-Buffered Compositor, Snapping & Theme Palette
  const comp = new DoubleBufferedCompositor();
  comp.prepareBackBuffer(
    [
      {
        id: 'w1',
        appId: 'terminal',
        pid: 101,
        workspace: 2,
        title: 'Terminal',
        x: 10,
        y: 50,
        width: 500,
        height: 400,
        minWidth: 300,
        minHeight: 200,
        isMinimized: false,
        snap: 'left',
        zIndex: 21,
      },
    ],
    2,
    1200,
    800
  );
  const front = comp.swapBuffers();
  const snapRect = computeWindowRect(
    { x: 0, y: 0, width: 400, height: 300, snap: 'right', zIndex: 1 },
    1200,
    800
  );
  const zone = detectEdgeSnapZone(10, 200, 1200);
  const lightPalette = applyThemePalette('light');
  applyThemePalette('dark');
  check(
    'Double-Buffer Kompozitör, Snapping & Tema Paleti',
    front.frameId === 1 &&
      front.surfaces.length === 1 &&
      snapRect.x === 604 &&
      zone === 'left' &&
      lightPalette.bg === THEME_PALETTES.light.bg,
    `Back->Front buffer takası (frame #${front.frameId}), Left/Right snap ve merkezi tema paleti doğrulandı`
  );

  // 12. Auth SHA-256 hashing & Multi-user provisioning
  const users = createInitialUsers();
  const user = { ...users[0], passwordHash: await hashPassword('anka2026') };
  const validPass = await verifyPassword(user, 'anka2026');
  const invalidPass = await verifyPassword(user, 'yanlis');
  const yeniUser = await createUserAccount(users, 'misafir', 'Misafir Kullanıcı', '1234', false);
  check(
    'SHA-256 Kimlik Doğrulama & Çoklu Kullanıcı',
    validPass && !invalidPass && yeniUser.uid === 1001 && yeniUser.homeDir === '/home/misafir',
    `Parola doğrulandı ve UID ${yeniUser.uid} (${yeniUser.username}) oluşturuldu`
  );

  // 13. Virtual Network Stack & DNS
  const resolved = resolveHost(root, 'localhost');
  const pingRes = measureLoopbackPing('localhost', root);
  check(
    'Sanal Ağ Yığını & Loopback Ping',
    resolved === '127.0.0.1' && pingRes.rttMs > 0,
    `localhost -> ${pingRes.ip} (RTT ${pingRes.rttMs} ms)`
  );

  // 14. IPC Message Bus
  let received: unknown = null;
  const unsub = ipcBus.subscribe('test:chan', (msg) => {
    received = msg.payload;
  });
  ipcBus.publish('test:chan', 1, { ping: 'pong' });
  unsub();
  check(
    'Çekirdek IPC Mesaj Veriyolu',
    (received as { ping?: string })?.ping === 'pong',
    'Süreçler arası mesaj başarıyla iletildi'
  );

  // 15. LRU Swap / Sayfa Değiştirme (RAM Dolduğunda Disk Takası)
  let swapPool = createInitialSwap();
  let fullFrames = createInitialFrames();
  const fillerAlloc = allocateFramesForProcess(fullFrames, 201, 'heavy-app', 4096);
  fullFrames = fillerAlloc.frames;
  const oomBeforeSwap = allocateFramesForProcess(fullFrames, 202, 'new-app', 64);
  const evicted = swapOutLRUFrames(fullFrames, swapPool, 2, [202]);
  fullFrames = evicted.frames;
  swapPool = evicted.swap;
  const allocAfterSwap = allocateFramesForProcess(fullFrames, 202, 'new-app', 64);
  const memWithSwap = getMemorySummary(allocAfterSwap.frames, swapPool);
  const cleanedSwap = freeSwapForProcess(swapPool, 201);
  const memAfterSwapClean = getMemorySummary(allocAfterSwap.frames, cleanedSwap);
  check(
    'LRU Swap / Sanal Bellek Değiştirme',
    !oomBeforeSwap.ok &&
      evicted.swappedCount === 2 &&
      allocAfterSwap.ok &&
      memWithSwap.swapUsedMB === 64 &&
      memAfterSwapClean.swapUsedSlots === 0,
    'Dolu RAMde 2 eski çerçeve (64 MB) LRU ile Swapa taşındı, yeni süreç yerleşti ve çıkışta swap temizlendi'
  );

  // 16. POSIX Sinyaller (SIGSTOP / SIGCONT) ve Zamanlayıcı Yalıtımı
  const sigProcs: OSProcess[] = [
    { ...mockProcs[0], pid: 301, state: 'stopped', cpuTimeMs: 100 },
    { ...mockProcs[1], pid: 302, state: 'running', cpuTimeMs: 100 },
  ];
  const stoppedStep = stepScheduler(sigProcs, createInitialSchedulerStats(), null);
  const stoppedProcAfter = stoppedStep.processes.find((p) => p.pid === 301)!;
  const resumedProcs = stoppedStep.processes.map((p) =>
    p.pid === 301 ? { ...p, state: 'running' as const } : p
  );
  const resumedStep = stepScheduler(resumedProcs, stoppedStep.stats, 301);
  check(
    'POSIX Sinyalleri (SIGSTOP / SIGCONT)',
    stoppedStep.stats.activePid === 302 &&
      stoppedProcAfter.cpuTimeMs === 100 &&
      resumedStep.stats.activePid === 301,
    'SIGSTOP durumundaki süreç CPU kuantumu almadı; SIGCONT sonrası öncelikli olarak çalıştı'
  );

  // 17. Çoklu Kullanıcı Ev Dizini & Tilde (~) Çözümleme
  const provisionedRoot = provisionUserHome(root, 'misafir');
  const guestDesktop = getNodeAtPath(provisionedRoot, '/home/misafir/Masaüstü');
  const guestSandbox = getNodeAtPath(provisionedRoot, '/home/misafir/.sandbox/paint');
  const guestResolved = normalizePath('~/Resimler', '/', '/home/misafir');
  check(
    'Çoklu Kullanıcı Ev Dizini (provisionUserHome)',
    Boolean(
      guestDesktop &&
        guestDesktop.owner === 'misafir' &&
        guestSandbox &&
        guestResolved === '/home/misafir/Resimler'
    ),
    '/home/misafir alt dizinleri (.sandbox dahil) ve ~ çözümlemesi doğrulandı'
  );

  // 18. /proc/meminfo Canlı Swap & CoW Raporlaması
  const memInfoWithSwap = readDynamicNodeContent(root, '/proc/meminfo', {
    frames: allocAfterSwap.frames,
    swapSlots: swapPool,
    processes: [],
    uptimeSec: 99,
  });
  check(
    '/proc/meminfo Canlı Swap & CoW Metrikleri',
    Boolean(
      memInfoWithSwap &&
        memInfoWithSwap.includes('SwapTotal:') &&
        /SwapUsed:\s+64 MB/.test(memInfoWithSwap) &&
        memInfoWithSwap.includes('CoWSaved:')
    ),
    '/proc/meminfo SwapTotal, SwapUsed (64 MB) ve CoWSaved değerlerini canlı raporladı'
  );

  // 19. vfsEnsureDir & Yeni Paket Uygulamaları Sandbox Yalıtımı
  const kanbanSandboxReady = getNodeAtPath(provisionedRoot, '/home/misafir/.sandbox/pkg-kanban');
  const ensured = vfsEnsureDir(provisionedRoot, '/home/misafir/.sandbox/custom-pkg/cache/sub', {
    user: 'misafir',
  });
  const nestedNode = getNodeAtPath(ensured, '/home/misafir/.sandbox/custom-pkg/cache/sub');
  const kanbanSandboxCheck = checkSandboxSyscall(
    'pkg-kanban',
    'write',
    '/home/misafir/.sandbox/pkg-kanban/board.json',
    'misafir',
    {}
  );
  check(
    'vfsEnsureDir & Paket Sandbox Otomatik Hazırlığı',
    Boolean(kanbanSandboxReady && nestedNode && nestedNode.type === 'dir' && kanbanSandboxCheck.allowed),
    'Yeni paket uygulamaları için özyinelemeli sandbox dizini ve yazma yetkisi doğrulandı'
  );

  // 20. Paket Merkezi & Uygulama Bildirimi Bütünlüğü
  const uniqueAppIds = new Set(PACKAGE_REGISTRY.map((p) => p.appId));
  const uniquePkgNames = new Set(PACKAGE_REGISTRY.map((p) => p.pkgName));
  const allManifestsValid = PACKAGE_REGISTRY.every(
    (p) => APP_MANIFESTS[p.appId] && APP_MANIFESTS[p.appId].isPackage === true
  );
  check(
    'Paket Merkezi & Manifest Bütünlüğü',
    PACKAGE_REGISTRY.length === 12 &&
      uniqueAppIds.size === PACKAGE_REGISTRY.length &&
      uniquePkgNames.size === PACKAGE_REGISTRY.length &&
      allManifestsValid,
    `${PACKAGE_REGISTRY.length} paket (oyun/verimlilik/geliştirici/araçlar) tüm manifestlerle tutarlı`
  );

  // 21. CSS Token & Çoklu Vurgu Paleti (5 Accent × 2 Mod)
  const accentKeys = Object.keys(ACCENT_PALETTES) as AccentColor[];
  const lightAccentHexes = new Set(accentKeys.map((a) => applyThemePalette('light', a).accent));
  const darkAccentHexes = new Set(accentKeys.map((a) => applyThemePalette('dark', a).accent));
  const distinctLightVsDark =
    THEME_PALETTES.light.bg !== THEME_PALETTES.dark.bg &&
    THEME_PALETTES.light.surface !== THEME_PALETTES.dark.surface &&
    THEME_PALETTES.light.text !== THEME_PALETTES.dark.text &&
    THEME_PALETTES.light.terminalBg !== THEME_PALETTES.dark.terminalBg &&
    THEME_PALETTES.light.terminalFg !== THEME_PALETTES.dark.terminalFg;
  applyThemePalette('dark', 'sky');
  check(
    'CSS Token & Çoklu Vurgu Paleti (5 Accent × 2 Mod)',
    distinctLightVsDark && lightAccentHexes.size === 5 && darkAccentHexes.size === 5,
    'Aydınlık/Karanlık yüzey + terminal tokenları ayrık ve 5 vurgu paletinin tümü üretildi'
  );

  // 22. Tema Tercihi Kalıcılığı & Güvenli Fallback
  const hydratedFallback = hydrateThemeFromStorage('ankaos_nonexistent_key_v33');
  check(
    'Tema Tercihi Kalıcılığı & Güvenli Fallback',
    hydratedFallback.theme === 'dark' && hydratedFallback.accent === 'sky',
    'Kayıtsız/bozuk tema anahtarında varsayılan (dark/sky) paleti güvenli yüklendi'
  );

  // 23. VFS Sistem Sürümü Bütünlüğü (/etc/os-release)
  const osRelease = readDynamicNodeContent(root, '/etc/os-release');
  check(
    'VFS Sistem Sürümü Bütünlüğü (/etc/os-release)',
    Boolean(osRelease && osRelease.includes('VERSION="3.5.0 (Kuzgun)"')),
    '/etc/os-release VERSION="3.5.0 (Kuzgun)" doğrulandı'
  );

  // 24. Çoklu Kullanıcı /home/$USER İzolasyonu
  let multiUserRoot = provisionUserHome(root, 'alice');
  multiUserRoot = provisionUserHome(multiUserRoot, 'bob');
  const aliceWriteBobDenied = vfsWriteFile(
    multiUserRoot,
    '/home/bob/Belgeler/gizli.txt',
    'yetkisiz',
    'text/plain',
    { user: 'alice', elevatedRoot: false }
  );
  const bobWriteOwnAllowed = vfsWriteFile(
    multiUserRoot,
    '/home/bob/Belgeler/kendi.txt',
    'izinli',
    'text/plain',
    { user: 'bob', elevatedRoot: false }
  );
  check(
    'Çoklu Kullanıcı /home/$USER İzolasyonu',
    !aliceWriteBobDenied.ok && bobWriteOwnAllowed.ok,
    'alice /home/bob dizinine izinsiz yazamadı; bob kendi ev dizinine yazabildi'
  );

  // 25. WebAssembly (.wasm) İkili Doğrulama ve Gerçek Çalıştırma
  const wasmBytes = buildSampleMathWasmBytes();
  const wasmNode = getNodeAtPath(root, '/home/kullanici/Projeler/topla.wasm');
  const wasmAdd = wasmNode?.content
    ? await runWasmBinary(wasmNode.content, 'add', [19, 23])
    : { ok: false, invoked: undefined };
  const wasmSquare = wasmNode?.content
    ? await runWasmBinary(wasmNode.content, 'square', [7])
    : { ok: false, invoked: undefined };
  check(
    'WebAssembly (.wasm) Doğrulama & Çalıştırma',
    WebAssembly.validate(wasmBytes) &&
      wasmAdd.ok &&
      wasmAdd.invoked?.result === 42 &&
      wasmSquare.ok &&
      wasmSquare.invoked?.result === 49,
    `topla.wasm: add(19,23)=${String(wasmAdd.invoked?.result)}, square(7)=${String(wasmSquare.invoked?.result)}`
  );

  // 26. Ring 3 İzole JS Sandbox & Global API Maskeleme
  const sandboxExec = executeSandboxedJS(
    'console.log(typeof window, typeof localStorage, typeof fetch, 6 * 7);',
    { timeoutMs: 1500 }
  );
  const sandboxRes = await sandboxExec.promise;
  check(
    'Ring 3 JS Sandbox & Global Yalıtım',
    sandboxRes.ok &&
      sandboxRes.logs.some((l) => l.includes('undefined undefined undefined 42')),
    `window/localStorage/fetch maskelendi -> çıktı: ${sandboxRes.logs[0] || '-'}`
  );

  // 27. ankash Komut Zincirleme (&&, ||, ;) & Tırnak Koruması
  const chain = splitCommandChain('mkdir test && echo "a && b" || echo hata; pwd');
  check(
    'ankash Komut Zincirleme (&&, ||, ;)',
    chain.length === 4 &&
      chain[0].cmd === 'mkdir test' &&
      chain[0].opAfter === '&&' &&
      chain[1].cmd === 'echo "a && b"' &&
      chain[1].opAfter === '||' &&
      chain[2].cmd === 'echo hata' &&
      chain[2].opAfter === ';' &&
      chain[3].cmd === 'pwd',
    '4 zincir segmenti tırnak içi && korunarak ayrıştırıldı'
  );

  // 28. VFS Atomik Taşıma (vfsMoveNode) & Döngü Koruması
  let moveRoot = vfsMkdir(root, '/home/kullanici/kutu').root;
  moveRoot = vfsWriteFile(moveRoot, '/home/kullanici/tasinacak.txt', 'merhaba').root;
  const movedOk = vfsMoveNode(moveRoot, '/home/kullanici/tasinacak.txt', '/home/kullanici/kutu');
  const blockedSelfMove = vfsMoveNode(
    movedOk.root,
    '/home/kullanici/kutu',
    '/home/kullanici/kutu/alt'
  );
  check(
    'VFS Atomik Taşıma & Alt-Klasör Koruması',
    movedOk.ok &&
      getNodeAtPath(movedOk.root, '/home/kullanici/tasinacak.txt') === null &&
      getNodeAtPath(movedOk.root, '/home/kullanici/kutu/tasinacak.txt')?.content === 'merhaba' &&
      !blockedSelfMove.ok,
    'Dosya taşındı ve bir klasörün kendi içine taşınması engellendi'
  );

  // 29. Çöp Kutusu (.Trash) Taşıma, Geri Yükleme & Boşaltma
  let trashRoot = vfsWriteFile(root, '/home/kullanici/Belgeler/gecici.txt', 'silinecek').root;
  const trashed = vfsMoveToTrash(trashRoot, '/home/kullanici/Belgeler/gecici.txt', '/home/kullanici');
  const restored = trashed.trashName
    ? vfsRestoreFromTrash(trashed.root, trashed.trashName, '/home/kullanici')
    : { ok: false, root: trashed.root };
  const trashedAgain = vfsMoveToTrash(restored.root, '/home/kullanici/Belgeler/gecici.txt', '/home/kullanici');
  const emptied = vfsEmptyTrash(trashedAgain.root, '/home/kullanici');
  const trashNodeAfterEmpty = getNodeAtPath(emptied.root, '/home/kullanici/.Trash');
  check(
    'Çöp Kutusu (.Trash) Taşı, Geri Yükle & Boşalt',
    trashed.ok &&
      getNodeAtPath(trashed.root, '/home/kullanici/Belgeler/gecici.txt') === null &&
      restored.ok &&
      getNodeAtPath(restored.root, '/home/kullanici/Belgeler/gecici.txt')?.content === 'silinecek' &&
      emptied.ok &&
      Object.keys(trashNodeAfterEmpty?.children || {}).length === 0,
    'gecici.txt .Trash dizinine taşındı, özgün konumuna geri yüklendi ve çöp boşaltıldı'
  );

  // 30. Varsayılan ~/.ankashrc & Çoklu Dil Sözdizimi Algılama
  const defaultRc = getNodeAtPath(root, '/home/kullanici/.ankashrc');
  const guestRc = getNodeAtPath(provisionedRoot, '/home/misafir/.ankashrc');
  check(
    '~/.ankashrc Başlangıç & Sözdizimi Renklendirme Algılama',
    Boolean(defaultRc?.content?.includes('alias ll=')) &&
      Boolean(guestRc?.content?.includes('alias ll=')) &&
      detectLanguageFromPath('app.js') === 'js' &&
      detectLanguageFromPath('index.html') === 'html' &&
      detectLanguageFromPath('.ankashrc') === 'sh' &&
      detectLanguageFromPath('snap.json') === 'json',
    'Varsayılan .ankashrc aliasları ve JS/HTML/Shell/JSON dil algılama doğrulandı'
  );

  // 31. WAT -> WASM Hızlı Derleme & Döngü/Koşul Çalıştırma (factorial & fibonacci)
  const mathCompiled = compileWatToWasm(WASM_TEMPLATES[0].wat);
  const fibCompiled = compileWatToWasm(WASM_TEMPLATES[1].wat);
  const factRun =
    mathCompiled.ok && mathCompiled.base64Content
      ? await runWasmBinary(mathCompiled.base64Content, 'factorial', [5])
      : { ok: false, invoked: undefined };
  const fibRun =
    fibCompiled.ok && fibCompiled.base64Content
      ? await runWasmBinary(fibCompiled.base64Content, 'fibonacci', [10])
      : { ok: false, invoked: undefined };
  check(
    'WAT -> WASM Derleyici & Kontrol Akışı (factorial/fibonacci)',
    Boolean(
      mathCompiled.ok &&
        mathCompiled.bytes &&
        WebAssembly.validate(mathCompiled.bytes) &&
        fibCompiled.ok &&
        fibCompiled.bytes &&
        WebAssembly.validate(fibCompiled.bytes) &&
        factRun.ok &&
        factRun.invoked?.result === 120 &&
        fibRun.ok &&
        fibRun.invoked?.result === 55
    ),
    `factorial(5)=${String(factRun.invoked?.result)}, fibonacci(10)=${String(fibRun.invoked?.result)} (${mathCompiled.compileTimeMs} ms)`
  );

  // 32. WAT Lineer Bellek & Statik Veri Segmenti (memory + data)
  const memCompiled = compileWatToWasm(WASM_TEMPLATES[2].wat);
  const expectedStrBytes = new TextEncoder().encode('AnkaOS Ring 3 WebAssembly Bellek Tamponu').length;
  const memRun =
    memCompiled.ok && memCompiled.base64Content
      ? await runWasmWithMemoryPreview(memCompiled.base64Content, 'strlen', [0])
      : { ok: false, invoked: undefined, memoryText: undefined };
  check(
    'WASM Lineer Bellek & Statik Data Segmenti',
    Boolean(
      memCompiled.ok &&
        memRun.ok &&
        memRun.invoked?.result === expectedStrBytes &&
        memRun.memoryText?.includes('AnkaOS Ring 3 WebAssembly')
    ),
    `strlen(0)=${String(memRun.invoked?.result)} bayt, bellek okundu: "${memRun.memoryText || ''}"`
  );

  // 33. .ankawasm Modül Paketleme, SHA-256 & VFS Doğrudan Çalıştırma
  const pkgBuild =
    mathCompiled.ok && mathCompiled.bytes
      ? await packageWasmModule({
          name: 'anka-math',
          version: '1.2.0',
          author: 'kullanici',
          wasmContentOrBytes: mathCompiled.bytes,
          watSource: WASM_TEMPLATES[0].wat,
          exports: mathCompiled.exports,
          entryFn: 'factorial',
        })
      : { ok: false, json: undefined, manifest: undefined };
  const pkgWrite = pkgBuild.json
    ? vfsWriteFile(root, '/home/kullanici/Projeler/anka-math.ankawasm', pkgBuild.json)
    : { ok: false, root };
  const pkgVfsNode = getNodeAtPath(pkgWrite.root, '/home/kullanici/Projeler/anka-math.ankawasm');
  const pkgParsed = pkgVfsNode?.content
    ? (JSON.parse(pkgVfsNode.content) as AnkaWasmPackageManifest)
    : null;
  const pkgExec = pkgVfsNode?.content
    ? await runWasmOrPackageFromVfsContent(pkgVfsNode.content, 'factorial', [6])
    : { ok: false, invoked: undefined };
  check(
    '.ankawasm Modül Paketleme & VFS Yürütme',
    Boolean(
      pkgBuild.ok &&
        pkgWrite.ok &&
        pkgParsed?.schema === 'ankaos-wasm-pkg-v1' &&
        (pkgParsed?.sha256.length || 0) >= 8 &&
        pkgExec.ok &&
        pkgExec.invoked?.result === 720
    ),
    `Paket SHA256=${pkgParsed?.sha256.slice(0, 12)}…, factorial(6)=${String(pkgExec.invoked?.result)}`
  );

  // 34. WASM Studio (wasm-builder) Entegrasyonu & .wat Renklendirme
  const starterWat = getNodeAtPath(root, '/home/kullanici/Projeler/merhaba.wat');
  const binWasmc = getNodeAtPath(root, '/bin/wasmc');
  const binWasmpkg = getNodeAtPath(root, '/bin/wasmpkg');
  check(
    'WASM Studio (wasm-builder) & VFS Araç Zinciri',
    Boolean(
      APP_MANIFESTS['wasm-builder'] &&
        starterWat?.type === 'file' &&
        binWasmc?.type === 'file' &&
        binWasmpkg?.type === 'file' &&
        detectLanguageFromPath('modul.wat') === 'wat' &&
        detectLanguageFromPath('modul.ankawasm') === 'json'
    ),
    'wasm-builder manifesti, ~/Projeler/merhaba.wat, /bin/wasmc & /bin/wasmpkg doğrulandı'
  );

  // 35. ankactl Servis Yönetimi & Cron Zamanlayıcı
  const initSvcs = createInitialServices();
  const stopEssential = controlServiceUnit(initSvcs, 'anka-init', 'stop');
  const stopNetd = controlServiceUnit(initSvcs, 'netd', 'stop');
  const restartNetd = controlServiceUnit(stopNetd.services, 'netd', 'restart');
  const cronTask = createCronJob('Yedek Kontrol', 45, 'fsck --quick');
  check(
    'ankactl Servis Yaşam Döngüsü & Cron Motoru',
    !stopEssential.ok &&
      stopNetd.ok &&
      stopNetd.unit?.status === 'inactive' &&
      restartNetd.ok &&
      restartNetd.unit?.status === 'active' &&
      restartNetd.unit?.restarts === 1 &&
      cronTask.intervalSec === 45 &&
      cronTask.enabled,
    'Kritik servis durdurma koruması, netd restart sayacı ve cron görev oluşturma doğrulandı'
  );

  // 36. Depolama (du), VFS Bütünlük Onarımı (fsck) & .ankatar Arşivleme (tar)
  const duReport = computeDiskUsage(root, '/home/kullanici');
  const brokenRoot = vfsDelete(root, '/home/kullanici/İndirilenler').root;
  const fsckRes = runVfsFsck(brokenRoot, '/home/kullanici', 'kullanici', true);
  const tarPack = createAnkaArchive(fsckRes.root, '/home/kullanici/Belgeler');
  const tarUnpack = tarPack.json
    ? extractAnkaArchive(fsckRes.root, tarPack.json, '/tmp')
    : { ok: false, root: fsckRes.root };
  check(
    'Depolama (du), fsck Onarımı & .ankatar Arşivleme (tar)',
    Boolean(
      duReport &&
        duReport.totalFiles >= 5 &&
        fsckRes.report.issuesFound >= 1 &&
        fsckRes.report.repairedCount >= 1 &&
        getNodeAtPath(fsckRes.root, '/home/kullanici/İndirilenler') !== null &&
        tarPack.ok &&
        tarUnpack.ok &&
        getNodeAtPath(tarUnpack.root, '/tmp/Belgeler/Notlar/Hoş_Geldiniz.txt') !== null
    ),
    `du=${duReport?.totalBytes || 0} B, fsck ${fsckRes.report.repairedCount} onarım, tar->/tmp/Belgeler doğrulandı`
  );

  // 37. Güç Profili Zamanlayıcı Kuantumu & ~/İndirilenler
  const perfStep = stepScheduler(
    mockProcs,
    createInitialSchedulerStats(),
    2,
    POWER_PROFILE_META.performance.quantumMs
  );
  const saverStep = stepScheduler(
    mockProcs,
    createInitialSchedulerStats(),
    2,
    POWER_PROFILE_META.powersaver.quantumMs
  );
  check(
    'Güç Profili Kuantumu (25/50/100 ms) & ~/İndirilenler',
    perfStep.stats.quantumMs === 25 &&
      saverStep.stats.quantumMs === 100 &&
      getNodeAtPath(root, '/home/kullanici/İndirilenler')?.type === 'dir',
    'Yüksek Performans=25ms, Güç Tasarrufu=100ms kuantum ve ~/İndirilenler dizini doğrulandı'
  );

  // 38. İnternet Köprüsü URL & SSRF Güvenlik Doğrulaması
  const validWiki = validateExternalUrl('https://tr.wikipedia.org/wiki/Anka');
  const blockedLocalhost = validateExternalUrl('http://127.0.0.1:3000/secret');
  const blockedMeta = validateExternalUrl('http://169.254.169.254/latest/meta-data');
  const blockedProto = validateExternalUrl('file:///etc/passwd');
  check(
    'İnternet Köprüsü URL & SSRF Engelleme Politikası',
    validWiki.ok && !blockedLocalhost.ok && !blockedMeta.ok && !blockedProto.ok,
    'Genel HTTPS URL kabul edildi; loopback, metadata (169.254.*) ve file:// engellendi'
  );

  // 39. 4-Köşe Çeyrek Pencere Yerleşimi & Sıcak Köşe Algılama
  const tlRect = computeWindowRect({ x: 0, y: 0, width: 400, height: 300, snap: 'top-left', zIndex: 1 }, 1280, 800);
  const trRect = computeWindowRect({ x: 0, y: 0, width: 400, height: 300, snap: 'top-right', zIndex: 1 }, 1280, 800);
  const blRect = computeWindowRect({ x: 0, y: 0, width: 400, height: 300, snap: 'bottom-left', zIndex: 1 }, 1280, 800);
  const brRect = computeWindowRect({ x: 0, y: 0, width: 400, height: 300, snap: 'bottom-right', zIndex: 1 }, 1280, 800);
  const zTL = detectEdgeSnapZone(12, 48, 1280, 800);
  const zBR = detectEdgeSnapZone(1265, 760, 1280, 800);
  check(
    '4-Köşe Çeyrek Pencere Yerleşimi (Window Tiling)',
    tlRect.x === 8 &&
      trRect.x > tlRect.x &&
      blRect.y > tlRect.y &&
      brRect.x === trRect.x &&
      brRect.y === blRect.y &&
      zTL === 'top-left' &&
      zBR === 'bottom-right',
    `4 çeyrek koordinatı (TL=${tlRect.width}x${tlRect.height}) ve köşe sıcak bölgeleri doğrulandı`
  );

  // 40. Satır Diff Algoritması & İç İçe VFS Yol Tamamlama
  const diffRes = computeLineDiff('satir 1\nsatir 2\nsatir 3', 'satir 1\nsatir 2b\nsatir 3\nsatir 4', 'a.txt', 'b.txt');
  const tabMatch = resolveTabCompletion('cat ~/Proj', '/home/kullanici', '/home/kullanici', root, ['cat', 'ls'], {});
  const nestedTabMatch = resolveTabCompletion('cat ~/Projeler/merhaba.w', '/home/kullanici', '/home/kullanici', root, ['cat'], {});
  check(
    'Kabuk Diff & İç İçe VFS Tab Tamamlama',
    !diffRes.identical &&
      diffRes.added === 2 &&
      diffRes.removed === 1 &&
      tabMatch === 'cat ~/Projeler/' &&
      nestedTabMatch === 'cat ~/Projeler/merhaba.wat',
    `diff (+${diffRes.added}/-${diffRes.removed}) ve Tab tamamlama (${nestedTabMatch || '-'}) doğrulandı`
  );

  // 41. .ankasynth Parça Serileştirme & Şema Doğrulama
  const synthJson = serializeAnkaSynthTrack({
    id: 'test-track',
    title: 'Anka Test Melodisi',
    bpm: 128,
    waveform: 'triangle',
    notes: [261.63, 329.63, 392.0, 523.25],
  });
  const parsedSynth = parseAnkaSynthTrack(synthJson);
  const invalidSynth = parseAnkaSynthTrack('{"schema":"bozuk","notes":[]}');
  check(
    '.ankasynth Sentez Şeması & Ayrıştırıcı',
    parsedSynth.ok &&
      parsedSynth.track?.bpm === 128 &&
      parsedSynth.track?.waveform === 'triangle' &&
      parsedSynth.track?.notes.length === 4 &&
      !invalidSynth.ok,
    'ankaos-synth-v1 JSON doğrulandı ve geçersiz şema reddedildi'
  );

  // 42. Dinamik Öncelik (renice) & Ön Plan Boost Sıralaması
  const lowPriProc: OSProcess = { ...mockProcs[0], pid: 401, priority: 10 };
  const highPriProc: OSProcess = { ...mockProcs[1], pid: 402, priority: -5 };
  const effNormal = getEffectivePriority(lowPriProc, null);
  const effBoosted = getEffectivePriority(lowPriProc, 401);
  const priStep = stepScheduler([lowPriProc, highPriProc], createInitialSchedulerStats(), null);
  check(
    'Süreç Önceliği (renice) & Ön Plan Boost',
    effBoosted < effNormal && priStep.stats.activePid === 402,
    `PID 402 (pri=-5) ön plansız PID 401 (pri=10) önüne geçti; FG boost (${effNormal} -> ${effBoosted})`
  );

  // 43. AnkaArama Akıllı Sorgu Ayrıştırıcı & Yerel VFS Arama
  const qMath = parseSmartQuery('sqrt(144) + 8');
  const qUnit = parseSmartQuery('100 km -> mil');
  const qColor = parseSmartQuery('#0ea5e9');
  const qBang = parseSmartQuery('!gh rust kernel');
  const vfsSearchHits = searchLocalVfs(root, '/home/kullanici', 'merhaba');
  check(
    'AnkaArama Akıllı Sorgu & Yerel VFS Arama',
    Boolean(
      qMath?.kind === 'math' &&
        qMath.value === '= 20' &&
        qUnit?.kind === 'unit' &&
        qUnit.value.includes('62.1371') &&
        qColor?.kind === 'color' &&
        qColor.subtitle?.includes('rgb(14, 165, 233)') &&
        qBang?.kind === 'bang' &&
        qBang.categoryOverride === 'dev' &&
        vfsSearchHits.some((h) => h.name === 'merhaba.wat')
    ),
    `Matematik (${qMath?.value}), Birim (${qUnit?.value}), Renk, !gh Bang ve ${vfsSearchHits.length} VFS eşleşmesi doğrulandı`
  );

  // 44. WASM Performans Profili & Flamegraph Motoru
  const fibCompile = compileWatToWasm(WASM_TEMPLATES[1].wat);
  const fibProf =
    fibCompile.ok && fibCompile.base64Content
      ? await profileWasmExecution({
          content: fibCompile.base64Content,
          moduleName: 'fibonacci.wasm',
          fnName: 'fibonacci',
          args: [10],
          iterations: 60,
        })
      : { ok: false as const, error: 'compile failed' };
  const fibAscii = fibProf.ok ? renderAsciiFlameSummary(fibProf.report) : '';
  check(
    'WASM Performans Profili & Flamegraph',
    Boolean(
      fibProf.ok &&
        fibProf.report.resultText === '55' &&
        fibProf.report.flameRoot.children.length >= 3 &&
        fibProf.report.functionStats.some((f) => f.name === 'fibonacci' && f.loopCount >= 1) &&
        fibProf.report.timelineSamplesUs.length > 0 &&
        fibAscii.includes('Hotspot')
    ),
    fibProf.ok
      ? `fibonacci(10)=55 · ort ${fibProf.report.metrics.hotAvgUs} µs · ${fibProf.report.functionStats.length} fn analiz edildi`
      : 'WASM profiler başarısız'
  );

  // 45. WASI Preview 1 (fd_write / proc_exit) & _start Yürütme
  const wasiTemplate = WASM_TEMPLATES.find((t) => t.id === 'wasi');
  const wasiCompiled = wasiTemplate ? compileWatToWasm(wasiTemplate.wat) : { ok: false };
  const wasiRun =
    wasiCompiled.ok && 'base64Content' in wasiCompiled && wasiCompiled.base64Content
      ? await runWasmBinary(wasiCompiled.base64Content)
      : { ok: false, stdoutText: undefined };
  const wasiProf =
    wasiCompiled.ok && 'base64Content' in wasiCompiled && wasiCompiled.base64Content
      ? await profileWasmExecution({
          content: wasiCompiled.base64Content,
          moduleName: 'wasi_merhaba.wasm',
          iterations: 20,
        })
      : { ok: false as const };
  check(
    'WASI Preview 1 (fd_write / proc_exit)',
    Boolean(
      wasiCompiled.ok &&
        wasiRun.ok &&
        wasiRun.stdoutText?.includes('AnkaOS WASI Preview 1 Merhaba Dunya!') &&
        wasiProf.ok
    ),
    wasiRun.ok && wasiRun.stdoutText
      ? `WASI stdout yakalandı: "${wasiRun.stdoutText.trim()}"`
      : 'WASI stdout yakalanamadı'
  );

  // 46. ankash Değişken Genişletme ($VAR / $?) & if/for Akış Kontrolü
  const expandedEnv = expandShellVariables('user=$USER exit=$? home=$HOME', { CUSTOM: '42' }, {
    cwd: '/home/kullanici/Projeler',
    user: 'kullanici',
    homeDir: '/home/kullanici',
    lastExit: 0,
  });
  const ifForRes = evaluateIfForScript(
    'if [ -d ~/Projeler ]; then\n  for x in alfa beta; do\n    echo $x\n  done\nelse\n  echo yok\nfi',
    root,
    {},
    { cwd: '/home/kullanici', user: 'kullanici', homeDir: '/home/kullanici', lastExit: 0 }
  );
  check(
    'ankash $VAR/$? & if/for Akış Kontrolü',
    expandedEnv === 'user=kullanici exit=0 home=/home/kullanici' &&
      ifForRes.ok &&
      ifForRes.commands.length === 2 &&
      ifForRes.commands[0] === 'echo alfa' &&
      ifForRes.commands[1] === 'echo beta',
    `Değişken genişletme + if/for akışı (${ifForRes.commands.join(' | ')}) doğrulandı`
  );

  // 47. Genişletilmiş 12 Uygulamalı Paket Merkezi & DND/Masaüstü Ayarları
  const newPkgIds = ['pkg-calendar', 'pkg-markdown', 'pkg-recorder', 'pkg-nettools', 'pkg-diff'] as const;
  const newManifestsOk = newPkgIds.every((id) => APP_MANIFESTS[id]?.isPackage === true);
  check(
    '12 Uygulamalı Paket Merkezi & Yeni Manifestler',
    PACKAGE_REGISTRY.length === 12 && newManifestsOk,
    'Takvim, Markdown Okuyucu, Ses Kaydedici, Ağ Analiz ve Diff İnceleyici manifestleri doğrulandı'
  );

  // 48. IndexedDB Depolama & Web Worker Daemon Modülleri
  const idbExportsOk = typeof idbGet === 'function' && typeof idbPut === 'function';
  const daemonCtl = startDaemonWorker(() => {});
  daemonCtl.stop();
  check(
    'IndexedDB Depolama & ankad Web Worker Modülü',
    idbExportsOk && typeof startDaemonWorker === 'function',
    'idbGet/idbPut ve startDaemonWorker güvenli başlatma/durdurma yaşam döngüsü doğrulandı'
  );

  // 49. ~/Müzik Dizini, Ses MIME Çıkarımı & fsck Onarımı
  const muzikDir = getNodeAtPath(root, '/home/kullanici/Müzik');
  const starterSynthNode = getNodeAtPath(root, '/home/kullanici/Müzik/Kuzgun_Ambiyans.ankasynth');
  const parsedMuzikTrack = starterSynthNode?.type === 'file' ? parseAnkaSynthTrack(starterSynthNode.content || '') : null;
  const webmWrite = vfsWriteFile(root, '/home/kullanici/Müzik/kayit.webm', 'data:audio/webm;base64,AAA=');
  const wavWrite = vfsWriteFile(webmWrite.root, '/home/kullanici/Müzik/efekt.wav', 'data:audio/wav;base64,BBB=');
  const webmNode = getNodeAtPath(wavWrite.root, '/home/kullanici/Müzik/kayit.webm');
  const wavNode = getNodeAtPath(wavWrite.root, '/home/kullanici/Müzik/efekt.wav');
  const brokenMuzikRoot = vfsDelete(root, '/home/kullanici/Müzik').root;
  const repairedMuzik = runVfsFsck(brokenMuzikRoot, '/home/kullanici', 'kullanici', true);
  check(
    '~/Müzik Klasörü, Ses MIME Çıkarımı & fsck Onarımı',
    muzikDir?.type === 'dir' &&
      parsedMuzikTrack !== null &&
      webmWrite.ok &&
      wavWrite.ok &&
      webmNode?.mimeType === 'audio/webm' &&
      wavNode?.mimeType === 'audio/wav' &&
      getNodeAtPath(repairedMuzik.root, '/home/kullanici/Müzik')?.type === 'dir',
    '~/Müzik, Kuzgun_Ambiyans.ankasynth, audio/webm + audio/wav MIME ve fsck onarımı doğrulandı'
  );

  // 50. ~/Müzik & ~/İndirilenler Sandbox Koruması
  const denyMuzik = checkSandboxSyscall('media', 'write', '/home/kullanici/Müzik/deneme.webm', 'kullanici', {});
  const allowMuzik = checkSandboxSyscall('media', 'write', '/home/kullanici/Müzik/deneme.webm', 'kullanici', {
    media: ['docs:rw'],
  });
  const denyDl = checkSandboxSyscall('browser', 'write', '/home/kullanici/İndirilenler/a.txt', 'kullanici', {});
  const allowDl = checkSandboxSyscall('browser', 'write', '/home/kullanici/İndirilenler/a.txt', 'kullanici', {
    browser: ['docs:rw'],
  });
  check(
    '~/Müzik & ~/İndirilenler Sandbox Koruması',
    !denyMuzik.allowed &&
      denyMuzik.requiresPrompt &&
      allowMuzik.allowed &&
      !denyDl.allowed &&
      denyDl.requiresPrompt &&
      allowDl.allowed,
    '~/Müzik ve ~/İndirilenler docs:rw izni olmadan engellendi, izin verilince açıldı'
  );

  return results;
}
