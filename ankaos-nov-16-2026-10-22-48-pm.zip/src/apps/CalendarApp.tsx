import React, { useMemo, useState } from 'react';
import { Calendar as CalendarIcon, CheckCircle2, ChevronLeft, ChevronRight, Plus, Trash2 } from 'lucide-react';
import { useOS } from '../os/kernel';
import { getNodeAtPath, HOME_PATH } from '../os/vfs';

interface CalendarEvent {
  id: string;
  date: string; // YYYY-MM-DD
  time: string;
  title: string;
  done: boolean;
}

const STORAGE_REL = '.sandbox/pkg-calendar/events.json';

function toDateKey(y: number, m: number, d: number): string {
  return `${y}-${String(m + 1).padStart(2, '0')}-${String(d).padStart(2, '0')}`;
}

export const CalendarApp: React.FC<{ windowId: string }> = () => {
  const { vfs, writeFile, currentUser, settings } = useOS();
  const tr = settings.language === 'tr';
  const userHome = currentUser.homeDir || HOME_PATH;
  const storePath = `${userHome}/${STORAGE_REL}`;

  const today = new Date();
  const todayKey = toDateKey(today.getFullYear(), today.getMonth(), today.getDate());

  const [viewYear, setViewYear] = useState(today.getFullYear());
  const [viewMonth, setViewMonth] = useState(today.getMonth());
  const [selectedDate, setSelectedDate] = useState(todayKey);
  const [titleInput, setTitleInput] = useState('');
  const [timeInput, setTimeInput] = useState('14:00');

  const [events, setEvents] = useState<CalendarEvent[]>(() => {
    const node = getNodeAtPath(vfs, storePath);
    if (node?.type === 'file' && node.content) {
      try {
        const parsed = JSON.parse(node.content) as CalendarEvent[];
        if (Array.isArray(parsed)) return parsed;
      } catch {
        // fallback below
      }
    }
    return [
      {
        id: 'ev-1',
        date: todayKey,
        time: '10:00',
        title: tr ? 'AnkaKernel Sistem Kontrolü' : 'AnkaKernel System Review',
        done: false,
      },
    ];
  });

  const persist = (next: CalendarEvent[]) => {
    setEvents(next);
    writeFile(storePath, JSON.stringify(next, null, 2), 'application/json', false, 'pkg-calendar');
  };

  const handleAddEvent = (e: React.FormEvent) => {
    e.preventDefault();
    const clean = titleInput.trim();
    if (!clean) return;
    const item: CalendarEvent = {
      id: `ev-${Date.now()}`,
      date: selectedDate,
      time: timeInput || '09:00',
      title: clean,
      done: false,
    };
    persist([...events, item]);
    setTitleInput('');
  };

  const monthDays = useMemo(() => {
    const firstDay = new Date(viewYear, viewMonth, 1);
    const totalDays = new Date(viewYear, viewMonth + 1, 0).getDate();
    // Monday = 0 ... Sunday = 6
    const offset = (firstDay.getDay() + 6) % 7;
    const cells: Array<{ day: number | null; key: string }> = [];
    for (let i = 0; i < offset; i++) cells.push({ day: null, key: `pad-${i}` });
    for (let d = 1; d <= totalDays; d++) {
      cells.push({ day: d, key: toDateKey(viewYear, viewMonth, d) });
    }
    return cells;
  }, [viewYear, viewMonth]);

  const eventsByDate = useMemo(() => {
    const map = new Map<string, CalendarEvent[]>();
    for (const ev of events) {
      const list = map.get(ev.date) || [];
      list.push(ev);
      map.set(ev.date, list);
    }
    return map;
  }, [events]);

  const selectedEvents = useMemo(
    () =>
      (eventsByDate.get(selectedDate) || [])
        .slice()
        .sort((a, b) => a.time.localeCompare(b.time)),
    [eventsByDate, selectedDate]
  );

  const monthTitle = new Date(viewYear, viewMonth, 1).toLocaleDateString(tr ? 'tr-TR' : 'en-US', {
    month: 'long',
    year: 'numeric',
  });

  const weekdays = tr
    ? ['Pzt', 'Sal', 'Çar', 'Per', 'Cum', 'Cmt', 'Paz']
    : ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];

  const shiftMonth = (delta: number) => {
    const d = new Date(viewYear, viewMonth + delta, 1);
    setViewYear(d.getFullYear());
    setViewMonth(d.getMonth());
  };

  return (
    <div className="h-full w-full flex flex-col md:flex-row bg-[var(--anka-surface)] text-[var(--anka-text)] anka-theme-transition">
      {/* Left: Month Calendar Grid */}
      <div className="flex-1 p-5 flex flex-col min-w-0">
        <div className="flex items-center justify-between gap-2 mb-4">
          <div className="flex items-center gap-2">
            <CalendarIcon size={18} className="text-[var(--anka-accent)]" />
            <h2 className="text-base font-semibold font-display capitalize">{monthTitle}</h2>
          </div>
          <div className="flex items-center gap-1.5">
            <button
              onClick={() => shiftMonth(-1)}
              className="p-1.5 rounded-lg border border-[var(--anka-border)] hover:bg-[var(--anka-surface-elevated)]"
            >
              <ChevronLeft size={14} />
            </button>
            <button
              onClick={() => {
                setViewYear(today.getFullYear());
                setViewMonth(today.getMonth());
                setSelectedDate(todayKey);
              }}
              className="px-2.5 py-1 rounded-lg text-xs font-medium border border-[var(--anka-border)] hover:bg-[var(--anka-surface-elevated)]"
            >
              {tr ? 'Bugün' : 'Today'}
            </button>
            <button
              onClick={() => shiftMonth(1)}
              className="p-1.5 rounded-lg border border-[var(--anka-border)] hover:bg-[var(--anka-surface-elevated)]"
            >
              <ChevronRight size={14} />
            </button>
          </div>
        </div>

        <div className="grid grid-cols-7 gap-1.5 text-center text-[11px] font-medium text-[var(--anka-text-subtle)] pb-2">
          {weekdays.map((wd) => (
            <div key={wd}>{wd}</div>
          ))}
        </div>

        <div className="grid grid-cols-7 gap-1.5 flex-1 auto-rows-fr">
          {monthDays.map((cell) => {
            if (!cell.day) return <div key={cell.key} className="rounded-xl bg-transparent" />;
            const isSelected = cell.key === selectedDate;
            const isToday = cell.key === todayKey;
            const dayEvents = eventsByDate.get(cell.key) || [];
            return (
              <button
                key={cell.key}
                onClick={() => setSelectedDate(cell.key)}
                className={`rounded-xl p-2 flex flex-col items-start justify-between border text-left transition-colors ${
                  isSelected
                    ? 'border-[var(--anka-accent)] bg-[var(--anka-accent-soft)]'
                    : 'border-[var(--anka-border)] bg-[var(--anka-surface-muted)] hover:bg-[var(--anka-surface-elevated)]'
                }`}
              >
                <span
                  className={`text-xs font-mono tabular-nums ${
                    isToday
                      ? 'text-[var(--anka-accent)] font-bold underline underline-offset-4'
                      : 'text-[var(--anka-text)]'
                  }`}
                >
                  {cell.day}
                </span>
                {dayEvents.length > 0 && (
                  <span className="text-[10px] font-mono text-[var(--anka-accent)] tabular-nums">
                    {dayEvents.length} {tr ? 'plan' : 'ev'}
                  </span>
                )}
              </button>
            );
          })}
        </div>
      </div>

      {/* Right: Daily Agenda */}
      <aside className="w-full md:w-80 border-t md:border-t-0 md:border-l border-[var(--anka-border)] bg-[var(--anka-bg)] p-4 flex flex-col gap-3">
        <div>
          <div className="text-[11px] font-mono text-[var(--anka-text-subtle)] tabular-nums">
            {selectedDate}
          </div>
          <h3 className="text-sm font-semibold">
            {tr ? 'Günlük Ajanda & Etkinlikler' : 'Daily Agenda'}
          </h3>
        </div>

        <form onSubmit={handleAddEvent} className="space-y-2 text-xs">
          <div className="flex gap-1.5">
            <input
              type="time"
              value={timeInput}
              onChange={(e) => setTimeInput(e.target.value)}
              className="px-2 py-1.5 rounded-lg border border-[var(--anka-border-strong)] bg-[var(--anka-surface)] font-mono outline-none"
            />
            <input
              type="text"
              value={titleInput}
              onChange={(e) => setTitleInput(e.target.value)}
              placeholder={tr ? 'Yeni etkinlik...' : 'New event...'}
              className="flex-1 min-w-0 px-2.5 py-1.5 rounded-lg border border-[var(--anka-border-strong)] bg-[var(--anka-surface)] outline-none focus:border-[var(--anka-accent)]"
            />
          </div>
          <button
            type="submit"
            className="w-full flex items-center justify-center gap-1.5 py-1.5 rounded-lg bg-[var(--anka-accent)] text-[var(--anka-accent-fg)] font-medium hover:bg-[var(--anka-accent-hover)]"
          >
            <Plus size={13} />
            <span>{tr ? 'Ajandaya Ekle' : 'Add Event'}</span>
          </button>
        </form>

        <div className="flex-1 overflow-y-auto os-scroll space-y-2 text-xs">
          {selectedEvents.length === 0 ? (
            <div className="py-8 text-center text-[var(--anka-text-subtle)]">
              {tr ? 'Bu gün için planlanmış etkinlik yok.' : 'No events scheduled for this day.'}
            </div>
          ) : (
            selectedEvents.map((ev) => (
              <div
                key={ev.id}
                className="p-2.5 rounded-xl border border-[var(--anka-border)] bg-[var(--anka-surface)] flex items-center gap-2"
              >
                <button
                  onClick={() =>
                    persist(events.map((x) => (x.id === ev.id ? { ...x, done: !x.done } : x)))
                  }
                  className={ev.done ? 'text-emerald-500' : 'text-[var(--anka-text-subtle)]'}
                >
                  <CheckCircle2 size={15} />
                </button>
                <div className="min-w-0 flex-1">
                  <div className={`font-medium truncate ${ev.done ? 'line-through opacity-50' : ''}`}>
                    {ev.title}
                  </div>
                  <div className="text-[10px] font-mono text-[var(--anka-text-subtle)] tabular-nums">
                    {ev.time}
                  </div>
                </div>
                <button
                  onClick={() => persist(events.filter((x) => x.id !== ev.id))}
                  className="p-1 text-rose-500 hover:bg-rose-500/10 rounded"
                >
                  <Trash2 size={12} />
                </button>
              </div>
            ))
          )}
        </div>
      </aside>
    </div>
  );
};
