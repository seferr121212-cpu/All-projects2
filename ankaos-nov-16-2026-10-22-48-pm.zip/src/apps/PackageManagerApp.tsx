import React, { useMemo, useState } from 'react';
import { Download, Play, Search, Trash2 } from 'lucide-react';
import { AppIcon } from '../components/AppIcon';
import { useOS } from '../os/kernel';
import { PACKAGE_REGISTRY } from '../os/packages';

export const PackageManagerApp: React.FC<{ windowId: string }> = () => {
  const { installedPackages, installPackage, removePackage, launchApp, settings } = useOS();
  const tr = settings.language === 'tr';

  const [category, setCategory] = useState<string>('all');
  const [search, setSearch] = useState('');
  const [notice, setNotice] = useState<string | null>(null);

  const categories = useMemo(() => {
    const unique = Array.from(
      new Set(PACKAGE_REGISTRY.map((p) => (tr ? p.categoryTr : p.categoryEn)))
    );
    return [{ id: 'all', label: tr ? 'Tümü' : 'All' }, ...unique.map((c) => ({ id: c, label: c }))];
  }, [tr]);

  const filteredPackages = useMemo(() => {
    const q = search.trim().toLowerCase();
    return PACKAGE_REGISTRY.filter((pkg) => {
      const pkgCat = tr ? pkg.categoryTr : pkg.categoryEn;
      if (category !== 'all' && pkgCat !== category) return false;
      if (!q) return true;
      return (
        pkg.pkgName.toLowerCase().includes(q) ||
        pkg.nameTr.toLowerCase().includes(q) ||
        pkg.nameEn.toLowerCase().includes(q) ||
        pkg.descriptionTr.toLowerCase().includes(q)
      );
    });
  }, [category, search, tr]);

  const showNotice = (msg: string) => {
    setNotice(msg);
    setTimeout(() => setNotice(null), 2400);
  };

  return (
    <div className="h-full w-full flex flex-col bg-[var(--anka-surface)] text-[var(--anka-text)] anka-theme-transition">
      {/* Header & Controls */}
      <div className="px-6 py-4 border-b border-[var(--anka-border)] space-y-3 bg-[var(--anka-surface)]">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h2 className="text-lg font-semibold font-display">
              {tr ? 'AnkaOS Paket Merkezi' : 'AnkaOS Package Center'}
            </h2>
            <p className="text-xs text-[var(--anka-text-subtle)]">
              {tr
                ? 'Ek uygulamaları /bin dizinine kurun veya kaldırın. Uçbirimde "pkg" komutuyla da yönetebilirsiniz.'
                : 'Install or remove userland apps into /bin. Also manageable via the "pkg" CLI command.'}
            </p>
          </div>
          <div className="text-xs font-mono text-[var(--anka-text-subtle)] tabular-nums">
            {installedPackages.length} / {PACKAGE_REGISTRY.length} {tr ? 'kurulu' : 'installed'}
          </div>
        </div>

        <div className="flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-1 p-1 rounded-lg bg-[var(--anka-surface-muted)] border border-[var(--anka-border)] overflow-x-auto">
            {categories.map((cat) => (
              <button
                key={cat.id}
                onClick={() => setCategory(cat.id)}
                className={`px-3 py-1.5 text-xs font-medium rounded-md whitespace-nowrap transition-colors ${
                  category === cat.id
                    ? 'bg-[var(--anka-surface)] text-[var(--anka-text)] shadow-sm'
                    : 'text-[var(--anka-text-subtle)] hover:text-[var(--anka-text)]'
                }`}
              >
                {cat.label}
              </button>
            ))}
          </div>

          <div className="relative">
            <Search size={13} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-[var(--anka-text-subtle)]" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder={tr ? 'Paket ara...' : 'Search packages...'}
              className="w-48 pl-7 pr-3 py-1.5 text-xs rounded-lg border border-[var(--anka-border-strong)] bg-[var(--anka-surface-muted)] text-[var(--anka-text)] outline-none focus:border-[var(--anka-accent)]"
            />
          </div>
        </div>
      </div>

      {notice && (
        <div className="px-6 py-1.5 text-xs bg-[var(--anka-accent-soft)] text-[var(--anka-accent)] border-b border-[var(--anka-border)]">
          {notice}
        </div>
      )}

      {/* Package List */}
      <div className="flex-1 overflow-y-auto os-scroll p-6 space-y-3 bg-[var(--anka-bg)]">
        {filteredPackages.length === 0 ? (
          <div className="py-12 text-center text-xs text-[var(--anka-text-subtle)]">
            {tr ? 'Aramanızla eşleşen paket bulunamadı.' : 'No matching packages found.'}
          </div>
        ) : (
          filteredPackages.map((pkg) => {
            const isInstalled = installedPackages.includes(pkg.appId);
            return (
              <div
                key={pkg.pkgName}
                className="p-4 rounded-xl border border-[var(--anka-border)] bg-[var(--anka-surface)] flex flex-col sm:flex-row sm:items-center justify-between gap-4"
              >
                <div className="flex items-start gap-3">
                  <AppIcon appId={pkg.appId} size={20} />
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-semibold">
                        {tr ? pkg.nameTr : pkg.nameEn}
                      </span>
                      <span className="text-xs font-mono text-[var(--anka-text-subtle)]">v{pkg.version}</span>
                    </div>
                    <p className="text-xs text-[var(--anka-text-muted)]">
                      {tr ? pkg.descriptionTr : pkg.descriptionEn}
                    </p>
                    <div className="text-[11px] text-[var(--anka-text-subtle)] font-mono">
                      {pkg.pkgName} · {pkg.sizeKB} KB · {tr ? pkg.categoryTr : pkg.categoryEn} · {pkg.author}
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  {isInstalled ? (
                    <>
                      <button
                        onClick={() => launchApp(pkg.appId)}
                        className="flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs font-medium bg-emerald-600 text-white hover:bg-emerald-500 transition-colors"
                      >
                        <Play size={13} />
                        <span>{tr ? 'Başlat' : 'Launch'}</span>
                      </button>
                      <button
                        onClick={() => {
                          const res = removePackage(pkg.pkgName);
                          showNotice(res.message);
                        }}
                        className="flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs font-medium border border-rose-300 dark:border-rose-900 text-rose-600 dark:text-rose-400 hover:bg-rose-500/10 transition-colors"
                      >
                        <Trash2 size={13} />
                        <span>{tr ? 'Kaldır' : 'Remove'}</span>
                      </button>
                    </>
                  ) : (
                    <button
                      onClick={() => {
                        const res = installPackage(pkg.pkgName);
                        showNotice(res.message);
                      }}
                      className="flex items-center gap-1.5 px-4 py-2 rounded-lg text-xs font-medium bg-[var(--anka-accent)] text-[var(--anka-accent-fg)] hover:bg-[var(--anka-accent-hover)] transition-colors"
                    >
                      <Download size={13} />
                      <span>{tr ? 'Kur' : 'Install'}</span>
                    </button>
                  )}
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
