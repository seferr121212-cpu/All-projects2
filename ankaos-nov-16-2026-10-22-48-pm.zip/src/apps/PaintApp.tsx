import React, { useEffect, useRef, useState } from 'react';
import { Circle, Eraser, Minus, Pen, RotateCcw, Save, Square, Trash2 } from 'lucide-react';
import { useOS } from '../os/kernel';
import { HOME_PATH } from '../os/vfs';

type Tool = 'pen' | 'eraser' | 'line' | 'rect' | 'circle';

const PALETTE = [
  '#0f172a',
  '#f8fafc',
  '#0284c7',
  '#059669',
  '#d97706',
  '#dc2626',
  '#4f46e5',
  '#64748b',
];

export const PaintApp: React.FC<{ windowId: string }> = () => {
  const { writeFile, pushNotification, settings, currentUser } = useOS();
  const tr = settings.language === 'tr';
  const userHome = currentUser.homeDir || HOME_PATH;

  const canvasRef = useRef<HTMLCanvasElement>(null);
  const snapshotRef = useRef<ImageData | null>(null);
  const historyRef = useRef<ImageData[]>([]);

  const [tool, setTool] = useState<Tool>('pen');
  const [color, setColor] = useState('#0284c7');
  const [strokeWidth, setStrokeWidth] = useState(4);
  const [drawing, setDrawing] = useState(false);
  const [startPos, setStartPos] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
  const [fileName, setFileName] = useState('cizim_1.png');
  const [savedNotice, setSavedNotice] = useState<{ text: string; isError?: boolean } | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    historyRef.current = [ctx.getImageData(0, 0, canvas.width, canvas.height)];
  }, []);

  const getCoords = (e: React.PointerEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current!;
    const rect = canvas.getBoundingClientRect();
    return {
      x: ((e.clientX - rect.left) / rect.width) * canvas.width,
      y: ((e.clientY - rect.top) / rect.height) * canvas.height,
    };
  };

  const handlePointerDown = (e: React.PointerEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const pos = getCoords(e);
    setDrawing(true);
    setStartPos(pos);
    snapshotRef.current = ctx.getImageData(0, 0, canvas.width, canvas.height);

    if (tool === 'pen' || tool === 'eraser') {
      ctx.beginPath();
      ctx.moveTo(pos.x, pos.y);
      ctx.strokeStyle = tool === 'eraser' ? '#ffffff' : color;
      ctx.lineWidth = strokeWidth;
      ctx.lineCap = 'round';
      ctx.lineJoin = 'round';
    }
  };

  const handlePointerMove = (e: React.PointerEvent<HTMLCanvasElement>) => {
    if (!drawing) return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const pos = getCoords(e);

    if (tool === 'pen' || tool === 'eraser') {
      ctx.lineTo(pos.x, pos.y);
      ctx.stroke();
      return;
    }

    if (snapshotRef.current) {
      ctx.putImageData(snapshotRef.current, 0, 0);
    }

    ctx.strokeStyle = color;
    ctx.lineWidth = strokeWidth;
    ctx.lineCap = 'round';
    ctx.beginPath();

    if (tool === 'line') {
      ctx.moveTo(startPos.x, startPos.y);
      ctx.lineTo(pos.x, pos.y);
      ctx.stroke();
    } else if (tool === 'rect') {
      ctx.strokeRect(startPos.x, startPos.y, pos.x - startPos.x, pos.y - startPos.y);
    } else if (tool === 'circle') {
      const r = Math.hypot(pos.x - startPos.x, pos.y - startPos.y);
      ctx.arc(startPos.x, startPos.y, r, 0, Math.PI * 2);
      ctx.stroke();
    }
  };

  const handlePointerUp = () => {
    if (!drawing) return;
    setDrawing(false);
    const canvas = canvasRef.current;
    const ctx = canvas?.getContext('2d');
    if (canvas && ctx) {
      historyRef.current = [
        ...historyRef.current.slice(-19),
        ctx.getImageData(0, 0, canvas.width, canvas.height),
      ];
    }
  };

  const handleUndo = () => {
    const canvas = canvasRef.current;
    const ctx = canvas?.getContext('2d');
    if (!canvas || !ctx || historyRef.current.length <= 1) return;
    historyRef.current.pop();
    const prev = historyRef.current[historyRef.current.length - 1];
    ctx.putImageData(prev, 0, 0);
  };

  const handleClear = () => {
    const canvas = canvasRef.current;
    const ctx = canvas?.getContext('2d');
    if (!canvas || !ctx) return;
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    historyRef.current.push(ctx.getImageData(0, 0, canvas.width, canvas.height));
  };

  const handleSaveToVFS = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const cleanName = (fileName.trim() || 'cizim.png').endsWith('.png')
      ? fileName.trim() || 'cizim.png'
      : `${fileName.trim()}.png`;
    const dataUrl = canvas.toDataURL('image/png');
    const path = `${userHome}/Resimler/${cleanName}`;
    const res = writeFile(path, dataUrl, 'image/data', false, 'paint');
    if (res.ok) {
      setSavedNotice({
        text: tr ? `Kaydedildi: ${cleanName}` : `Saved: ${cleanName}`,
        isError: false,
      });
      pushNotification(
        tr ? 'Çizim Kaydedildi' : 'Drawing Saved',
        `${path}`,
        'viewer'
      );
      setTimeout(() => setSavedNotice(null), 2200);
    } else {
      setSavedNotice({
        text: res.error || (tr ? 'Sandbox yazma izni bekleniyor' : 'Sandbox permission required'),
        isError: true,
      });
      setTimeout(() => setSavedNotice(null), 3200);
    }
  };

  const tools: { id: Tool; icon: React.FC<{ size?: number }>; label: string }[] = [
    { id: 'pen', icon: Pen, label: tr ? 'Kalem' : 'Pen' },
    { id: 'eraser', icon: Eraser, label: tr ? 'Silgi' : 'Eraser' },
    { id: 'line', icon: Minus, label: tr ? 'Çizgi' : 'Line' },
    { id: 'rect', icon: Square, label: tr ? 'Dikdörtgen' : 'Rectangle' },
    { id: 'circle', icon: Circle, label: tr ? 'Daire' : 'Circle' },
  ];

  return (
    <div className="h-full w-full flex flex-col bg-[var(--anka-bg)] text-[var(--anka-text)] anka-theme-transition">
      {/* Toolbar */}
      <div className="px-3 py-2 border-b border-[var(--anka-border)] bg-[var(--anka-surface)] flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-1.5">
          {tools.map((item) => {
            const Icon = item.icon;
            return (
              <button
                key={item.id}
                onClick={() => setTool(item.id)}
                title={item.label}
                className={`p-2 rounded-lg text-xs transition-colors ${
                  tool === item.id
                    ? 'bg-[var(--anka-accent)] text-[var(--anka-accent-fg)]'
                    : 'hover:bg-[var(--anka-surface-elevated)] text-[var(--anka-text-muted)]'
                }`}
              >
                <Icon size={15} />
              </button>
            );
          })}

          <div className="h-5 w-px bg-[var(--anka-border)] mx-1" />

          <div className="flex items-center gap-1">
            {PALETTE.map((c) => (
              <button
                key={c}
                onClick={() => {
                  setColor(c);
                  if (tool === 'eraser') setTool('pen');
                }}
                style={{
                  backgroundColor: c,
                  outlineColor: color === c && tool !== 'eraser' ? 'var(--anka-accent)' : undefined,
                }}
                className={`w-5 h-5 rounded-full border transition-transform ${
                  color === c && tool !== 'eraser'
                    ? 'scale-110 outline-2 outline-offset-2 border-white'
                    : 'border-[var(--anka-border-strong)]'
                }`}
              />
            ))}
          </div>

          <div className="h-5 w-px bg-[var(--anka-border)] mx-1" />

          <label className="flex items-center gap-2 text-xs text-[var(--anka-text-subtle)]">
            <span className="tabular-nums w-6">{strokeWidth}px</span>
            <input
              type="range"
              min={1}
              max={24}
              value={strokeWidth}
              onChange={(e) => setStrokeWidth(Number(e.target.value))}
              style={{ accentColor: 'var(--anka-accent)' }}
              className="w-20"
            />
          </label>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleUndo}
            title={tr ? 'Geri Al' : 'Undo'}
            className="p-2 rounded-lg border border-[var(--anka-border-strong)] hover:bg-[var(--anka-surface-elevated)]"
          >
            <RotateCcw size={14} />
          </button>
          <button
            onClick={handleClear}
            title={tr ? 'Temizle' : 'Clear'}
            className="p-2 rounded-lg border border-[var(--anka-border-strong)] hover:bg-[var(--anka-surface-elevated)]"
          >
            <Trash2 size={14} />
          </button>
          <input
            type="text"
            value={fileName}
            onChange={(e) => setFileName(e.target.value)}
            className="w-28 px-2 py-1 text-xs rounded-lg border border-[var(--anka-border-strong)] bg-[var(--anka-surface-muted)] text-[var(--anka-text)] font-mono outline-none focus:border-[var(--anka-accent)]"
          />
          <button
            onClick={handleSaveToVFS}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium bg-[var(--anka-accent)] text-[var(--anka-accent-fg)] hover:bg-[var(--anka-accent-hover)] transition-colors"
          >
            <Save size={14} />
            <span>{tr ? 'Resimlere Kaydet' : 'Save PNG'}</span>
          </button>
        </div>
      </div>

      {savedNotice && (
        <div
          className={`px-4 py-1 text-xs border-b border-[var(--anka-border)] ${
            savedNotice.isError
              ? 'bg-amber-500/15 text-amber-700 dark:text-amber-300'
              : 'bg-emerald-500/15 text-emerald-700 dark:text-emerald-300'
          }`}
        >
          {savedNotice.text}
        </div>
      )}

      {/* Canvas Container */}
      <div className="flex-1 p-4 flex items-center justify-center overflow-auto os-scroll">
        <canvas
          ref={canvasRef}
          width={960}
          height={600}
          onPointerDown={handlePointerDown}
          onPointerMove={handlePointerMove}
          onPointerUp={handlePointerUp}
          onPointerLeave={handlePointerUp}
          className="bg-white rounded-lg shadow-sm border border-[var(--anka-border-strong)] max-w-full max-h-full cursor-crosshair touch-none"
        />
      </div>
    </div>
  );
};
