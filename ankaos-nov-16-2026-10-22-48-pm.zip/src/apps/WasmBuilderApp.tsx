import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  Box,
  CheckCircle2,
  Cpu,
  FileCode2,
  Flame,
  FolderOpen,
  Hammer,
  Package,
  Play,
  RefreshCw,
  Save,
  ShieldAlert,
  Sparkles,
  Terminal,
} from 'lucide-react';
import { WasmProfilerView } from '../components/WasmProfilerView';
import { highlightCode } from '../os/highlight';
import { useOS } from '../os/kernel';
import { decodeWasmBytes, WASM_B64_PREFIX } from '../os/sandboxRuntime';
import { formatBytes, getNodeAtPath, HOME_PATH, normalizePath, searchVFS } from '../os/vfs';
import {
  AnkaWasmPackageManifest,
  compileWatToWasm,
  packageWasmModule,
  runWasmWithMemoryPreview,
  WASM_TEMPLATES,
  WasmCompileResult,
  WasmExportMeta,
} from '../os/wasmCompiler';
import { profileWasmExecution, WasmProfileReport } from '../os/wasmProfiler';

interface WasmBuilderAppProps {
  windowId: string;
  launchArgs?: Record<string, string>;
}

interface BinaryInspection {
  mode: 'compiled' | 'wasm' | 'package';
  byteLength: number;
  compileTimeMs?: number;
  exports: WasmExportMeta[];
  sectionSummary: Array<{ name: string; bytes: number }>;
  hexHeader: string;
  pkgManifest?: AnkaWasmPackageManifest;
  base64Payload: string;
}

function bytesToHexPreview(bytes: Uint8Array, limit = 64): string {
  return Array.from(bytes.slice(0, limit))
    .map((b) => b.toString(16).padStart(2, '0'))
    .join(' ');
}

export const WasmBuilderApp: React.FC<WasmBuilderAppProps> = ({ windowId, launchArgs }) => {
  const { vfs, writeFile, chmodNode, updateWindowTitle, settings, currentUser, launchApp } =
    useOS();
  const tr = settings.language === 'tr';
  const userHome = currentUser.homeDir || HOME_PATH;

  const [watPath, setWatPath] = useState<string>(() => {
    const arg = launchArgs?.path;
    if (arg && /\.(wat|wast)$/i.test(arg)) {
      return normalizePath(arg, userHome, userHome);
    }
    return `${userHome}/Projeler/merhaba.wat`;
  });

  const [watSource, setWatSource] = useState<string>(() => {
    const arg = launchArgs?.path ? normalizePath(launchArgs.path, userHome, userHome) : null;
    if (arg && /\.(wat|wast)$/i.test(arg)) {
      const n = getNodeAtPath(vfs, arg);
      if (n?.type === 'file' && n.content) return n.content;
    }
    const defaultNode = getNodeAtPath(vfs, `${userHome}/Projeler/merhaba.wat`);
    if (defaultNode?.type === 'file' && defaultNode.content) return defaultNode.content;
    return WASM_TEMPLATES[0].wat;
  });

  const [outWasmPath, setOutWasmPath] = useState<string>(() => {
    const base = watPath.replace(/\.(wat|wast)$/i, '');
    return `${base}.wasm`;
  });

  const [pkgOutPath, setPkgOutPath] = useState<string>(() => {
    const base = watPath.replace(/\.(wat|wast)$/i, '');
    return `${base}.ankawasm`;
  });

  const [pkgName, setPkgName] = useState<string>('merhaba-wasm');
  const [pkgVersion, setPkgVersion] = useState<string>('1.0.0');
  const [installToBin, setInstallToBin] = useState<boolean>(true);

  const [compileResult, setCompileResult] = useState<WasmCompileResult | null>(null);
  const [inspection, setInspection] = useState<BinaryInspection | null>(null);
  const [activeVfsBinaryPath, setActiveVfsBinaryPath] = useState<string>(
    launchArgs?.path && /\.(wasm|ankawasm)$/i.test(launchArgs.path)
      ? normalizePath(launchArgs.path, userHome, userHome)
      : `${userHome}/Projeler/topla.wasm`
  );

  const [selectedFn, setSelectedFn] = useState<string>('');
  const [argInputs, setArgInputs] = useState<string[]>(['5', '7']);
  const [runOutput, setRunOutput] = useState<{
    ok: boolean;
    message: string;
    durationMs?: number;
    memoryText?: string;
    memoryHex?: string;
  } | null>(null);
  const [statusBanner, setStatusBanner] = useState<{ ok: boolean; text: string } | null>(null);
  const [activeTab, setActiveTab] = useState<'editor' | 'profiler'>(() =>
    launchArgs?.tab === 'profiler' || /\.wasmprof\.json$/i.test(launchArgs?.path || '')
      ? 'profiler'
      : 'editor'
  );
  const [profileIterations, setProfileIterations] = useState<number>(300);
  const [isProfiling, setIsProfiling] = useState<boolean>(false);
  const [profileReport, setProfileReport] = useState<WasmProfileReport | null>(() => {
    const argPath = launchArgs?.path ? normalizePath(launchArgs.path, userHome, userHome) : null;
    if (argPath && /\.wasmprof\.json$/i.test(argPath)) {
      const node = getNodeAtPath(vfs, argPath);
      if (node?.type === 'file' && node.content) {
        try {
          const parsed = JSON.parse(node.content) as WasmProfileReport;
          if (parsed.schema === 'ankaos-wasm-profile-v1') return parsed;
        } catch {
          // ignore invalid json
        }
      }
    }
    return null;
  });

  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const preRef = useRef<HTMLPreElement>(null);
  const gutterRef = useRef<HTMLDivElement>(null);

  const vfsWasmFiles = useMemo(() => {
    const watNodes = searchVFS(vfs, '.wat');
    const wasmNodes = searchVFS(vfs, '.wasm');
    const pkgNodes = searchVFS(vfs, '.ankawasm');
    const profNodes = searchVFS(vfs, '.wasmprof.json');
    const seen = new Set<string>();
    const combined: Array<{ path: string; name: string; kind: 'wat' | 'wasm' | 'pkg' | 'prof'; size: number }> = [];
    for (const item of [...watNodes, ...wasmNodes, ...pkgNodes, ...profNodes]) {
      if (item.node.type !== 'file' || seen.has(item.path)) continue;
      seen.add(item.path);
      const lower = item.node.name.toLowerCase();
      const kind = lower.endsWith('.wasmprof.json')
        ? 'prof'
        : lower.endsWith('.ankawasm')
          ? 'pkg'
          : lower.endsWith('.wasm')
            ? 'wasm'
            : lower.endsWith('.wat')
              ? 'wat'
              : null;
      if (kind) {
        combined.push({ path: item.path, name: item.node.name, kind, size: item.node.size });
      }
    }
    return combined.sort((a, b) => a.path.localeCompare(b.path, 'tr'));
  }, [vfs]);

  const traceFiles = useMemo(
    () => vfsWasmFiles.filter((f) => f.kind === 'prof'),
    [vfsWasmFiles]
  );

  const lastWasmrunNode = getNodeAtPath(vfs, '/tmp/last_wasmrun.wasmprof.json');
  const hasLastWasmrun = Boolean(lastWasmrunNode && lastWasmrunNode.type === 'file');

  useEffect(() => {
    const shortName = watPath.split('/').pop() || 'modul.wat';
    updateWindowTitle(
      windowId,
      `WASM Studio — ${shortName}`
    );
  }, [watPath, windowId, updateWindowTitle]);

  // Helper to inspect an existing .wasm or .ankawasm VFS file
  const inspectVfsBinary = async (path: string) => {
    const norm = normalizePath(path, userHome, userHome);
    const node = getNodeAtPath(vfs, norm);
    if (!node || node.type !== 'file') {
      setStatusBanner({ ok: false, text: `${norm} bulunamadı.` });
      return;
    }
    const content = node.content || '';
    setActiveVfsBinaryPath(norm);

    if (norm.toLowerCase().endsWith('.ankawasm') || content.trim().startsWith('{')) {
      try {
        const manifest = JSON.parse(content) as AnkaWasmPackageManifest;
        if (manifest.schema === 'ankaos-wasm-pkg-v1') {
          const bytes = decodeWasmBytes(manifest.wasmBase64);
          if (manifest.watSource) setWatSource(manifest.watSource);
          setInspection({
            mode: 'package',
            byteLength: bytes.length,
            exports: manifest.exports || [],
            sectionSummary: [],
            hexHeader: bytesToHexPreview(bytes),
            pkgManifest: manifest,
            base64Payload: manifest.wasmBase64,
          });
          const funcExps = (manifest.exports || []).filter((e) => e.kind === 'func');
          const firstFn = manifest.entryFn || funcExps[0]?.name || '';
          setSelectedFn(firstFn);
          const fnMeta = funcExps.find((e) => e.name === firstFn);
          if (fnMeta) {
            setArgInputs(fnMeta.params.map((_, i) => String(i === 0 ? 5 : i + 2)));
          }
          setStatusBanner({
            ok: true,
            text: tr
              ? `Paket yüklendi: ${manifest.name} v${manifest.version} (${bytes.length} B)`
              : `Package loaded: ${manifest.name} v${manifest.version}`,
          });
          return;
        }
      } catch {
        // fallback to wasm check
      }
    }

    const bytes = decodeWasmBytes(content);
    if (bytes.length < 8 || !WebAssembly.validate(bytes)) {
      setStatusBanner({ ok: false, text: tr ? 'Geçersiz WASM ikilisi.' : 'Invalid WASM binary.' });
      return;
    }
    const inst = (await WebAssembly.instantiate(bytes)) as unknown as WebAssembly.WebAssemblyInstantiatedSource;
    const rawExports = inst.instance.exports as Record<string, unknown>;
    const exps: WasmExportMeta[] = Object.entries(rawExports).map(([name, val]) => {
      if (val instanceof WebAssembly.Memory) {
        return { name, kind: 'memory', params: [], results: [] };
      }
      const len = typeof val === 'function' ? val.length : 0;
      return {
        name,
        kind: 'func',
        params: Array.from({ length: len }, () => 'i32'),
        results: ['i32'],
      };
    });
    const b64 = content.startsWith(WASM_B64_PREFIX)
      ? content
      : `${WASM_B64_PREFIX}${btoa(String.fromCharCode(...bytes))}`;

    setInspection({
      mode: 'wasm',
      byteLength: bytes.length,
      exports: exps,
      sectionSummary: [],
      hexHeader: bytesToHexPreview(bytes),
      base64Payload: b64,
    });
    const firstFn = exps.find((e) => e.kind === 'func');
    if (firstFn) {
      setSelectedFn(firstFn.name);
      setArgInputs(firstFn.params.map((_, i) => String(i === 0 ? 6 : i + 3)));
    }
    setStatusBanner({
      ok: true,
      text: tr ? `İkili inceleniyor: ${norm} (${bytes.length} B)` : `Inspecting ${norm}`,
    });
  };

  const loadProfileTraceFile = (tracePath: string) => {
    const norm = normalizePath(tracePath, userHome, userHome);
    const node = getNodeAtPath(vfs, norm);
    if (!node || node.type !== 'file' || !node.content) {
      setStatusBanner({ ok: false, text: tr ? `İz dosyası bulunamadı: ${norm}` : `Trace not found: ${norm}` });
      return;
    }
    try {
      const parsed = JSON.parse(node.content) as WasmProfileReport;
      if (parsed.schema !== 'ankaos-wasm-profile-v1') {
        setStatusBanner({ ok: false, text: tr ? 'Geçersiz .wasmprof.json biçimi.' : 'Invalid profile format.' });
        return;
      }
      setProfileReport(parsed);
      setActiveTab('profiler');
      setStatusBanner({
        ok: true,
        text: tr
          ? `Flamegraph izi yüklendi: ${norm} (${parsed.entryFn}, ${parsed.iterations}×)`
          : `Loaded trace: ${norm}`,
      });
    } catch {
      setStatusBanner({ ok: false, text: tr ? 'Profil JSON ayrıştırılamadı.' : 'Failed to parse profile JSON.' });
    }
  };

  // Load launchArgs.path on open / update
  useEffect(() => {
    if (launchArgs?.tab === 'profiler') {
      setActiveTab('profiler');
    }

    if (!launchArgs?.path) {
      // Auto-compile default WAT on first launch so inspector is immediately populated
      const initialCompile = compileWatToWasm(watSource);
      setCompileResult(initialCompile);
      if (initialCompile.ok && initialCompile.bytes && initialCompile.base64Content) {
        setInspection({
          mode: 'compiled',
          byteLength: initialCompile.sizeBytes,
          compileTimeMs: initialCompile.compileTimeMs,
          exports: initialCompile.exports,
          sectionSummary: initialCompile.sectionSummary,
          hexHeader: bytesToHexPreview(initialCompile.bytes),
          base64Payload: initialCompile.base64Content,
        });
        const firstFn = initialCompile.exports.find((e) => e.kind === 'func');
        if (firstFn) {
          setSelectedFn(firstFn.name);
          setArgInputs(firstFn.params.map((_, i) => String(i === 0 ? 5 : 7)));
        }
      }
      if (launchArgs?.tab === 'profiler' && hasLastWasmrun) {
        loadProfileTraceFile('/tmp/last_wasmrun.wasmprof.json');
      }
      return;
    }

    const norm = normalizePath(launchArgs.path, userHome, userHome);
    if (/\.wasmprof\.json$/i.test(norm)) {
      loadProfileTraceFile(norm);
      return;
    }

    if (/\.(wat|wast)$/i.test(norm)) {
      const node = getNodeAtPath(vfs, norm);
      if (node?.type === 'file' && node.content !== undefined) {
        setWatPath(norm);
        setWatSource(node.content);
        const base = norm.replace(/\.(wat|wast)$/i, '');
        setOutWasmPath(`${base}.wasm`);
        setPkgOutPath(`${base}.ankawasm`);
        const baseName = base.split('/').pop() || 'modul';
        setPkgName(baseName.replace(/[^a-z0-9_-]/gi, '-').toLowerCase());
        const res = compileWatToWasm(node.content);
        setCompileResult(res);
        if (res.ok && res.bytes && res.base64Content) {
          setInspection({
            mode: 'compiled',
            byteLength: res.sizeBytes,
            compileTimeMs: res.compileTimeMs,
            exports: res.exports,
            sectionSummary: res.sectionSummary,
            hexHeader: bytesToHexPreview(res.bytes),
            base64Payload: res.base64Content,
          });
        }
      }
    } else if (/\.(wasm|ankawasm)$/i.test(norm)) {
      void inspectVfsBinary(norm);
    }
  }, [launchArgs?.path, launchArgs?.tab]);

  const handleLoadTemplate = (tplId: string) => {
    const tpl = WASM_TEMPLATES.find((t) => t.id === tplId);
    if (!tpl) return;
    const targetWat = `${userHome}/Projeler/${tpl.fileName}`;
    const base = targetWat.replace(/\.wat$/i, '');
    setWatPath(targetWat);
    setWatSource(tpl.wat);
    setOutWasmPath(`${base}.wasm`);
    setPkgOutPath(`${base}.ankawasm`);
    setPkgName(tpl.fileName.replace(/\.wat$/i, '').replace(/[^a-z0-9_-]/gi, '-'));
    setRunOutput(null);
    const res = compileWatToWasm(tpl.wat);
    setCompileResult(res);
    if (res.ok && res.bytes && res.base64Content) {
      setInspection({
        mode: 'compiled',
        byteLength: res.sizeBytes,
        compileTimeMs: res.compileTimeMs,
        exports: res.exports,
        sectionSummary: res.sectionSummary,
        hexHeader: bytesToHexPreview(res.bytes),
        base64Payload: res.base64Content,
      });
      const firstFn = res.exports.find((e) => e.kind === 'func');
      if (firstFn) {
        setSelectedFn(firstFn.name);
        setArgInputs(firstFn.params.map((_, i) => String(tpl.id === 'memory' ? 0 : i === 0 ? 5 : 7)));
      }
    }
  };

  const handleSaveWat = () => {
    const target = normalizePath(watPath, userHome, userHome);
    const w = writeFile(target, watSource, 'text/wat', false, 'wasm-builder');
    setStatusBanner({
      ok: w.ok,
      text: w.ok ? (tr ? `WAT kaydedildi: ${target}` : `Saved WAT: ${target}`) : w.error || 'Hata',
    });
  };

  const handleCompile = (saveToVfs = true): BinaryInspection | null => {
    const res = compileWatToWasm(watSource);
    setCompileResult(res);
    if (!res.ok || !res.bytes || !res.base64Content) {
      setStatusBanner({ ok: false, text: res.error || 'Derleme hatası' });
      return null;
    }

    const nextInsp: BinaryInspection = {
      mode: 'compiled',
      byteLength: res.sizeBytes,
      compileTimeMs: res.compileTimeMs,
      exports: res.exports,
      sectionSummary: res.sectionSummary,
      hexHeader: bytesToHexPreview(res.bytes),
      base64Payload: res.base64Content,
    };
    setInspection(nextInsp);

    const funcExports = res.exports.filter((e) => e.kind === 'func');
    if (funcExports.length > 0 && !funcExports.some((e) => e.name === selectedFn)) {
      setSelectedFn(funcExports[0].name);
      setArgInputs(funcExports[0].params.map((_, i) => String(i === 0 ? 5 : 7)));
    }

    if (saveToVfs) {
      const targetWasm = normalizePath(outWasmPath, userHome, userHome);
      const w = writeFile(targetWasm, res.base64Content, 'application/wasm', false, 'wasm-builder');
      if (w.ok) {
        chmodNode(targetWasm, '+x', false);
        setActiveVfsBinaryPath(targetWasm);
        setStatusBanner({
          ok: true,
          text: tr
            ? `Derlendi ve VFS'ye yazıldı: ${targetWasm} (${res.sizeBytes} B · ${res.compileTimeMs} ms)`
            : `Compiled to ${targetWasm} (${res.sizeBytes} B in ${res.compileTimeMs} ms)`,
        });
      } else {
        setStatusBanner({
          ok: false,
          text: w.error || 'WASM dosyası VFS yazma izni reddedildi.',
        });
      }
    } else {
      setStatusBanner({
        ok: true,
        text: tr
          ? `Doğrulandı: ${res.sizeBytes} B (${res.compileTimeMs} ms)`
          : `Validated: ${res.sizeBytes} B (${res.compileTimeMs} ms)`,
      });
    }
    return nextInsp;
  };

  const handlePackageModule = async () => {
    const compiled = handleCompile(true);
    if (!compiled) return;

    const cleanPkgName = pkgName.trim().replace(/[^a-z0-9_-]/gi, '-') || 'anka-wasm-pkg';
    const pkgRes = await packageWasmModule({
      name: cleanPkgName,
      version: pkgVersion.trim() || '1.0.0',
      author: currentUser.username,
      description: `AnkaOS WASM Studio (${watPath.split('/').pop() || 'modul'})`,
      wasmContentOrBytes: compiled.base64Payload,
      watSource,
      exports: compiled.exports,
      entryFn: selectedFn || undefined,
    });

    if (!pkgRes.ok || !pkgRes.json || !pkgRes.manifest) {
      setStatusBanner({ ok: false, text: pkgRes.error || 'Paketleme hatası' });
      return;
    }

    const targetPkg = normalizePath(pkgOutPath, userHome, userHome);
    const w = writeFile(
      targetPkg,
      pkgRes.json,
      'application/vnd.ankaos.wasm-pkg+json',
      false,
      'wasm-builder'
    );
    if (!w.ok) {
      setStatusBanner({ ok: false, text: w.error || 'Paket VFS üzerine yazılamadı' });
      return;
    }

    setActiveVfsBinaryPath(targetPkg);
    setInspection({
      ...compiled,
      mode: 'package',
      pkgManifest: pkgRes.manifest,
    });

    let binMsg = '';
    if (installToBin) {
      const wrapper = `#!/bin/ankash\n# ANKA_WASM_PKG:${targetPkg}\nwasmrun ${targetPkg}\n`;
      const binRes = writeFile(`/bin/${cleanPkgName}`, wrapper, 'text/x-shellscript', true, 'wasm-builder');
      if (binRes.ok) {
        chmodNode(`/bin/${cleanPkgName}`, '+x', true);
        binMsg = tr
          ? ` · Komut kuruldu: /bin/${cleanPkgName}`
          : ` · Installed CLI: /bin/${cleanPkgName}`;
      }
    }

    setStatusBanner({
      ok: true,
      text: tr
        ? `Paket oluşturuldu: ${targetPkg} (SHA-256: ${pkgRes.manifest.sha256.slice(0, 12)}…)${binMsg}`
        : `Packaged: ${targetPkg} (SHA-256: ${pkgRes.manifest.sha256.slice(0, 12)}…)${binMsg}`,
    });
  };

  const handleRunOnVfs = async (useTargetPath = false) => {
    let payload = inspection?.base64Payload;
    if (useTargetPath) {
      const node = getNodeAtPath(vfs, activeVfsBinaryPath);
      if (node?.type === 'file' && node.content) {
        payload = node.content;
      }
    } else if (!payload) {
      const compiled = handleCompile(true);
      payload = compiled?.base64Payload;
    }

    if (!payload) {
      setRunOutput({ ok: false, message: tr ? 'Çalıştırılacak modül yok.' : 'No binary to execute.' });
      return;
    }

    const fnMeta = inspection?.exports.find((e) => e.name === selectedFn && e.kind === 'func');
    const arity = fnMeta ? fnMeta.params.length : argInputs.length;
    const parsedArgs = Array.from({ length: arity }, (_, idx) => {
      const v = Number(argInputs[idx] ?? 0);
      return Number.isNaN(v) ? 0 : v;
    });

    const res = await runWasmWithMemoryPreview(payload, selectedFn || undefined, parsedArgs);
    if (!res.ok) {
      setRunOutput({ ok: false, message: res.error || 'WASM çalıştırma hatası' });
      return;
    }

    const resultStr = res.invoked
      ? `${res.invoked.fn}(${res.invoked.args.join(', ')}) => ${String(res.invoked.result)}`
      : tr
        ? 'Modül başarıyla yüklendi (dışa aktarılan fonksiyon seçilmedi)'
        : 'Module instantiated';

    setRunOutput({
      ok: true,
      message: resultStr,
      durationMs: res.durationMs,
      memoryText: res.memoryText,
      memoryHex: res.memoryHex,
    });
  };

  const handleCompileAndRun = async () => {
    const compiled = handleCompile(true);
    if (!compiled) return;
    const funcExps = compiled.exports.filter((e) => e.kind === 'func');
    const targetFn = funcExps.some((e) => e.name === selectedFn)
      ? selectedFn
      : funcExps[0]?.name || '';
    if (targetFn && targetFn !== selectedFn) setSelectedFn(targetFn);

    const fnMeta = funcExps.find((e) => e.name === targetFn);
    const arity = fnMeta ? fnMeta.params.length : 0;
    const parsedArgs = Array.from({ length: arity }, (_, idx) => {
      const v = Number(argInputs[idx] ?? 0);
      return Number.isNaN(v) ? 0 : v;
    });

    const res = await runWasmWithMemoryPreview(compiled.base64Payload, targetFn || undefined, parsedArgs);
    if (!res.ok) {
      setRunOutput({ ok: false, message: res.error || 'Çalıştırma hatası' });
      return;
    }
    setRunOutput({
      ok: true,
      message: res.invoked
        ? `${res.invoked.fn}(${res.invoked.args.join(', ')}) => ${String(res.invoked.result)}`
        : 'OK',
      durationMs: res.durationMs,
      memoryText: res.memoryText,
      memoryHex: res.memoryHex,
    });
  };

  const handleRunProfiler = async (switchTab = true) => {
    let payload = inspection?.base64Payload;
    let sourceLabel = activeVfsBinaryPath;

    if (!payload) {
      const compiled = handleCompile(false);
      payload = compiled?.base64Payload;
      sourceLabel = outWasmPath;
    }

    if (!payload) {
      setStatusBanner({ ok: false, text: tr ? 'Profil çıkarılacak WASM modülü bulunamadı.' : 'No WASM binary to profile.' });
      return;
    }

    setIsProfiling(true);
    const fnMeta = funcExports.find((e) => e.name === selectedFn) || funcExports[0];
    const targetFn = fnMeta?.name || selectedFn || undefined;
    const arity = fnMeta ? fnMeta.params.length : argInputs.length;
    const parsedArgs = Array.from({ length: arity }, (_, idx) => {
      const v = Number(argInputs[idx] ?? 0);
      return Number.isNaN(v) ? 0 : v;
    });

    const profRes = await profileWasmExecution({
      content: payload,
      moduleName: (sourceLabel.split('/').pop() || 'modul.wasm'),
      sourcePath: sourceLabel,
      fnName: targetFn,
      args: parsedArgs,
      iterations: profileIterations,
    });
    setIsProfiling(false);

    if (!profRes.ok) {
      setStatusBanner({ ok: false, text: profRes.error });
      return;
    }

    setProfileReport(profRes.report);
    if (switchTab) setActiveTab('profiler');
    writeFile(
      '/tmp/last_wasmrun.wasmprof.json',
      JSON.stringify(profRes.report, null, 2),
      'application/json',
      false,
      'wasm-builder'
    );
    setStatusBanner({
      ok: true,
      text: tr
        ? `Profil hazır: ${profRes.report.entryFn} · ort ${profRes.report.metrics.hotAvgUs.toFixed(2)} µs (${profRes.report.metrics.opsPerSec.toLocaleString('tr-TR')} ops/s)`
        : `Profiled ${profRes.report.entryFn} · avg ${profRes.report.metrics.hotAvgUs.toFixed(2)} µs`,
    });
  };

  const handleSaveProfileToVfs = () => {
    if (!profileReport) return;
    const base = (watPath || outWasmPath).replace(/\.(wat|wast|wasm|ankawasm|wasmprof\.json)$/i, '');
    const dest = normalizePath(`${base}.wasmprof.json`, userHome, userHome);
    const w = writeFile(dest, JSON.stringify(profileReport, null, 2), 'application/json', false, 'wasm-builder');
    setStatusBanner({
      ok: w.ok,
      text: w.ok
        ? tr
          ? `Flamegraph izi kaydedildi: ${dest}`
          : `Saved profile trace: ${dest}`
        : w.error || 'Kayıt hatası',
    });
  };

  const handleScroll = () => {
    const ta = textareaRef.current;
    if (!ta) return;
    if (preRef.current) {
      preRef.current.scrollTop = ta.scrollTop;
      preRef.current.scrollLeft = ta.scrollLeft;
    }
    if (gutterRef.current) {
      gutterRef.current.scrollTop = ta.scrollTop;
    }
  };

  const handleEditorKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 's') {
      e.preventDefault();
      handleSaveWat();
    } else if (e.key === 'Tab') {
      e.preventDefault();
      const target = e.currentTarget;
      const start = target.selectionStart;
      const end = target.selectionEnd;
      setWatSource(watSource.slice(0, start) + '  ' + watSource.slice(end));
      requestAnimationFrame(() => {
        target.selectionStart = target.selectionEnd = start + 2;
      });
    }
  };

  const lineCount = useMemo(() => Math.max(1, watSource.split('\n').length), [watSource]);
  const highlighted = useMemo(() => highlightCode(watSource, 'wat'), [watSource]);
  const funcExports = useMemo(
    () => (inspection?.exports || []).filter((e) => e.kind === 'func'),
    [inspection]
  );
  const activeFnMeta = funcExports.find((e) => e.name === selectedFn) || funcExports[0];

  return (
    <div className="h-full w-full flex flex-col bg-[var(--anka-bg)] text-[var(--anka-text)] anka-theme-transition">
      {/* Top Toolbar */}
      <div className="px-3 py-2 border-b border-[var(--anka-border)] bg-[var(--anka-surface-muted)] flex flex-wrap items-center justify-between gap-2 shrink-0">
        <div className="flex items-center gap-2">
          <div className="w-7 h-7 rounded-lg bg-amber-500/15 border border-amber-500/30 flex items-center justify-center">
            <Cpu size={15} className="text-amber-500" />
          </div>
          <div>
            <div className="text-xs font-semibold leading-tight">
              {tr ? 'AnkaOS WASM Studio & Modül Paketleyici' : 'AnkaOS WASM Studio & Packager'}
            </div>
            <div className="text-[10px] text-[var(--anka-text-subtle)] font-mono">
              WAT → Binary (.wasm) → .ankawasm Bundle → Ring 3 VFS Runner
            </div>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-1.5">
          {/* Segmented Mode Switcher: Editor vs Flamegraph Profiler */}
          <div className="flex items-center gap-0.5 p-0.5 rounded-lg border border-[var(--anka-border)] bg-[var(--anka-surface)] mr-1">
            <button
              type="button"
              onClick={() => setActiveTab('editor')}
              className={`flex items-center gap-1.5 px-2.5 py-1 rounded-md text-xs font-medium transition-colors whitespace-nowrap shrink-0 ${
                activeTab === 'editor'
                  ? 'bg-[var(--anka-accent)] text-[var(--anka-accent-fg)]'
                  : 'text-[var(--anka-text-muted)] hover:text-[var(--anka-text)]'
              }`}
            >
              <FileCode2 size={12} />
              <span>{tr ? 'Kod & Derleyici' : 'Editor & Build'}</span>
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('profiler')}
              className={`flex items-center gap-1.5 px-2.5 py-1 rounded-md text-xs font-medium transition-colors whitespace-nowrap shrink-0 ${
                activeTab === 'profiler'
                  ? 'bg-[var(--anka-accent)] text-[var(--anka-accent-fg)]'
                  : 'text-[var(--anka-text-muted)] hover:text-[var(--anka-text)]'
              }`}
            >
              <Flame size={12} />
              <span>{tr ? 'Flamegraph & Profiler' : 'Flamegraph Profiler'}</span>
            </button>
          </div>

          <button
            onClick={handleSaveWat}
            className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-medium border border-[var(--anka-border-strong)] hover:bg-[var(--anka-surface-elevated)] transition-colors whitespace-nowrap shrink-0"
          >
            <Save size={13} />
            <span>{tr ? 'WAT Kaydet' : 'Save WAT'}</span>
          </button>

          <button
            onClick={() => handleCompile(true)}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium bg-[var(--anka-accent)] text-[var(--anka-accent-fg)] hover:bg-[var(--anka-accent-hover)] transition-colors whitespace-nowrap shrink-0"
          >
            <Hammer size={13} />
            <span>{tr ? 'Hızlı Derle (.wasm)' : 'Compile (.wasm)'}</span>
          </button>

          <button
            onClick={handleCompileAndRun}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium bg-emerald-600 text-white hover:bg-emerald-500 transition-colors whitespace-nowrap shrink-0"
          >
            <Play size={13} />
            <span>{tr ? 'Derle & Çalıştır' : 'Build & Run'}</span>
          </button>

          <button
            onClick={handlePackageModule}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium bg-amber-600 text-white hover:bg-amber-500 transition-colors whitespace-nowrap shrink-0"
          >
            <Package size={13} />
            <span>{tr ? 'Paketle (.ankawasm)' : 'Package (.ankawasm)'}</span>
          </button>

          <button
            onClick={() => launchApp('terminal', { cwd: `${userHome}/Projeler` })}
            title={tr ? 'Uçbirimde Aç' : 'Open in Terminal'}
            className="p-1.5 rounded-lg border border-[var(--anka-border)] text-[var(--anka-text-muted)] hover:text-[var(--anka-text)] hover:bg-[var(--anka-surface-elevated)] transition-colors"
          >
            <Terminal size={14} />
          </button>
        </div>
      </div>

      {statusBanner && (
        <div
          className={`px-3 py-1.5 text-xs border-b flex items-center justify-between shrink-0 ${
            statusBanner.ok
              ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-600 dark:text-emerald-400'
              : 'bg-rose-500/10 border-rose-500/30 text-rose-600 dark:text-rose-400'
          }`}
        >
          <div className="flex items-center gap-2 min-w-0">
            {statusBanner.ok ? <CheckCircle2 size={13} className="shrink-0" /> : <ShieldAlert size={13} className="shrink-0" />}
            <span className="font-mono truncate">{statusBanner.text}</span>
          </div>
          <button
            onClick={() => setStatusBanner(null)}
            className="text-[11px] opacity-70 hover:opacity-100 ml-2 shrink-0"
          >
            ×
          </button>
        </div>
      )}

      {/* Main 3-Column Workspace */}
      <div className="flex-1 min-h-0 flex overflow-hidden">
        {/* Left Sidebar: Templates & VFS WASM Assets */}
        <aside className="w-56 shrink-0 border-r border-[var(--anka-border)] bg-[var(--anka-surface-muted)] flex flex-col overflow-hidden">
          <div className="p-3 border-b border-[var(--anka-border)] space-y-1.5">
            <div className="flex items-center gap-1.5 text-[11px] font-semibold text-[var(--anka-text-subtle)] uppercase tracking-wider">
              <Sparkles size={11} className="text-amber-500" />
              <span>{tr ? 'Hazır Şablonlar' : 'Templates'}</span>
            </div>
            <div className="space-y-1">
              {WASM_TEMPLATES.map((tpl) => (
                <button
                  key={tpl.id}
                  onClick={() => handleLoadTemplate(tpl.id)}
                  className="w-full text-left px-2.5 py-1.5 rounded-lg text-xs hover:bg-[var(--anka-surface-elevated)] transition-colors flex items-center justify-between gap-1"
                >
                  <span className="truncate font-medium">{tr ? tpl.labelTr : tpl.labelEn}</span>
                  <span className="text-[10px] font-mono text-[var(--anka-text-subtle)]">.wat</span>
                </button>
              ))}
            </div>
          </div>

          <div className="flex-1 min-h-0 flex flex-col p-3 overflow-y-auto os-scroll space-y-2">
            <div className="flex items-center justify-between text-[11px] font-semibold text-[var(--anka-text-subtle)] uppercase tracking-wider">
              <div className="flex items-center gap-1.5">
                <FolderOpen size={11} className="text-[var(--anka-accent)]" />
                <span>{tr ? 'VFS İkilileri & Kaynaklar' : 'VFS Binaries'}</span>
              </div>
              <span className="font-mono text-[10px]">{vfsWasmFiles.length}</span>
            </div>

            <div className="space-y-1">
              {vfsWasmFiles.map((f) => {
                const isSelected =
                  f.path === watPath || f.path === activeVfsBinaryPath;
                return (
                  <button
                    key={f.path}
                    onClick={() => {
                      if (f.kind === 'prof') {
                        loadProfileTraceFile(f.path);
                      } else if (f.kind === 'wat') {
                        const node = getNodeAtPath(vfs, f.path);
                        if (node?.content !== undefined) {
                          setWatPath(f.path);
                          setWatSource(node.content);
                          const base = f.path.replace(/\.(wat|wast)$/i, '');
                          setOutWasmPath(`${base}.wasm`);
                          setPkgOutPath(`${base}.ankawasm`);
                          handleCompile(false);
                        }
                      } else {
                        void inspectVfsBinary(f.path);
                      }
                    }}
                    className={`w-full text-left px-2.5 py-1.5 rounded-lg text-xs transition-colors border ${
                      isSelected
                        ? 'bg-[var(--anka-accent-soft)] border-[var(--anka-accent)] text-[var(--anka-text)]'
                        : 'border-transparent hover:bg-[var(--anka-surface-elevated)] text-[var(--anka-text-muted)]'
                    }`}
                  >
                    <div className="flex items-center justify-between gap-1">
                      <span className="truncate font-mono text-[11px] font-medium">{f.name}</span>
                      <span
                        className={`text-[9px] font-mono px-1 py-0.5 rounded uppercase shrink-0 ${
                          f.kind === 'prof'
                            ? 'bg-rose-500/20 text-rose-600 dark:text-rose-300'
                            : f.kind === 'pkg'
                              ? 'bg-amber-500/20 text-amber-600 dark:text-amber-300'
                              : f.kind === 'wasm'
                                ? 'bg-emerald-500/20 text-emerald-600 dark:text-emerald-300'
                                : 'bg-sky-500/20 text-sky-600 dark:text-sky-300'
                        }`}
                      >
                        {f.kind}
                      </span>
                    </div>
                    <div className="text-[10px] text-[var(--anka-text-subtle)] truncate font-mono">
                      {f.path.replace(userHome, '~')} · {formatBytes(f.size)}
                    </div>
                  </button>
                );
              })}
            </div>
          </div>
        </aside>

        {activeTab === 'profiler' ? (
          <WasmProfilerView
            tr={tr}
            report={profileReport}
            targetLabel={outWasmPath.replace(userHome, '~')}
            availableFns={funcExports.map((f) => f.name)}
            selectedFn={selectedFn}
            onSelectFn={setSelectedFn}
            iterations={profileIterations}
            onChangeIterations={setProfileIterations}
            isProfiling={isProfiling}
            onRunProfile={() => void handleRunProfiler(false)}
            onLoadLastWasmrun={() => loadProfileTraceFile('/tmp/last_wasmrun.wasmprof.json')}
            hasLastWasmrun={hasLastWasmrun}
            onSaveProfile={handleSaveProfileToVfs}
            traceFiles={traceFiles}
            onSelectTraceFile={loadProfileTraceFile}
          />
        ) : (
        <>

        {/* Center Pane: WAT Editor + Paths & Packager Form */}
        <div className="flex-1 min-w-0 flex flex-col border-r border-[var(--anka-border)] bg-[var(--anka-surface)]">
          {/* Path Bar */}
          <div className="px-3 py-2 border-b border-[var(--anka-border)] bg-[var(--anka-surface-muted)] grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
            <label className="flex items-center gap-1.5 min-w-0">
              <FileCode2 size={13} className="text-sky-500 shrink-0" />
              <span className="text-[11px] text-[var(--anka-text-subtle)] shrink-0">WAT:</span>
              <input
                type="text"
                value={watPath}
                onChange={(e) => setWatPath(e.target.value)}
                className="flex-1 min-w-0 px-2 py-1 rounded border border-[var(--anka-border)] bg-[var(--anka-surface)] font-mono text-[11px] outline-none focus:border-[var(--anka-accent)]"
              />
            </label>
            <label className="flex items-center gap-1.5 min-w-0">
              <Cpu size={13} className="text-emerald-500 shrink-0" />
              <span className="text-[11px] text-[var(--anka-text-subtle)] shrink-0">WASM:</span>
              <input
                type="text"
                value={outWasmPath}
                onChange={(e) => setOutWasmPath(e.target.value)}
                className="flex-1 min-w-0 px-2 py-1 rounded border border-[var(--anka-border)] bg-[var(--anka-surface)] font-mono text-[11px] outline-none focus:border-[var(--anka-accent)]"
              />
            </label>
          </div>

          {/* Highlighted WAT Source Editor */}
          <div className="flex-1 flex min-h-0 overflow-hidden bg-[var(--anka-surface)]">
            <div
              ref={gutterRef}
              className="w-11 shrink-0 py-3 pr-2 text-right font-mono text-xs leading-6 text-[var(--anka-text-subtle)] bg-[var(--anka-surface-muted)] border-r border-[var(--anka-border)] overflow-hidden select-none tabular-nums"
            >
              {Array.from({ length: lineCount }, (_, i) => (
                <div key={i}>{i + 1}</div>
              ))}
            </div>

            <div className="relative flex-1 min-w-0 h-full overflow-hidden">
              <pre
                ref={preRef}
                aria-hidden="true"
                className="absolute inset-0 m-0 p-3 font-mono text-[12.5px] leading-6 whitespace-pre overflow-hidden pointer-events-none select-none text-[var(--anka-text)]"
              >
                {highlighted}
              </pre>
              <textarea
                ref={textareaRef}
                value={watSource}
                onChange={(e) => setWatSource(e.target.value)}
                onScroll={handleScroll}
                onKeyDown={handleEditorKeyDown}
                spellCheck={false}
                wrap="off"
                style={{ caretColor: 'var(--anka-accent)' }}
                className="relative z-10 w-full h-full p-3 font-mono text-[12.5px] leading-6 bg-transparent text-transparent outline-none resize-none overflow-auto os-scroll select-text selection:bg-sky-500/30 whitespace-pre"
              />
            </div>
          </div>

          {/* Bottom Packager Settings Strip */}
          <div className="p-3 border-t border-[var(--anka-border)] bg-[var(--anka-surface-muted)] space-y-2 text-xs shrink-0">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-1.5 font-semibold text-[11px] uppercase tracking-wider text-[var(--anka-text-subtle)]">
                <Box size={12} className="text-amber-500" />
                <span>{tr ? 'Modül Paketleme (.ankawasm)' : 'Module Packaging (.ankawasm)'}</span>
              </div>
              <label className="flex items-center gap-1.5 text-[11px] cursor-pointer">
                <input
                  type="checkbox"
                  checked={installToBin}
                  onChange={(e) => setInstallToBin(e.target.checked)}
                  style={{ accentColor: 'var(--anka-accent)' }}
                />
                <span>{tr ? '/bin komutu olarak kur' : 'Install as /bin command'}</span>
              </label>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
              <input
                type="text"
                value={pkgName}
                onChange={(e) => setPkgName(e.target.value)}
                placeholder={tr ? 'Paket adı' : 'Package name'}
                className="px-2 py-1 rounded border border-[var(--anka-border)] bg-[var(--anka-surface)] font-mono text-[11px] outline-none focus:border-[var(--anka-accent)]"
              />
              <input
                type="text"
                value={pkgVersion}
                onChange={(e) => setPkgVersion(e.target.value)}
                placeholder="1.0.0"
                className="px-2 py-1 rounded border border-[var(--anka-border)] bg-[var(--anka-surface)] font-mono text-[11px] outline-none focus:border-[var(--anka-accent)]"
              />
              <input
                type="text"
                value={pkgOutPath}
                onChange={(e) => setPkgOutPath(e.target.value)}
                placeholder="~/Projeler/modul.ankawasm"
                className="px-2 py-1 rounded border border-[var(--anka-border)] bg-[var(--anka-surface)] font-mono text-[11px] outline-none focus:border-[var(--anka-accent)]"
              />
            </div>
          </div>
        </div>

        {/* Right Pane: Binary Inspector & Direct VFS WASM Runner */}
        <aside className="w-80 shrink-0 bg-[var(--anka-surface)] flex flex-col overflow-y-auto os-scroll p-3 space-y-4">
          {/* Binary Status Card */}
          <div className="rounded-xl border border-[var(--anka-border)] bg-[var(--anka-surface-muted)] p-3 space-y-2.5">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold">
                {tr ? 'İkili & Doğrulama Durumu' : 'Binary & Validation'}
              </span>
              {inspection ? (
                <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-emerald-500/15 text-emerald-600 dark:text-emerald-400">
                  WebAssembly.validate OK
                </span>
              ) : (
                <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-amber-500/15 text-amber-500">
                  Bekliyor
                </span>
              )}
            </div>

            {compileResult && !compileResult.ok && (
              <div className="p-2 rounded-lg bg-rose-500/10 border border-rose-500/30 text-[11px] font-mono text-rose-500">
                {compileResult.error}
              </div>
            )}

            {inspection && (
              <>
                <div className="grid grid-cols-2 gap-2 text-[11px]">
                  <div className="p-2 rounded-lg bg-[var(--anka-surface)] border border-[var(--anka-border)]">
                    <div className="text-[var(--anka-text-subtle)]">{tr ? 'Boyut' : 'Size'}</div>
                    <div className="font-mono font-semibold tabular-nums">
                      {inspection.byteLength} B
                    </div>
                  </div>
                  <div className="p-2 rounded-lg bg-[var(--anka-surface)] border border-[var(--anka-border)]">
                    <div className="text-[var(--anka-text-subtle)]">
                      {inspection.compileTimeMs !== undefined
                        ? tr
                          ? 'Derleme'
                          : 'Compile'
                        : tr
                          ? 'Tür'
                          : 'Format'}
                    </div>
                    <div className="font-mono font-semibold tabular-nums">
                      {inspection.compileTimeMs !== undefined
                        ? `${inspection.compileTimeMs} ms`
                        : inspection.mode === 'package'
                          ? '.ankawasm'
                          : '.wasm'}
                    </div>
                  </div>
                </div>

                {inspection.sectionSummary.length > 0 && (
                  <div className="space-y-1">
                    <div className="text-[10px] font-semibold uppercase tracking-wider text-[var(--anka-text-subtle)]">
                      {tr ? 'WASM Bölümleri' : 'Sections'}
                    </div>
                    <div className="flex flex-wrap gap-1">
                      {inspection.sectionSummary.map((s) => (
                        <span
                          key={s.name}
                          className="text-[10px] font-mono px-1.5 py-0.5 rounded border border-[var(--anka-border)] bg-[var(--anka-surface)] tabular-nums"
                        >
                          {s.name}: {s.bytes}B
                        </span>
                      ))}
                    </div>
                  </div>
                )}

                {inspection.pkgManifest && (
                  <div className="p-2 rounded-lg bg-amber-500/10 border border-amber-500/25 text-[10px] font-mono space-y-0.5">
                    <div className="font-semibold text-amber-600 dark:text-amber-300">
                      {inspection.pkgManifest.name} v{inspection.pkgManifest.version}
                    </div>
                    <div className="text-[var(--anka-text-subtle)] truncate">
                      SHA256: {inspection.pkgManifest.sha256}
                    </div>
                  </div>
                )}

                <div>
                  <div className="text-[10px] font-semibold uppercase tracking-wider text-[var(--anka-text-subtle)] mb-1">
                    {tr ? 'İkili Bayt Önizleme (Magic: 00 61 73 6d)' : 'Binary Hex Header'}
                  </div>
                  <div className="p-2 rounded-lg bg-[var(--anka-terminal-bg)] text-[var(--anka-terminal-fg)] font-mono text-[10px] leading-relaxed break-all select-text">
                    {inspection.hexHeader}
                  </div>
                </div>
              </>
            )}
          </div>

          {/* Direct VFS WASM Executor */}
          <div className="rounded-xl border border-[var(--anka-border)] bg-[var(--anka-surface-muted)] p-3 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold">
                {tr ? 'VFS Üzerinde WASM Çalıştırıcı' : 'Direct VFS WASM Runner'}
              </span>
              <button
                onClick={() => void inspectVfsBinary(activeVfsBinaryPath)}
                title={tr ? 'VFS İkilisini Yenile' : 'Reload from VFS'}
                className="p-1 rounded hover:bg-[var(--anka-surface-elevated)] text-[var(--anka-text-subtle)]"
              >
                <RefreshCw size={12} />
              </button>
            </div>

            <div className="space-y-1">
              <div className="text-[10px] text-[var(--anka-text-subtle)]">
                {tr ? 'Aktif VFS İkilisi / Paket:' : 'Target VFS Binary:'}
              </div>
              <input
                type="text"
                value={activeVfsBinaryPath}
                onChange={(e) => setActiveVfsBinaryPath(e.target.value)}
                className="w-full px-2 py-1 rounded border border-[var(--anka-border)] bg-[var(--anka-surface)] font-mono text-[11px] outline-none focus:border-[var(--anka-accent)]"
              />
            </div>

            <div className="space-y-1">
              <div className="text-[10px] text-[var(--anka-text-subtle)]">
                {tr ? 'Dışa Aktarılan Fonksiyon' : 'Exported Function'}
              </div>
              <select
                value={selectedFn}
                onChange={(e) => {
                  const fn = e.target.value;
                  setSelectedFn(fn);
                  const meta = funcExports.find((x) => x.name === fn);
                  if (meta) {
                    setArgInputs(meta.params.map((_, i) => argInputs[i] ?? String(i === 0 ? 5 : 7)));
                  }
                }}
                className="w-full px-2 py-1.5 rounded border border-[var(--anka-border)] bg-[var(--anka-surface)] font-mono text-xs outline-none"
              >
                {funcExports.length === 0 ? (
                  <option value="">{tr ? '(Fonksiyon yok)' : '(No exported functions)'}</option>
                ) : (
                  funcExports.map((fn) => (
                    <option key={fn.name} value={fn.name}>
                      {fn.name}({fn.params.join(', ')}) → {fn.results.join(', ') || 'void'}
                    </option>
                  ))
                )}
              </select>
            </div>

            {activeFnMeta && activeFnMeta.params.length > 0 && (
              <div className="space-y-1.5">
                <div className="text-[10px] text-[var(--anka-text-subtle)]">
                  {tr ? 'Parametreler' : 'Arguments'}
                </div>
                <div className="grid grid-cols-2 gap-1.5">
                  {activeFnMeta.params.map((pt, idx) => (
                    <label key={idx} className="flex items-center gap-1 text-[11px] font-mono">
                      <span className="text-[var(--anka-text-subtle)]">
                        p{idx}({pt}):
                      </span>
                      <input
                        type="number"
                        value={argInputs[idx] ?? '0'}
                        onChange={(e) => {
                          const next = [...argInputs];
                          next[idx] = e.target.value;
                          setArgInputs(next);
                        }}
                        className="w-full px-2 py-1 rounded border border-[var(--anka-border)] bg-[var(--anka-surface)] font-mono text-xs outline-none focus:border-[var(--anka-accent)]"
                      />
                    </label>
                  ))}
                </div>
              </div>
            )}

            <div className="grid grid-cols-2 gap-2">
              <button
                onClick={() => void handleRunOnVfs(false)}
                className="flex items-center justify-center gap-1.5 px-2.5 py-2 rounded-lg text-xs font-medium bg-emerald-600 text-white hover:bg-emerald-500 transition-colors"
              >
                <Play size={12} />
                <span>{tr ? 'Bellekte Çalıştır' : 'Run Compiled'}</span>
              </button>
              <button
                onClick={() => void handleRunOnVfs(true)}
                className="flex items-center justify-center gap-1.5 px-2.5 py-2 rounded-lg text-xs font-medium border border-[var(--anka-border-strong)] hover:bg-[var(--anka-surface-elevated)] transition-colors"
              >
                <FolderOpen size={12} />
                <span>{tr ? 'VFS’ten Çalıştır' : 'Run VFS File'}</span>
              </button>
            </div>

            {runOutput && (
              <div
                className={`p-2.5 rounded-lg border font-mono text-xs space-y-1.5 ${
                  runOutput.ok
                    ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-600 dark:text-emerald-300'
                    : 'bg-rose-500/10 border-rose-500/30 text-rose-600 dark:text-rose-400'
                }`}
              >
                <div className="font-semibold break-all">{runOutput.message}</div>
                {runOutput.durationMs !== undefined && (
                  <div className="flex items-center justify-between gap-2 text-[10px] opacity-90">
                    <span>Ring 3 WebAssembly · {runOutput.durationMs} ms</span>
                    <button
                      type="button"
                      onClick={() => void handleRunProfiler(true)}
                      className="inline-flex items-center gap-1 underline hover:no-underline font-sans font-medium"
                    >
                      <Flame size={11} />
                      <span>{tr ? 'Flamegraph Aç' : 'Profile'}</span>
                    </button>
                  </div>
                )}
                {runOutput.memoryText !== undefined && (
                  <div className="pt-1 border-t border-emerald-500/20 text-[10px] space-y-0.5 text-[var(--anka-text)]">
                    <div className="text-[var(--anka-text-subtle)]">
                      {tr ? 'Lineer Bellek (UTF-8 @ 0x0):' : 'Linear Memory (UTF-8 @ 0x0):'}
                    </div>
                    <div className="p-1.5 rounded bg-[var(--anka-surface)] break-all">
                      {runOutput.memoryText || '(boş)'}
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>
        </aside>
        </>
        )}
      </div>
    </div>
  );
};
