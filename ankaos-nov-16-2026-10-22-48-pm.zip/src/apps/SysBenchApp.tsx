import React, { useState } from 'react';
import { Cpu, FileText, Gauge, HardDrive, Layers, Play } from 'lucide-react';
import { AsyncIOQueue } from '../os/ioQueue';
import { useOS } from '../os/kernel';
import {
  allocateFramesForProcess,
  createInitialFrames,
  createInitialSwap,
  forkFramesCopyOnWrite,
  handleCowPageFault,
  swapOutLRUFrames,
} from '../os/mmu';
import { getAppSandboxDir } from '../os/security';
import { HOME_PATH } from '../os/vfs';

interface BenchmarkEntry {
  id: string;
  subsystem: string;
  metric: string;
  durationMs: number;
  throughput: string;
}

export const SysBenchApp: React.FC<{ windowId: string }> = () => {
  const { writeFile, currentUser, settings, pushNotification } = useOS();
  const tr = settings.language === 'tr';

  const [running, setRunning] = useState(false);
  const [results, setResults] = useState<BenchmarkEntry[]>([]);
  const [exportNotice, setExportNotice] = useState<string | null>(null);

  const runSuite = async () => {
    setRunning(true);
    setExportNotice(null);

    // 1. CPU Prime Sieve Benchmark
    const cpuStart = performance.now();
    const limit = 120000;
    const sieve = new Uint8Array(limit + 1);
    let primeCount = 0;
    for (let i = 2; i <= limit; i++) {
      if (sieve[i] === 0) {
        primeCount++;
        for (let j = i * i; j <= limit; j += i) sieve[j] = 1;
      }
    }
    const cpuMs = Math.max(0.2, Number((performance.now() - cpuStart).toFixed(2)));
    const cpuOps = Math.round((limit / cpuMs) * 1000).toLocaleString('tr-TR');

    // 2. MMU CoW + LRU Swap Microbenchmark (isolated test pool)
    const mmuStart = performance.now();
    let testFrames = createInitialFrames();
    let testSwap = createInitialSwap();
    const allocA = allocateFramesForProcess(testFrames, 501, 'bench-parent', 4096);
    testFrames = allocA.frames;
    const cow = forkFramesCopyOnWrite(testFrames, 501, 502);
    testFrames = cow.frames;
    const evicted = swapOutLRUFrames(testFrames, testSwap, 8, []);
    testFrames = evicted.frames;
    testSwap = evicted.swap;
    const fault = handleCowPageFault(testFrames, 502, 'bench-child');
    const mmuMs = Math.max(0.1, Number((performance.now() - mmuStart).toFixed(2)));

    // 3. AsyncIOQueue Dispatch Latency Benchmark
    const ioQueue = new AsyncIOQueue();
    const ioStart = performance.now();
    const jobs = Array.from({ length: 12 }, (_, idx) =>
      ioQueue.enqueue(
        'write',
        `/tmp/bench_${idx}.dat`,
        () => undefined,
        idx % 3 === 0 ? 'high' : 'normal'
      )
    );
    await Promise.all(jobs);
    const ioMs = Math.max(0.2, Number((performance.now() - ioStart).toFixed(2)));
    const ioStats = ioQueue.getStats();

    setResults([
      {
        id: 'cpu',
        subsystem: tr ? 'CPU (Asal Sayı Eleği)' : 'CPU (Prime Sieve)',
        metric: `${primeCount} asal sayı (N=120K)`,
        durationMs: cpuMs,
        throughput: `${cpuOps} iter/sn`,
      },
      {
        id: 'mmu',
        subsystem: tr ? 'MMU (CoW Fork + LRU Swap)' : 'MMU (CoW + LRU Swap)',
        metric: `128 çerçeve + ${evicted.swappedCount} swap (${fault.ok ? 'CoW OK' : 'Skip'})`,
        durationMs: mmuMs,
        throughput: `${Math.round(128 / (mmuMs / 1000)).toLocaleString('tr-TR')} sf/sn`,
      },
      {
        id: 'io',
        subsystem: tr ? 'Asenkron G/Ç Kuyruğu' : 'Async I/O Queue',
        metric: `${ioStats.completedCount} görev (ort. ${ioStats.avgLatencyMs} ms)`,
        durationMs: ioMs,
        throughput: `${Math.round((12 / ioMs) * 1000)} IOPS`,
      },
    ]);
    setRunning(false);
  };

  const handleSaveReport = (toDocs: boolean) => {
    if (results.length === 0) return;
    const userHome = currentUser.homeDir || HOME_PATH;
    const targetPath = toDocs
      ? `${userHome}/Belgeler/ankabench_rapor.txt`
      : `${getAppSandboxDir(currentUser.username, 'pkg-sysbench')}/ankabench_rapor.txt`;
    const body = [
      `AnkaOS v3.5 AnkaBench Performans Raporu (${new Date().toLocaleString('tr-TR')})`,
      '========================================================================',
      ...results.map(
        (r) => `${r.subsystem.padEnd(28)} | ${r.durationMs} ms | ${r.throughput} | ${r.metric}`
      ),
    ].join('\n');
    const res = writeFile(targetPath, body, 'text/plain', false, 'pkg-sysbench');
    if (res.ok) {
      setExportNotice(tr ? `Rapor kaydedildi: ${targetPath}` : `Saved: ${targetPath}`);
      pushNotification('AnkaBench', targetPath, 'editor');
    } else {
      setExportNotice(res.error || (tr ? 'Sandbox izni bekleniyor' : 'Sandbox permission required'));
    }
  };

  return (
    <div className="h-full w-full flex flex-col bg-[var(--anka-surface)] text-[var(--anka-text)] anka-theme-transition">
      <div className="px-5 py-3.5 border-b border-[var(--anka-border)] bg-[var(--anka-surface)] flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-xl bg-[var(--anka-accent-soft)] text-[var(--anka-accent)] flex items-center justify-center">
            <Gauge size={18} />
          </div>
          <div>
            <h2 className="text-sm font-semibold">
              {tr ? 'AnkaBench Çekirdek Kıyaslama Aracı' : 'AnkaBench Kernel Suite'}
            </h2>
            <p className="text-xs text-[var(--anka-text-subtle)]">
              {tr
                ? 'CPU, MMU (CoW + Swap) ve Async I/O gerçek zamanlı performans ölçümü'
                : 'Real-time CPU, MMU CoW/Swap, and Async I/O latency benchmark'}
            </p>
          </div>
        </div>

        <button
          onClick={runSuite}
          disabled={running}
          className="flex items-center gap-2 px-4 py-2 rounded-lg text-xs font-medium bg-[var(--anka-accent)] text-[var(--anka-accent-fg)] hover:bg-[var(--anka-accent-hover)] disabled:opacity-50 transition-colors"
        >
          <Play size={14} />
          <span>{running ? (tr ? 'Ölçülüyor...' : 'Running...') : tr ? 'Testi Başlat' : 'Run Benchmark'}</span>
        </button>
      </div>

      <div className="flex-1 overflow-y-auto os-scroll p-5 space-y-5 bg-[var(--anka-bg)]">
        {results.length === 0 ? (
          <div className="h-full min-h-[220px] flex flex-col items-center justify-center text-center space-y-2 text-[var(--anka-text-subtle)]">
            <Gauge size={34} className="opacity-40" />
            <p className="text-sm font-medium text-[var(--anka-text-muted)]">
              {tr ? 'Henüz kıyaslama çalıştırılmadı.' : 'No benchmark executed yet.'}
            </p>
            <p className="text-xs max-w-md">
              {tr
                ? 'Testi Başlat düğmesiyle işlemci hızı, sayfa çerçevesi tahsisi/CoW ve G/Ç kuyruğu gecikmesini ölçün.'
                : 'Click Run Benchmark to measure CPU throughput, MMU CoW/Swap, and Async I/O queue speed.'}
            </p>
          </div>
        ) : (
          <>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {results.map((r) => {
                const Icon = r.id === 'cpu' ? Cpu : r.id === 'mmu' ? HardDrive : Layers;
                return (
                  <div
                    key={r.id}
                    className="p-4 rounded-xl border border-[var(--anka-border)] bg-[var(--anka-surface)] space-y-2"
                  >
                    <div className="flex items-center gap-2 text-xs font-semibold">
                      <Icon size={15} className="text-[var(--anka-accent)]" />
                      <span>{r.subsystem}</span>
                    </div>
                    <div className="text-xl font-bold font-mono tabular-nums text-emerald-600 dark:text-emerald-400">
                      {r.durationMs} ms
                    </div>
                    <div className="text-xs font-mono tabular-nums text-[var(--anka-text)]">
                      {r.throughput}
                    </div>
                    <div className="text-[11px] text-[var(--anka-text-subtle)]">{r.metric}</div>
                  </div>
                );
              })}
            </div>

            <div className="flex flex-wrap items-center gap-2 pt-2 border-t border-[var(--anka-border)]">
              <button
                onClick={() => handleSaveReport(false)}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium border border-[var(--anka-border-strong)] bg-[var(--anka-surface)] hover:bg-[var(--anka-surface-elevated)]"
              >
                <FileText size={13} />
                <span>{tr ? 'Sandboxa Kaydet' : 'Save to Sandbox'}</span>
              </button>
              <button
                onClick={() => handleSaveReport(true)}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium border border-[var(--anka-border-strong)] bg-[var(--anka-surface)] hover:bg-[var(--anka-surface-elevated)]"
              >
                <FileText size={13} />
                <span>{tr ? 'Belgelere Aktar (Sandbox Denetimli)' : 'Export to Documents'}</span>
              </button>
              {exportNotice && (
                <span className="text-xs font-mono text-[var(--anka-accent)]">
                  {exportNotice}
                </span>
              )}
            </div>
          </>
        )}
      </div>
    </div>
  );
};
