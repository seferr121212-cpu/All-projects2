import React, { useEffect, useState } from 'react';
import { RotateCcw } from 'lucide-react';
import { useOS } from '../os/kernel';

const GRID = 16;
type Point = { x: number; y: number };

export const SnakeApp: React.FC<{ windowId: string }> = ({ windowId }) => {
  const { settings, activeWindowId } = useOS();
  const tr = settings.language === 'tr';

  const [snake, setSnake] = useState<Point[]>([
    { x: 8, y: 8 },
    { x: 7, y: 8 },
    { x: 6, y: 8 },
  ]);
  const [dir, setDir] = useState<Point>({ x: 1, y: 0 });
  const [food, setFood] = useState<Point>({ x: 12, y: 8 });
  const [score, setScore] = useState(0);
  const [best, setBest] = useState(() => Number(localStorage.getItem('ankaos_snake_best') || '0'));
  const [gameOver, setGameOver] = useState(false);

  const reset = () => {
    setSnake([
      { x: 8, y: 8 },
      { x: 7, y: 8 },
      { x: 6, y: 8 },
    ]);
    setDir({ x: 1, y: 0 });
    setFood({ x: 12, y: 8 });
    setScore(0);
    setGameOver(false);
  };

  useEffect(() => {
    if (activeWindowId !== windowId) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'ArrowUp' && dir.y !== 1) {
        e.preventDefault();
        setDir({ x: 0, y: -1 });
      } else if (e.key === 'ArrowDown' && dir.y !== -1) {
        e.preventDefault();
        setDir({ x: 0, y: 1 });
      } else if (e.key === 'ArrowLeft' && dir.x !== 1) {
        e.preventDefault();
        setDir({ x: -1, y: 0 });
      } else if (e.key === 'ArrowRight' && dir.x !== -1) {
        e.preventDefault();
        setDir({ x: 1, y: 0 });
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [dir, activeWindowId, windowId]);

  useEffect(() => {
    if (gameOver) return;
    const id = window.setInterval(() => {
      setSnake((prev) => {
        const head = { x: prev[0].x + dir.x, y: prev[0].y + dir.y };
        if (
          head.x < 0 ||
          head.y < 0 ||
          head.x >= GRID ||
          head.y >= GRID ||
          prev.some((p) => p.x === head.x && p.y === head.y)
        ) {
          setGameOver(true);
          return prev;
        }
        const next = [head, ...prev];
        if (head.x === food.x && head.y === food.y) {
          setScore((s) => {
            const ns = s + 10;
            if (ns > best) {
              setBest(ns);
              localStorage.setItem('ankaos_snake_best', String(ns));
            }
            return ns;
          });
          setFood({
            x: Math.floor(Math.random() * GRID),
            y: Math.floor(Math.random() * GRID),
          });
        } else {
          next.pop();
        }
        return next;
      });
    }, 135);
    return () => window.clearInterval(id);
  }, [dir, food, gameOver, best]);

  return (
    <div className="h-full w-full flex flex-col items-center justify-between bg-[var(--anka-bg)] text-[var(--anka-text)] p-4 select-none anka-theme-transition">
      <div className="w-full flex items-center justify-between text-xs">
        <div className="font-mono tabular-nums space-x-3">
          <span>
            {tr ? 'Skor:' : 'Score:'} <strong className="text-emerald-600 dark:text-emerald-400">{score}</strong>
          </span>
          <span>
            {tr ? 'En İyi:' : 'Best:'} <strong className="text-[var(--anka-accent)]">{best}</strong>
          </span>
        </div>
        <button
          onClick={reset}
          className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg border border-[var(--anka-border)] bg-[var(--anka-surface)] hover:bg-[var(--anka-surface-elevated)] transition-colors"
        >
          <RotateCcw size={13} />
          <span>{tr ? 'Yeniden' : 'Restart'}</span>
        </button>
      </div>

      <div
        className="grid bg-[var(--anka-surface)] border border-[var(--anka-border)] rounded-xl p-1 gap-0.5 shadow-sm"
        style={{
          gridTemplateColumns: `repeat(${GRID}, 18px)`,
          gridTemplateRows: `repeat(${GRID}, 18px)`,
        }}
      >
        {Array.from({ length: GRID * GRID }, (_, idx) => {
          const x = idx % GRID;
          const y = Math.floor(idx / GRID);
          const isHead = snake[0].x === x && snake[0].y === y;
          const isBody = snake.slice(1).some((p) => p.x === x && p.y === y);
          const isFood = food.x === x && food.y === y;
          return (
            <div
              key={idx}
              className={`rounded-sm ${
                isHead
                  ? 'bg-emerald-500'
                  : isBody
                    ? 'bg-emerald-600'
                    : isFood
                      ? 'bg-amber-500'
                      : 'bg-[var(--anka-surface-muted)]'
              }`}
            />
          );
        })}
      </div>

      <div className="text-xs text-[var(--anka-text-subtle)]">
        {gameOver
          ? tr
            ? 'Oyun Bitti! Tekrar oynamak için Yeniden düğmesine basın.'
            : 'Game Over! Click Restart.'
          : tr
            ? 'Yön tuşları ile yılanı kontrol edin'
            : 'Use Arrow keys to steer'}
      </div>
    </div>
  );
};
