import React, { useCallback, useEffect, useState } from 'react';
import { ArrowDown, ArrowLeft, ArrowRight, ArrowUp, RotateCcw, Trophy, Undo2 } from 'lucide-react';
import { useOS } from '../os/kernel';

type Grid = number[][];
type Dir = 'left' | 'right' | 'up' | 'down';

const TILE_STYLES: Record<number, string> = {
  0: 'bg-slate-200/70 dark:bg-slate-800/70 text-transparent',
  2: 'bg-slate-100 dark:bg-slate-700 text-slate-900 dark:text-slate-100',
  4: 'bg-amber-100 dark:bg-amber-900/60 text-slate-900 dark:text-amber-100',
  8: 'bg-amber-300 dark:bg-amber-700 text-slate-950 dark:text-white',
  16: 'bg-orange-400 dark:bg-orange-600 text-white',
  32: 'bg-rose-500 text-white',
  64: 'bg-rose-600 text-white',
  128: 'bg-sky-500 text-white',
  256: 'bg-sky-600 text-white',
  512: 'bg-indigo-600 text-white',
  1024: 'bg-emerald-600 text-white',
  2048: 'bg-emerald-500 text-white ring-2 ring-amber-400',
};

function emptyGrid(): Grid {
  return Array.from({ length: 4 }, () => [0, 0, 0, 0]);
}

function addRandomTile(grid: Grid): Grid {
  const empty: [number, number][] = [];
  for (let r = 0; r < 4; r++) {
    for (let c = 0; c < 4; c++) {
      if (grid[r][c] === 0) empty.push([r, c]);
    }
  }
  if (empty.length === 0) return grid;
  const [r, c] = empty[Math.floor(Math.random() * empty.length)];
  const next = grid.map((row) => [...row]);
  next[r][c] = Math.random() < 0.9 ? 2 : 4;
  return next;
}

function slideRowLeft(row: number[]): { row: number[]; gained: number; moved: boolean } {
  const filtered = row.filter((v) => v !== 0);
  const out: number[] = [];
  let gained = 0;
  for (let i = 0; i < filtered.length; i++) {
    if (i + 1 < filtered.length && filtered[i] === filtered[i + 1]) {
      const merged = filtered[i] * 2;
      out.push(merged);
      gained += merged;
      i += 1;
    } else {
      out.push(filtered[i]);
    }
  }
  while (out.length < 4) out.push(0);
  const moved = out.some((v, idx) => v !== row[idx]);
  return { row: out, gained, moved };
}

function rotateCW(grid: Grid): Grid {
  const out = emptyGrid();
  for (let r = 0; r < 4; r++) {
    for (let c = 0; c < 4; c++) {
      out[c][3 - r] = grid[r][c];
    }
  }
  return out;
}

function moveGrid(grid: Grid, dir: Dir): { grid: Grid; gained: number; moved: boolean } {
  let working = grid.map((r) => [...r]);
  const rotations = dir === 'left' ? 0 : dir === 'down' ? 1 : dir === 'right' ? 2 : 3;
  for (let i = 0; i < rotations; i++) working = rotateCW(working);

  let totalGained = 0;
  let anyMoved = false;
  const slid = working.map((row) => {
    const res = slideRowLeft(row);
    totalGained += res.gained;
    if (res.moved) anyMoved = true;
    return res.row;
  });

  let restored = slid;
  for (let i = 0; i < (4 - rotations) % 4; i++) restored = rotateCW(restored);
  return { grid: restored, gained: totalGained, moved: anyMoved };
}

function hasAnyMoves(grid: Grid): boolean {
  for (let r = 0; r < 4; r++) {
    for (let c = 0; c < 4; c++) {
      if (grid[r][c] === 0) return true;
      if (r < 3 && grid[r][c] === grid[r + 1][c]) return true;
      if (c < 3 && grid[r][c] === grid[r][c + 1]) return true;
    }
  }
  return false;
}

export const Game2048App: React.FC<{ windowId: string }> = ({ windowId }) => {
  const { settings, activeWindowId } = useOS();
  const tr = settings.language === 'tr';

  const initBoard = () => addRandomTile(addRandomTile(emptyGrid()));

  const [grid, setGrid] = useState<Grid>(initBoard);
  const [prevState, setPrevState] = useState<{ grid: Grid; score: number } | null>(null);
  const [score, setScore] = useState(0);
  const [bestScore, setBestScore] = useState(() => {
    try {
      return Number(localStorage.getItem('ankaos_2048_best_v1') || '0');
    } catch {
      return 0;
    }
  });
  const [won2048, setWon2048] = useState(false);
  const [continueAfterWin, setContinueAfterWin] = useState(false);
  const [gameOver, setGameOver] = useState(false);

  const reset = useCallback(() => {
    setGrid(initBoard());
    setPrevState(null);
    setScore(0);
    setWon2048(false);
    setContinueAfterWin(false);
    setGameOver(false);
  }, []);

  const step = useCallback(
    (dir: Dir) => {
      if (gameOver) return;
      const res = moveGrid(grid, dir);
      if (!res.moved) return;

      setPrevState({ grid: grid.map((r) => [...r]), score });
      const withTile = addRandomTile(res.grid);
      const nextScore = score + res.gained;
      setGrid(withTile);
      setScore(nextScore);

      if (nextScore > bestScore) {
        setBestScore(nextScore);
        try {
          localStorage.setItem('ankaos_2048_best_v1', String(nextScore));
        } catch {
          // ignore
        }
      }

      if (!won2048 && withTile.flat().some((v) => v >= 2048)) {
        setWon2048(true);
      }
      if (!hasAnyMoves(withTile)) {
        setGameOver(true);
      }
    },
    [grid, score, bestScore, won2048, gameOver]
  );

  const handleUndo = () => {
    if (!prevState) return;
    setGrid(prevState.grid);
    setScore(prevState.score);
    setPrevState(null);
    setGameOver(false);
  };

  useEffect(() => {
    if (activeWindowId !== windowId) return;
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'ArrowLeft' || e.key.toLowerCase() === 'a') {
        e.preventDefault();
        step('left');
      } else if (e.key === 'ArrowRight' || e.key.toLowerCase() === 'd') {
        e.preventDefault();
        step('right');
      } else if (e.key === 'ArrowUp' || e.key.toLowerCase() === 'w') {
        e.preventDefault();
        step('up');
      } else if (e.key === 'ArrowDown' || e.key.toLowerCase() === 's') {
        e.preventDefault();
        step('down');
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [step, activeWindowId, windowId]);

  return (
    <div className="h-full w-full flex flex-col items-center justify-between p-5 bg-[var(--anka-bg)] text-[var(--anka-text)] select-none anka-theme-transition">
      {/* Header */}
      <div className="w-full max-w-sm flex items-center justify-between gap-2">
        <div>
          <h2 className="text-xl font-bold tracking-tight">Anka 2048</h2>
          <p className="text-[11px] text-[var(--anka-text-subtle)] font-mono tabular-nums">
            {tr ? 'Skor' : 'Score'}: <strong className="text-[var(--anka-accent)]">{score}</strong> ·{' '}
            <Trophy size={11} className="inline text-amber-500" /> {bestScore}
          </p>
        </div>

        <div className="flex items-center gap-1.5">
          <button
            onClick={handleUndo}
            disabled={!prevState}
            title={tr ? 'Geri Al' : 'Undo'}
            className="p-2 rounded-lg border border-[var(--anka-border)] bg-[var(--anka-surface)] hover:bg-[var(--anka-surface-elevated)] disabled:opacity-40 transition-colors"
          >
            <Undo2 size={14} />
          </button>
          <button
            onClick={reset}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium bg-[var(--anka-accent)] hover:bg-[var(--anka-accent-hover)] text-[var(--anka-accent-fg)] transition-colors"
          >
            <RotateCcw size={13} />
            <span>{tr ? 'Yeniden' : 'Reset'}</span>
          </button>
        </div>
      </div>

      {/* Board */}
      <div className="relative p-3 rounded-2xl border border-[var(--anka-border)] bg-[var(--anka-surface-elevated)] shadow-sm">
        <div className="grid grid-cols-4 gap-2.5">
          {grid.flat().map((val, idx) => (
            <div
              key={idx}
              className={`w-16 h-16 sm:w-18 sm:h-18 rounded-xl flex items-center justify-center font-mono font-bold tabular-nums transition-transform duration-100 ${
                val >= 1024 ? 'text-base' : val >= 128 ? 'text-xl' : 'text-2xl'
              } ${TILE_STYLES[val] || 'bg-amber-500 text-white'}`}
            >
              {val > 0 ? val : ''}
            </div>
          ))}
        </div>

        {(gameOver || (won2048 && !continueAfterWin)) && (
          <div className="absolute inset-0 rounded-2xl bg-slate-950/75 backdrop-blur-xs flex flex-col items-center justify-center p-4 text-center space-y-3 text-white">
            <h3 className="text-lg font-bold">
              {won2048 && !continueAfterWin
                ? tr
                  ? '2048 Hedefine Ulaşıldı!'
                  : 'Reached 2048!'
                : tr
                  ? 'Hamle Kalmadı'
                  : 'Game Over'}
            </h3>
            <p className="text-xs text-slate-300 font-mono">
              {tr ? 'Puan' : 'Score'}: {score}
            </p>
            <div className="flex items-center gap-2">
              {won2048 && !continueAfterWin && !gameOver && (
                <button
                  onClick={() => setContinueAfterWin(true)}
                  className="px-3 py-1.5 rounded-lg text-xs font-medium bg-emerald-600 hover:bg-emerald-500"
                >
                  {tr ? 'Devam Et' : 'Keep Playing'}
                </button>
              )}
              <button
                onClick={reset}
                className="px-3.5 py-1.5 rounded-lg text-xs font-medium bg-[var(--anka-accent)] hover:bg-[var(--anka-accent-hover)] text-[var(--anka-accent-fg)]"
              >
                {tr ? 'Tekrar Oyna' : 'Play Again'}
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Directional Controls */}
      <div className="flex flex-col items-center gap-1.5">
        <button
          onClick={() => step('up')}
          className="p-2 rounded-lg border border-[var(--anka-border)] bg-[var(--anka-surface)] hover:bg-[var(--anka-surface-elevated)] transition-colors"
        >
          <ArrowUp size={15} />
        </button>
        <div className="flex items-center gap-1.5">
          <button
            onClick={() => step('left')}
            className="p-2 rounded-lg border border-[var(--anka-border)] bg-[var(--anka-surface)] hover:bg-[var(--anka-surface-elevated)] transition-colors"
          >
            <ArrowLeft size={15} />
          </button>
          <button
            onClick={() => step('down')}
            className="p-2 rounded-lg border border-[var(--anka-border)] bg-[var(--anka-surface)] hover:bg-[var(--anka-surface-elevated)] transition-colors"
          >
            <ArrowDown size={15} />
          </button>
          <button
            onClick={() => step('right')}
            className="p-2 rounded-lg border border-[var(--anka-border)] bg-[var(--anka-surface)] hover:bg-[var(--anka-surface-elevated)] transition-colors"
          >
            <ArrowRight size={15} />
          </button>
        </div>
        <span className="text-[11px] text-[var(--anka-text-subtle)]">
          {tr ? 'Yön tuşları veya WASD ile oynayın' : 'Use Arrow keys or WASD'}
        </span>
      </div>
    </div>
  );
};
