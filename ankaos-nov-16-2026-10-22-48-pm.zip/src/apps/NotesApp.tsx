import React, { useEffect, useMemo, useState } from 'react';
import { FilePlus, Save, Search, Trash2 } from 'lucide-react';
import { useOS } from '../os/kernel';
import { HOME_PATH, listDir } from '../os/vfs';

export const NotesApp: React.FC<{ windowId: string }> = () => {
  const { vfs, writeFile, deleteNode, settings, currentUser } = useOS();
  const tr = settings.language === 'tr';
  const notesDir = `${currentUser.homeDir || HOME_PATH}/Belgeler/Notlar`;

  const notes = useMemo(
    () => listDir(vfs, notesDir).filter((n) => n.type === 'file'),
    [vfs, notesDir]
  );

  const [selectedName, setSelectedName] = useState<string>(() => notes[0]?.name || '');
  const [draft, setDraft] = useState<string>(() => notes[0]?.content || '');
  const [search, setSearch] = useState('');
  const [savedFlag, setSavedFlag] = useState(false);

  // Sync active note list when switching OS user accounts
  useEffect(() => {
    setSelectedName(notes[0]?.name || '');
    setDraft(notes[0]?.content || '');
    setSearch('');
  }, [notesDir]);

  const filteredNotes = useMemo(() => {
    if (!search.trim()) return notes;
    const q = search.toLowerCase();
    return notes.filter(
      (n) =>
        n.name.toLowerCase().includes(q) ||
        (n.content || '').toLowerCase().includes(q)
    );
  }, [notes, search]);

  const handleSelect = (name: string, content: string) => {
    setSelectedName(name);
    setDraft(content);
  };

  const handleCreateNote = () => {
    const idx = notes.length + 1;
    const name = `${tr ? 'Not' : 'Note'}_${idx}.txt`;
    const initial = `${tr ? 'Yeni Not' : 'New Note'}\n\n`;
    const res = writeFile(`${notesDir}/${name}`, initial, undefined, false, 'notes');
    if (res.ok) {
      setSelectedName(name);
      setDraft(initial);
    }
  };

  const handleSave = () => {
    if (!selectedName) return;
    const res = writeFile(`${notesDir}/${selectedName}`, draft, undefined, false, 'notes');
    if (res.ok) {
      setSavedFlag(true);
      setTimeout(() => setSavedFlag(false), 1600);
    }
  };

  const handleDelete = (name: string) => {
    const res = deleteNode(`${notesDir}/${name}`, false, 'notes');
    if (res.ok && selectedName === name) {
      const remaining = notes.filter((n) => n.name !== name);
      setSelectedName(remaining[0]?.name || '');
      setDraft(remaining[0]?.content || '');
    }
  };

  return (
    <div className="h-full w-full flex bg-[var(--anka-surface)] text-[var(--anka-text)] anka-theme-transition">
      {/* Sidebar */}
      <aside className="w-56 shrink-0 border-r border-[var(--anka-border)] bg-[var(--anka-surface-muted)] flex flex-col">
        <div className="p-3 border-b border-[var(--anka-border)] space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold">{tr ? 'Tüm Notlar' : 'All Notes'}</span>
            <button
              onClick={handleCreateNote}
              title={tr ? 'Yeni Not' : 'New Note'}
              className="p-1.5 rounded-lg bg-[var(--anka-accent)] hover:bg-[var(--anka-accent-hover)] text-[var(--anka-accent-fg)] transition-colors"
            >
              <FilePlus size={14} />
            </button>
          </div>
          <div className="relative">
            <Search size={13} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-[var(--anka-text-subtle)]" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder={tr ? 'Notlarda ara...' : 'Search notes...'}
              className="w-full pl-7 pr-2 py-1.5 text-xs rounded-lg border border-[var(--anka-border)] bg-[var(--anka-surface)] outline-none focus:border-[var(--anka-accent)]"
            />
          </div>
        </div>

        <div className="flex-1 overflow-y-auto os-scroll p-2 space-y-1">
          {filteredNotes.map((n) => {
            const active = n.name === selectedName;
            return (
              <div
                key={n.id}
                onClick={() => handleSelect(n.name, n.content || '')}
                style={active ? { backgroundColor: 'var(--anka-accent-soft)' } : undefined}
                className={`group flex items-center justify-between px-2.5 py-2 rounded-lg cursor-pointer transition-colors ${
                  active
                    ? 'text-[var(--anka-accent)]'
                    : 'hover:bg-[var(--anka-surface-elevated)]'
                }`}
              >
                <div className="min-w-0">
                  <div className="text-xs font-medium truncate">{n.name}</div>
                  <div className="text-[11px] text-[var(--anka-text-subtle)] truncate">
                    {(n.content || '').split('\n')[0] || (tr ? 'Boş not' : 'Empty note')}
                  </div>
                </div>
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    handleDelete(n.name);
                  }}
                  className="opacity-0 group-hover:opacity-100 p-1 text-[var(--anka-text-subtle)] hover:text-rose-500 transition-opacity"
                >
                  <Trash2 size={13} />
                </button>
              </div>
            );
          })}
        </div>
      </aside>

      {/* Editor */}
      <div className="flex-1 flex flex-col min-w-0">
        {selectedName ? (
          <>
            <div className="px-4 py-2.5 border-b border-[var(--anka-border)] flex items-center justify-between">
              <span className="text-xs font-medium text-[var(--anka-text-subtle)] font-mono">
                {selectedName}
              </span>
              <div className="flex items-center gap-3">
                {savedFlag && (
                  <span className="text-xs text-emerald-500 font-medium">
                    {tr ? 'Kaydedildi' : 'Saved'}
                  </span>
                )}
                <button
                  onClick={handleSave}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium bg-[var(--anka-accent)] hover:bg-[var(--anka-accent-hover)] text-[var(--anka-accent-fg)] transition-colors"
                >
                  <Save size={13} />
                  <span>{tr ? 'Kaydet' : 'Save'}</span>
                </button>
              </div>
            </div>
            <textarea
              value={draft}
              onChange={(e) => setDraft(e.target.value)}
              onKeyDown={(e) => {
                if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 's') {
                  e.preventDefault();
                  handleSave();
                }
              }}
              className="flex-1 p-5 bg-transparent outline-none resize-none text-sm leading-relaxed os-scroll select-text"
              placeholder={tr ? 'Notunuzu buraya yazın...' : 'Write your note here...'}
            />
          </>
        ) : (
          <div className="flex-1 flex flex-col items-center justify-center text-[var(--anka-text-subtle)] text-sm gap-3">
            <p>{tr ? 'Başlamak için yeni bir not oluşturun.' : 'Create a new note to start.'}</p>
            <button
              onClick={handleCreateNote}
              className="px-4 py-2 rounded-lg text-xs font-medium bg-[var(--anka-accent)] hover:bg-[var(--anka-accent-hover)] text-[var(--anka-accent-fg)] transition-colors"
            >
              {tr ? 'Yeni Not Oluştur' : 'Create Note'}
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
