import React, { useState } from 'react';
import { Activity, Download, Globe, Network, Search } from 'lucide-react';
import { useOS } from '../os/kernel';
import {
  fetchPageLive,
  LiveDnsResponse,
  LivePageFetchResponse,
  pingHostLive,
  resolveDnsLive,
} from '../os/net';
import { formatBytes, HOME_PATH } from '../os/vfs';

type NetTab = 'http' | 'dns' | 'ping';

export const NetToolsApp: React.FC<{ windowId: string }> = () => {
  const { writeFile, recordNetworkTraffic, currentUser, settings } = useOS();
  const tr = settings.language === 'tr';
  const userHome = currentUser.homeDir || HOME_PATH;

  const [tab, setTab] = useState<NetTab>('http');
  const [urlInput, setUrlInput] = useState('https://example.com');
  const [httpLoading, setHttpLoading] = useState(false);
  const [httpRes, setHttpRes] = useState<LivePageFetchResponse | null>(null);
  const [savedNotice, setSavedNotice] = useState<string | null>(null);

  const [dnsHost, setDnsHost] = useState('wikipedia.org');
  const [dnsLoading, setDnsLoading] = useState(false);
  const [dnsRes, setDnsRes] = useState<LiveDnsResponse | null>(null);

  const [pingHost, setPingHost] = useState('github.com');
  const [pingLoading, setPingLoading] = useState(false);
  const [pingRows, setPingRows] = useState<Array<{ seq: number; ip?: string; port?: number; rttMs?: number; error?: string }>>([]);

  const handleHttpFetch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!urlInput.trim()) return;
    setHttpLoading(true);
    setSavedNotice(null);
    const target = urlInput.startsWith('http') ? urlInput.trim() : `https://${urlInput.trim()}`;
    const res = await fetchPageLive(target);
    if (res.ok) recordNetworkTraffic('eth0', res.bytes || 512, 128);
    setHttpRes(res);
    setHttpLoading(false);
  };

  const handleDnsLookup = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!dnsHost.trim()) return;
    setDnsLoading(true);
    const res = await resolveDnsLive(dnsHost.trim());
    if (res.ok) recordNetworkTraffic('eth0', 256, 64);
    setDnsRes(res);
    setDnsLoading(false);
  };

  const handlePingProbe = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!pingHost.trim()) return;
    setPingLoading(true);
    setPingRows([]);
    const results: typeof pingRows = [];
    for (let seq = 1; seq <= 3; seq++) {
      const r = await pingHostLive(pingHost.trim());
      if (r.ok) recordNetworkTraffic('eth0', 64, 64);
      results.push({ seq, ip: r.ip, port: r.port, rttMs: r.rttMs, error: r.error });
      setPingRows([...results]);
    }
    setPingLoading(false);
  };

  return (
    <div className="h-full w-full flex flex-col bg-[var(--anka-surface)] text-[var(--anka-text)] anka-theme-transition">
      <div className="px-5 py-3 border-b border-[var(--anka-border)] bg-[var(--anka-surface-muted)] flex flex-wrap items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          <Network size={16} className="text-[var(--anka-accent)]" />
          <h2 className="text-sm font-semibold font-display">
            {tr ? 'Ağ & HTTP/DNS Analiz Stüdyosu' : 'Net & HTTP/DNS Suite'}
          </h2>
        </div>
        <div className="flex items-center gap-1 p-1 rounded-lg bg-[var(--anka-surface)] border border-[var(--anka-border)] text-xs">
          {(
            [
              { id: 'http', label: 'HTTP Fetch' },
              { id: 'dns', label: 'DNS Sorgu' },
              { id: 'ping', label: 'TCP Ping' },
            ] as const
          ).map((item) => (
            <button
              key={item.id}
              onClick={() => setTab(item.id)}
              className={`px-3 py-1 rounded-md font-medium ${
                tab === item.id
                  ? 'bg-[var(--anka-accent)] text-[var(--anka-accent-fg)]'
                  : 'text-[var(--anka-text-subtle)] hover:text-[var(--anka-text)]'
              }`}
            >
              {item.label}
            </button>
          ))}
        </div>
      </div>

      <div className="flex-1 overflow-y-auto os-scroll p-5 space-y-4">
        {tab === 'http' && (
          <>
            <form onSubmit={(e) => void handleHttpFetch(e)} className="flex gap-2 text-xs">
              <div className="relative flex-1">
                <Globe size={13} className="absolute left-3 top-1/2 -translate-y-1/2 text-[var(--anka-text-subtle)]" />
                <input
                  type="text"
                  value={urlInput}
                  onChange={(e) => setUrlInput(e.target.value)}
                  className="w-full pl-8 pr-3 py-2 rounded-lg border border-[var(--anka-border-strong)] bg-[var(--anka-surface-muted)] font-mono outline-none focus:border-[var(--anka-accent)]"
                />
              </div>
              <button
                type="submit"
                disabled={httpLoading}
                className="px-4 py-2 rounded-lg bg-[var(--anka-accent)] text-[var(--anka-accent-fg)] font-medium hover:bg-[var(--anka-accent-hover)]"
              >
                {httpLoading ? '...' : 'GET'}
              </button>
            </form>

            {httpRes && (
              <div className="space-y-3">
                <div className="p-3 rounded-xl border border-[var(--anka-border)] bg-[var(--anka-surface-muted)] flex flex-wrap items-center justify-between gap-2 text-xs font-mono tabular-nums">
                  <span>
                    HTTP {httpRes.status ?? 'ERR'} · {httpRes.contentType || '-'} ·{' '}
                    {formatBytes(httpRes.bytes || 0)}
                  </span>
                  {httpRes.rawText && (
                    <button
                      onClick={() => {
                        const slug = new URL(httpRes.finalUrl || urlInput).hostname.replace(/[^a-z0-9.-]/gi, '_');
                        const dest = `${userHome}/İndirilenler/fetch_${slug}.txt`;
                        const r = writeFile(dest, httpRes.rawText || '', 'text/plain', false, 'pkg-nettools');
                        setSavedNotice(r.ok ? `Kaydedildi: ${dest}` : r.error || 'Hata');
                      }}
                      className="flex items-center gap-1 px-2.5 py-1 rounded bg-[var(--anka-surface)] border border-[var(--anka-border)] hover:border-[var(--anka-accent)]"
                    >
                      <Download size={12} />
                      <span>~/İndirilenler</span>
                    </button>
                  )}
                </div>
                {savedNotice && <div className="text-xs text-emerald-500">{savedNotice}</div>}
                {httpRes.error ? (
                  <div className="p-3 rounded-xl border border-rose-500/30 bg-rose-500/10 text-xs text-rose-500">
                    {httpRes.error}
                  </div>
                ) : (
                  <pre className="p-4 rounded-xl border border-[var(--anka-terminal-border)] bg-[var(--anka-terminal-bg)] text-[var(--anka-terminal-fg)] font-mono text-xs whitespace-pre-wrap max-h-96 overflow-y-auto os-scroll">
                    {httpRes.rawText || httpRes.textPreview || ''}
                  </pre>
                )}
              </div>
            )}
          </>
        )}

        {tab === 'dns' && (
          <>
            <form onSubmit={(e) => void handleDnsLookup(e)} className="flex gap-2 text-xs">
              <div className="relative flex-1">
                <Search size={13} className="absolute left-3 top-1/2 -translate-y-1/2 text-[var(--anka-text-subtle)]" />
                <input
                  type="text"
                  value={dnsHost}
                  onChange={(e) => setDnsHost(e.target.value)}
                  className="w-full pl-8 pr-3 py-2 rounded-lg border border-[var(--anka-border-strong)] bg-[var(--anka-surface-muted)] font-mono outline-none focus:border-[var(--anka-accent)]"
                />
              </div>
              <button
                type="submit"
                disabled={dnsLoading}
                className="px-4 py-2 rounded-lg bg-[var(--anka-accent)] text-[var(--anka-accent-fg)] font-medium"
              >
                {dnsLoading ? '...' : tr ? 'Çözümle' : 'Resolve'}
              </button>
            </form>
            {dnsRes && (
              <div className="p-4 rounded-xl border border-[var(--anka-terminal-border)] bg-[var(--anka-terminal-bg)] text-[var(--anka-terminal-fg)] font-mono text-xs space-y-2">
                {dnsRes.ok ? (
                  <>
                    <div className="text-emerald-400">
                      {dnsRes.host} · {dnsRes.tookMs} ms
                    </div>
                    <div>A (IPv4)  : {dnsRes.v4?.join(', ') || '-'}</div>
                    <div>AAAA      : {dnsRes.v6?.join(', ') || '-'}</div>
                    <div>NS        : {dnsRes.ns?.join(', ') || '-'}</div>
                    <div>
                      MX        :{' '}
                      {dnsRes.mx?.map((m) => `${m.exchange}(${m.priority})`).join(', ') || '-'}
                    </div>
                  </>
                ) : (
                  <div className="text-rose-400">{dnsRes.error || 'DNS başarısız'}</div>
                )}
              </div>
            )}
          </>
        )}

        {tab === 'ping' && (
          <>
            <form onSubmit={(e) => void handlePingProbe(e)} className="flex gap-2 text-xs">
              <div className="relative flex-1">
                <Activity size={13} className="absolute left-3 top-1/2 -translate-y-1/2 text-[var(--anka-text-subtle)]" />
                <input
                  type="text"
                  value={pingHost}
                  onChange={(e) => setPingHost(e.target.value)}
                  className="w-full pl-8 pr-3 py-2 rounded-lg border border-[var(--anka-border-strong)] bg-[var(--anka-surface-muted)] font-mono outline-none focus:border-[var(--anka-accent)]"
                />
              </div>
              <button
                type="submit"
                disabled={pingLoading}
                className="px-4 py-2 rounded-lg bg-[var(--anka-accent)] text-[var(--anka-accent-fg)] font-medium"
              >
                {pingLoading ? '...' : '3× Ping'}
              </button>
            </form>
            {pingRows.length > 0 && (
              <div className="p-4 rounded-xl border border-[var(--anka-terminal-border)] bg-[var(--anka-terminal-bg)] text-[var(--anka-terminal-fg)] font-mono text-xs space-y-1.5 tabular-nums">
                {pingRows.map((row) =>
                  row.error ? (
                    <div key={row.seq} className="text-rose-400">
                      seq={row.seq} HATA: {row.error}
                    </div>
                  ) : (
                    <div key={row.seq}>
                      seq={row.seq} · {row.ip}:{row.port} · rtt={row.rttMs} ms
                    </div>
                  )
                )}
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
};
