import React, { useEffect, useRef, useState } from 'react';
import {
  FileAudio,
  FolderOpen,
  Music,
  Pause,
  Play,
  Plus,
  Save,
  Sliders,
  Volume2,
  VolumeX,
} from 'lucide-react';
import { useOS } from '../os/kernel';
import {
  parseAnkaSynthTrack,
  serializeAnkaSynthTrack,
  SynthTrack,
} from '../os/mediaSynth';
import { getNodeAtPath, HOME_PATH, listDir, normalizePath } from '../os/vfs';

interface MediaPlayerAppProps {
  windowId: string;
  launchArgs?: Record<string, string>;
}

const DEFAULT_TRACKS: SynthTrack[] = [
  {
    id: 'kuzgun-ambient',
    title: 'Kuzgun Gece Ambiyansı',
    bpm: 96,
    waveform: 'sine',
    notes: [220, 261.63, 329.63, 392.0, 329.63, 293.66, 261.63, 196.0],
  },
  {
    id: 'kristal-sentez',
    title: 'Kristal Sentez Döngüsü',
    bpm: 120,
    waveform: 'triangle',
    notes: [261.63, 329.63, 392.0, 523.25, 493.88, 392.0, 329.63, 293.66],
  },
  {
    id: 'retro-kare',
    title: '8-Bit Çekirdek Marşı',
    bpm: 140,
    waveform: 'square',
    notes: [329.63, 329.63, 392.0, 440.0, 392.0, 329.63, 293.66, 261.63],
  },
];

const PIANO_KEYS = [
  { label: 'Sol3', freq: 196.0 },
  { label: 'La3', freq: 220.0 },
  { label: 'Do4', freq: 261.63 },
  { label: 'Re4', freq: 293.66 },
  { label: 'Mi4', freq: 329.63 },
  { label: 'Fa4', freq: 349.23 },
  { label: 'Sol4', freq: 392.0 },
  { label: 'La4', freq: 440.0 },
  { label: 'Si4', freq: 493.88 },
  { label: 'Do5', freq: 523.25 },
];

const WAVEFORMS: OscillatorType[] = ['sine', 'triangle', 'square', 'sawtooth'];

function formatTime(sec: number): string {
  if (!Number.isFinite(sec) || sec < 0) return '0:00';
  const m = Math.floor(sec / 60);
  const s = Math.floor(sec % 60);
  return `${m}:${String(s).padStart(2, '0')}`;
}

export const MediaPlayerApp: React.FC<MediaPlayerAppProps> = ({ launchArgs }) => {
  const { settings, updateSettings, vfs, writeFile, currentUser } = useOS();
  const tr = settings.language === 'tr';
  const userHome = currentUser.homeDir || HOME_PATH;

  const [tracks, setTracks] = useState<SynthTrack[]>(DEFAULT_TRACKS);
  const [trackIdx, setTrackIdx] = useState(0);
  const [playing, setPlaying] = useState(false);
  const [step, setStep] = useState(0);
  const [editingStep, setEditingStep] = useState<number | null>(null);
  const [bars, setBars] = useState<number[]>(Array(20).fill(8));
  const [showSeqEditor, setShowSeqEditor] = useState(false);
  const [statusNotice, setStatusNotice] = useState<string | null>(null);

  // Local Host Audio File Playback State
  const [audioSourceUrl, setAudioSourceUrl] = useState<string | null>(null);
  const [audioFileName, setAudioFileName] = useState<string | null>(null);
  const [audioPlaying, setAudioPlaying] = useState(false);
  const [audioTime, setAudioTime] = useState({ current: 0, duration: 0 });
  const [vfsPickerOpen, setVfsPickerOpen] = useState(false);

  const audioCtxRef = useRef<AudioContext | null>(null);
  const gainRef = useRef<GainNode | null>(null);
  const analyserRef = useRef<AnalyserNode | null>(null);
  const htmlAudioRef = useRef<HTMLAudioElement | null>(null);
  const mediaElemSrcRef = useRef<MediaElementAudioSourceNode | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const showMsg = (msg: string) => {
    setStatusNotice(msg);
    setTimeout(() => setStatusNotice(null), 2600);
  };

  const ensureAudio = () => {
    if (!audioCtxRef.current) {
      const Ctx =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      const ctx = new Ctx();
      const gain = ctx.createGain();
      const analyser = ctx.createAnalyser();
      analyser.fftSize = 64;
      analyser.smoothingTimeConstant = 0.78;
      gain.connect(analyser);
      analyser.connect(ctx.destination);
      audioCtxRef.current = ctx;
      gainRef.current = gain;
      analyserRef.current = analyser;
    }
    if (audioCtxRef.current.state === 'suspended') {
      void audioCtxRef.current.resume();
    }
    if (gainRef.current) {
      gainRef.current.gain.value = settings.muted ? 0 : (settings.volume / 100) * 0.25;
    }
  };

  useEffect(() => {
    if (gainRef.current) {
      gainRef.current.gain.value = settings.muted ? 0 : (settings.volume / 100) * 0.25;
    }
  }, [settings.volume, settings.muted]);

  const openVfsAudioFile = (normPath: string) => {
    const node = getNodeAtPath(vfs, normPath);
    if (!node || node.type !== 'file' || !node.content) return;
    if (normPath.endsWith('.ankasynth') || normPath.endsWith('.json')) {
      const parsed = parseAnkaSynthTrack(node.content);
      if (parsed.ok && parsed.track) {
        setTracks((prev) => {
          const existingIdx = prev.findIndex((t) => t.id === parsed.track!.id);
          if (existingIdx >= 0) {
            const copy = [...prev];
            copy[existingIdx] = parsed.track!;
            setTrackIdx(existingIdx);
            return copy;
          }
          setTrackIdx(prev.length);
          return [...prev, parsed.track!];
        });
        setAudioFileName(null);
        setShowSeqEditor(true);
        showMsg(`${parsed.track.title} yüklendi`);
      }
      return;
    }

    if (/\.(webm|wav|mp3|ogg|m4a|flac|aac)$/i.test(node.name) || node.mimeType?.startsWith('audio/')) {
      if (audioSourceUrl && audioSourceUrl.startsWith('blob:')) {
        URL.revokeObjectURL(audioSourceUrl);
      }
      setPlaying(false);
      setAudioSourceUrl(node.content);
      setAudioFileName(node.name);
      setAudioPlaying(false);
      setAudioTime({ current: 0, duration: 0 });
      showMsg(`${node.name} (${tr ? 'VFS Ses' : 'VFS Audio'}) yüklendi`);
    }
  };

  // Open .ankasynth or recorded VFS audio when launched with a path
  useEffect(() => {
    if (!launchArgs?.path) return;
    const norm = normalizePath(launchArgs.path, userHome, userHome);
    openVfsAudioFile(norm);
  }, [launchArgs?.path, userHome]);

  // Real-time AnalyserNode FFT Spectrum Loop
  useEffect(() => {
    let rafId = 0;
    const dataArray = new Uint8Array(32);

    const tick = () => {
      const analyser = analyserRef.current;
      if (analyser && (playing || audioPlaying)) {
        analyser.getByteFrequencyData(dataArray);
        const bins = Array.from({ length: 20 }, (_, i) => {
          const v = dataArray[i] || 0;
          return Math.max(8, Math.min(100, Math.round((v / 255) * 100)));
        });
        setBars(bins);
      } else {
        setBars((prev) =>
          prev.some((b) => b > 10) ? prev.map((b) => Math.max(8, Math.round(b * 0.85))) : prev
        );
      }
      rafId = requestAnimationFrame(tick);
    };

    rafId = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(rafId);
  }, [playing, audioPlaying]);

  const playTone = (freq: number, wave: OscillatorType = 'sine', durationSec = 0.28) => {
    ensureAudio();
    const ctx = audioCtxRef.current;
    const master = gainRef.current;
    if (!ctx || !master) return;

    const osc = ctx.createOscillator();
    const env = ctx.createGain();
    osc.type = wave;
    osc.frequency.setValueAtTime(freq, ctx.currentTime);

    env.gain.setValueAtTime(0.001, ctx.currentTime);
    env.gain.exponentialRampToValueAtTime(1, ctx.currentTime + 0.02);
    env.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + durationSec);

    osc.connect(env);
    env.connect(master);
    osc.start();
    osc.stop(ctx.currentTime + durationSec + 0.02);
  };

  const track = tracks[trackIdx] || tracks[0];

  useEffect(() => {
    if (!playing || audioFileName) return;
    const intervalMs = Math.round((60 / track.bpm) * 1000 * 0.5);
    const id = window.setInterval(() => {
      setStep((prev) => {
        const next = (prev + 1) % track.notes.length;
        playTone(track.notes[next], track.waveform, intervalMs / 1000);
        return next;
      });
    }, intervalMs);
    return () => window.clearInterval(id);
  }, [playing, track, audioFileName, settings.volume, settings.muted]);

  useEffect(() => {
    return () => {
      if (audioSourceUrl && audioSourceUrl.startsWith('blob:')) URL.revokeObjectURL(audioSourceUrl);
    };
  }, [audioSourceUrl]);

  useEffect(() => {
    return () => {
      audioCtxRef.current?.close();
    };
  }, []);

  const updateCurrentTrack = (patch: Partial<SynthTrack>) => {
    setTracks((prev) =>
      prev.map((tItem, idx) => (idx === trackIdx ? { ...tItem, ...patch } : tItem))
    );
  };

  const handleSaveTrackToVfs = () => {
    const slug = track.title
      .toLowerCase()
      .replace(/[^a-z0-9-_]+/gi, '_')
      .replace(/^_|_$/g, '');
    const outPath = `${userHome}/Belgeler/${slug || 'sentez'}.ankasynth`;
    const res = writeFile(
      outPath,
      serializeAnkaSynthTrack(track),
      'application/vnd.ankaos.synth+json',
      false,
      'media'
    );
    if (res.ok) {
      showMsg(tr ? `Kaydedildi: ~/Belgeler/${slug}.ankasynth` : `Saved to ~/Belgeler`);
    } else {
      showMsg(res.error || (tr ? 'Sandbox izni gerekiyor' : 'Permission required'));
    }
  };

  const handleCreateNewTrack = () => {
    const nextNum = tracks.length + 1;
    const newTrack: SynthTrack = {
      id: `custom-${Date.now()}`,
      title: tr ? `Özel Parça #${nextNum}` : `Custom Track #${nextNum}`,
      bpm: 112,
      waveform: 'triangle',
      notes: [261.63, 293.66, 329.63, 392.0, 440.0, 392.0, 329.63, 261.63],
    };
    setTracks((prev) => [...prev, newTrack]);
    setTrackIdx(tracks.length);
    setAudioFileName(null);
    setShowSeqEditor(true);
  };

  const handleLocalAudioUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (audioSourceUrl) URL.revokeObjectURL(audioSourceUrl);
    const nextUrl = URL.createObjectURL(file);
    setPlaying(false);
    setAudioSourceUrl(nextUrl);
    setAudioFileName(file.name);
    setAudioPlaying(false);
    setAudioTime({ current: 0, duration: 0 });
    e.target.value = '';
  };

  const toggleLocalAudioPlay = async () => {
    const el = htmlAudioRef.current;
    if (!el) return;
    ensureAudio();
    const ctx = audioCtxRef.current;
    const gain = gainRef.current;
    if (ctx && gain && !mediaElemSrcRef.current) {
      mediaElemSrcRef.current = ctx.createMediaElementSource(el);
      mediaElemSrcRef.current.connect(gain);
    }
    if (el.paused) {
      await el.play();
      setAudioPlaying(true);
    } else {
      el.pause();
      setAudioPlaying(false);
    }
  };

  const vfsSynthFiles = [
    ...listDir(vfs, `${userHome}/Belgeler`).map((f) => ({ node: f, path: `${userHome}/Belgeler/${f.name}` })),
    ...listDir(vfs, `${userHome}/Müzik`).map((f) => ({ node: f, path: `${userHome}/Müzik/${f.name}` })),
  ].filter(
    (entry) =>
      entry.node.type === 'file' &&
      (entry.node.name.endsWith('.ankasynth') ||
        /\.(webm|wav|mp3|ogg|m4a|flac|aac)$/i.test(entry.node.name))
  );

  return (
    <div className="h-full w-full flex flex-col bg-[var(--anka-bg)] text-[var(--anka-text)] p-5 gap-4 overflow-y-auto os-scroll anka-theme-transition">
      {/* Header & Volume */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2.5 min-w-0">
          <div
            style={{ backgroundColor: 'var(--anka-accent-soft)', color: 'var(--anka-accent)' }}
            className="w-9 h-9 rounded-xl flex items-center justify-center shrink-0"
          >
            {audioFileName ? <FileAudio size={18} /> : <Music size={18} />}
          </div>
          <div className="min-w-0">
            <div className="text-sm font-semibold truncate">
              {audioFileName || track.title}
            </div>
            <div className="text-xs text-[var(--anka-text-subtle)] tabular-nums">
              {audioFileName
                ? `${formatTime(audioTime.current)} / ${formatTime(audioTime.duration)} · Yerel Ses`
                : `${track.bpm} BPM · ${track.waveform} · WebAudio FFT`}
            </div>
          </div>
        </div>

        <div className="flex items-center gap-1.5">
          <button
            onClick={() => fileInputRef.current?.click()}
            className="px-2.5 py-1.5 rounded-lg border border-[var(--anka-border)] bg-[var(--anka-surface)] hover:bg-[var(--anka-surface-elevated)] text-xs flex items-center gap-1.5"
            title={tr ? 'Bilgisayardan MP3/WAV/OGG Aç' : 'Open Local Audio File'}
          >
            <FolderOpen size={13} />
            <span>{tr ? 'Ses Dosyası Aç' : 'Open Audio'}</span>
          </button>
          <input
            ref={fileInputRef}
            type="file"
            accept="audio/*"
            onChange={handleLocalAudioUpload}
            className="hidden"
          />
          <button
            onClick={() => updateSettings({ muted: !settings.muted })}
            className="p-2 rounded-lg hover:bg-[var(--anka-surface-elevated)] text-[var(--anka-text-muted)] transition-colors"
          >
            {settings.muted ? <VolumeX size={16} /> : <Volume2 size={16} />}
          </button>
          <input
            type="range"
            min={0}
            max={100}
            value={settings.muted ? 0 : settings.volume}
            onChange={(e) =>
              updateSettings({ volume: Number(e.target.value), muted: false })
            }
            style={{ accentColor: 'var(--anka-accent)' }}
            className="w-20"
          />
        </div>
      </div>

      {statusNotice && (
        <div className="px-3 py-1.5 rounded-lg bg-[var(--anka-accent-soft)] text-[var(--anka-accent)] text-xs font-medium">
          {statusNotice}
        </div>
      )}

      {/* Real WebAudio AnalyserNode FFT Spectrum */}
      <div className="h-28 rounded-xl border border-[var(--anka-border)] bg-[var(--anka-surface)] px-4 flex items-end justify-between gap-1 py-3 shrink-0">
        {bars.map((val, i) => (
          <div
            key={i}
            style={{ height: `${val}%`, backgroundColor: 'var(--anka-accent)' }}
            className="flex-1 rounded-t opacity-85 transition-[height] duration-75"
          />
        ))}
      </div>

      {/* Local Audio Player Scrubber OR Track Selector */}
      {audioFileName && audioSourceUrl ? (
        <div className="p-3 rounded-xl border border-[var(--anka-border)] bg-[var(--anka-surface)] space-y-2">
          <audio
            ref={htmlAudioRef}
            src={audioSourceUrl}
            onTimeUpdate={(e) =>
              setAudioTime({
                current: e.currentTarget.currentTime,
                duration: e.currentTarget.duration || 0,
              })
            }
            onLoadedMetadata={(e) =>
              setAudioTime({
                current: 0,
                duration: e.currentTarget.duration || 0,
              })
            }
            onEnded={() => setAudioPlaying(false)}
          />
          <div className="flex items-center gap-3">
            <button
              onClick={() => void toggleLocalAudioPlay()}
              className="px-3.5 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold flex items-center gap-1.5"
            >
              {audioPlaying ? <Pause size={14} /> : <Play size={14} />}
              <span>{audioPlaying ? (tr ? 'Duraklat' : 'Pause') : tr ? 'Çal' : 'Play'}</span>
            </button>
            <input
              type="range"
              min={0}
              max={audioTime.duration || 1}
              step={0.1}
              value={audioTime.current}
              onChange={(e) => {
                const next = Number(e.target.value);
                if (htmlAudioRef.current) htmlAudioRef.current.currentTime = next;
              }}
              style={{ accentColor: 'var(--anka-accent)' }}
              className="flex-1"
            />
            <button
              onClick={() => {
                if (htmlAudioRef.current) htmlAudioRef.current.pause();
                setAudioPlaying(false);
                setAudioFileName(null);
              }}
              className="px-2.5 py-1 rounded-lg border border-[var(--anka-border)] text-xs text-[var(--anka-text-subtle)] hover:text-[var(--anka-text)]"
            >
              {tr ? 'Senteze Dön' : 'Back to Synth'}
            </button>
          </div>
        </div>
      ) : (
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-1.5 overflow-x-auto os-scroll flex-1">
            {tracks.map((tItem, idx) => (
              <button
                key={tItem.id}
                onClick={() => {
                  setTrackIdx(idx);
                  setStep(0);
                }}
                className={`px-3 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap transition-colors ${
                  trackIdx === idx
                    ? 'bg-[var(--anka-accent)] text-[var(--anka-accent-fg)]'
                    : 'bg-[var(--anka-surface)] border border-[var(--anka-border)] text-[var(--anka-text-muted)] hover:bg-[var(--anka-surface-elevated)]'
                }`}
              >
                {tItem.title}
              </button>
            ))}
            <button
              onClick={handleCreateNewTrack}
              title={tr ? 'Yeni Parça' : 'New Track'}
              className="p-1.5 rounded-lg border border-[var(--anka-border)] bg-[var(--anka-surface)] hover:bg-[var(--anka-surface-elevated)]"
            >
              <Plus size={14} />
            </button>
          </div>

          <div className="flex items-center gap-1.5 shrink-0">
            <button
              onClick={() => setShowSeqEditor((v) => !v)}
              className={`px-2.5 py-1.5 rounded-lg border text-xs flex items-center gap-1 ${
                showSeqEditor
                  ? 'border-[var(--anka-accent)] bg-[var(--anka-accent-soft)] text-[var(--anka-accent)]'
                  : 'border-[var(--anka-border)] bg-[var(--anka-surface)]'
              }`}
            >
              <Sliders size={13} />
              <span>{tr ? 'Sıralayıcı' : 'Sequencer'}</span>
            </button>
            <button
              onClick={handleSaveTrackToVfs}
              title={tr ? '.ankasynth olarak Belgeler dizinine kaydet' : 'Save .ankasynth to Belgeler'}
              className="p-1.5 rounded-lg border border-[var(--anka-border)] bg-[var(--anka-surface)] hover:bg-[var(--anka-surface-elevated)]"
            >
              <Save size={14} />
            </button>
            <button
              onClick={() => setPlaying((p) => !p)}
              className="px-4 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold flex items-center gap-1.5 transition-colors"
            >
              {playing ? <Pause size={14} /> : <Play size={14} />}
              <span>{playing ? (tr ? 'Duraklat' : 'Pause') : tr ? 'Çal' : 'Play'}</span>
            </button>
          </div>
        </div>
      )}

      {/* Custom 8-Step Synth Sequencer Editor */}
      {showSeqEditor && !audioFileName && (
        <div className="p-3.5 rounded-xl border border-[var(--anka-border)] bg-[var(--anka-surface)] space-y-3 text-xs">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <input
              type="text"
              value={track.title}
              onChange={(e) => updateCurrentTrack({ title: e.target.value })}
              className="px-2.5 py-1 rounded-md border border-[var(--anka-border)] bg-[var(--anka-surface-muted)] font-semibold outline-none w-44"
            />
            <div className="flex items-center gap-2">
              <span className="text-[var(--anka-text-subtle)] font-mono tabular-nums">
                {track.bpm} BPM
              </span>
              <input
                type="range"
                min={60}
                max={200}
                value={track.bpm}
                onChange={(e) => updateCurrentTrack({ bpm: Number(e.target.value) })}
                style={{ accentColor: 'var(--anka-accent)' }}
                className="w-24"
              />
              <select
                value={track.waveform}
                onChange={(e) =>
                  updateCurrentTrack({ waveform: e.target.value as OscillatorType })
                }
                className="px-2 py-1 rounded-md border border-[var(--anka-border)] bg-[var(--anka-surface-muted)] outline-none font-mono"
              >
                {WAVEFORMS.map((w) => (
                  <option key={w} value={w}>
                    {w}
                  </option>
                ))}
              </select>
              {vfsSynthFiles.length > 0 && (
                <button
                  onClick={() => setVfsPickerOpen((v) => !v)}
                  className="px-2 py-1 rounded-md border border-[var(--anka-border)] hover:bg-[var(--anka-surface-elevated)]"
                >
                  .ankasynth ({vfsSynthFiles.length})
                </button>
              )}
            </div>
          </div>

          {vfsPickerOpen && vfsSynthFiles.length > 0 && (
            <div className="flex flex-wrap gap-1.5 pt-1 border-t border-[var(--anka-border)]">
              {vfsSynthFiles.map((entry) => (
                <button
                  key={entry.node.id}
                  onClick={() => {
                    openVfsAudioFile(entry.path);
                    setVfsPickerOpen(false);
                  }}
                  className="px-2 py-1 rounded border border-[var(--anka-border)] bg-[var(--anka-surface-muted)] hover:border-[var(--anka-accent)] font-mono text-[11px]"
                >
                  {entry.node.name}
                </button>
              ))}
            </div>
          )}

          <div className="grid grid-cols-8 gap-1.5">
            {track.notes.map((freq, idx) => {
              const matchedKey = PIANO_KEYS.reduce((best, cur) =>
                Math.abs(cur.freq - freq) < Math.abs(best.freq - freq) ? cur : best
              );
              const isCurrentStep = playing && step === idx;
              const isSelected = editingStep === idx;
              return (
                <button
                  key={idx}
                  onClick={() => setEditingStep(isSelected ? null : idx)}
                  className={`py-2 rounded-lg border font-mono text-[11px] flex flex-col items-center gap-0.5 transition-colors ${
                    isSelected
                      ? 'border-[var(--anka-accent)] bg-[var(--anka-accent-soft)] text-[var(--anka-accent)]'
                      : isCurrentStep
                        ? 'border-emerald-500 bg-emerald-500/15 text-emerald-500 font-semibold'
                        : 'border-[var(--anka-border)] bg-[var(--anka-surface-muted)]'
                  }`}
                >
                  <span className="text-[10px] text-[var(--anka-text-subtle)]">#{idx + 1}</span>
                  <span>{matchedKey.label}</span>
                </button>
              );
            })}
          </div>
          {editingStep !== null && (
            <div className="text-[11px] text-[var(--anka-accent)]">
              {tr
                ? `Adım #${editingStep + 1} seçili — aşağıdan bir nota tuşuna basarak atayın.`
                : `Step #${editingStep + 1} selected — tap a piano key below to assign.`}
            </div>
          )}
        </div>
      )}

      {/* Interactive Synth Keyboard */}
      <div className="space-y-2 mt-auto">
        <div className="text-xs text-[var(--anka-text-subtle)] tabular-nums">
          {tr ? 'Canlı Sentezleyici Klavyesi' : 'Live Synthesizer Keys'} (Adım: {step + 1}/
          {track.notes.length})
        </div>
        <div className="grid grid-cols-5 sm:grid-cols-10 gap-1.5">
          {PIANO_KEYS.map((k) => (
            <button
              key={k.label}
              onPointerDown={() => {
                playTone(k.freq, track.waveform, 0.32);
                if (editingStep !== null) {
                  const nextNotes = [...track.notes];
                  nextNotes[editingStep] = k.freq;
                  updateCurrentTrack({ notes: nextNotes });
                }
              }}
              className="h-12 rounded-lg bg-[var(--anka-surface)] border border-[var(--anka-border)] hover:border-[var(--anka-accent)] hover:bg-[var(--anka-accent-soft)] active:scale-95 transition-all text-xs font-medium flex flex-col items-center justify-end pb-1.5"
            >
              <span>{k.label}</span>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};
