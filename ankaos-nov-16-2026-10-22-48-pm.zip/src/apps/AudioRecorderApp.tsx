import React, { useEffect, useRef, useState } from 'react';
import { Disc, FolderOpen, Mic, Play, Square, Waves } from 'lucide-react';
import { useOS } from '../os/kernel';
import { serializeAnkaSynthTrack } from '../os/mediaSynth';
import { formatBytes, HOME_PATH, listDir } from '../os/vfs';

export const AudioRecorderApp: React.FC<{ windowId: string }> = () => {
  const { vfs, writeFile, launchApp, currentUser, settings } = useOS();
  const tr = settings.language === 'tr';
  const userHome = currentUser.homeDir || HOME_PATH;
  const musicDir = `${userHome}/Müzik`;

  const [recording, setRecording] = useState(false);
  const [sourceMode, setSourceMode] = useState<'mic' | 'synth'>('mic');
  const [elapsedSec, setElapsedSec] = useState(0);
  const [statusMsg, setStatusMsg] = useState<string | null>(null);
  const [lastSavedUrl, setLastSavedUrl] = useState<string | null>(null);

  const canvasRef = useRef<HTMLCanvasElement>(null);
  const timerRef = useRef<number | null>(null);
  const rafRef = useRef<number | null>(null);
  const mediaRecRef = useRef<MediaRecorder | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const audioCtxRef = useRef<AudioContext | null>(null);
  const chunksRef = useRef<Blob[]>([]);

  const musicFiles = listDir(vfs, musicDir);

  useEffect(() => {
    return () => {
      if (timerRef.current) window.clearInterval(timerRef.current);
      if (rafRef.current) cancelAnimationFrame(rafRef.current);
      streamRef.current?.getTracks().forEach((t) => t.stop());
      void audioCtxRef.current?.close();
    };
  }, []);

  const drawWaveform = (analyser: AnalyserNode | null, active: boolean) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    const data = analyser ? new Uint8Array(analyser.frequencyBinCount) : null;

    const tick = () => {
      const w = canvas.width;
      const h = canvas.height;
      ctx.fillStyle = '#090d16';
      ctx.fillRect(0, 0, w, h);

      ctx.strokeStyle = 'rgba(56,189,248,0.22)';
      ctx.beginPath();
      ctx.moveTo(0, h / 2);
      ctx.lineTo(w, h / 2);
      ctx.stroke();

      if (active && analyser && data) {
        analyser.getByteTimeDomainData(data);
        ctx.strokeStyle = '#38bdf8';
        ctx.lineWidth = 2;
        ctx.beginPath();
        const slice = w / data.length;
        for (let i = 0; i < data.length; i++) {
          const y = ((data[i] - 128) / 128) * (h * 0.4) + h / 2;
          if (i === 0) ctx.moveTo(0, y);
          else ctx.lineTo(i * slice, y);
        }
        ctx.stroke();
        rafRef.current = requestAnimationFrame(tick);
      }
    };
    tick();
  };

  const stopRecording = () => {
    if (timerRef.current) {
      window.clearInterval(timerRef.current);
      timerRef.current = null;
    }
    if (rafRef.current) {
      cancelAnimationFrame(rafRef.current);
      rafRef.current = null;
    }
    setRecording(false);
    if (mediaRecRef.current && mediaRecRef.current.state !== 'inactive') {
      mediaRecRef.current.stop();
    } else {
      streamRef.current?.getTracks().forEach((t) => t.stop());
    }
  };

  const startRecording = async () => {
    if (recording) return;
    setStatusMsg(null);
    setElapsedSec(0);
    chunksRef.current = [];

    try {
      let stream: MediaStream;
      let usedSynth = sourceMode === 'synth';

      if (sourceMode === 'mic' && navigator.mediaDevices?.getUserMedia) {
        try {
          stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        } catch {
          usedSynth = true;
          const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
          const actx = new AudioCtx();
          audioCtxRef.current = actx;
          const osc = actx.createOscillator();
          const gain = actx.createGain();
          osc.type = 'triangle';
          osc.frequency.value = 329.63;
          gain.gain.value = 0.08;
          const dest = actx.createMediaStreamDestination();
          osc.connect(gain);
          gain.connect(dest);
          osc.start();
          stream = dest.stream;
        }
      } else {
        usedSynth = true;
        const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
        const actx = new AudioCtx();
        audioCtxRef.current = actx;
        const osc = actx.createOscillator();
        const gain = actx.createGain();
        osc.type = 'sine';
        osc.frequency.value = 440;
        gain.gain.value = 0.08;
        const dest = actx.createMediaStreamDestination();
        osc.connect(gain);
        gain.connect(dest);
        osc.start();
        stream = dest.stream;
      }

      streamRef.current = stream;
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      const analyserCtx = audioCtxRef.current || new AudioCtx();
      audioCtxRef.current = analyserCtx;
      const src = analyserCtx.createMediaStreamSource(stream);
      const analyser = analyserCtx.createAnalyser();
      analyser.fftSize = 256;
      src.connect(analyser);

      const rec = new MediaRecorder(stream);
      mediaRecRef.current = rec;
      rec.ondataavailable = (ev) => {
        if (ev.data.size > 0) chunksRef.current.push(ev.data);
      };
      rec.onstop = () => {
        stream.getTracks().forEach((t) => t.stop());
        const blob = new Blob(chunksRef.current, { type: rec.mimeType || 'audio/webm' });
        const reader = new FileReader();
        reader.onload = () => {
          const dataUrl = typeof reader.result === 'string' ? reader.result : '';
          const stamp = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
          const path = `${musicDir}/kayit_${stamp}.webm`;
          const wRes = writeFile(path, dataUrl, 'audio/webm', false, 'pkg-recorder');
          setLastSavedUrl(dataUrl);
          setStatusMsg(
            wRes.ok
              ? tr
                ? `Kayıt kaydedildi: ${path}`
                : `Recording saved: ${path}`
              : wRes.error || 'Kaydedilemedi'
          );
        };
        reader.readAsDataURL(blob);
      };

      rec.start(250);
      setRecording(true);
      setStatusMsg(
        usedSynth
          ? tr
            ? 'Mikrofon erişimi yerine dahili Sentezleyici kanalı kaydediliyor...'
            : 'Recording internal Synth tone stream...'
          : tr
            ? 'Mikrofon kaydı etkin...'
            : 'Microphone recording active...'
      );
      drawWaveform(analyser, true);
      timerRef.current = window.setInterval(() => setElapsedSec((s) => s + 1), 1000);
    } catch {
      // Pure .ankasynth fallback when MediaRecorder is unsupported
      const synthJson = serializeAnkaSynthTrack({
        id: `rec-${Date.now()}`,
        title: 'Anka Stüdyo Kaydı',
        bpm: 120,
        waveform: 'triangle',
        notes: [261.63, 329.63, 392.0, 523.25, 392.0, 329.63],
      });
      const path = `${musicDir}/studyo_ornek_${Date.now().toString().slice(-4)}.ankasynth`;
      writeFile(path, synthJson, 'application/vnd.ankaos.synth+json', false, 'pkg-recorder');
      setStatusMsg(tr ? `Sentez kayıt oluşturuldu: ${path}` : `Saved synth sequence: ${path}`);
    }
  };

  return (
    <div className="h-full w-full flex flex-col bg-[var(--anka-surface)] text-[var(--anka-text)] anka-theme-transition">
      <div className="px-5 py-3.5 border-b border-[var(--anka-border)] bg-[var(--anka-surface-muted)] flex flex-wrap items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          <Mic size={16} className="text-rose-500" />
          <h2 className="text-sm font-semibold font-display">
            {tr ? 'Ses & Mikrofon Stüdyosu' : 'Audio & Microphone Studio'}
          </h2>
        </div>
        <div className="flex items-center gap-1 p-1 rounded-lg bg-[var(--anka-surface)] border border-[var(--anka-border)] text-xs">
          <button
            onClick={() => setSourceMode('mic')}
            disabled={recording}
            className={`px-2.5 py-1 rounded-md ${
              sourceMode === 'mic'
                ? 'bg-[var(--anka-accent)] text-[var(--anka-accent-fg)] font-medium'
                : 'text-[var(--anka-text-subtle)]'
            }`}
          >
            {tr ? 'Mikrofon' : 'Mic'}
          </button>
          <button
            onClick={() => setSourceMode('synth')}
            disabled={recording}
            className={`px-2.5 py-1 rounded-md ${
              sourceMode === 'synth'
                ? 'bg-[var(--anka-accent)] text-[var(--anka-accent-fg)] font-medium'
                : 'text-[var(--anka-text-subtle)]'
            }`}
          >
            {tr ? 'Dahili Sentez' : 'Internal Synth'}
          </button>
        </div>
      </div>

      <div className="p-5 space-y-4">
        <div className="rounded-2xl border border-[var(--anka-border)] bg-[#090d16] p-3 space-y-3">
          <canvas ref={canvasRef} width={580} height={110} className="w-full h-24 rounded-lg" />
          <div className="flex items-center justify-between text-xs text-slate-300 font-mono tabular-nums">
            <span className="flex items-center gap-1.5">
              <Waves size={13} className="text-sky-400" />
              <span>{recording ? (tr ? 'KAYITTA' : 'REC') : tr ? 'HAZIR' : 'READY'}</span>
            </span>
            <span>
              {String(Math.floor(elapsedSec / 60)).padStart(2, '0')}:
              {String(elapsedSec % 60).padStart(2, '0')}
            </span>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {!recording ? (
            <button
              onClick={() => void startRecording()}
              className="flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-semibold bg-rose-600 text-white hover:bg-rose-500 transition-colors"
            >
              <Disc size={14} />
              <span>{tr ? 'Kaydı Başlat' : 'Start Recording'}</span>
            </button>
          ) : (
            <button
              onClick={stopRecording}
              className="flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-semibold bg-amber-600 text-white hover:bg-amber-500 transition-colors"
            >
              <Square size={13} />
              <span>{tr ? 'Durdur ve ~/Müzik İçine Kaydet' : 'Stop & Save to ~/Müzik'}</span>
            </button>
          )}
          <button
            onClick={() => launchApp('files', { path: musicDir })}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs border border-[var(--anka-border-strong)] hover:bg-[var(--anka-surface-elevated)]"
          >
            <FolderOpen size={13} />
            <span>~/Müzik</span>
          </button>
        </div>

        {statusMsg && (
          <div className="text-xs text-emerald-500 font-medium">{statusMsg}</div>
        )}
        {lastSavedUrl && (
          <audio controls src={lastSavedUrl} className="w-full h-9" />
        )}
      </div>

      <div className="flex-1 overflow-y-auto os-scroll border-t border-[var(--anka-border)] bg-[var(--anka-bg)] p-4 space-y-2">
        <div className="text-xs font-semibold text-[var(--anka-text-subtle)]">
          {tr ? '~/Müzik Dosyaları' : 'Files in ~/Müzik'}
        </div>
        {musicFiles.length === 0 ? (
          <div className="text-xs text-[var(--anka-text-subtle)] py-4">
            {tr ? 'Henüz kaydedilmiş ses dosyası yok.' : 'No recordings yet.'}
          </div>
        ) : (
          musicFiles.map((f) => {
            const p = `${musicDir}/${f.name}`;
            return (
              <div
                key={f.id}
                className="p-2.5 rounded-xl border border-[var(--anka-border)] bg-[var(--anka-surface)] flex items-center justify-between text-xs"
              >
                <div className="min-w-0">
                  <div className="font-medium truncate">{f.name}</div>
                  <div className="text-[11px] font-mono text-[var(--anka-text-subtle)] tabular-nums">
                    {formatBytes(f.size)}
                  </div>
                </div>
                <button
                  onClick={() => launchApp('media', { path: p })}
                  className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-[var(--anka-accent-soft)] text-[var(--anka-accent)] font-medium"
                >
                  <Play size={11} />
                  <span>{tr ? 'AnkaSes' : 'Play'}</span>
                </button>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
