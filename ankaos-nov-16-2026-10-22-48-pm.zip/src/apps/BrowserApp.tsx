import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  ArrowLeft,
  ArrowRight,
  BookOpen,
  Clock,
  Code2,
  Download,
  ExternalLink,
  FileCode2,
  FileText,
  FolderOpen,
  Globe,
  Home,
  Image as ImageIcon,
  Newspaper,
  Plus,
  RefreshCw,
  Search,
  Star,
  Trash2,
  WifiOff,
  X,
} from 'lucide-react';
import { AnkaLogo } from '../components/AnkaLogo';
import { useOS } from '../os/kernel';
import {
  fetchPageLive,
  fetchSearchSuggestions,
  LiveDnsResponse,
  LivePageFetchResponse,
  LiveSearchResponse,
  resolveDnsLive,
  searchWebLive,
  validateExternalUrl,
} from '../os/net';
import {
  LocalVfsMatch,
  parseSmartQuery,
  SearchCategory,
  searchLocalVfs,
} from '../os/searchUtils';
import { ACCENT_PALETTES, THEME_PALETTES } from '../os/theme';
import { AccentColor, ThemeMode } from '../os/types';
import { formatBytes, getNodeAtPath, HOME_PATH, listDir, normalizePath } from '../os/vfs';

interface BrowserAppProps {
  windowId: string;
  launchArgs?: Record<string, string>;
}

interface BookmarkEntry {
  title: string;
  url: string;
}

interface BrowserTab {
  id: string;
  title: string;
  url: string;
  history: string[];
  historyIndex: number;
  readerMode: boolean;
  loading: boolean;
  searchData: LiveSearchResponse | null;
  readerData: LivePageFetchResponse | null;
  error: string | null;
}

function buildDocsHtml(theme: ThemeMode, accent: AccentColor): string {
  const palette = THEME_PALETTES[theme];
  const accentHex = (ACCENT_PALETTES[accent] || ACCENT_PALETTES.sky)[theme].hex;
  const codeColor = theme === 'dark' ? '#34d399' : '#047857';

  return `<!doctype html>
<html lang="tr">
<head>
<meta charset="utf-8" />
<style>
  body { font-family: system-ui, sans-serif; margin: 0; padding: 36px; background: ${palette.surface}; color: ${palette.text}; line-height: 1.65; transition: background-color 180ms ease, color 180ms ease; }
  .wrap { max-width: 720px; margin: 0 auto; }
  h1 { font-size: 28px; color: ${palette.text}; margin-bottom: 8px; }
  h2 { font-size: 18px; color: ${accentHex}; margin-top: 28px; border-bottom: 1px solid ${palette.border}; padding-bottom: 6px; }
  code { font-family: monospace; background: ${palette.surfaceElevated}; padding: 2px 6px; border-radius: 5px; color: ${codeColor}; }
  p, li { color: ${palette.textMuted}; }
  strong { color: ${palette.text}; }
  ul { padding-left: 20px; }
  li { margin: 6px 0; }
</style>
</head>
<body>
  <div class="wrap">
    <h1>AnkaOS v3.5 Sistem Kılavuzu</h1>
    <p>AnkaOS; Ring 0/Ring 3 yetki ayrımı, Web Worker Watchdog JS Sandbox, gerçek WebAssembly (.wasm) çalıştırıcısı, Preemptive Priority zamanlayıcısı, Copy-on-Write (CoW) + LRU Swap bellek yönetimi, AnkaArama canlı internet motoru, ankactl servis/cron yöneticisi ve VFS Bütünlük (fsck/tar) araçlarıyla donatılmış tam yığın işletim sistemidir.</p>

    <h2>1. Canlı İnternet, AnkaArama &amp; AnkaTarayıcı</h2>
    <ul>
      <li><strong>AnkaArama (<code>ankaos://arama</code>):</strong> Express arka uç köprüsü üzerinden gerçek zamanlı DuckDuckGo + Vikipedi araması, anlık bilgi kartları ve SSRF korumalı canlı sayfa vekili (proxy) sunar.</li>
      <li><strong>Okuma Modu &amp; İndirmeler:</strong> Sayfaları temiz Okuma Modu ile görüntüleyebilir, tek tıkla <code>~/İndirilenler</code> klasörüne kaydedebilirsiniz.</li>
      <li><strong>Uçbirim İnternet Araçları:</strong> <code>search</code>, <code>nslookup</code>, <code>wget</code>, CORS'suz <code>curl https://...</code> ve canlı <code>ping</code> desteği içerir.</li>
    </ul>

    <h2>2. Eksiksiz Çekirdek &amp; Sistem Altsistemleri</h2>
    <ul>
      <li><strong>Servis &amp; Cron Yöneticisi (<code>ankactl</code> / <code>crontab</code>):</strong> <code>vfsd</code>, <code>netd</code>, <code>crond</code>, <code>audiod</code>, <code>pkgd</code> servislerini yönetir ve zamanlanmış arka plan görevlerini çalıştırır.</li>
      <li><strong>Depolama Analizi (<code>du</code>), <code>fsck</code> &amp; Arşivleme (<code>tar</code>):</strong> Dizin boyut analizi, otomatik VFS onarımı ve <code>.ankatar</code> arşiv paketleme desteklenir.</li>
      <li><strong>Güç Profilleri:</strong> Üst çubuktan <em>Yüksek Performans (25 ms)</em>, <em>Dengeli (50 ms)</em> ve <em>Güç Tasarrufu (100 ms)</em> zamanlayıcı kuantumu seçilebilir.</li>
    </ul>

    <h2>3. Doğrulama &amp; Kısayollar</h2>
    <ul>
      <li>Uçbirimde <code>selftest</code> komutuyla tüm <strong>42 çekirdek ve ağ testini</strong> çalıştırın.</li>
      <li><code>Alt + Space</code> / <code>Ctrl + K</code>: Hızlı Başlatıcı &amp; Web Araması | <code>Alt + 1..4</code>: Sanal çalışma alanları</li>
    </ul>
  </div>
</body>
</html>`;
}

function parseSearchUrl(url: string): { query: string; category: SearchCategory } {
  if (!url.startsWith('ankaos://arama')) return { query: '', category: 'all' };
  const qIdx = url.indexOf('?');
  if (qIdx === -1) return { query: '', category: 'all' };
  const params = new URLSearchParams(url.slice(qIdx + 1));
  const query = params.get('q') || '';
  const rawCat = (params.get('cat') || 'all').toLowerCase();
  const category = (['all', 'wiki', 'dev', 'news', 'images', 'files'].includes(rawCat)
    ? rawCat
    : 'all') as SearchCategory;
  return { query, category };
}

function buildSearchUrl(query: string, category: SearchCategory = 'all'): string {
  const clean = query.trim();
  if (!clean) return 'ankaos://arama';
  const params = new URLSearchParams({ q: clean });
  if (category !== 'all') params.set('cat', category);
  return `ankaos://arama?${params.toString()}`;
}

function classifyNavigationTarget(rawInput: string, userHome: string, category: SearchCategory = 'all'): string {
  const trimmed = rawInput.trim();
  if (!trimmed) return 'ankaos://arama';
  if (trimmed.startsWith('ankaos://') || trimmed.startsWith('vfs://')) {
    return trimmed;
  }
  if (trimmed.startsWith('/') || trimmed.startsWith('~/')) {
    return `vfs://${normalizePath(trimmed, userHome, userHome)}`;
  }
  if (/^https?:\/\//i.test(trimmed)) {
    return trimmed;
  }
  // Hostname heuristic (contains dot, no spaces, valid domain chars, not a decimal number)
  if (
    !/\s/.test(trimmed) &&
    !/^\d+(\.\d+)+$/.test(trimmed) &&
    /^[a-z0-9-]+(\.[a-z0-9-]+)+(\/.*)?$/i.test(trimmed)
  ) {
    return `https://${trimmed}`;
  }
  const smart = parseSmartQuery(trimmed);
  if (smart?.kind === 'bang' && smart.cleanedQuery && smart.categoryOverride) {
    return buildSearchUrl(smart.cleanedQuery, smart.categoryOverride);
  }
  return buildSearchUrl(trimmed, category);
}

function getTabTitleForUrl(url: string, tr: boolean): string {
  if (url === 'ankaos://arama') return 'AnkaArama';
  if (url.startsWith('ankaos://arama?')) {
    const { query } = parseSearchUrl(url);
    return query ? `${query} — AnkaArama` : 'AnkaArama';
  }
  if (url === 'ankaos://kilavuz') return tr ? 'Sistem Kılavuzu' : 'System Manual';
  if (url.startsWith('vfs://')) return url.split('/').pop() || 'VFS';
  try {
    return new URL(url).hostname.replace(/^www\./, '');
  } catch {
    return url;
  }
}

function makeTab(initialUrl: string, tr: boolean): BrowserTab {
  return {
    id: `tab-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
    title: getTabTitleForUrl(initialUrl, tr),
    url: initialUrl,
    history: [initialUrl],
    historyIndex: 0,
    readerMode: false,
    loading: false,
    searchData: null,
    readerData: null,
    error: null,
  };
}

export const BrowserApp: React.FC<BrowserAppProps> = ({ launchArgs }) => {
  const {
    vfs,
    writeFile,
    deleteNode,
    settings,
    launchApp,
    currentUser,
    recordNetworkTraffic,
    netStatus,
    refreshNetStatus,
  } = useOS();
  const tr = settings.language === 'tr';
  const lang = settings.language;
  const userHome = currentUser.homeDir || HOME_PATH;
  const bookmarksPath = `${userHome}/.bookmarks.json`;

  const startUrl = useMemo(() => {
    if (launchArgs?.path) {
      return `vfs://${normalizePath(launchArgs.path, userHome, userHome)}`;
    }
    if (launchArgs?.query) {
      return `ankaos://arama?q=${encodeURIComponent(launchArgs.query)}`;
    }
    if (launchArgs?.url) {
      return classifyNavigationTarget(launchArgs.url, userHome);
    }
    return 'ankaos://arama';
  }, [launchArgs?.path, launchArgs?.query, launchArgs?.url, userHome]);

  const [tabs, setTabs] = useState<BrowserTab[]>(() => [makeTab(startUrl, tr)]);
  const [activeTabId, setActiveTabId] = useState<string>(() => tabs[0].id);
  const [addressInput, setAddressInput] = useState(startUrl);
  const [searchBoxInput, setSearchBoxInput] = useState(launchArgs?.query || '');
  const [reloadTick, setReloadTick] = useState(0);
  const [toastMsg, setToastMsg] = useState<string | null>(null);
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [drawerTab, setDrawerTab] = useState<'downloads' | 'history'>('downloads');
  const [visitLog, setVisitLog] = useState<{ url: string; title: string; at: number }[]>([]);
  const [recentQueries, setRecentQueries] = useState<string[]>([]);
  const [suggestions, setSuggestions] = useState<string[]>([]);
  const [suggestOpen, setSuggestOpen] = useState(false);
  const [activeSuggestIdx, setActiveSuggestIdx] = useState(-1);
  const [dnsQuickResult, setDnsQuickResult] = useState<LiveDnsResponse | null>(null);
  const [lightboxImage, setLightboxImage] = useState<{
    title: string;
    thumbUrl: string;
    pageUrl: string;
    metaText: string;
  } | null>(null);
  const addressInputRef = useRef<HTMLInputElement>(null);
  const searchBoxRef = useRef<HTMLInputElement>(null);

  const downloadFiles = useMemo(() => listDir(vfs, `${userHome}/İndirilenler`), [vfs, userHome]);

  const activeTab = useMemo(
    () => tabs.find((t) => t.id === activeTabId) || tabs[0],
    [tabs, activeTabId]
  );

  const { query: activeSearchQuery, category: activeSearchCategory } = useMemo(
    () => parseSearchUrl(activeTab.url),
    [activeTab.url]
  );

  const localVfsHits: LocalVfsMatch[] = useMemo(
    () => (activeSearchQuery ? searchLocalVfs(vfs, userHome, activeSearchQuery) : []),
    [activeSearchQuery, vfs, userHome]
  );

  // Debounced live autocomplete suggestions when typing in AnkaArama search box
  useEffect(() => {
    const q = searchBoxInput.trim();
    if (q.length < 2 || q.startsWith('!') || q.startsWith('#') || q.startsWith('http')) {
      setSuggestions([]);
      return;
    }
    const timer = window.setTimeout(async () => {
      const list = await fetchSearchSuggestions(q, lang);
      setSuggestions(list);
      setActiveSuggestIdx(-1);
    }, 200);
    return () => window.clearTimeout(timer);
  }, [searchBoxInput, lang]);

  const bookmarks: BookmarkEntry[] = useMemo(() => {
    const node = getNodeAtPath(vfs, bookmarksPath);
    if (!node || node.type !== 'file' || !node.content) return [];
    try {
      const parsed = JSON.parse(node.content) as BookmarkEntry[];
      return Array.isArray(parsed) ? parsed : [];
    } catch {
      return [];
    }
  }, [vfs, bookmarksPath]);

  const showToast = (msg: string) => {
    setToastMsg(msg);
    setTimeout(() => setToastMsg(null), 3000);
  };

  const updateTab = useCallback((tabId: string, updater: (prev: BrowserTab) => BrowserTab) => {
    setTabs((prev) => prev.map((t) => (t.id === tabId ? updater(t) : t)));
  }, []);

  const loadContentForUrl = useCallback(
    async (tabId: string, targetUrl: string, forceReader = false) => {
      if (targetUrl.startsWith('ankaos://arama?')) {
        const { query: q, category } = parseSearchUrl(targetUrl);
        setSearchBoxInput(q);
        setSuggestOpen(false);
        if (!q) return;

        setRecentQueries((prev) => [q, ...prev.filter((item) => item !== q)].slice(0, 6));

        const smart = parseSmartQuery(q);
        if (smart?.kind === 'dns' && smart.dnsHost) {
          setDnsQuickResult(null);
          void resolveDnsLive(smart.dnsHost).then(setDnsQuickResult);
        } else {
          setDnsQuickResult(null);
        }

        if (category === 'files') {
          updateTab(tabId, (t) => ({
            ...t,
            loading: false,
            error: null,
            title: `${q} — AnkaArama`,
          }));
          return;
        }

        updateTab(tabId, (t) => ({
          ...t,
          loading: true,
          error: null,
          title: `${q} — AnkaArama`,
        }));
        try {
          const data = await searchWebLive(q, lang, category);
          recordNetworkTraffic('eth0', JSON.stringify(data).length, q.length + 64);
          updateTab(tabId, (t) => ({
            ...t,
            loading: false,
            searchData: data,
            error: !data.ok && data.results.length === 0 ? (tr ? 'Arama motoru yanıt vermedi.' : 'Search upstream unreachable.') : null,
          }));
        } catch (err) {
          updateTab(tabId, (t) => ({
            ...t,
            loading: false,
            error: err instanceof Error ? err.message : 'Arama başarısız',
          }));
        }
        return;
      }

      if ((targetUrl.startsWith('http://') || targetUrl.startsWith('https://')) && forceReader) {
        updateTab(tabId, (t) => ({ ...t, loading: true, error: null }));
        try {
          const page = await fetchPageLive(targetUrl);
          recordNetworkTraffic('eth0', page.bytes || 512, 128);
          updateTab(tabId, (t) => ({
            ...t,
            loading: false,
            readerData: page,
            title: page.title || t.title,
            error: page.ok ? null : page.error || 'Sayfa yüklenemedi',
          }));
        } catch (err) {
          updateTab(tabId, (t) => ({
            ...t,
            loading: false,
            error: err instanceof Error ? err.message : 'Sayfa alınamadı',
          }));
        }
      }
    },
    [lang, recordNetworkTraffic, tr, updateTab]
  );

  const navigateTabTo = useCallback(
    (tabId: string, rawTarget: string, options?: { replace?: boolean; readerMode?: boolean }) => {
      const normalized = classifyNavigationTarget(rawTarget, userHome);
      setAddressInput(normalized);
      const tabTitle = getTabTitleForUrl(normalized, tr);
      if (normalized !== 'ankaos://arama') {
        setVisitLog((prev) => [
          { url: normalized, title: tabTitle, at: Date.now() },
          ...prev.filter((v) => v.url !== normalized).slice(0, 39),
        ]);
      }
      updateTab(tabId, (t) => {
        const nextHistory = options?.replace
          ? t.history
          : [...t.history.slice(0, t.historyIndex + 1), normalized];
        const nextIdx = options?.replace ? t.historyIndex : nextHistory.length - 1;
        return {
          ...t,
          url: normalized,
          title: tabTitle,
          history: nextHistory,
          historyIndex: nextIdx,
          readerMode: options?.readerMode ?? false,
          error: null,
          readerData: null,
          searchData: normalized === 'ankaos://arama' ? null : t.searchData,
        };
      });
      void loadContentForUrl(tabId, normalized, options?.readerMode ?? false);
    },
    [loadContentForUrl, tr, updateTab, userHome]
  );

  // Sync incoming launchArgs changes (e.g., from Spotlight "Web'de Ara" or FilesApp)
  useEffect(() => {
    if (launchArgs?.path || launchArgs?.query || launchArgs?.url) {
      navigateTabTo(activeTab.id, startUrl);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [launchArgs?.path, launchArgs?.query, launchArgs?.url]);

  // Trigger initial search if tab starts on a query URL
  useEffect(() => {
    if (startUrl.startsWith('ankaos://arama?q=') || startUrl.startsWith('http')) {
      void loadContentForUrl(tabs[0].id, startUrl, false);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Keep address bar in sync when switching tabs
  useEffect(() => {
    if (activeTab) {
      setAddressInput(activeTab.url);
    }
  }, [activeTab]);

  // Listen to link clicks inside /api/proxy iframes
  useEffect(() => {
    const onMessage = (ev: MessageEvent) => {
      if (ev.data && ev.data.type === 'ankaos-browser-navigate' && typeof ev.data.url === 'string') {
        navigateTabTo(activeTab.id, ev.data.url);
      }
    };
    window.addEventListener('message', onMessage);
    return () => window.removeEventListener('message', onMessage);
  }, [activeTab.id, navigateTabTo]);

  const handleAddressSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    navigateTabTo(activeTab.id, addressInput);
  };

  const handleGoBack = () => {
    if (activeTab.historyIndex <= 0) return;
    const prevIdx = activeTab.historyIndex - 1;
    const prevUrl = activeTab.history[prevIdx];
    setAddressInput(prevUrl);
    updateTab(activeTab.id, (t) => ({
      ...t,
      url: prevUrl,
      title: getTabTitleForUrl(prevUrl, tr),
      historyIndex: prevIdx,
      readerMode: false,
      error: null,
    }));
    void loadContentForUrl(activeTab.id, prevUrl, false);
  };

  const handleGoForward = () => {
    if (activeTab.historyIndex >= activeTab.history.length - 1) return;
    const nextIdx = activeTab.historyIndex + 1;
    const nextUrl = activeTab.history[nextIdx];
    setAddressInput(nextUrl);
    updateTab(activeTab.id, (t) => ({
      ...t,
      url: nextUrl,
      title: getTabTitleForUrl(nextUrl, tr),
      historyIndex: nextIdx,
      readerMode: false,
      error: null,
    }));
    void loadContentForUrl(activeTab.id, nextUrl, false);
  };

  const handleReload = () => {
    setReloadTick((n) => n + 1);
    void loadContentForUrl(activeTab.id, activeTab.url, activeTab.readerMode);
  };

  const toggleReaderMode = () => {
    if (!activeTab.url.startsWith('http://') && !activeTab.url.startsWith('https://')) return;
    const nextMode = !activeTab.readerMode;
    updateTab(activeTab.id, (t) => ({ ...t, readerMode: nextMode }));
    if (nextMode && !activeTab.readerData) {
      void loadContentForUrl(activeTab.id, activeTab.url, true);
    }
  };

  const isBookmarked = bookmarks.some((b) => b.url === activeTab.url);

  const toggleBookmark = () => {
    if (activeTab.url === 'ankaos://arama') return;
    const next = isBookmarked
      ? bookmarks.filter((b) => b.url !== activeTab.url)
      : [...bookmarks, { title: activeTab.title, url: activeTab.url }];
    writeFile(bookmarksPath, JSON.stringify(next, null, 2), 'application/json', false, 'browser');
    showToast(isBookmarked ? (tr ? 'Yer imi kaldırıldı' : 'Bookmark removed') : tr ? 'Yer imlerine eklendi' : 'Bookmark added');
  };

  const handleSaveDownload = async () => {
    if (!activeTab.url.startsWith('http://') && !activeTab.url.startsWith('https://')) return;
    showToast(tr ? 'Sayfa VFS ~/İndirilenler klasörüne indiriliyor...' : 'Downloading to ~/İndirilenler...');
    try {
      const page = activeTab.readerData || (await fetchPageLive(activeTab.url));
      if (!page.ok || !page.rawText) {
        showToast(page.error || (tr ? 'İndirme başarısız' : 'Download failed'));
        return;
      }
      const hostSlug = new URL(activeTab.url).hostname.replace(/[^a-z0-9.-]/gi, '_');
      const isHtml = (page.contentType || '').includes('html');
      const ext = isHtml ? 'html' : 'txt';
      const filePath = `${userHome}/İndirilenler/${hostSlug}_${Date.now()}.${ext}`;
      const res = writeFile(filePath, page.rawText, isHtml ? 'text/html' : 'text/plain', false, 'browser');
      showToast(
        res.ok
          ? tr
            ? `İndirildi: ~/İndirilenler/${hostSlug}.${ext}`
            : `Saved to ~/İndirilenler`
          : res.error || 'Yazma hatası'
      );
    } catch (err) {
      showToast(err instanceof Error ? err.message : 'İndirme hatası');
    }
  };

  const addNewTab = () => {
    const t = makeTab('ankaos://arama', tr);
    setTabs((prev) => [...prev, t]);
    setActiveTabId(t.id);
    setAddressInput('ankaos://arama');
    setSearchBoxInput('');
  };

  const closeTab = (tabId: string) => {
    if (tabs.length === 1) {
      navigateTabTo(tabId, 'ankaos://arama');
      return;
    }
    const idx = tabs.findIndex((t) => t.id === tabId);
    const nextTabs = tabs.filter((t) => t.id !== tabId);
    setTabs(nextTabs);
    if (activeTabId === tabId) {
      const fallback = nextTabs[Math.max(0, idx - 1)];
      setActiveTabId(fallback.id);
    }
  };

  const highlightTerms = (text: string, query: string): React.ReactNode => {
    const terms = query
      .trim()
      .split(/\s+/)
      .filter((w) => w.length >= 2)
      .slice(0, 4);
    if (!text || terms.length === 0) return text;
    const escaped = terms.map((w) => w.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')).join('|');
    const regex = new RegExp(`(${escaped})`, 'gi');
    const parts = text.split(regex);
    return parts.map((part, idx) =>
      idx % 2 === 1 ? (
        <mark key={idx} className="bg-[var(--anka-accent-soft)] text-[var(--anka-text)] rounded px-0.5 font-medium">
          {part}
        </mark>
      ) : (
        part
      )
    );
  };

  const renderSearchHome = () => {
    const queryStr = activeSearchQuery;
    const activeCategory = activeSearchCategory;
    const smartIntent = queryStr ? parseSmartQuery(queryStr) : null;
    const searchData = activeTab.searchData;

    const categories: Array<{
      id: SearchCategory;
      labelTr: string;
      labelEn: string;
      icon: React.ReactNode;
    }> = [
      { id: 'all', labelTr: 'Tümü', labelEn: 'All', icon: <Search size={12} /> },
      { id: 'wiki', labelTr: 'Vikipedi', labelEn: 'Wiki', icon: <BookOpen size={12} /> },
      { id: 'dev', labelTr: 'Geliştirici', labelEn: 'Developer', icon: <Code2 size={12} /> },
      { id: 'news', labelTr: 'Haberler', labelEn: 'News', icon: <Newspaper size={12} /> },
      { id: 'images', labelTr: 'Görseller', labelEn: 'Images', icon: <ImageIcon size={12} /> },
      { id: 'files', labelTr: `VFS (${localVfsHits.length})`, labelEn: `Files (${localVfsHits.length})`, icon: <FolderOpen size={12} /> },
    ];

    const submitWithSuggestion = (val: string, cat: SearchCategory = activeCategory) => {
      setSearchBoxInput(val);
      setSuggestOpen(false);
      navigateTabTo(activeTab.id, classifyNavigationTarget(val, userHome, cat));
    };

    const handleCategorySwitch = (nextCat: SearchCategory) => {
      if (!queryStr) return;
      navigateTabTo(activeTab.id, buildSearchUrl(queryStr, nextCat));
    };

    return (
      <div className="h-full overflow-y-auto os-scroll bg-[var(--anka-surface)] px-6 py-7">
        <div className="max-w-4xl mx-auto space-y-6">
          {/* AnkaArama Brand + Search Input */}
          <div className="space-y-4">
            <div className="flex items-center justify-between gap-4">
              <div className="flex items-center gap-3">
                <AnkaLogo size={34} withFrame />
                <div>
                  <h1 className="text-2xl font-display font-bold tracking-tight text-[var(--anka-text)]">
                    AnkaArama
                  </h1>
                  <p className="text-xs text-[var(--anka-text-subtle)]">
                    {tr
                      ? 'Çoklu web motoru, Vikipedi bilgi kartı, GitHub/npm geliştirici araması ve VFS dizini'
                      : 'Multi-engine web search, Wikipedia cards, developer registry & local VFS index'}
                  </p>
                </div>
              </div>
              <button
                onClick={() => void refreshNetStatus()}
                className="text-xs font-mono text-[var(--anka-text-subtle)] hover:text-[var(--anka-text)] flex items-center gap-1.5 whitespace-nowrap"
                title={tr ? 'Bağlantıyı test et' : 'Test internet'}
              >
                <Globe size={13} className={netStatus?.online === false ? 'text-rose-500' : 'text-emerald-500'} />
                <span>
                  {netStatus === null
                    ? tr
                      ? 'Kontrol ediliyor'
                      : 'Checking'
                    : netStatus.online
                      ? `${tr ? 'Çevrimiçi' : 'Online'} · ${netStatus.rttMs} ms`
                      : tr
                        ? 'Çevrimdışı'
                        : 'Offline'}
                </span>
              </button>
            </div>

            {/* Search Input + Live Autocomplete Dropdown */}
            <div className="relative">
              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  if (activeSuggestIdx >= 0 && suggestions[activeSuggestIdx]) {
                    submitWithSuggestion(suggestions[activeSuggestIdx]);
                    return;
                  }
                  const q = searchBoxInput.trim();
                  if (!q) return;
                  submitWithSuggestion(q, activeCategory);
                }}
                className="flex gap-2"
              >
                <div className="flex-1 relative">
                  <Search
                    size={15}
                    className="absolute left-3.5 top-1/2 -translate-y-1/2 text-[var(--anka-text-subtle)]"
                  />
                  <input
                    ref={searchBoxRef}
                    type="text"
                    value={searchBoxInput}
                    onFocus={() => setSuggestOpen(true)}
                    onBlur={() => setTimeout(() => setSuggestOpen(false), 160)}
                    onKeyDown={(e) => {
                      if (!suggestOpen || suggestions.length === 0) return;
                      if (e.key === 'ArrowDown') {
                        e.preventDefault();
                        setActiveSuggestIdx((i) => Math.min(suggestions.length - 1, i + 1));
                      } else if (e.key === 'ArrowUp') {
                        e.preventDefault();
                        setActiveSuggestIdx((i) => Math.max(-1, i - 1));
                      } else if (e.key === 'Escape') {
                        setSuggestOpen(false);
                      }
                    }}
                    onChange={(e) => {
                      setSearchBoxInput(e.target.value);
                      setSuggestOpen(true);
                    }}
                    placeholder={
                      tr
                        ? 'Web, !gh react, !viki, !haber, 100 km -> mil, #0ea5e9 veya dns:github.com...'
                        : 'Search web, !gh react, !wiki, !news, 100 km -> mi, #0ea5e9...'
                    }
                    className="w-full pl-10 pr-9 py-2.5 rounded-xl text-sm border border-[var(--anka-border-strong)] bg-[var(--anka-surface-muted)] text-[var(--anka-text)] outline-none focus:border-[var(--anka-accent)]"
                  />
                  {searchBoxInput && (
                    <button
                      type="button"
                      onClick={() => {
                        setSearchBoxInput('');
                        setSuggestions([]);
                        searchBoxRef.current?.focus();
                      }}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-[var(--anka-text-subtle)] hover:text-[var(--anka-text)]"
                    >
                      <X size={14} />
                    </button>
                  )}
                </div>
                <button
                  type="submit"
                  className="px-5 py-2.5 rounded-xl text-xs font-semibold bg-[var(--anka-accent)] text-[var(--anka-accent-fg)] hover:bg-[var(--anka-accent-hover)] whitespace-nowrap"
                >
                  {tr ? 'Ara' : 'Search'}
                </button>
              </form>

              {suggestOpen && suggestions.length > 0 && (
                <div className="absolute left-0 right-20 top-full mt-1.5 rounded-xl border border-[var(--anka-border-strong)] bg-[var(--anka-surface)] shadow-xl z-30 overflow-hidden py-1">
                  {suggestions.map((s, idx) => (
                    <button
                      key={s}
                      type="button"
                      onMouseDown={(e) => {
                        e.preventDefault();
                        submitWithSuggestion(s);
                      }}
                      className={`w-full px-3.5 py-2 text-left text-xs flex items-center gap-2.5 transition-colors ${
                        idx === activeSuggestIdx
                          ? 'bg-[var(--anka-accent-soft)] text-[var(--anka-text)]'
                          : 'hover:bg-[var(--anka-surface-muted)] text-[var(--anka-text-muted)]'
                      }`}
                    >
                      <Search size={12} className="text-[var(--anka-text-subtle)] shrink-0" />
                      <span className="truncate">{s}</span>
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Category Filter Tabs when query active */}
            {queryStr && (
              <div className="flex items-center gap-1 p-1 rounded-xl bg-[var(--anka-surface-muted)] border border-[var(--anka-border)] overflow-x-auto">
                {categories.map((cat) => {
                  const active = activeCategory === cat.id;
                  return (
                    <button
                      key={cat.id}
                      onClick={() => handleCategorySwitch(cat.id)}
                      className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap shrink-0 transition-colors ${
                        active
                          ? 'bg-[var(--anka-surface)] text-[var(--anka-text)] shadow-sm'
                          : 'text-[var(--anka-text-subtle)] hover:text-[var(--anka-text)]'
                      }`}
                    >
                      <span className={active ? 'text-[var(--anka-accent)]' : ''}>{cat.icon}</span>
                      <span>{tr ? cat.labelTr : cat.labelEn}</span>
                    </button>
                  );
                })}
              </div>
            )}
          </div>

          {/* Smart Instant Intent Card (Math / Unit / Color / DNS) */}
          {smartIntent && smartIntent.kind !== 'bang' && (
            <div className="p-4 rounded-xl border border-[var(--anka-border-strong)] bg-[var(--anka-surface-muted)] flex flex-wrap items-center justify-between gap-4">
              <div className="flex items-center gap-3">
                {smartIntent.hex && (
                  <div
                    className="w-10 h-10 rounded-lg border border-[var(--anka-border-strong)] shrink-0"
                    style={{ backgroundColor: smartIntent.hex }}
                  />
                )}
                <div>
                  <div className="text-[11px] font-medium text-[var(--anka-text-subtle)]">
                    {smartIntent.title}
                  </div>
                  <div className="text-lg font-mono font-bold tabular-nums text-[var(--anka-accent)]">
                    {smartIntent.value}
                  </div>
                  {smartIntent.subtitle && (
                    <div className="text-xs font-mono text-[var(--anka-text-muted)] mt-0.5">
                      {smartIntent.subtitle}
                    </div>
                  )}
                </div>
              </div>

              {smartIntent.kind === 'dns' && dnsQuickResult && (
                <div className="text-xs font-mono text-[var(--anka-text-muted)] space-y-0.5">
                  <div>
                    IPv4: {dnsQuickResult.v4?.join(', ') || (dnsQuickResult.ok ? '(yok)' : dnsQuickResult.error)}
                  </div>
                  {dnsQuickResult.ns && dnsQuickResult.ns.length > 0 && (
                    <div className="text-[11px] text-[var(--anka-text-subtle)]">
                      NS: {dnsQuickResult.ns.slice(0, 2).join(', ')}
                    </div>
                  )}
                </div>
              )}
            </div>
          )}

          {/* Home Landing (No Active Query) */}
          {!queryStr && (
            <div className="space-y-6">
              {bookmarks.length > 0 && (
                <div className="space-y-2.5">
                  <div className="text-xs font-semibold text-[var(--anka-text-subtle)]">
                    {tr ? 'Hızlı Bağlantılar & Yer İmleri' : 'Quick Links & Bookmarks'}
                  </div>
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                    {bookmarks.map((bm) => (
                      <button
                        key={bm.url}
                        onClick={() => navigateTabTo(activeTab.id, bm.url)}
                        className="p-3 rounded-xl border border-[var(--anka-border)] bg-[var(--anka-surface-muted)] hover:bg-[var(--anka-surface-elevated)] text-left transition-colors"
                      >
                        <div className="text-xs font-semibold truncate">{bm.title}</div>
                        <div className="text-[11px] font-mono text-[var(--anka-text-subtle)] truncate mt-0.5">
                          {bm.url.replace(/^https?:\/\//, '')}
                        </div>
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {recentQueries.length > 0 && (
                <div className="space-y-2">
                  <div className="text-xs font-semibold text-[var(--anka-text-subtle)]">
                    {tr ? 'Son Aramalar' : 'Recent Searches'}
                  </div>
                  <div className="flex flex-wrap gap-2 text-xs">
                    {recentQueries.map((rq) => (
                      <button
                        key={rq}
                        onClick={() => submitWithSuggestion(rq, 'all')}
                        className="px-3 py-1.5 rounded-lg border border-[var(--anka-border)] hover:bg-[var(--anka-surface-muted)] text-[var(--anka-text-muted)] transition-colors flex items-center gap-1.5"
                      >
                        <Clock size={11} />
                        <span>{rq}</span>
                      </button>
                    ))}
                  </div>
                </div>
              )}

              <div className="space-y-2">
                <div className="text-xs font-semibold text-[var(--anka-text-subtle)]">
                  {tr ? 'Akıllı Operatörler & Örnek Aramalar' : 'Smart Operators & Sample Queries'}
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 text-xs">
                  {[
                    { q: 'WebAssembly', desc: tr ? 'Genel Web & Vikipedi Bilgi Kartı' : 'Web & Wikipedia Knowledge' },
                    { q: '!gh rust kernel', desc: tr ? 'GitHub, npm & StackOverflow Geliştirici Araması' : 'GitHub, npm & StackOverflow' },
                    { q: '!haber yapay zeka', desc: tr ? 'Canlı Haberler & Hacker News Akışı' : 'Live News & Hacker News' },
                    { q: '120 km -> mil', desc: tr ? 'Anlık Birim / Matematik / #Hex Renk' : 'Instant Unit / Math / Hex Color' },
                  ].map((ex) => (
                    <button
                      key={ex.q}
                      onClick={() => submitWithSuggestion(ex.q, 'all')}
                      className="p-3 rounded-xl border border-[var(--anka-border)] bg-[var(--anka-surface-muted)] hover:border-[var(--anka-accent)] text-left transition-colors"
                    >
                      <div className="font-mono font-semibold text-[var(--anka-accent)]">{ex.q}</div>
                      <div className="text-[11px] text-[var(--anka-text-subtle)] mt-0.5">{ex.desc}</div>
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* Local VFS Search Results Tab */}
          {queryStr && activeCategory === 'files' && (
            <div className="space-y-3">
              <div className="text-[11px] font-mono text-[var(--anka-text-subtle)] tabular-nums border-b border-[var(--anka-border)] pb-2">
                {localVfsHits.length} {tr ? 'yerel VFS eşleşmesi' : 'local VFS matches'} · {userHome}
              </div>
              {localVfsHits.length === 0 ? (
                <div className="py-10 text-center text-xs text-[var(--anka-text-subtle)]">
                  {tr ? 'Yerel VFS dosyalarında eşleşme bulunamadı.' : 'No local VFS files matched.'}
                </div>
              ) : (
                localVfsHits.map((m) => (
                  <div
                    key={m.path}
                    className="p-3.5 rounded-xl border border-[var(--anka-border)] bg-[var(--anka-surface)] flex items-center justify-between gap-3"
                  >
                    <div className="min-w-0 space-y-1">
                      <div className="text-xs font-mono text-[var(--anka-text-subtle)] truncate">
                        {m.path} · {formatBytes(m.size)}
                      </div>
                      <div className="text-sm font-semibold text-[var(--anka-text)] truncate">{m.name}</div>
                      <div className="text-xs text-[var(--anka-text-muted)] truncate">
                        {highlightTerms(m.snippet, queryStr)}
                      </div>
                    </div>
                    <div className="flex items-center gap-1.5 shrink-0">
                      {m.type === 'file' ? (
                        <button
                          onClick={() => launchApp('editor', { path: m.path })}
                          className="px-3 py-1.5 rounded-lg text-xs font-medium bg-[var(--anka-accent-soft)] text-[var(--anka-accent)] hover:bg-[var(--anka-accent)] hover:text-[var(--anka-accent-fg)] transition-colors"
                        >
                          {tr ? 'Düzenle' : 'Edit'}
                        </button>
                      ) : (
                        <button
                          onClick={() => launchApp('files', { path: m.path })}
                          className="px-3 py-1.5 rounded-lg text-xs font-medium bg-[var(--anka-accent-soft)] text-[var(--anka-accent)]"
                        >
                          {tr ? 'Klasörü Aç' : 'Open'}
                        </button>
                      )}
                    </div>
                  </div>
                ))
              )}
            </div>
          )}

          {/* Search Loading */}
          {activeCategory !== 'files' && activeTab.loading && (
            <div className="space-y-3 py-4">
              {[0, 1, 2].map((skeleton) => (
                <div
                  key={skeleton}
                  className="p-4 rounded-xl border border-[var(--anka-border)] bg-[var(--anka-surface-muted)] space-y-2 animate-pulse"
                >
                  <div className="h-3 w-40 rounded bg-[var(--anka-surface-elevated)]" />
                  <div className="h-4 w-72 rounded bg-[var(--anka-surface-elevated)]" />
                  <div className="h-3 w-full rounded bg-[var(--anka-surface-elevated)]" />
                </div>
              ))}
            </div>
          )}

          {/* Search Error */}
          {activeCategory !== 'files' && !activeTab.loading && activeTab.error && (
            <div className="p-4 rounded-xl border border-rose-500/30 bg-rose-500/10 text-xs text-rose-600 dark:text-rose-400 flex items-center gap-2.5">
              <WifiOff size={15} className="shrink-0" />
              <span>{activeTab.error}</span>
            </div>
          )}

          {/* Live Web Search Results */}
          {activeCategory !== 'files' && !activeTab.loading && queryStr && searchData && (
            <div className="space-y-4">
              <div className="flex flex-wrap items-center justify-between gap-2 text-[11px] font-mono text-[var(--anka-text-subtle)] tabular-nums border-b border-[var(--anka-border)] pb-2">
                <span>
                  {searchData.results.length} {tr ? 'sonuç' : 'results'} · {searchData.tookMs} ms
                  {searchData.cached ? (tr ? ' · önbellekten' : ' · cached') : ''}
                  {localVfsHits.length > 0 && (
                    <>
                      {' · '}
                      <button
                        onClick={() => handleCategorySwitch('files')}
                        className="text-[var(--anka-accent)] hover:underline"
                      >
                        {localVfsHits.length} {tr ? 'yerel VFS dosyası' : 'local files'}
                      </button>
                    </>
                  )}
                </span>
                <span>
                  {Object.entries(searchData.sourceStatus || {})
                    .map(([k, v]) => `${k}: ${v}`)
                    .join(' · ')}
                </span>
              </div>

              {/* Wikipedia / Knowledge Card */}
              {searchData.knowledgeCard && (
                <div className="p-4 rounded-xl border border-[var(--anka-border-strong)] bg-[var(--anka-surface-muted)] flex flex-col sm:flex-row gap-4">
                  {searchData.knowledgeCard.imageUrl && (
                    <img
                      src={searchData.knowledgeCard.imageUrl}
                      alt={searchData.knowledgeCard.title}
                      referrerPolicy="no-referrer"
                      className="w-24 h-24 rounded-lg object-cover border border-[var(--anka-border)] shrink-0 bg-[var(--anka-surface)]"
                    />
                  )}
                  <div className="flex-1 min-w-0 space-y-1.5">
                    <div className="flex items-center justify-between gap-2">
                      <div>
                        <h2 className="text-base font-display font-bold text-[var(--anka-text)]">
                          {searchData.knowledgeCard.title}
                        </h2>
                        {searchData.knowledgeCard.subtitle && (
                          <div className="text-xs text-[var(--anka-text-subtle)]">
                            {searchData.knowledgeCard.subtitle}
                          </div>
                        )}
                      </div>
                      <span className="text-[11px] font-mono text-[var(--anka-accent)] shrink-0">
                        {searchData.knowledgeCard.source}
                      </span>
                    </div>
                    <p className="text-xs text-[var(--anka-text-muted)] leading-relaxed">
                      {searchData.knowledgeCard.summary}
                    </p>
                    <div className="flex items-center gap-3 pt-1">
                      <button
                        onClick={() => navigateTabTo(activeTab.id, searchData.knowledgeCard!.url)}
                        className="text-xs font-medium text-[var(--anka-accent)] hover:underline inline-flex items-center gap-1"
                      >
                        <span>{tr ? 'Kaynağı Aç' : 'Open Source'}</span>
                        <ExternalLink size={11} />
                      </button>
                      <button
                        onClick={() =>
                          navigateTabTo(activeTab.id, searchData.knowledgeCard!.url, { readerMode: true })
                        }
                        className="text-xs font-medium text-[var(--anka-text-muted)] hover:text-[var(--anka-text)] hover:underline"
                      >
                        {tr ? 'Okuma Modunda Oku' : 'Reader View'}
                      </button>
                    </div>
                  </div>
                </div>
              )}

              {/* DuckDuckGo Instant Answer */}
              {searchData.instantAnswer && searchData.instantAnswer.abstract && !searchData.knowledgeCard && (
                <div className="p-4 rounded-xl border border-[var(--anka-border-strong)] bg-[var(--anka-surface-muted)] space-y-2">
                  <div className="flex items-center justify-between gap-2">
                    <h2 className="text-sm font-semibold text-[var(--anka-text)]">
                      {searchData.instantAnswer.heading}
                    </h2>
                    <span className="text-[11px] font-mono text-[var(--anka-accent)]">
                      {searchData.instantAnswer.source}
                    </span>
                  </div>
                  <p className="text-xs text-[var(--anka-text-muted)] leading-relaxed">
                    {searchData.instantAnswer.abstract}
                  </p>
                  {searchData.instantAnswer.url && (
                    <button
                      onClick={() => navigateTabTo(activeTab.id, searchData.instantAnswer!.url)}
                      className="text-xs font-medium text-[var(--anka-accent)] hover:underline inline-flex items-center gap-1"
                    >
                      <span>{tr ? 'Kaynağı Aç' : 'Open Source'}</span>
                      <ExternalLink size={11} />
                    </button>
                  )}
                </div>
              )}

              {/* Image Grid or Standard Result List */}
              {searchData.results.length === 0 ? (
                <div className="py-8 text-center text-xs text-[var(--anka-text-subtle)]">
                  {tr
                    ? 'Bu sorgu için web sonucu dönmedi veya yukarı akış ağ erişimi kısıtlı.'
                    : 'No results returned or upstream network unreachable.'}
                </div>
              ) : activeCategory === 'images' ? (
                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
                  {searchData.results.map((hit, idx) => (
                    <button
                      key={`${hit.url}-${idx}`}
                      onClick={() =>
                        setLightboxImage({
                          title: hit.title,
                          thumbUrl: hit.thumbUrl || hit.url,
                          pageUrl: hit.url,
                          metaText: hit.snippet,
                        })
                      }
                      className="group rounded-xl border border-[var(--anka-border)] bg-[var(--anka-surface-muted)] overflow-hidden text-left hover:border-[var(--anka-accent)] transition-colors"
                    >
                      <div className="aspect-[4/3] w-full bg-[var(--anka-bg)] overflow-hidden">
                        <img
                          src={hit.thumbUrl || hit.url}
                          alt={hit.title}
                          referrerPolicy="no-referrer"
                          loading="lazy"
                          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-200"
                        />
                      </div>
                      <div className="p-2 space-y-0.5">
                        <div className="text-xs font-medium truncate text-[var(--anka-text)]">
                          {hit.title}
                        </div>
                        <div className="text-[10px] font-mono text-[var(--anka-text-subtle)] truncate tabular-nums">
                          {hit.snippet}
                        </div>
                      </div>
                    </button>
                  ))}
                </div>
              ) : (
                <div className="space-y-3">
                  {searchData.results.map((hit, idx) => (
                    <div
                      key={`${hit.url}-${idx}`}
                      className="p-3.5 rounded-xl border border-[var(--anka-border)] hover:border-[var(--anka-border-strong)] bg-[var(--anka-surface)] transition-colors space-y-1.5"
                    >
                      <div className="flex items-center justify-between gap-3 text-[11px] font-mono text-[var(--anka-text-subtle)]">
                        <span className="truncate flex items-center gap-2 tabular-nums">
                          <span>{hit.domain}</span>
                          <span aria-hidden="true">·</span>
                          <span>{hit.source}</span>
                          {hit.meta?.language && (
                            <>
                              <span aria-hidden="true">·</span>
                              <span>{hit.meta.language}</span>
                            </>
                          )}
                          {typeof hit.meta?.stars === 'number' && (
                            <>
                              <span aria-hidden="true">·</span>
                              <span>{hit.meta.stars.toLocaleString('tr-TR')} ★</span>
                            </>
                          )}
                          {hit.meta?.version && (
                            <>
                              <span aria-hidden="true">·</span>
                              <span>v{hit.meta.version}</span>
                            </>
                          )}
                        </span>
                        <div className="flex items-center gap-2.5 shrink-0">
                          <button
                            onClick={() => navigateTabTo(activeTab.id, hit.url, { readerMode: true })}
                            className="text-[11px] text-[var(--anka-accent)] hover:underline"
                          >
                            {tr ? 'Okuma Modu' : 'Reader'}
                          </button>
                          <button
                            onClick={() => {
                              const t = makeTab(hit.url, tr);
                              setTabs((prev) => [...prev, t]);
                              setActiveTabId(t.id);
                            }}
                            className="text-[11px] text-[var(--anka-text-subtle)] hover:text-[var(--anka-text)]"
                            title={tr ? 'Yeni Sekmede Aç' : 'Open in New Tab'}
                          >
                            +Tab
                          </button>
                        </div>
                      </div>
                      <button
                        onClick={() => navigateTabTo(activeTab.id, hit.url)}
                        className="text-left text-sm font-semibold text-[var(--anka-accent)] hover:underline block"
                      >
                        {highlightTerms(hit.title, queryStr)}
                      </button>
                      {hit.snippet && (
                        <p className="text-xs text-[var(--anka-text-muted)] leading-relaxed">
                          {highlightTerms(hit.snippet, queryStr)}
                        </p>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>

        {/* Image Preview Lightbox Modal */}
        {lightboxImage && (
          <div
            onClick={() => setLightboxImage(null)}
            className="fixed inset-0 z-50 bg-slate-950/75 backdrop-blur-sm flex items-center justify-center p-6"
          >
            <div
              onClick={(e) => e.stopPropagation()}
              className="max-w-2xl w-full rounded-2xl border border-[var(--anka-border-strong)] bg-[var(--anka-surface)] shadow-2xl overflow-hidden"
            >
              <div className="px-4 py-3 border-b border-[var(--anka-border)] flex items-center justify-between gap-3">
                <div className="min-w-0">
                  <div className="text-xs font-semibold truncate">{lightboxImage.title}</div>
                  <div className="text-[11px] font-mono text-[var(--anka-text-subtle)]">
                    {lightboxImage.metaText}
                  </div>
                </div>
                <button
                  onClick={() => setLightboxImage(null)}
                  className="p-1.5 rounded-lg hover:bg-[var(--anka-surface-elevated)]"
                >
                  <X size={15} />
                </button>
              </div>
              <div className="p-4 bg-[var(--anka-bg)] flex items-center justify-center max-h-[60vh]">
                <img
                  src={lightboxImage.thumbUrl}
                  alt={lightboxImage.title}
                  referrerPolicy="no-referrer"
                  className="max-h-[54vh] rounded-lg object-contain"
                />
              </div>
              <div className="px-4 py-3 border-t border-[var(--anka-border)] flex items-center justify-end gap-2">
                <button
                  onClick={() => {
                    const url = lightboxImage.pageUrl;
                    setLightboxImage(null);
                    navigateTabTo(activeTab.id, url);
                  }}
                  className="px-3.5 py-1.5 rounded-lg text-xs font-medium bg-[var(--anka-accent)] text-[var(--anka-accent-fg)] hover:bg-[var(--anka-accent-hover)]"
                >
                  {tr ? 'Kaynağı Tarayıcıda Aç' : 'Open Source'}
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    );
  };

  const renderContent = () => {
    if (activeTab.url === 'ankaos://kilavuz') {
      return (
        <iframe
          key={`docs-${reloadTick}-${settings.theme}-${settings.accent}`}
          title="AnkaOS Kılavuz"
          sandbox="allow-same-origin"
          srcDoc={buildDocsHtml(settings.theme, settings.accent)}
          className="w-full h-full border-0 bg-[var(--anka-surface)]"
        />
      );
    }

    if (activeTab.url === 'ankaos://arama' || activeTab.url.startsWith('ankaos://arama?')) {
      return renderSearchHome();
    }

    if (activeTab.url.startsWith('vfs://')) {
      const vfsPath = normalizePath(activeTab.url.slice(6), userHome, userHome);
      const node = getNodeAtPath(vfs, vfsPath);
      if (!node || node.type !== 'file') {
        return (
          <div className="h-full flex flex-col items-center justify-center text-[var(--anka-text-subtle)] p-6 text-center space-y-2 bg-[var(--anka-surface)]">
            <Globe size={32} className="opacity-40" />
            <div className="text-sm font-medium text-[var(--anka-text)]">
              {tr ? 'Dosya bulunamadı (404)' : 'File not found (404)'}
            </div>
            <div className="text-xs font-mono text-[var(--anka-text-subtle)]">{vfsPath}</div>
          </div>
        );
      }
      return (
        <iframe
          key={`${vfsPath}-${reloadTick}`}
          title={node.name}
          sandbox="allow-scripts"
          srcDoc={node.content || ''}
          className="w-full h-full border-0 bg-white"
        />
      );
    }

    if (activeTab.url.startsWith('http://') || activeTab.url.startsWith('https://')) {
      const check = validateExternalUrl(activeTab.url);
      if (!check.ok) {
        return (
          <div className="h-full flex flex-col items-center justify-center p-8 text-center space-y-2">
            <WifiOff size={32} className="text-rose-500 opacity-75" />
            <div className="text-sm font-semibold">{tr ? 'Erişim Engellendi' : 'Blocked URL'}</div>
            <div className="text-xs text-[var(--anka-text-subtle)]">{check.error}</div>
          </div>
        );
      }

      if (activeTab.readerMode) {
        return (
          <div className="h-full overflow-y-auto os-scroll px-6 py-8 bg-[var(--anka-surface)]">
            <div className="max-w-2xl mx-auto space-y-4">
              {activeTab.loading ? (
                <div className="py-12 text-center text-xs text-[var(--anka-text-subtle)]">
                  {tr ? 'Okuma modu hazırlanıyor...' : 'Loading reader view...'}
                </div>
              ) : activeTab.error ? (
                <div className="p-4 rounded-xl border border-rose-500/30 bg-rose-500/10 text-xs text-rose-500">
                  {activeTab.error}
                </div>
              ) : activeTab.readerData ? (
                <>
                  <div className="text-[11px] font-mono text-[var(--anka-text-subtle)] break-all">
                    {activeTab.readerData.finalUrl || activeTab.url}
                  </div>
                  <h1 className="text-xl font-display font-bold text-[var(--anka-text)]">
                    {activeTab.readerData.title || activeTab.url}
                  </h1>
                  {activeTab.readerData.description && (
                    <p className="text-xs italic text-[var(--anka-text-subtle)] border-l-2 border-[var(--anka-accent)] pl-3">
                      {activeTab.readerData.description}
                    </p>
                  )}
                  <div className="text-sm text-[var(--anka-text-muted)] leading-relaxed whitespace-pre-wrap">
                    {activeTab.readerData.textPreview || (tr ? 'Metin içeriği boş.' : 'No text extracted.')}
                  </div>
                </>
              ) : null}
            </div>
          </div>
        );
      }

      return (
        <iframe
          key={`proxy-${activeTab.id}-${activeTab.url}-${reloadTick}`}
          title={activeTab.title}
          sandbox="allow-scripts allow-forms allow-popups"
          src={`/api/proxy?url=${encodeURIComponent(check.url)}`}
          className="w-full h-full border-0 bg-white"
        />
      );
    }

    return renderSearchHome();
  };

  const isExternal = activeTab.url.startsWith('http://') || activeTab.url.startsWith('https://');

  return (
    <div
      tabIndex={-1}
      onKeyDown={(e) => {
        if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 't') {
          e.preventDefault();
          addNewTab();
        } else if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'l') {
          e.preventDefault();
          addressInputRef.current?.focus();
          addressInputRef.current?.select();
        } else if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'w') {
          e.preventDefault();
          closeTab(activeTab.id);
        }
      }}
      className="h-full w-full flex flex-col bg-[var(--anka-surface)] text-[var(--anka-text)] anka-theme-transition outline-none"
    >
      {/* Multi-Tab Bar */}
      <div className="px-2 pt-1.5 bg-[var(--anka-surface-muted)] border-b border-[var(--anka-border)] flex items-center gap-1 overflow-x-auto">
        {tabs.map((tab) => {
          const isActive = tab.id === activeTab.id;
          return (
            <div
              key={tab.id}
              onClick={() => setActiveTabId(tab.id)}
              className={`group flex items-center gap-2 px-3 py-1.5 rounded-t-lg text-xs cursor-pointer max-w-[180px] border border-b-0 transition-colors ${
                isActive
                  ? 'bg-[var(--anka-surface)] border-[var(--anka-border)] text-[var(--anka-text)] font-medium'
                  : 'border-transparent text-[var(--anka-text-subtle)] hover:bg-[var(--anka-surface-elevated)]/60'
              }`}
            >
              <Globe size={12} className="shrink-0 text-[var(--anka-accent)]" />
              <span className="truncate flex-1">{tab.title}</span>
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  closeTab(tab.id);
                }}
                className="opacity-60 hover:opacity-100 p-0.5 rounded hover:bg-[var(--anka-surface-elevated)]"
              >
                <X size={11} />
              </button>
            </div>
          );
        })}
        <button
          onClick={addNewTab}
          title={tr ? 'Yeni Sekme' : 'New Tab'}
          className="p-1.5 rounded-md text-[var(--anka-text-subtle)] hover:text-[var(--anka-text)] hover:bg-[var(--anka-surface-elevated)] shrink-0"
        >
          <Plus size={14} />
        </button>
      </div>

      {/* Navigation & Address Bar */}
      <div className="px-3 py-2 border-b border-[var(--anka-border)] bg-[var(--anka-surface-muted)] flex items-center gap-1.5">
        <button
          onClick={handleGoBack}
          disabled={activeTab.historyIndex <= 0}
          title={tr ? 'Geri' : 'Back'}
          className="p-1.5 rounded-lg hover:bg-[var(--anka-surface-elevated)] disabled:opacity-35"
        >
          <ArrowLeft size={14} />
        </button>
        <button
          onClick={handleGoForward}
          disabled={activeTab.historyIndex >= activeTab.history.length - 1}
          title={tr ? 'İleri' : 'Forward'}
          className="p-1.5 rounded-lg hover:bg-[var(--anka-surface-elevated)] disabled:opacity-35"
        >
          <ArrowRight size={14} />
        </button>
        <button
          onClick={handleReload}
          title={tr ? 'Yenile' : 'Reload'}
          className="p-1.5 rounded-lg hover:bg-[var(--anka-surface-elevated)]"
        >
          <RefreshCw size={14} className={activeTab.loading ? 'animate-spin' : ''} />
        </button>
        <button
          onClick={() => {
            setSearchBoxInput('');
            navigateTabTo(activeTab.id, 'ankaos://arama');
          }}
          title="AnkaArama"
          className="p-1.5 rounded-lg hover:bg-[var(--anka-surface-elevated)]"
        >
          <Home size={14} />
        </button>

        <form onSubmit={handleAddressSubmit} className="flex-1 min-w-0">
          <input
            ref={addressInputRef}
            type="text"
            value={addressInput}
            onChange={(e) => setAddressInput(e.target.value)}
            placeholder={tr ? "Web'de ara veya URL girin..." : 'Search web or enter URL...'}
            className="w-full px-3 py-1.5 rounded-lg text-xs font-mono border border-[var(--anka-border-strong)] bg-[var(--anka-surface)] text-[var(--anka-text)] outline-none focus:border-[var(--anka-accent)]"
          />
        </form>

        {isExternal && (
          <>
            <button
              onClick={toggleReaderMode}
              title={tr ? 'Okuma Modu' : 'Reader Mode'}
              className={`px-2.5 py-1.5 rounded-lg text-xs font-medium border flex items-center gap-1 whitespace-nowrap transition-colors ${
                activeTab.readerMode
                  ? 'bg-[var(--anka-accent)] text-[var(--anka-accent-fg)] border-transparent'
                  : 'border-[var(--anka-border-strong)] hover:bg-[var(--anka-surface-elevated)]'
              }`}
            >
              <FileText size={13} />
              <span>{tr ? 'Okuma' : 'Reader'}</span>
            </button>
            <button
              onClick={() => void handleSaveDownload()}
              title={tr ? 'VFS ~/İndirilenler klasörüne kaydet' : 'Download to ~/İndirilenler'}
              className="p-1.5 rounded-lg border border-[var(--anka-border-strong)] hover:bg-[var(--anka-surface-elevated)]"
            >
              <Download size={14} />
            </button>
          </>
        )}

        <button
          onClick={() => setDrawerOpen((v) => !v)}
          title={tr ? 'Geçmiş & İndirilenler' : 'History & Downloads'}
          className={`p-1.5 rounded-lg transition-colors ${
            drawerOpen
              ? 'bg-[var(--anka-accent-soft)] text-[var(--anka-accent)]'
              : 'hover:bg-[var(--anka-surface-elevated)]'
          }`}
        >
          <Clock size={14} />
        </button>

        <button
          onClick={toggleBookmark}
          disabled={activeTab.url === 'ankaos://arama'}
          title={tr ? 'Yer İmlerine Ekle / Kaldır' : 'Toggle Bookmark'}
          className="p-1.5 rounded-lg hover:bg-[var(--anka-surface-elevated)] disabled:opacity-35"
        >
          <Star size={14} className={isBookmarked ? 'text-amber-500 fill-amber-500' : ''} />
        </button>
      </div>

      {/* Bookmarks Bar */}
      <div className="px-3 py-1.5 border-b border-[var(--anka-border)] bg-[var(--anka-surface)] flex items-center gap-2 text-xs overflow-x-auto">
        <button
          onClick={() => navigateTabTo(activeTab.id, 'ankaos://arama')}
          className="flex items-center gap-1.5 px-2.5 py-1 rounded-md hover:bg-[var(--anka-surface-elevated)] whitespace-nowrap"
        >
          <Search size={12} className="text-[var(--anka-accent)]" />
          <span>AnkaArama</span>
        </button>
        <button
          onClick={() => navigateTabTo(activeTab.id, 'ankaos://kilavuz')}
          className="flex items-center gap-1.5 px-2.5 py-1 rounded-md hover:bg-[var(--anka-surface-elevated)] whitespace-nowrap"
        >
          <BookOpen size={12} className="text-[var(--anka-accent)]" />
          <span>{tr ? 'Kılavuz' : 'Manual'}</span>
        </button>
        <button
          onClick={() => navigateTabTo(activeTab.id, `vfs://${userHome}/Projeler/site.html`)}
          className="flex items-center gap-1.5 px-2.5 py-1 rounded-md hover:bg-[var(--anka-surface-elevated)] whitespace-nowrap"
        >
          <FileCode2 size={12} className="text-emerald-500" />
          <span>site.html</span>
        </button>
        {bookmarks.map((bm) => (
          <button
            key={bm.url}
            onClick={() => navigateTabTo(activeTab.id, bm.url)}
            className="flex items-center gap-1.5 px-2.5 py-1 rounded-md hover:bg-[var(--anka-surface-elevated)] whitespace-nowrap text-[var(--anka-text-muted)]"
          >
            <Globe size={11} />
            <span>{bm.title}</span>
          </button>
        ))}

        {toastMsg && (
          <span className="ml-auto text-[11px] font-medium text-[var(--anka-accent)] whitespace-nowrap">
            {toastMsg}
          </span>
        )}
        {!toastMsg && activeTab.url.startsWith('vfs://') && (
          <button
            onClick={() => launchApp('editor', { path: activeTab.url.slice(6) })}
            className="ml-auto text-[11px] text-[var(--anka-accent)] hover:underline whitespace-nowrap"
          >
            {tr ? 'Kaynağı Düzenle' : 'Edit Source'}
          </button>
        )}
      </div>

      <div className="flex-1 min-h-0 flex overflow-hidden">
        <div className="flex-1 min-w-0 h-full">{renderContent()}</div>

        {drawerOpen && (
          <aside className="w-72 border-l border-[var(--anka-border)] bg-[var(--anka-surface-muted)] flex flex-col shrink-0">
            <div className="p-2 border-b border-[var(--anka-border)] flex items-center justify-between gap-1">
              <div className="flex items-center gap-1 p-0.5 rounded-lg bg-[var(--anka-surface)] border border-[var(--anka-border)] text-xs">
                <button
                  onClick={() => setDrawerTab('downloads')}
                  className={`px-2.5 py-1 rounded-md font-medium ${
                    drawerTab === 'downloads'
                      ? 'bg-[var(--anka-accent)] text-[var(--anka-accent-fg)]'
                      : 'text-[var(--anka-text-subtle)]'
                  }`}
                >
                  {tr ? `İndirilenler (${downloadFiles.length})` : `Downloads (${downloadFiles.length})`}
                </button>
                <button
                  onClick={() => setDrawerTab('history')}
                  className={`px-2.5 py-1 rounded-md font-medium ${
                    drawerTab === 'history'
                      ? 'bg-[var(--anka-accent)] text-[var(--anka-accent-fg)]'
                      : 'text-[var(--anka-text-subtle)]'
                  }`}
                >
                  {tr ? `Geçmiş (${visitLog.length})` : `History (${visitLog.length})`}
                </button>
              </div>
              <button
                onClick={() => setDrawerOpen(false)}
                className="p-1 rounded hover:bg-[var(--anka-surface-elevated)] text-[var(--anka-text-subtle)]"
              >
                <X size={13} />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto os-scroll p-2.5 space-y-2 text-xs">
              {drawerTab === 'downloads' ? (
                downloadFiles.length === 0 ? (
                  <div className="py-8 text-center text-[var(--anka-text-subtle)]">
                    {tr ? '~/İndirilenler klasörü boş.' : '~/İndirilenler is empty.'}
                  </div>
                ) : (
                  downloadFiles.map((f) => {
                    const p = `${userHome}/İndirilenler/${f.name}`;
                    return (
                      <div
                        key={f.id}
                        className="p-2.5 rounded-lg border border-[var(--anka-border)] bg-[var(--anka-surface)] space-y-1.5"
                      >
                        <div className="font-medium truncate">{f.name}</div>
                        <div className="text-[11px] font-mono text-[var(--anka-text-subtle)] tabular-nums">
                          {formatBytes(f.size)}
                        </div>
                        <div className="flex items-center gap-1.5 pt-0.5">
                          <button
                            onClick={() => navigateTabTo(activeTab.id, `vfs://${p}`)}
                            className="px-2 py-0.5 rounded bg-[var(--anka-accent-soft)] text-[var(--anka-accent)] font-medium"
                          >
                            {tr ? 'Aç' : 'Open'}
                          </button>
                          <button
                            onClick={() => launchApp('editor', { path: p })}
                            className="px-2 py-0.5 rounded border border-[var(--anka-border)] hover:bg-[var(--anka-surface-elevated)]"
                          >
                            {tr ? 'Düzenle' : 'Edit'}
                          </button>
                          <button
                            onClick={() => launchApp('files', { path: `${userHome}/İndirilenler` })}
                            className="p-1 rounded hover:bg-[var(--anka-surface-elevated)] ml-auto"
                            title={tr ? 'Klasörü Aç' : 'Open Folder'}
                          >
                            <FolderOpen size={12} />
                          </button>
                          <button
                            onClick={() => deleteNode(p, false, 'browser')}
                            className="p-1 rounded hover:bg-rose-500/10 text-rose-500"
                            title={tr ? 'Sil' : 'Delete'}
                          >
                            <Trash2 size={12} />
                          </button>
                        </div>
                      </div>
                    );
                  })
                )
              ) : visitLog.length === 0 ? (
                <div className="py-8 text-center text-[var(--anka-text-subtle)]">
                  {tr ? 'Henüz ziyaret geçmişi yok.' : 'No browsing history yet.'}
                </div>
              ) : (
                <>
                  <button
                    onClick={() => setVisitLog([])}
                    className="w-full py-1 rounded border border-[var(--anka-border)] text-[11px] text-[var(--anka-text-subtle)] hover:text-[var(--anka-text)]"
                  >
                    {tr ? 'Geçmişi Temizle' : 'Clear History'}
                  </button>
                  {visitLog.map((v, idx) => (
                    <button
                      key={`${v.url}-${idx}`}
                      onClick={() => navigateTabTo(activeTab.id, v.url)}
                      className="w-full text-left p-2 rounded-lg border border-[var(--anka-border)] bg-[var(--anka-surface)] hover:border-[var(--anka-accent)] space-y-0.5"
                    >
                      <div className="font-medium truncate">{v.title}</div>
                      <div className="text-[10px] font-mono text-[var(--anka-text-subtle)] truncate">
                        {v.url} · {new Date(v.at).toLocaleTimeString('tr-TR')}
                      </div>
                    </button>
                  ))}
                </>
              )}
            </div>
          </aside>
        )}
      </div>
    </div>
  );
};
