import React, { useCallback, useEffect, useState } from 'react';
import { Delete } from 'lucide-react';
import { useOS } from '../os/kernel';

export const CalculatorApp: React.FC<{ windowId: string }> = ({ windowId }) => {
  const { settings, activeWindowId } = useOS();
  const tr = settings.language === 'tr';

  const [expr, setExpr] = useState('0');
  const [history, setHistory] = useState<string[]>([]);
  const [scientific, setScientific] = useState(false);

  const append = useCallback((val: string) => {
    setExpr((prev) => {
      if (prev === '0' && /[0-9]/.test(val)) return val;
      if (prev === 'Hata') return val;
      return prev + val;
    });
  }, []);

  const evaluate = useCallback(() => {
    try {
      const sanitized = expr
        .replace(/×/g, '*')
        .replace(/÷/g, '/')
        .replace(/π/g, 'Math.PI')
        .replace(/sin\(/g, 'Math.sin(')
        .replace(/cos\(/g, 'Math.cos(')
        .replace(/tan\(/g, 'Math.tan(')
        .replace(/sqrt\(/g, 'Math.sqrt(')
        .replace(/log\(/g, 'Math.log10(')
        .replace(/\^/g, '**');
      const res = Function(`"use strict"; return (${sanitized})`)();
      const formatted = Number.isFinite(res)
        ? String(Number(res.toFixed(10)))
        : 'Hata';
      setHistory((h) => [`${expr} = ${formatted}`, ...h.slice(0, 7)]);
      setExpr(formatted);
    } catch {
      setExpr('Hata');
    }
  }, [expr]);

  const clear = useCallback(() => setExpr('0'), []);
  const backspace = useCallback(
    () => setExpr((prev) => (prev.length <= 1 || prev === 'Hata' ? '0' : prev.slice(0, -1))),
    []
  );

  useEffect(() => {
    if (activeWindowId !== windowId) return;
    const onKey = (e: KeyboardEvent) => {
      if (/^[0-9+\-*/().]$/.test(e.key)) {
        append(e.key);
      } else if (e.key === 'Enter') {
        e.preventDefault();
        evaluate();
      } else if (e.key === 'Backspace') {
        backspace();
      } else if (e.key === 'Escape') {
        clear();
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [activeWindowId, windowId, append, evaluate, backspace, clear]);

  const baseButtons = [
    ['C', '(', ')', '÷'],
    ['7', '8', '9', '×'],
    ['4', '5', '6', '-'],
    ['1', '2', '3', '+'],
    ['0', '.', '⌫', '='],
  ];

  const sciButtons = ['sin(', 'cos(', 'tan(', 'sqrt(', 'log(', 'π', '^'];

  return (
    <div className="h-full w-full flex flex-col bg-[var(--anka-bg)] text-[var(--anka-text)] p-4 select-none anka-theme-transition">
      {/* Mode Switch */}
      <div className="flex items-center justify-between mb-3">
        <span className="text-xs font-medium text-[var(--anka-text-subtle)]">
          {scientific ? (tr ? 'Bilimsel' : 'Scientific') : tr ? 'Standart' : 'Standard'}
        </span>
        <button
          onClick={() => setScientific((s) => !s)}
          className="text-xs px-2.5 py-1 rounded-md border border-[var(--anka-border)] bg-[var(--anka-surface)] hover:bg-[var(--anka-surface-elevated)] transition-colors"
        >
          {scientific ? (tr ? 'Standart Mod' : 'Standard') : tr ? 'Bilimsel Mod' : 'Scientific'}
        </button>
      </div>

      {/* Display */}
      <div className="p-3 rounded-xl border border-[var(--anka-border)] bg-[var(--anka-surface)] mb-3 text-right">
        <div className="h-10 overflow-y-auto os-scroll text-[11px] font-mono text-[var(--anka-text-subtle)] space-y-0.5 mb-1">
          {history.slice(0, 2).map((h, i) => (
            <div key={i}>{h}</div>
          ))}
        </div>
        <div className="text-2xl font-semibold font-mono tabular-nums truncate">{expr}</div>
      </div>

      {scientific && (
        <div className="grid grid-cols-7 gap-1.5 mb-2">
          {sciButtons.map((btn) => (
            <button
              key={btn}
              onClick={() => append(btn)}
              className="py-1.5 rounded-lg text-xs font-mono bg-[var(--anka-surface-elevated)] hover:opacity-85 transition-opacity"
            >
              {btn}
            </button>
          ))}
        </div>
      )}

      {/* Keypad */}
      <div className="flex-1 grid grid-rows-5 gap-2">
        {baseButtons.map((row, rIdx) => (
          <div key={rIdx} className="grid grid-cols-4 gap-2">
            {row.map((btn) => {
              const isEquals = btn === '=';
              const isOp = ['÷', '×', '-', '+', '(', ')'].includes(btn);
              return (
                <button
                  key={btn}
                  onClick={() => {
                    if (btn === 'C') clear();
                    else if (btn === '⌫') backspace();
                    else if (btn === '=') evaluate();
                    else append(btn);
                  }}
                  className={`rounded-xl font-medium text-base flex items-center justify-center transition-colors ${
                    isEquals
                      ? 'bg-[var(--anka-accent)] hover:bg-[var(--anka-accent-hover)] text-[var(--anka-accent-fg)]'
                      : isOp
                        ? 'bg-[var(--anka-surface-elevated)] text-[var(--anka-accent)] hover:opacity-85'
                        : btn === 'C'
                          ? 'bg-rose-500/15 text-rose-600 dark:text-rose-400 hover:bg-rose-500/25'
                          : 'bg-[var(--anka-surface)] border border-[var(--anka-border)] hover:bg-[var(--anka-surface-elevated)]'
                  }`}
                >
                  {btn === '⌫' ? <Delete size={17} /> : btn}
                </button>
              );
            })}
          </div>
        ))}
      </div>
    </div>
  );
};
