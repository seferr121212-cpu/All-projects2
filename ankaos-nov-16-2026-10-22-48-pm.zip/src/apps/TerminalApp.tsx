import React, { useEffect, useRef, useState } from 'react';
import { Square } from 'lucide-react';
import { computeDiskUsage } from '../os/archive';
import { canExecuteNode } from '../os/auth';
import { useOS } from '../os/kernel';
import { getMemorySummary } from '../os/mmu';
import {
  downloadSnapshotSync,
  fetchPageLive,
  measureLoopbackPing,
  pingHostLive,
  resolveDnsLive,
  searchWebLive,
  uploadSnapshotSync,
} from '../os/net';
import { PACKAGE_REGISTRY } from '../os/packages';
import { executeSandboxedJS, runWasmBinary, WASM_B64_PREFIX } from '../os/sandboxRuntime';
import { runKernelSelfTests } from '../os/selftest';
import { POWER_PROFILE_META } from '../os/services';
import {
  computeLineDiff,
  evaluateIfForScript,
  expandShellVariables,
  resolveTabCompletion,
  splitCommandChain,
  splitPipes,
  tokenizeArgs,
} from '../os/shellUtils';
import { ACCENT_PALETTES } from '../os/theme';
import { AccentColor, PowerProfile } from '../os/types';
import {
  formatBytes,
  getNodeAtPath,
  HOME_PATH,
  listDir,
  normalizePath,
  readDynamicNodeContent,
} from '../os/vfs';
import {
  AnkaWasmPackageManifest,
  compileWatToWasm,
  packageWasmModule,
  runWasmOrPackageFromVfsContent,
} from '../os/wasmCompiler';
import { profileWasmExecution, renderAsciiFlameSummary } from '../os/wasmProfiler';

interface TerminalLine {
  id: string;
  kind: 'prompt' | 'output' | 'error' | 'info' | 'success';
  cwd?: string;
  text: string;
}

interface TerminalAppProps {
  windowId: string;
  launchArgs?: Record<string, string>;
}

const KNOWN_COMMANDS = [
  'help',
  'ls',
  'cd',
  'pwd',
  'cat',
  'echo',
  'touch',
  'mkdir',
  'rm',
  'cp',
  'mv',
  'chmod',
  'alias',
  'unalias',
  'sudo',
  'su',
  'useradd',
  'passwd',
  'tree',
  'find',
  'grep',
  'head',
  'tail',
  'wc',
  'sort',
  'uniq',
  'diff',
  'sha256',
  'base64',
  'env',
  'export',
  'clear',
  'whoami',
  'id',
  'uname',
  'date',
  'uptime',
  'ps',
  'kill',
  'renice',
  'fork',
  'cowfault',
  'aslr',
  'ringtest',
  'sandbox',
  'ioqueue',
  'jobs',
  'fg',
  'sleep',
  'free',
  'vmstat',
  'syscalls',
  'ifconfig',
  'ping',
  'curl',
  'df',
  'neofetch',
  'pkg',
  'sh',
  'selftest',
  'theme',
  'accent',
  'edit',
  'open',
  'hex',
  'run',
  'wasmrun',
  'wasmprof',
  'wasmc',
  'wasmpkg',
  'wasm-builder',
  'ankactl',
  'crontab',
  'du',
  'fsck',
  'tar',
  'nslookup',
  'search',
  'wget',
  'power',
  'snapshot',
  'screenshot',
  'calc',
  'history',
  'reboot',
];

function formatUptime(sec: number): string {
  const h = Math.floor(sec / 3600);
  const m = Math.floor((sec % 3600) / 60);
  const s = sec % 60;
  return `${h}s ${m}d ${s}sn`;
}

const waitTick = () => new Promise<void>((r) => setTimeout(r, 25));

export const TerminalApp: React.FC<TerminalAppProps> = ({ launchArgs }) => {
  const {
    vfs,
    writeFile,
    makeDir,
    deleteNode,
    copyNode,
    moveNode,
    chmodNode,
    exportSystemSnapshot,
    importSystemSnapshot,
    launchApp,
    openFileWithDefaultApp,
    processes,
    schedulerStats,
    ioQueueStats,
    forkProcess,
    triggerCowWriteFault,
    attemptKernelMemoryAccess,
    backgroundJobs,
    spawnBackgroundJob,
    networkInterfaces,
    recordNetworkTraffic,
    frames,
    swapSlots,
    syscalls,
    killProcess,
    signalProcess,
    reniceProcess,
    installedPackages,
    installPackage,
    removePackage,
    services,
    controlService,
    cronJobs,
    addCronJob,
    removeCronJob,
    runDiskCheck,
    createArchiveFromVfs,
    extractArchiveToVfs,
    powerProfile,
    setPowerProfile,
    uptimeSec,
    rebootSystem,
    settings,
    updateSettings,
    toggleTheme,
    captureDesktopScreenshot,
    currentUser,
    switchUser,
    createUser,
    setUserPassword,
  } = useOS();

  const userHome = currentUser.homeDir || HOME_PATH;
  const [cwd, setCwd] = useState<string>(() => launchArgs?.cwd || userHome);
  const [envVars, setEnvVars] = useState<Record<string, string>>({
    USER: currentUser.username,
    HOME: userHome,
    SHELL: '/bin/ankash',
    PATH: '/bin:/usr/bin',
    TERM: 'ankaterm-256color',
  });
  const [aliases, setAliases] = useState<Record<string, string>>({});
  const [input, setInput] = useState('');
  const [cmdHistory, setCmdHistory] = useState<string[]>([]);
  const [historyIdx, setHistoryIdx] = useState(-1);
  const [runningSandbox, setRunningSandbox] = useState(false);
  const [lines, setLines] = useState<TerminalLine[]>([
    {
      id: 'init-1',
      kind: 'info',
      text: 'AnkaOS ankash 3.5 — Yardım için "help", çekirdek testleri için "selftest" yazın.',
    },
  ]);

  const endRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const abortWorkerRef = useRef<(() => void) | null>(null);
  const ranLaunchCmdRef = useRef(false);
  const executeChainRef = useRef<(rawChain: string) => Promise<void> | void>(() => {});

  // Live refs so chained commands (&&, ||, ;) always see latest committed state
  const vfsRef = useRef(vfs);
  const cwdRef = useRef(cwd);
  const aliasesRef = useRef(aliases);
  const envRef = useRef(envVars);
  const pkgsRef = useRef(installedPackages);
  const lastExitRef = useRef(0);

  vfsRef.current = vfs;
  cwdRef.current = cwd;
  aliasesRef.current = aliases;
  envRef.current = envVars;
  pkgsRef.current = installedPackages;

  // Load ~/.ankashrc aliases & exports on mount / user switch
  useEffect(() => {
    setEnvVars((prev) => ({
      ...prev,
      USER: currentUser.username,
      HOME: userHome,
    }));
    if (!launchArgs?.cwd) {
      setCwd(userHome);
      cwdRef.current = userHome;
    }

    const rcNode = getNodeAtPath(vfsRef.current, `${userHome}/.ankashrc`);
    const loadedAliases: Record<string, string> = {};
    if (rcNode?.type === 'file' && rcNode.content) {
      const rcLines = rcNode.content.split('\n');
      for (const rawLine of rcLines) {
        const line = rawLine.trim();
        if (!line || line.startsWith('#')) continue;
        if (line.startsWith('alias ')) {
          const rest = line.slice(6).trim();
          const eq = rest.indexOf('=');
          if (eq > 0) {
            const name = rest.slice(0, eq).trim();
            let val = rest.slice(eq + 1).trim();
            if (
              (val.startsWith("'") && val.endsWith("'")) ||
              (val.startsWith('"') && val.endsWith('"'))
            ) {
              val = val.slice(1, -1);
            }
            if (name) loadedAliases[name] = val;
          }
        } else if (line.startsWith('export ')) {
          const rest = line.slice(7).trim();
          const eq = rest.indexOf('=');
          if (eq > 0) {
            const k = rest.slice(0, eq).trim();
            let v = rest.slice(eq + 1).trim();
            if ((v.startsWith("'") && v.endsWith("'")) || (v.startsWith('"') && v.endsWith('"'))) {
              v = v.slice(1, -1);
            }
            setEnvVars((prev) => ({ ...prev, [k]: v }));
          }
        }
      }
    }
    setAliases(loadedAliases);
    aliasesRef.current = loadedAliases;
  }, [currentUser.username, userHome, launchArgs?.cwd]);

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [lines]);

  useEffect(() => {
    const cmd = typeof launchArgs?.cmd === 'string' ? launchArgs.cmd.trim() : '';
    if (!cmd || ranLaunchCmdRef.current) return;
    ranLaunchCmdRef.current = true;
    const activeCwd = cwdRef.current || userHome;
    const promptCwd = activeCwd.startsWith(userHome)
      ? '~' + activeCwd.slice(userHome.length) || '~'
      : activeCwd;
    appendLines([{ kind: 'prompt', cwd: promptCwd, text: cmd }]);
    void executeChainRef.current(cmd);
  }, [launchArgs?.cmd, userHome]);

  useEffect(() => {
    return () => {
      abortWorkerRef.current?.();
    };
  }, []);

  const appendLines = (entries: Omit<TerminalLine, 'id'>[]) => {
    setLines((prev) => [
      ...prev,
      ...entries.map((e, i) => ({
        ...e,
        id: `ln-${Date.now()}-${i}-${Math.random().toString(36).slice(2, 6)}`,
      })),
    ]);
  };

  const displayCwd = cwd.startsWith(userHome)
    ? '~' + cwd.slice(userHome.length)
    : cwd;

  const expandEnv = (str: string, activeCwd: string) =>
    expandShellVariables(str, envRef.current, {
      cwd: activeCwd,
      user: currentUser.username,
      homeDir: userHome,
      lastExit: lastExitRef.current,
    });

  const applyPipeStage = (inputText: string, stageRaw: string, activeCwd: string): string => {
    const tokens = tokenizeArgs(expandEnv(stageRaw, activeCwd));
    if (tokens.length === 0) return inputText;
    const [cmd, ...args] = tokens;
    const rows = inputText.split('\n');

    if (cmd === 'grep') {
      const needle = (args[0] || '').toLowerCase();
      return rows.filter((r) => r.toLowerCase().includes(needle)).join('\n');
    }
    if (cmd === 'wc') {
      if (args.includes('-l')) return String(inputText.trim() === '' ? 0 : rows.length);
      const words = inputText.trim() ? inputText.trim().split(/\s+/).length : 0;
      return `  ${rows.length}  ${words}  ${inputText.length}`;
    }
    if (cmd === 'head') {
      const n = args[0] === '-n' && args[1] ? Number(args[1]) : 10;
      return rows.slice(0, Number.isNaN(n) ? 10 : n).join('\n');
    }
    if (cmd === 'tail') {
      const n = args[0] === '-n' && args[1] ? Number(args[1]) : 10;
      return rows.slice(-(Number.isNaN(n) ? 10 : n)).join('\n');
    }
    if (cmd === 'sort') {
      return [...rows].sort((a, b) => a.localeCompare(b, 'tr')).join('\n');
    }
    if (cmd === 'uniq') {
      const outRows: string[] = [];
      for (const r of rows) {
        if (outRows.length === 0 || outRows[outRows.length - 1] !== r) {
          outRows.push(r);
        }
      }
      return outRows.join('\n');
    }
    return inputText;
  };

  const expandAliasCommand = (rawCmd: string, visited = new Set<string>()): string => {
    const trimmed = rawCmd.trim();
    if (!trimmed) return trimmed;
    const spaceIdx = trimmed.search(/\s/);
    const firstWord = spaceIdx === -1 ? trimmed : trimmed.slice(0, spaceIdx);
    const rest = spaceIdx === -1 ? '' : trimmed.slice(spaceIdx);
    const aliasVal = aliasesRef.current[firstWord];
    if (aliasVal && !visited.has(firstWord)) {
      visited.add(firstWord);
      return expandAliasCommand(aliasVal + rest, visited);
    }
    return trimmed;
  };

  const runSingleCommand = (
    rawCmd: string,
    currentCwd: string,
    elevatedRoot = false,
    visitedAliases = new Set<string>(),
    substDepth = 0
  ): {
    out: string;
    err?: string;
    nextCwd?: string;
    clear?: boolean;
    mutatedVfs?: boolean;
    asyncOp?: () => Promise<number>;
  } => {
    const expandedCmd = expandAliasCommand(rawCmd, visitedAliases);
    let withSubst = expandedCmd;
    if (substDepth < 3 && withSubst.includes('$(')) {
      withSubst = withSubst.replace(/\$\(([^()]+)\)/g, (_, inner: string) => {
        const sub = runSingleCommand(inner.trim(), currentCwd, elevatedRoot, new Set<string>(), substDepth + 1);
        return (sub.out || '').replace(/\r?\n+$/, '').replace(/\r?\n/g, ' ');
      });
    }
    const tokens = tokenizeArgs(expandEnv(withSubst, currentCwd));
    if (tokens.length === 0) return { out: '' };
    const [cmd, ...args] = tokens;
    const liveVfs = vfsRef.current;

    if (cmd === 'sudo') {
      if (args.length === 0) return { out: '', err: 'Kullanım: sudo <komut>' };
      return runSingleCommand(args.join(' '), currentCwd, true, visitedAliases);
    }

    // Direct script execution ./script.sh or /path/script.sh
    if (cmd.startsWith('./') || cmd.startsWith('/')) {
      const path = normalizePath(cmd, currentCwd, userHome);
      const node = getNodeAtPath(liveVfs, path);
      if (!node || node.type !== 'file') {
        return { out: '', err: `ankash: ${cmd}: Böyle bir dosya yok` };
      }
      if (!canExecuteNode(node, currentUser.username, elevatedRoot)) {
        return {
          out: '',
          err: `ankash: ${cmd}: Çalıştırma izni yok (chmod +x ${cmd} kullanın)`,
        };
      }
      if (node.name.toLowerCase().endsWith('.wasm') || (node.content || '').startsWith(WASM_B64_PREFIX)) {
        const wasmContent = node.content || '';
        return {
          out: '',
          asyncOp: async () => {
            const res = await runWasmBinary(wasmContent);
            if (!res.ok) {
              appendLines([{ kind: 'error', text: res.error || 'WASM hatası' }]);
              return 1;
            }
            const outLines = [
              `[WASM Ring 3 · ${res.byteLength} B · ${res.durationMs} ms] Dışa aktarılanlar: ${res.exportsList.join(', ')}`,
            ];
            if (res.stdoutText) {
              outLines.push(res.stdoutText.trimEnd());
            }
            if (res.invoked) {
              outLines.push(`${res.invoked.fn}(${res.invoked.args.join(', ')}) => ${String(res.invoked.result)}`);
            }
            appendLines([{ kind: 'success', text: outLines.join('\n') }]);
            return 0;
          },
        };
      }
      const scriptBody = node.content || '';
      return {
        out: '',
        asyncOp: async () => {
          const parsed = evaluateIfForScript(scriptBody, liveVfs, envRef.current, {
            cwd: currentCwd,
            user: currentUser.username,
            homeDir: userHome,
            lastExit: lastExitRef.current,
          });
          if (!parsed.ok) {
            appendLines([{ kind: 'error', text: parsed.error || 'Betik ayrıştırma hatası' }]);
            return 1;
          }
          envRef.current = parsed.env;
          setEnvVars(parsed.env);
          for (const sl of parsed.commands) {
            await executeChain(sl);
          }
          return lastExitRef.current;
        },
      };
    }

    switch (cmd) {
      case 'help':
        return {
          out: [
            'ankash v3.5 Komut Referansı:',
            '  Dosya Sistemi : ls [-la], cd, pwd, cat, tree [-a], du [yol], fsck [-f], tar [-czf|-xzf], diff, touch, mkdir, rm, cp, mv, chmod, hex',
            '  Metin & Kripto: grep, head, tail, wc, sort, uniq, sha256, base64',
            '  Kabuk & Betik : alias, unalias, $VAR, $?, $(komut), if/then/else/fi, for/in/do/done, ~/.ankashrc, && , || , ; , | , > , >>',
            '  Servis & Cron : ankactl [status|start|stop|restart <servis>], crontab [-l|-a <sn> <komut>|-r <id>], power [performance|balanced|powersaver]',
            '  İzole Çalışma : run <dosya>, wasmrun <dosya> [--profile|-p] [--open], wasmprof [iz|dosya], wasmc, wasmpkg, wasm-builder',
            '  Kullanıcı/Yet : sudo, su <kullanici> [parola], useradd <ad> [parola], passwd [yeni]',
            '  Masaüstü/Tema : screenshot, theme [dark|light|toggle], accent [sky|emerald|amber|rose|slate]',
            '  Çekirdek/MMU  : ps, jobs, fg [%id], fork <pid>, cowfault <pid>, kill [-TERM] <pid|%id>, renice, free, vmstat, ioqueue, syscalls',
            '  Güvenlik/Yedek: aslr, ringtest [pid], sandbox, snapshot [export|import|sync push|sync pull]',
            '  İnternet & Ağ : search <sorgu>, nslookup <alanadi>, wget <url>, curl <hedef>, ping <hedef>, ifconfig, pkg, selftest',
          ].join('\n'),
        };

      case 'clear':
        return { out: '', clear: true };

      case 'pwd':
        return { out: currentCwd };

      case 'whoami':
        return { out: elevatedRoot ? 'root' : currentUser.username };

      case 'id':
        return {
          out: elevatedRoot
            ? 'uid=0(root) gid=0(root) gruplar=0(root)'
            : `uid=${currentUser.uid}(${currentUser.username}) gid=${currentUser.uid}(${currentUser.username})`,
        };

      case 'alias': {
        if (args.length === 0) {
          const entries = Object.entries(aliasesRef.current);
          if (entries.length === 0) return { out: 'Tanımlı alias yok.' };
          return { out: entries.map(([k, v]) => `alias ${k}='${v}'`).join('\n') };
        }
        const joined = args.join(' ');
        const eqIdx = joined.indexOf('=');
        if (eqIdx === -1) {
          const val = aliasesRef.current[joined];
          return val
            ? { out: `alias ${joined}='${val}'` }
            : { out: '', err: `alias: ${joined}: bulunamadı` };
        }
        const name = joined.slice(0, eqIdx).trim();
        let val = joined.slice(eqIdx + 1).trim();
        if ((val.startsWith("'") && val.endsWith("'")) || (val.startsWith('"') && val.endsWith('"'))) {
          val = val.slice(1, -1);
        }
        if (!name) return { out: '', err: "Kullanım: alias ad='komut'" };
        const nextAliases = { ...aliasesRef.current, [name]: val };
        aliasesRef.current = nextAliases;
        setAliases(nextAliases);
        return { out: `alias ${name}='${val}'` };
      }

      case 'unalias': {
        if (!args[0]) return { out: '', err: 'Kullanım: unalias <ad>' };
        if (!(args[0] in aliasesRef.current)) {
          return { out: '', err: `unalias: ${args[0]} bulunamadı` };
        }
        const nextAliases = { ...aliasesRef.current };
        delete nextAliases[args[0]];
        aliasesRef.current = nextAliases;
        setAliases(nextAliases);
        return { out: '' };
      }

      case 'su': {
        const target = args[0] || 'root';
        const pass = args[1] || '';
        return {
          out: '',
          asyncOp: async () => {
            const res = await switchUser(target, pass);
            if (!res.ok) {
              appendLines([{ kind: 'error', text: res.error || 'Yetki hatası' }]);
              return 1;
            }
            appendLines([{ kind: 'success', text: `Aktif kullanıcı: ${target}` }]);
            return 0;
          },
        };
      }

      case 'useradd': {
        if (!args[0]) return { out: '', err: 'Kullanım: useradd <kullanici_adi> [parola]' };
        return {
          out: '',
          asyncOp: async () => {
            const res = await createUser(args[0], args[0], args[1] || '');
            if (!res.ok) {
              appendLines([{ kind: 'error', text: res.error || 'Oluşturulamadı' }]);
              return 1;
            }
            appendLines([
              {
                kind: 'success',
                text: `Kullanıcı '${args[0]}' ve /home/${args[0]} dizini oluşturuldu.`,
              },
            ]);
            return 0;
          },
        };
      }

      case 'passwd': {
        const nextPass = args[0] || null;
        return {
          out: '',
          asyncOp: async () => {
            await setUserPassword(currentUser.username, nextPass);
            appendLines([
              {
                kind: 'success',
                text: nextPass
                  ? `${currentUser.username} parolası güncellendi.`
                  : `${currentUser.username} parolası kaldırıldı.`,
              },
            ]);
            return 0;
          },
        };
      }

      case 'env':
        return {
          out: Object.entries({ ...envRef.current, USER: currentUser.username, PWD: currentCwd })
            .map(([k, v]) => `${k}=${v}`)
            .join('\n'),
        };

      case 'export': {
        const assignment = args.join(' ');
        const eqIdx = assignment.indexOf('=');
        if (eqIdx === -1) return { out: '', err: 'Kullanım: export ANAHTAR=DEĞER' };
        const key = assignment.slice(0, eqIdx).trim();
        const val = assignment.slice(eqIdx + 1).trim();
        const nextEnv = { ...envRef.current, [key]: val };
        envRef.current = nextEnv;
        setEnvVars(nextEnv);
        return { out: '' };
      }

      case 'date':
        return { out: new Date().toLocaleString(settings.language === 'tr' ? 'tr-TR' : 'en-US') };

      case 'uptime':
        return {
          out: `up ${formatUptime(uptimeSec)}, bağlam değişimi: ${schedulerStats.contextSwitches}`,
        };

      case 'uname':
        return {
          out: args.includes('-a')
            ? 'AnkaOS anka-is-istasyonu 6.1.0-ankaos #4 SMP x86_64/WebAssembly AnkaKernel'
            : 'AnkaOS',
        };

      case 'history':
        return {
          out: cmdHistory.map((c, idx) => `  ${String(idx + 1).padStart(3, ' ')}  ${c}`).join('\n'),
        };

      case 'cd': {
        const target = args[0] ? normalizePath(args[0], currentCwd, userHome) : userHome;
        const node = getNodeAtPath(liveVfs, target);
        if (!node) return { out: '', err: `cd: ${args[0]}: Bulunamadı` };
        if (node.type !== 'dir') return { out: '', err: `cd: ${args[0]}: Dizin değil` };
        return { out: '', nextCwd: target };
      }

      case 'ls': {
        const longMode = args.some((a) => a.startsWith('-') && a.includes('l'));
        const showAll = args.some((a) => a.startsWith('-') && a.includes('a'));
        const pathArg = args.find((a) => !a.startsWith('-'));
        const targetPath = pathArg ? normalizePath(pathArg, currentCwd, userHome) : currentCwd;
        const node = getNodeAtPath(liveVfs, targetPath);
        if (!node) return { out: '', err: `ls: '${pathArg}': Bulunamadı` };
        if (node.type === 'file') {
          return {
            out: longMode
              ? `${node.permissions}  ${node.owner.padEnd(10)} ${formatBytes(node.size).padStart(8)}  ${node.name}`
              : node.name,
          };
        }
        const allEntries = listDir(liveVfs, targetPath);
        const entries = showAll ? allEntries : allEntries.filter((e) => !e.name.startsWith('.'));
        if (entries.length === 0 && !showAll) return { out: '' };
        if (longMode) {
          const rows = entries.map((e) => {
            const d = new Date(e.updatedAt).toLocaleTimeString('tr-TR', {
              hour: '2-digit',
              minute: '2-digit',
            });
            const sizeStr = e.type === 'dir' ? '4.0 KB' : formatBytes(e.size);
            return `${e.permissions}  ${e.owner.padEnd(10)} ${sizeStr.padStart(8)}  ${d}  ${e.name}${
              e.type === 'dir' ? '/' : ''
            }`;
          });
          if (showAll) rows.unshift('drwxr-xr-x  kullanici    4.0 KB  ..', 'drwxr-xr-x  kullanici    4.0 KB  .');
          return { out: rows.join('\n') };
        }
        return { out: entries.map((e) => (e.type === 'dir' ? `${e.name}/` : e.name)).join('   ') };
      }

      case 'tree': {
        const showAll = args.includes('-a');
        const pathArg = args.find((a) => !a.startsWith('-'));
        const targetPath = pathArg ? normalizePath(pathArg, currentCwd, userHome) : currentCwd;
        const rootNode = getNodeAtPath(liveVfs, targetPath);
        if (!rootNode) return { out: '', err: `tree: '${pathArg || args[0]}' bulunamadı` };
        const linesOut: string[] = [targetPath];
        const walk = (dirPath: string, prefix: string) => {
          const allChildren = listDir(liveVfs, dirPath);
          const children = showAll ? allChildren : allChildren.filter((c) => !c.name.startsWith('.'));
          children.forEach((child, idx) => {
            const isLast = idx === children.length - 1;
            linesOut.push(`${prefix}${isLast ? '└── ' : '├── '}${child.name}${child.type === 'dir' ? '/' : ''}`);
            if (child.type === 'dir') {
              walk(dirPath === '/' ? `/${child.name}` : `${dirPath}/${child.name}`, prefix + (isLast ? '    ' : '│   '));
            }
          });
        };
        if (rootNode.type === 'dir') walk(targetPath, '');
        return { out: linesOut.join('\n') };
      }

      case 'cat': {
        if (!args[0]) return { out: '', err: 'Kullanım: cat <dosya>' };
        const path = normalizePath(args[0], currentCwd, userHome);
        const content = readDynamicNodeContent(liveVfs, path, { frames, swapSlots, processes, uptimeSec });
        if (content === null) return { out: '', err: `cat: ${args[0]}: Dosya okunamadı` };
        const node = getNodeAtPath(liveVfs, path);
        if (node?.mimeType === 'image/data') {
          return { out: `[İkili Görsel Verisi: ${formatBytes(node.size)} — 'open ${args[0]}' ile görüntüleyin]` };
        }
        if (node?.mimeType === 'application/wasm' || content.startsWith(WASM_B64_PREFIX)) {
          return { out: `[WebAssembly İkili Modülü: ${formatBytes(node?.size || content.length)} — 'wasmrun ${args[0]}' veya 'hex ${args[0]}' kullanın]` };
        }
        return { out: content };
      }

      case 'echo':
        return { out: args.join(' ') };

      case 'touch': {
        if (!args[0]) return { out: '', err: 'Kullanım: touch <dosya>' };
        const path = normalizePath(args[0], currentCwd, userHome);
        if (getNodeAtPath(liveVfs, path)) return { out: '' };
        const res = writeFile(path, '', undefined, elevatedRoot);
        return res.ok ? { out: '', mutatedVfs: true } : { out: '', err: res.error };
      }

      case 'mkdir': {
        if (!args[0]) return { out: '', err: 'Kullanım: mkdir <dizin>' };
        const res = makeDir(normalizePath(args[0], currentCwd, userHome), elevatedRoot);
        return res.ok ? { out: '', mutatedVfs: true } : { out: '', err: res.error };
      }

      case 'rm': {
        const cleanArgs = args.filter((a) => !a.startsWith('-'));
        if (!cleanArgs[0]) return { out: '', err: 'Kullanım: rm <hedef>' };
        const res = deleteNode(normalizePath(cleanArgs[0], currentCwd, userHome), elevatedRoot);
        return res.ok ? { out: '', mutatedVfs: true } : { out: '', err: res.error };
      }

      case 'chmod': {
        if (args.length < 2) return { out: '', err: 'Kullanım: chmod <755|+x|-w> <dosya>' };
        const res = chmodNode(normalizePath(args[1], currentCwd, userHome), args[0], elevatedRoot);
        return res.ok ? { out: '', mutatedVfs: true } : { out: '', err: res.error };
      }

      case 'cp': {
        if (args.length < 2) return { out: '', err: 'Kullanım: cp <kaynak> <hedef>' };
        const res = copyNode(
          normalizePath(args[0], currentCwd, userHome),
          normalizePath(args[1], currentCwd, userHome)
        );
        return res.ok ? { out: '', mutatedVfs: true } : { out: '', err: res.error };
      }

      case 'mv': {
        if (args.length < 2) return { out: '', err: 'Kullanım: mv <kaynak> <hedef>' };
        const src = normalizePath(args[0], currentCwd, userHome);
        const dest = normalizePath(args[1], currentCwd, userHome);
        const res = moveNode(src, dest);
        return res.ok ? { out: '', mutatedVfs: true } : { out: '', err: res.error };
      }

      case 'find': {
        const pattern = (args[0] || '').toLowerCase();
        const matches: string[] = [];
        const walkFind = (dirPath: string) => {
          for (const child of listDir(liveVfs, dirPath)) {
            const p = dirPath === '/' ? `/${child.name}` : `${dirPath}/${child.name}`;
            if (!pattern || child.name.toLowerCase().includes(pattern)) matches.push(p);
            if (child.type === 'dir') walkFind(p);
          }
        };
        walkFind(currentCwd);
        return { out: matches.join('\n') || 'Eşleşen öğe yok.' };
      }

      case 'grep': {
        if (args.length < 2) return { out: '', err: 'Kullanım: grep <desen> <dosya>' };
        const needle = args[0].toLowerCase();
        const txt = readDynamicNodeContent(liveVfs, normalizePath(args[1], currentCwd, userHome), {
          frames,
          swapSlots,
          processes,
          uptimeSec,
        });
        if (txt === null) return { out: '', err: `grep: ${args[1]} okunamadı` };
        return {
          out: txt
            .split('\n')
            .map((line, i) => ({ line, num: i + 1 }))
            .filter((x) => x.line.toLowerCase().includes(needle))
            .map((x) => `${x.num}: ${x.line}`)
            .join('\n'),
        };
      }

      case 'head':
      case 'tail':
      case 'wc':
      case 'sort':
      case 'uniq': {
        const fileArg = [...args].reverse().find((a, idx, arr) => {
          if (a.startsWith('-')) return false;
          const prev = arr[idx + 1];
          return prev !== '-n';
        });
        if (!fileArg) {
          return { out: '', err: `Kullanım: ${cmd} [seçenekler] <dosya>` };
        }
        const target = normalizePath(fileArg, currentCwd, userHome);
        const txt = readDynamicNodeContent(liveVfs, target, {
          frames,
          swapSlots,
          processes,
          uptimeSec,
        });
        if (txt === null) return { out: '', err: `${cmd}: ${fileArg} okunamadı` };
        return { out: applyPipeStage(txt, `${cmd} ${args.join(' ')}`, currentCwd) };
      }

      case 'diff': {
        if (args.length < 2) return { out: '', err: 'Kullanım: diff <dosya1> <dosya2>' };
        const pathA = normalizePath(args[0], currentCwd, userHome);
        const pathB = normalizePath(args[1], currentCwd, userHome);
        const txtA = readDynamicNodeContent(liveVfs, pathA, { frames, swapSlots, processes, uptimeSec });
        const txtB = readDynamicNodeContent(liveVfs, pathB, { frames, swapSlots, processes, uptimeSec });
        if (txtA === null) return { out: '', err: `diff: ${args[0]} okunamadı` };
        if (txtB === null) return { out: '', err: `diff: ${args[1]} okunamadı` };
        const res = computeLineDiff(txtA, txtB, args[0], args[1]);
        return { out: res.diffText };
      }

      case 'sha256': {
        if (args.length === 0) return { out: '', err: 'Kullanım: sha256 <dosya> | sha256 --text <metin>' };
        const isText = args[0] === '--text' || args[0] === '-t';
        let payload = '';
        let label = '';
        if (isText) {
          payload = args.slice(1).join(' ');
          label = 'metin';
        } else {
          const p = normalizePath(args[0], currentCwd, userHome);
          const content = readDynamicNodeContent(liveVfs, p, { frames, swapSlots, processes, uptimeSec });
          if (content === null) return { out: '', err: `sha256: ${args[0]} okunamadı` };
          payload = content;
          label = args[0];
        }
        return {
          out: '',
          asyncOp: async () => {
            const bytes = new TextEncoder().encode(payload);
            const digest = await crypto.subtle.digest('SHA-256', bytes);
            const hex = Array.from(new Uint8Array(digest))
              .map((b) => b.toString(16).padStart(2, '0'))
              .join('');
            appendLines([{ kind: 'output', text: `${hex}  ${label}` }]);
            return 0;
          },
        };
      }

      case 'base64': {
        const decode = args.includes('-d') || args.includes('--decode');
        const isText = args.includes('--text') || args.includes('-t');
        const cleanArgs = args.filter((a) => a !== '-d' && a !== '--decode' && a !== '--text' && a !== '-t');
        if (cleanArgs.length === 0) {
          return { out: '', err: 'Kullanım: base64 [-d] <dosya> | base64 [-d] --text <metin>' };
        }
        let payload = '';
        if (isText) {
          payload = cleanArgs.join(' ');
        } else {
          const p = normalizePath(cleanArgs[0], currentCwd, userHome);
          const content = readDynamicNodeContent(liveVfs, p, { frames, swapSlots, processes, uptimeSec });
          if (content === null) return { out: '', err: `base64: ${cleanArgs[0]} okunamadı` };
          payload = content;
        }
        try {
          if (decode) {
            const bin = atob(payload.trim());
            const bytes = Uint8Array.from(bin, (c) => c.charCodeAt(0));
            return { out: new TextDecoder().decode(bytes) };
          }
          const bytes = new TextEncoder().encode(payload);
          let bin = '';
          bytes.forEach((b) => {
            bin += String.fromCharCode(b);
          });
          return { out: btoa(bin) };
        } catch {
          return { out: '', err: 'base64: Geçersiz Base64 verisi' };
        }
      }

      case 'theme': {
        const arg = (args[0] || '').toLowerCase();
        if (!arg) {
          return {
            out: `Aktif tema: ${settings.theme === 'dark' ? 'Karanlık (dark)' : 'Aydınlık (light)'} | Vurgu: ${settings.accent}`,
          };
        }
        if (arg === 'toggle') {
          const nextMode = settings.theme === 'dark' ? 'light' : 'dark';
          toggleTheme();
          return { out: `Tema değiştirildi: ${nextMode}` };
        }
        if (arg === 'dark' || arg === 'light') {
          updateSettings({ theme: arg });
          return { out: `Tema ayarlandı: ${arg}` };
        }
        return { out: '', err: 'Kullanım: theme [dark | light | toggle]' };
      }

      case 'accent': {
        const arg = (args[0] || '').toLowerCase() as AccentColor;
        if (!arg) {
          return {
            out: `Aktif vurgu rengi: ${settings.accent} (Seçenekler: ${Object.keys(ACCENT_PALETTES).join(', ')})`,
          };
        }
        if (arg in ACCENT_PALETTES) {
          updateSettings({ accent: arg });
          return { out: `Sistem vurgu rengi güncellendi: ${arg}` };
        }
        return {
          out: '',
          err: `Geçersiz vurgu rengi. Seçenekler: ${Object.keys(ACCENT_PALETTES).join(', ')}`,
        };
      }

      case 'ps': {
        const header = '  PID  RING  PRI  DURUM     CPU%   BELLEK  KULLANICI   KOMUT';
        const rows = processes.map(
          (p) =>
            `${String(p.pid).padStart(5)}  R${p.privilegeRing}    ${String(p.priority).padStart(3)}  ${p.state.padEnd(8)}  ${p.cpu
              .toFixed(1)
              .padStart(4)}  ${String(p.memoryMB + 'M').padStart(6)}  ${p.user.padEnd(10)}  ${p.command}${
              p.isForeground ? ' [FG]' : ''
            }`
        );
        return { out: [header, ...rows].join('\n') };
      }

      case 'fork': {
        const pid = Number(args[0]) || processes.find((p) => p.privilegeRing === 3)?.pid || 24;
        const res = forkProcess(pid);
        return res.ok ? { out: res.message } : { out: '', err: res.message };
      }

      case 'cowfault': {
        const pid = Number(args[0]) || processes.find((p) => p.name.endsWith('-fork'))?.pid;
        if (!pid) return { out: '', err: 'Kullanım: cowfault <pid> (önce fork <pid> çalıştırın)' };
        const res = triggerCowWriteFault(pid);
        return res.ok ? { out: res.message } : { out: '', err: res.message };
      }

      case 'aslr': {
        return {
          out: processes
            .map(
              (p) =>
                `PID=${String(p.pid).padEnd(4)} R${p.privilegeRing} ${p.name.padEnd(14)} Heap=${
                  p.aslrLayout?.heapBase || '-'
                }  Stack=${p.aslrLayout?.stackBase || '-'}`
            )
            .join('\n'),
        };
      }

      case 'ringtest': {
        const targetPid =
          Number(args[0]) || processes.find((p) => p.privilegeRing === 3)?.pid || 100;
        const res = attemptKernelMemoryAccess(targetPid, '0xffff800000001000');
        return res.ok ? { out: res.message } : { out: '', err: res.message };
      }

      case 'sandbox': {
        const grants = Object.entries(settings.sandboxGrants || {})
          .map(([app, caps]) => `  ${app.padEnd(12)} -> [${caps.join(', ') || 'sadece ~/.sandbox'}]`)
          .join('\n');
        return { out: `Sandbox İzin Politikaları:\n${grants}` };
      }

      case 'ioqueue': {
        return {
          out: `Async I/O Kuyruğu -> Bekleyen: ${ioQueueStats.queuedCount} | İşlenen: ${ioQueueStats.processingCount} | Tamamlanan: ${ioQueueStats.completedCount} | Ort: ${ioQueueStats.avgLatencyMs} ms`,
        };
      }

      case 'jobs': {
        if (backgroundJobs.length === 0) return { out: 'Arka planda çalışan iş yok.' };
        return {
          out: backgroundJobs
            .map((j) => `[${j.jobId}]  ${j.status.padEnd(8)}  PID=${j.pid}  ${j.command}`)
            .join('\n'),
        };
      }

      case 'fg': {
        if (backgroundJobs.length === 0) {
          return { out: '', err: 'fg: ön plana alınacak arka plan işi yok' };
        }
        const jobNum = args[0] ? Number(args[0].replace(/^%/, '')) : null;
        const job =
          jobNum !== null
            ? backgroundJobs.find((j) => j.jobId === jobNum)
            : [...backgroundJobs].reverse().find((j) => j.status === 'running' || j.status === 'stopped') ||
              backgroundJobs[backgroundJobs.length - 1];
        if (!job) {
          return { out: '', err: `fg: %${args[0] || ''} işi bulunamadı` };
        }
        signalProcess(job.pid, 'SIGCONT');
        return {
          out: `[${job.jobId}] Ön plana alındı: ${job.command} (PID ${job.pid} · durum=${job.status})`,
        };
      }

      case 'sleep': {
        const sec = Math.max(1, Math.min(30, Number(args[0]) || 2));
        const job = spawnBackgroundJob(`sleep ${sec}`, sec * 1000);
        return { out: `[${job.jobId}] Arka planda başlatıldı (PID ${job.pid}, ${sec}sn)` };
      }

      case 'kill': {
        if (args.length === 0) {
          return { out: '', err: 'Kullanım: kill [-STOP|-CONT|-TERM|-KILL] <pid | %iş_no>' };
        }
        let sig: 'SIGSTOP' | 'SIGCONT' | 'SIGTERM' | 'SIGKILL' = 'SIGKILL';
        let pidStr = args[0];
        if (args[0].startsWith('-')) {
          const flag = args[0].toUpperCase().replace(/^-/, '');
          pidStr = args[1] || '';
          if (flag === 'STOP' || flag === 'SIGSTOP') sig = 'SIGSTOP';
          else if (flag === 'CONT' || flag === 'SIGCONT') sig = 'SIGCONT';
          else if (flag === 'TERM' || flag === 'SIGTERM') sig = 'SIGTERM';
          else if (flag === '9' || flag === 'KILL' || flag === 'SIGKILL') sig = 'SIGKILL';
          else return { out: '', err: `Bilinmeyen sinyal: ${args[0]}` };
        }
        let pid = Number(pidStr);
        if (pidStr.startsWith('%')) {
          const jId = Number(pidStr.slice(1));
          const job = backgroundJobs.find((j) => j.jobId === jId);
          if (!job) return { out: '', err: `kill: ${pidStr} arka plan işi bulunamadı` };
          pid = job.pid;
        }
        if (!pid || Number.isNaN(pid)) {
          return { out: '', err: 'Kullanım: kill [-STOP|-CONT|-TERM|-KILL] <pid | %iş_no>' };
        }
        if (sig === 'SIGKILL' && !args[0].startsWith('-')) {
          const res = killProcess(pid);
          return res.ok ? { out: `Süreç ${pid} sonlandırıldı.` } : { out: '', err: res.error };
        }
        const res = signalProcess(pid, sig);
        return res.ok ? { out: res.message } : { out: '', err: res.message };
      }

      case 'renice': {
        if (args.length < 2) return { out: '', err: 'Kullanım: renice <öncelik -20..19> <pid>' };
        const pri = Number(args[0]);
        const pid = Number(args[1]);
        const res = reniceProcess(pid, pri);
        return res.ok
          ? { out: `PID ${pid} önceliği ${pri} olarak güncellendi.` }
          : { out: '', err: res.error };
      }

      case 'ifconfig': {
        return {
          out: networkInterfaces
            .map(
              (ifc) =>
                `${ifc.name}: flags=<${ifc.status},RUNNING>  mtu 1500\n` +
                `        inet ${ifc.ip}  netmask ${ifc.netmask}  ether ${ifc.mac}\n` +
                `        RX packets ${ifc.rxPackets}  bytes ${ifc.rxBytes}  |  TX packets ${ifc.txPackets}  bytes ${ifc.txBytes}`
            )
            .join('\n\n'),
        };
      }

      case 'ping': {
        const host = args[0] || 'localhost';
        if (host === 'localhost' || /^\d{1,3}(\.\d{1,3}){3}$/.test(host)) {
          const r = measureLoopbackPing(host, liveVfs);
          recordNetworkTraffic(r.ip === '127.0.0.1' ? 'lo' : 'eth0', 64, 64);
          return {
            out: [
              `PING ${host} (${r.ip}) 56(84) bytes of data.`,
              `64 bytes from ${r.ip}: icmp_seq=1 ttl=${r.ttl} time=${r.rttMs} ms`,
              `64 bytes from ${r.ip}: icmp_seq=2 ttl=${r.ttl} time=${(r.rttMs * 0.96).toFixed(2)} ms`,
              `--- ${host} ping statistics ---`,
              `2 packets transmitted, 2 received, 0% packet loss`,
            ].join('\n'),
          };
        }
        return {
          out: '',
          asyncOp: async () => {
            const p = await pingHostLive(host);
            if (!p.ok) {
              appendLines([{ kind: 'error', text: `ping: ${host}: ${p.error || 'Ulaşılamadı'}` }]);
              return 1;
            }
            recordNetworkTraffic('eth0', 64, 64);
            appendLines([
              {
                kind: 'output',
                text: `PING ${host} (${p.ip}) TCP:${p.port} — rtt=${p.rttMs} ms (0% kayıp)`,
              },
            ]);
            return 0;
          },
        };
      }

      case 'nslookup': {
        if (!args[0]) return { out: '', err: 'Kullanım: nslookup <alanadi>' };
        const host = args[0];
        return {
          out: '',
          asyncOp: async () => {
            const res = await resolveDnsLive(host);
            if (!res.ok) {
              appendLines([{ kind: 'error', text: `nslookup: ${res.error || 'Çözümlenemedi'}` }]);
              return 1;
            }
            recordNetworkTraffic('eth0', 256, 64);
            appendLines([
              {
                kind: 'output',
                text: [
                  `Sunucu:  AnkaNet DNS Bridge (${res.tookMs} ms)`,
                  `Ad:      ${res.host}`,
                  `IPv4 A:  ${res.v4?.join(', ') || '(yok)'}`,
                  `IPv6:    ${res.v6?.join(', ') || '(yok)'}`,
                  `NS:      ${res.ns?.slice(0, 3).join(', ') || '-'}`,
                ].join('\n'),
              },
            ]);
            return 0;
          },
        };
      }

      case 'search': {
        if (args.length === 0) return { out: '', err: 'Kullanım: search <arama_sorgusu>' };
        const q = args.join(' ');
        return {
          out: '',
          asyncOp: async () => {
            const res = await searchWebLive(q, settings.language);
            if (!res.ok && res.results.length === 0) {
              appendLines([{ kind: 'error', text: `Arama başarısız: ${res.error || 'Ağ erişilemedi'}` }]);
              return 1;
            }
            recordNetworkTraffic('eth0', 1024, 128);
            const linesOut: string[] = [
              `[AnkaArama · ${res.results.length} sonuç · ${res.tookMs} ms]`,
            ];
            if (res.instantAnswer?.abstract) {
              linesOut.push(`  [Bilgi] ${res.instantAnswer.heading}: ${res.instantAnswer.abstract.slice(0, 220)}`);
            }
            res.results.slice(0, 6).forEach((hit, idx) => {
              linesOut.push(`  ${idx + 1}. ${hit.title}\n     ${hit.url}`);
            });
            appendLines([{ kind: 'output', text: linesOut.join('\n') }]);
            return 0;
          },
        };
      }

      case 'wget': {
        if (!args[0]) return { out: '', err: 'Kullanım: wget <https://...> [-o dosya]' };
        const urlArg = args[0].startsWith('http') ? args[0] : `https://${args[0]}`;
        const outIdx = args.indexOf('-o');
        const customOut = outIdx !== -1 && args[outIdx + 1] ? args[outIdx + 1] : null;
        return {
          out: '',
          asyncOp: async () => {
            const page = await fetchPageLive(urlArg);
            if (!page.ok || !page.rawText) {
              appendLines([{ kind: 'error', text: `wget: ${page.error || 'İndirilemedi'}` }]);
              return 1;
            }
            const hostSlug = new URL(urlArg).hostname.replace(/[^a-z0-9.-]/gi, '_');
            const isHtml = (page.contentType || '').includes('html');
            const defaultPath = `${userHome}/İndirilenler/${hostSlug}.${isHtml ? 'html' : 'txt'}`;
            const destPath = customOut ? normalizePath(customOut, currentCwd, userHome) : defaultPath;
            const wRes = writeFile(destPath, page.rawText, isHtml ? 'text/html' : 'text/plain', elevatedRoot);
            if (!wRes.ok) {
              appendLines([{ kind: 'error', text: wRes.error || 'Kaydedilemedi' }]);
              return 1;
            }
            recordNetworkTraffic('eth0', page.bytes || page.rawText.length, 128);
            appendLines([
              {
                kind: 'success',
                text: `İndirildi: ${destPath} (${formatBytes(page.bytes || page.rawText.length)}, HTTP ${page.status})`,
              },
            ]);
            await waitTick();
            return 0;
          },
        };
      }

      case 'curl': {
        if (!args[0]) return { out: '', err: 'Kullanım: curl <dosya_yolu_veya_url>' };
        if (args[0].startsWith('vfs://') || args[0].startsWith('/') || args[0].startsWith('~/')) {
          const p = normalizePath(args[0].replace(/^vfs:\/\//, ''), currentCwd, userHome);
          const content = readDynamicNodeContent(liveVfs, p, { frames, swapSlots, processes, uptimeSec });
          if (content === null) return { out: '', err: `curl: (37) Dosya okunamadı: ${p}` };
          recordNetworkTraffic('lo', content.length, 64);
          return { out: content };
        }
        const targetUrl = args[0].startsWith('http') ? args[0] : `https://${args[0]}`;
        return {
          out: '',
          asyncOp: async () => {
            const page = await fetchPageLive(targetUrl);
            if (!page.ok) {
              appendLines([{ kind: 'error', text: `curl: ${page.error || 'İstek başarısız'}` }]);
              return 1;
            }
            recordNetworkTraffic('eth0', page.bytes || 256, 128);
            const body = page.textPreview || page.rawText || '';
            appendLines([
              {
                kind: 'output',
                text: `[HTTP ${page.status} · ${page.contentType} · ${formatBytes(page.bytes || 0)}]\n${body.slice(0, 1600)}`,
              },
            ]);
            return 0;
          },
        };
      }

      case 'free': {
        const s = getMemorySummary(frames, swapSlots);
        return {
          out: [
            '               toplam      kullanılan        boş     çerçeveler',
            `Bellek:       ${String(s.totalMB).padStart(6)}M      ${String(s.usedMB).padStart(
              8
            )}M    ${String(s.freeMB).padStart(7)}M     ${s.usedFrames}/${s.totalFrames}`,
            `Takas (Swap): ${String(s.swapTotalMB).padStart(6)}M      ${String(
              s.swapUsedMB
            ).padStart(8)}M    ${String(s.swapTotalMB - s.swapUsedMB).padStart(
              7
            )}M     ${s.swapUsedSlots}/64`,
          ].join('\n'),
        };
      }

      case 'vmstat': {
        const s = getMemorySummary(frames, swapSlots);
        return {
          out: [
            `MMU Toplam Çerçeve : ${s.totalFrames} x ${s.frameSizeMB} MB = ${s.totalMB} MB`,
            `Kullanılan / CoW   : ${s.usedFrames} çerçeve (${s.usedMB} MB, %${s.usagePct}) | CoW Tasarruf: ${s.cowSavedMB} MB`,
            `Takas (LRU Swap)   : ${s.swapUsedSlots}/64 yuva (${s.swapUsedMB}/${s.swapTotalMB} MB)`,
            `Zamanlayıcı        : Preemptive Priority | Bağlam: ${schedulerStats.contextSwitches} | Kesinti: ${schedulerStats.preemptions}`,
            `Async G/Ç Kuyruğu  : Bekleyen ${ioQueueStats.queuedCount} | Tamamlanan ${ioQueueStats.completedCount}`,
          ].join('\n'),
        };
      }

      case 'syscalls': {
        if (syscalls.length === 0) return { out: 'Henüz sistem çağrısı yok.' };
        return {
          out: syscalls
            .slice(0, 15)
            .map(
              (sc) =>
                `[${new Date(sc.timestamp).toLocaleTimeString('tr-TR')}] PID=${String(sc.pid).padEnd(
                  4
                )} ${sc.name.padEnd(14)} (${sc.args}) -> ${sc.status}`
            )
            .join('\n'),
        };
      }

      case 'df':
        return {
          out: [
            'DosyaSistemi          Boyut  Kul   Boş  Kul% BağlandığıYer',
            'vfs-IndexedDB+LS       10M  180K  9.8M    2% /',
            'procfs                   0     0     0    0% /proc',
            'devfs                    0     0     0    0% /dev',
          ].join('\n'),
        };

      case 'neofetch': {
        const s = getMemorySummary(frames, swapSlots);
        return {
          out: [
            `       /\\        ${currentUser.username}@anka-is-istasyonu`,
            '      /  \\       ---------------------------',
            '     / /\\ \\      İşletim Sistemi : AnkaOS 3.5 (Kuzgun)',
            '    / ____ \\     Çekirdek        : AnkaKernel 6.1.0-wasm',
            `   /_/    \\_\\    Çalışma Süresi  : ${formatUptime(uptimeSec)}`,
            `                 Tema & Vurgu    : ${settings.theme} / ${settings.accent}`,
            `                 Çalışma Zamanı  : Ring 3 Web Worker + WebAssembly`,
            `                 Zamanlayıcı     : Preemptive Priority (${schedulerStats.contextSwitches} switch, ${schedulerStats.preemptions} preempt)`,
            `                 Bellek & Swap   : ${s.usedMB}/${s.totalMB} MiB (%${s.usagePct}) | Swap ${s.swapUsedMB}/${s.swapTotalMB} MiB`,
          ].join('\n'),
        };
      }

      case 'pkg': {
        const sub = args[0] || 'list';
        if (sub === 'list') {
          return {
            out: PACKAGE_REGISTRY.map((p) => {
              const installed = pkgsRef.current.includes(p.appId) ? '[KURULU]' : '[MEVCUT]';
              return `${installed.padEnd(9)} ${p.pkgName.padEnd(18)} v${p.version}  (${p.sizeKB} KB) — ${p.nameTr}`;
            }).join('\n'),
          };
        }
        if (sub === 'install' && args[1]) {
          const res = installPackage(args[1]);
          return res.ok ? { out: res.message } : { out: '', err: res.message };
        }
        if (sub === 'remove' && args[1]) {
          const res = removePackage(args[1]);
          return res.ok ? { out: res.message } : { out: '', err: res.message };
        }
        return { out: '', err: 'Kullanım: pkg [list | install <ad> | remove <ad>]' };
      }

      case 'sh': {
        if (!args[0]) return { out: '', err: 'Kullanım: sh <betik.sh>' };
        const path = normalizePath(args[0], currentCwd, userHome);
        const content = readDynamicNodeContent(liveVfs, path, { frames, swapSlots, processes, uptimeSec });
        if (content === null) return { out: '', err: `sh: ${args[0]} bulunamadı` };
        return {
          out: '',
          asyncOp: async () => {
            const parsed = evaluateIfForScript(content, liveVfs, envRef.current, {
              cwd: currentCwd,
              user: currentUser.username,
              homeDir: userHome,
              lastExit: lastExitRef.current,
            });
            if (!parsed.ok) {
              appendLines([{ kind: 'error', text: parsed.error || 'Betik ayrıştırma hatası' }]);
              return 1;
            }
            envRef.current = parsed.env;
            setEnvVars(parsed.env);
            for (const sl of parsed.commands) {
              await executeChain(sl);
            }
            return lastExitRef.current;
          },
        };
      }

      case 'selftest':
        return {
          out: '',
          asyncOp: async () => {
            const results = await runKernelSelfTests();
            const passedCount = results.filter((r) => r.passed).length;
            appendLines([
              { kind: 'info', text: 'AnkaOS v3.5 Çekirdek & Altsistem Doğrulama Testleri:' },
              ...results.map((r) => ({
                kind: (r.passed ? 'success' : 'error') as 'success' | 'error',
                text: `${r.passed ? '[GEÇTİ]' : '[KALDI]'} ${r.name} — ${r.detail}`,
              })),
              {
                kind: passedCount === results.length ? 'success' : 'error',
                text: `Sonuç: ${passedCount}/${results.length} test başarıyla tamamlandı.`,
              },
            ]);
            return passedCount === results.length ? 0 : 1;
          },
        };

      case 'edit': {
        if (!args[0]) {
          launchApp('editor');
          return { out: 'Kod Düzenleyici açıldı.' };
        }
        launchApp('editor', { path: normalizePath(args[0], currentCwd, userHome) });
        return { out: `Düzenleniyor: ${args[0]}` };
      }

      case 'open': {
        if (!args[0]) return { out: '', err: 'Kullanım: open <hedef>' };
        const path = normalizePath(args[0], currentCwd, userHome);
        if (!getNodeAtPath(liveVfs, path)) return { out: '', err: `open: ${args[0]} bulunamadı` };
        openFileWithDefaultApp(path);
        return { out: `Açıldı: ${path}` };
      }

      case 'hex': {
        if (!pkgsRef.current.includes('pkg-hex')) {
          return {
            out: '',
            err: "hex-inceleyici paketi kurulu değil. Kurmak için 'pkg install hex-inceleyici' yazın.",
          };
        }
        const target = args[0] ? normalizePath(args[0], currentCwd, userHome) : '/etc/os-release';
        if (!getNodeAtPath(liveVfs, target)) return { out: '', err: `hex: ${target} bulunamadı` };
        launchApp('pkg-hex', { path: target });
        return { out: `Hex İnceleyici açıldı: ${target}` };
      }

      case 'wasmc': {
        if (!args[0]) return { out: '', err: 'Kullanım: wasmc <kaynak.wat> [-o hedef.wasm]' };
        const srcPath = normalizePath(args[0], currentCwd, userHome);
        const srcNode = getNodeAtPath(liveVfs, srcPath);
        if (!srcNode || srcNode.type !== 'file') {
          return { out: '', err: `wasmc: ${args[0]} bulunamadı` };
        }
        const outFlagIdx = args.indexOf('-o');
        const outArg = outFlagIdx !== -1 && args[outFlagIdx + 1] ? args[outFlagIdx + 1] : null;
        const destPath = normalizePath(
          outArg || srcPath.replace(/\.(wat|wast)$/i, '') + '.wasm',
          currentCwd,
          userHome
        );

        const compiled = compileWatToWasm(srcNode.content || '');
        if (!compiled.ok || !compiled.base64Content) {
          return { out: '', err: `wasmc derleme hatası: ${compiled.error}` };
        }
        const wRes = writeFile(destPath, compiled.base64Content, 'application/wasm', elevatedRoot);
        if (!wRes.ok) return { out: '', err: wRes.error };
        chmodNode(destPath, '+x', elevatedRoot);

        const sectionsText = compiled.sectionSummary.map((s) => `${s.name}:${s.bytes}B`).join(' ');
        const exportsText = compiled.exports.map((e) => `${e.kind}:${e.name}`).join(', ') || '(yok)';
        return {
          out: [
            `[wasmc OK] ${srcPath} -> ${destPath}`,
            `  Boyut: ${compiled.sizeBytes} B | Süre: ${compiled.compileTimeMs} ms | Bölümler: ${sectionsText}`,
            `  Dışa aktarılanlar: ${exportsText}`,
          ].join('\n'),
          mutatedVfs: true,
        };
      }

      case 'wasmpkg': {
        const sub = (args[0] || '').toLowerCase();
        if (sub === 'info' && args[1]) {
          const pkgPath = normalizePath(args[1], currentCwd, userHome);
          const node = getNodeAtPath(liveVfs, pkgPath);
          if (!node || node.type !== 'file' || !node.content) {
            return { out: '', err: `wasmpkg: ${args[1]} bulunamadı` };
          }
          try {
            const m = JSON.parse(node.content) as AnkaWasmPackageManifest;
            if (m.schema !== 'ankaos-wasm-pkg-v1') {
              return { out: '', err: 'Geçerli bir .ankawasm paketi değil.' };
            }
            return {
              out: [
                `Paket  : ${m.name} v${m.version} (${m.author})`,
                `Giriş  : ${m.entryFn}()`,
                `Boyut  : ${m.byteLength} B`,
                `SHA256 : ${m.sha256}`,
                `İhraç  : ${m.exports.map((e) => e.name).join(', ') || '(yok)'}`,
              ].join('\n'),
            };
          } catch {
            return { out: '', err: 'Paket JSON ayrıştırılamadı.' };
          }
        }

        if (sub === 'pack' && args[1]) {
          const srcPath = normalizePath(args[1], currentCwd, userHome);
          const srcNode = getNodeAtPath(liveVfs, srcPath);
          if (!srcNode || srcNode.type !== 'file') {
            return { out: '', err: `wasmpkg: ${args[1]} bulunamadı` };
          }
          const outIdx = args.indexOf('-o');
          const nameIdx = args.indexOf('--name');
          const installBin = args.includes('--install');
          const outArg = outIdx !== -1 && args[outIdx + 1] ? args[outIdx + 1] : null;
          const pkgNameArg = nameIdx !== -1 && args[nameIdx + 1] ? args[nameIdx + 1] : null;
          const destPath = normalizePath(
            outArg || srcPath.replace(/\.(wat|wast|wasm)$/i, '') + '.ankawasm',
            currentCwd,
            userHome
          );
          const pkgName = (pkgNameArg || srcNode.name.replace(/\.(wat|wast|wasm)$/i, ''))
            .replace(/[^a-z0-9_-]/gi, '-')
            .toLowerCase();

          return {
            out: '',
            asyncOp: async () => {
              let wasmPayload = srcNode.content || '';
              let watSource: string | undefined;
              let exportsMeta;

              if (/\.(wat|wast)$/i.test(srcNode.name)) {
                watSource = wasmPayload;
                const compiled = compileWatToWasm(watSource);
                if (!compiled.ok || !compiled.base64Content) {
                  appendLines([{ kind: 'error', text: `wasmpkg derleme hatası: ${compiled.error}` }]);
                  return 1;
                }
                wasmPayload = compiled.base64Content;
                exportsMeta = compiled.exports;
              }

              const pkgRes = await packageWasmModule({
                name: pkgName,
                version: '1.0.0',
                author: currentUser.username,
                wasmContentOrBytes: wasmPayload,
                watSource,
                exports: exportsMeta,
              });

              if (!pkgRes.ok || !pkgRes.json || !pkgRes.manifest) {
                appendLines([{ kind: 'error', text: pkgRes.error || 'Paketleme hatası' }]);
                return 1;
              }

              const wRes = writeFile(
                destPath,
                pkgRes.json,
                'application/vnd.ankaos.wasm-pkg+json',
                elevatedRoot
              );
              if (!wRes.ok) {
                appendLines([{ kind: 'error', text: wRes.error || 'Paket yazılamadı' }]);
                return 1;
              }

              let binLine = '';
              if (installBin) {
                const wrapper = `#!/bin/ankash\n# ANKA_WASM_PKG:${destPath}\nwasmrun ${destPath}\n`;
                const bRes = writeFile(`/bin/${pkgName}`, wrapper, 'text/x-shellscript', true);
                if (bRes.ok) {
                  chmodNode(`/bin/${pkgName}`, '+x', true);
                  binLine = `\n  Komut kuruldu: /bin/${pkgName} (doğrudan '${pkgName} [args]' yazın)`;
                }
              }

              appendLines([
                {
                  kind: 'success',
                  text: `[wasmpkg OK] ${pkgRes.manifest.name} -> ${destPath} (${pkgRes.manifest.byteLength} B · SHA256: ${pkgRes.manifest.sha256.slice(0, 12)}…)${binLine}`,
                },
              ]);
              await waitTick();
              return 0;
            },
          };
        }

        return {
          out: '',
          err: 'Kullanım: wasmpkg pack <dosya.wat|.wasm> [-o cikti.ankawasm] [--name ad] [--install] | wasmpkg info <dosya.ankawasm>',
        };
      }

      case 'wasm-builder': {
        const target = args[0] ? normalizePath(args[0], currentCwd, userHome) : undefined;
        launchApp('wasm-builder', target ? { path: target } : undefined);
        return { out: target ? `WASM Studio açıldı: ${target}` : 'WASM Studio açıldı.' };
      }

      case 'wasmprof': {
        const rawTarget = args[0];
        if (!rawTarget) {
          const lastTrace = getNodeAtPath(liveVfs, '/tmp/last_wasmrun.wasmprof.json');
          if (lastTrace && lastTrace.type === 'file') {
            launchApp('wasm-builder', { path: '/tmp/last_wasmrun.wasmprof.json', tab: 'profiler' });
            return { out: 'Son wasmrun profili Flamegraph arayüzünde açıldı: /tmp/last_wasmrun.wasmprof.json' };
          }
          launchApp('wasm-builder', { tab: 'profiler' });
          return { out: 'WASM Studio Flamegraph Profiler açıldı.' };
        }
        const target = normalizePath(rawTarget, currentCwd, userHome);
        const node = getNodeAtPath(liveVfs, target);
        if (!node || node.type !== 'file') {
          return { out: '', err: `wasmprof: ${rawTarget} bulunamadı` };
        }
        if (/\.wasmprof\.json$/i.test(node.name)) {
          launchApp('wasm-builder', { path: target, tab: 'profiler' });
          return { out: `Flamegraph izi açıldı: ${target}` };
        }
        const fnName = args[1] && !args[1].startsWith('--') ? args[1] : undefined;
        const numArgs = args
          .slice(fnName ? 2 : 1)
          .filter((a) => !a.startsWith('--'))
          .map(Number)
          .filter((n) => !Number.isNaN(n));
        let content = node.content || '';
        return {
          out: '',
          asyncOp: async () => {
            if (/\.(wat|wast)$/i.test(node.name)) {
              const compiled = compileWatToWasm(content);
              if (!compiled.ok || !compiled.base64Content) {
                appendLines([{ kind: 'error', text: `WAT derleme hatası: ${compiled.error}` }]);
                return 1;
              }
              content = compiled.base64Content;
            }
            const profRes = await profileWasmExecution({
              content,
              moduleName: node.name,
              sourcePath: target,
              fnName,
              args: numArgs,
              iterations: 300,
            });
            if (!profRes.ok) {
              appendLines([{ kind: 'error', text: profRes.error }]);
              return 1;
            }
            const traceJson = JSON.stringify(profRes.report, null, 2);
            const tracePath = target.replace(/\.(wat|wast|wasm|ankawasm)$/i, '') + '.wasmprof.json';
            writeFile('/tmp/last_wasmrun.wasmprof.json', traceJson, 'application/json', false);
            writeFile(tracePath, traceJson, 'application/json', false);
            appendLines([
              { kind: 'info', text: renderAsciiFlameSummary(profRes.report) },
              { kind: 'success', text: `Görsel Flamegraph açılıyor -> ${tracePath}` },
            ]);
            launchApp('wasm-builder', { path: tracePath, tab: 'profiler' });
            return 0;
          },
        };
      }

      case 'wasmrun': {
        if (!args[0]) {
          return {
            out: '',
            err: 'Kullanım: wasmrun <dosya.wasm|.ankawasm|.wat> [fonksiyon] [arg1...] [--profile|-p] [--open] [--iters=300] [--save=yol.wasmprof.json]',
          };
        }
        const positional: string[] = [];
        let withProfile = false;
        let openGui = false;
        let iterations = 300;
        let customSavePath: string | null = null;
        for (const a of args) {
          if (a === '--profile' || a === '-p') {
            withProfile = true;
          } else if (a === '--open') {
            openGui = true;
            withProfile = true;
          } else if (a.startsWith('--iters=')) {
            const parsed = Number(a.slice(8));
            if (Number.isFinite(parsed) && parsed > 0) iterations = parsed;
            withProfile = true;
          } else if (a.startsWith('--save=')) {
            customSavePath = a.slice(7).trim();
            withProfile = true;
          } else {
            positional.push(a);
          }
        }
        if (!positional[0]) {
          return { out: '', err: 'wasmrun: hedef WASM dosyası belirtilmedi' };
        }
        const target = normalizePath(positional[0], currentCwd, userHome);
        const node = getNodeAtPath(liveVfs, target);
        if (!node || node.type !== 'file') return { out: '', err: `wasmrun: ${positional[0]} bulunamadı` };
        const fnName = positional[1];
        const numArgs = positional.slice(2).map(Number).filter((n) => !Number.isNaN(n));
        let content = node.content || '';
        return {
          out: '',
          asyncOp: async () => {
            if (/\.(wat|wast)$/i.test(node.name)) {
              const compiled = compileWatToWasm(content);
              if (!compiled.ok || !compiled.base64Content) {
                appendLines([{ kind: 'error', text: `WAT derleme hatası: ${compiled.error}` }]);
                return 1;
              }
              content = compiled.base64Content;
            }
            const res = await runWasmOrPackageFromVfsContent(content, fnName, numArgs);
            if (!res.ok) {
              appendLines([{ kind: 'error', text: res.error || 'WASM çalıştırma hatası' }]);
              return 1;
            }
            const rows = [
              `[WASM Ring 3 · ${res.byteLength} B · ${res.durationMs} ms] Dışa aktarılanlar: ${res.exportsList.join(', ') || '(yok)'}`,
            ];
            if (res.stdoutText) {
              rows.push(res.stdoutText.trimEnd());
            }
            if (res.invoked) {
              rows.push(
                `${res.invoked.fn}(${res.invoked.args.join(', ')}) => ${String(res.invoked.result)}`
              );
            }
            appendLines([{ kind: 'success', text: rows.join('\n') }]);

            // Profile execution and persist trace for visual Flamegraph inspection
            const profRes = await profileWasmExecution({
              content,
              moduleName: node.name,
              sourcePath: target,
              fnName: res.invoked?.fn || fnName,
              args: numArgs,
              iterations: withProfile ? iterations : 120,
            });
            if (profRes.ok) {
              const traceJson = JSON.stringify(profRes.report, null, 2);
              writeFile('/tmp/last_wasmrun.wasmprof.json', traceJson, 'application/json', false);
              if (withProfile) {
                const saveDest = customSavePath
                  ? normalizePath(customSavePath, currentCwd, userHome)
                  : `${target.replace(/\.(wat|wast|wasm|ankawasm)$/i, '')}.wasmprof.json`;
                writeFile(saveDest, traceJson, 'application/json', false);
                appendLines([
                  { kind: 'info', text: renderAsciiFlameSummary(profRes.report) },
                  {
                    kind: 'info',
                    text: `İz kaydedildi: ${saveDest} (Görsel analiz için: 'wasmprof ${saveDest}')`,
                  },
                ]);
                if (openGui) {
                  launchApp('wasm-builder', { path: saveDest, tab: 'profiler' });
                }
              }
            }
            return 0;
          },
        };
      }

      case 'run': {
        if (!args[0]) return { out: '', err: 'Kullanım: run <betik.js | modul.wasm | modul.ankawasm | kaynak.wat>' };
        const target = normalizePath(args[0], currentCwd, userHome);
        const node = getNodeAtPath(liveVfs, target);
        if (!node || node.type !== 'file') return { out: '', err: `run: ${args[0]} bulunamadı` };
        const content = node.content || '';
        const lowerName = node.name.toLowerCase();

        if (
          lowerName.endsWith('.wasm') ||
          lowerName.endsWith('.ankawasm') ||
          lowerName.endsWith('.wat') ||
          content.startsWith(WASM_B64_PREFIX)
        ) {
          const fnName = args[1];
          const numArgs = args.slice(2).map(Number).filter((n) => !Number.isNaN(n));
          return {
            out: '',
            asyncOp: async () => {
              let payload = content;
              if (lowerName.endsWith('.wat')) {
                const compiled = compileWatToWasm(content);
                if (!compiled.ok || !compiled.base64Content) {
                  appendLines([{ kind: 'error', text: `WAT derleme hatası: ${compiled.error}` }]);
                  return 1;
                }
                payload = compiled.base64Content;
              }
              const res = await runWasmOrPackageFromVfsContent(payload, fnName, numArgs);
              if (!res.ok) {
                appendLines([{ kind: 'error', text: res.error || 'WASM hatası' }]);
                return 1;
              }
              const rows = [
                `[WASM Ring 3 · ${res.byteLength} B · ${res.durationMs} ms] Dışa aktarılanlar: ${res.exportsList.join(', ')}`,
              ];
              if (res.stdoutText) {
                rows.push(res.stdoutText.trimEnd());
              }
              if (res.invoked) {
                rows.push(
                  `${res.invoked.fn}(${res.invoked.args.join(', ')}) => ${String(res.invoked.result)}`
                );
              }
              appendLines([{ kind: 'success', text: rows.join('\n') }]);
              return 0;
            },
          };
        }

        return {
          out: '',
          asyncOp: async () => {
            setRunningSandbox(true);
            const streamed: string[] = [];
            const { promise, abort } = executeSandboxedJS(content, {
              timeoutMs: 2000,
              onLog: (line) => streamed.push(line),
            });
            abortWorkerRef.current = abort;
            const res = await promise;
            abortWorkerRef.current = null;
            setRunningSandbox(false);

            if (streamed.length > 0) {
              appendLines([{ kind: 'output', text: streamed.join('\n') }]);
            } else if (res.logs.length > 0) {
              appendLines([{ kind: 'output', text: res.logs.join('\n') }]);
            }

            if (res.ok) {
              appendLines([
                {
                  kind: 'info',
                  text: `[Ring 3 ${res.runtime} · ${res.durationMs} ms · Çıkış: 0]`,
                },
              ]);
              return 0;
            }
            appendLines([
              {
                kind: 'error',
                text: `${res.error || 'Çalıştırma hatası'} [${res.durationMs} ms]`,
              },
            ]);
            return 1;
          },
        };
      }

      case 'screenshot': {
        return {
          out: '',
          asyncOp: async () => {
            const res = await captureDesktopScreenshot();
            if (!res.ok) {
              appendLines([{ kind: 'error', text: res.error || 'Ekran görüntüsü alınamadı' }]);
              return 1;
            }
            appendLines([{ kind: 'success', text: `Ekran görüntüsü kaydedildi: ${res.path}` }]);
            return 0;
          },
        };
      }

      case 'snapshot': {
        const sub = (args[0] || 'export').toLowerCase();
        if (sub === 'export') {
          const outPath = normalizePath(args[1] || '~/ankaos-snapshot.json', currentCwd, userHome);
          const json = exportSystemSnapshot();
          const wRes = writeFile(outPath, json, 'application/json', elevatedRoot);
          if (!wRes.ok) return { out: '', err: wRes.error };
          return {
            out: `Sistem snapshot yedeği kaydedildi: ${outPath} (${formatBytes(json.length)})`,
            mutatedVfs: true,
          };
        }
        if (sub === 'import') {
          if (!args[1]) return { out: '', err: 'Kullanım: snapshot import <dosya.json>' };
          const srcPath = normalizePath(args[1], currentCwd, userHome);
          const node = getNodeAtPath(liveVfs, srcPath);
          if (!node || node.type !== 'file') {
            return { out: '', err: `snapshot: ${args[1]} bulunamadı` };
          }
          const impRes = importSystemSnapshot(node.content || '');
          if (!impRes.ok) return { out: '', err: impRes.error };
          return {
            out: `Snapshot başarıyla geri yüklendi: ${srcPath}`,
            mutatedVfs: true,
          };
        }
        if (sub === 'sync') {
          const action = (args[1] || '').toLowerCase();
          const key = args[2] || 'anka-varsayilan';
          if (action === 'push') {
            return {
              out: '',
              asyncOp: async () => {
                const json = exportSystemSnapshot();
                const res = await uploadSnapshotSync(key, json);
                if (!res.ok) {
                  appendLines([{ kind: 'error', text: res.error || 'Eşitleme yükleme hatası' }]);
                  return 1;
                }
                appendLines([
                  {
                    kind: 'success',
                    text: `Bulut snapshot yüklendi -> anahtar='${res.syncKey}' (${formatBytes(res.bytes || json.length)})`,
                  },
                ]);
                return 0;
              },
            };
          }
          if (action === 'pull') {
            if (!args[2]) return { out: '', err: 'Kullanım: snapshot sync pull <anahtar>' };
            return {
              out: '',
              asyncOp: async () => {
                const res = await downloadSnapshotSync(key);
                if (!res.ok || !res.snapshotJson) {
                  appendLines([{ kind: 'error', text: res.error || 'Sunucuda yedek bulunamadı' }]);
                  return 1;
                }
                const impRes = importSystemSnapshot(res.snapshotJson);
                if (!impRes.ok) {
                  appendLines([{ kind: 'error', text: impRes.error || 'Snapshot geçersiz' }]);
                  return 1;
                }
                appendLines([
                  {
                    kind: 'success',
                    text: `Bulut snapshot indirildi ve uygulandı <- anahtar='${res.syncKey}' (${formatBytes(res.bytes || 0)})`,
                  },
                ]);
                return 0;
              },
            };
          }
        }
        return {
          out: '',
          err: 'Kullanım: snapshot [export [dosya.json] | import <dosya.json> | sync push [anahtar] | sync pull <anahtar>]',
        };
      }

      case 'ankactl': {
        const sub = (args[0] || 'status').toLowerCase();
        if (sub === 'status') {
          return {
            out: services
              .map(
                (s) =>
                  `${s.name.padEnd(12)} ${s.status.padEnd(10)} PID=${String(s.pid ?? '-').padEnd(4)} ${s.descriptionTr}`
              )
              .join('\n'),
          };
        }
        if ((sub === 'start' || sub === 'stop' || sub === 'restart') && args[1]) {
          const res = controlService(args[1], sub);
          return res.ok ? { out: res.message } : { out: '', err: res.message };
        }
        return { out: '', err: 'Kullanım: ankactl [status | start <servis> | stop <servis> | restart <servis>]' };
      }

      case 'crontab': {
        const flag = args[0] || '-l';
        if (flag === '-l') {
          if (cronJobs.length === 0) return { out: 'Tanımlı cron görevi yok.' };
          return {
            out: cronJobs
              .map(
                (j) =>
                  `${j.id}  [${j.enabled ? 'AKTİF' : 'PASİF'}]  her ${String(j.intervalSec).padEnd(4)}sn  (çalışma:${j.runCount})  ${j.command}`
              )
              .join('\n'),
          };
        }
        if (flag === '-a' && args[1] && args[2]) {
          const sec = Number(args[1]);
          const command = args.slice(2).join(' ');
          const job = addCronJob(command, Number.isNaN(sec) ? 60 : sec, command);
          return { out: `Cron görevi eklendi: ${job.id} (${job.intervalSec}sn -> ${job.command})` };
        }
        if (flag === '-r' && args[1]) {
          const ok = removeCronJob(args[1]);
          return ok
            ? { out: `Cron görevi silindi: ${args[1]}` }
            : { out: '', err: `Görev bulunamadı: ${args[1]}` };
        }
        return { out: '', err: 'Kullanım: crontab [-l | -a <saniye> <komut> | -r <id>]' };
      }

      case 'du': {
        const target = normalizePath(args[0] || currentCwd, currentCwd, userHome);
        const report = computeDiskUsage(liveVfs, target);
        if (!report) return { out: '', err: `du: '${target}' bulunamadı` };
        const rows = report.entries.map(
          (e) => `${formatBytes(e.bytes).padStart(9)}  ${e.path}${e.type === 'dir' ? '/' : ''}`
        );
        rows.push(`${formatBytes(report.totalBytes).padStart(9)}  ${report.targetPath} (TOPLAM: ${report.totalFiles} dosya)`);
        return { out: rows.join('\n') };
      }

      case 'fsck': {
        const repair = args.includes('-f') || !args.includes('--dry');
        const rep = runDiskCheck(repair);
        return {
          out: [
            `AnkaVFS Bütünlük Denetimi (${repair ? 'Onarım Etkin' : 'Salt Okunur'})`,
            `  İncelenen düğüm : ${rep.checkedNodes}`,
            `  Bulunan sorun   : ${rep.issuesFound}`,
            `  Onarılan öğe    : ${rep.repairedCount}`,
            ...(rep.details.length ? rep.details.map((d) => `  - ${d}`) : ['  Durum: Temiz (hata yok).']),
          ].join('\n'),
          mutatedVfs: rep.repairedCount > 0,
        };
      }

      case 'tar': {
        const flag = args[0] || '';
        if (flag === '-czf' && args[1] && args[2]) {
          const outArch = normalizePath(args[1], currentCwd, userHome);
          const target = normalizePath(args[2], currentCwd, userHome);
          const res = createArchiveFromVfs(target, outArch);
          return res.ok ? { out: res.message, mutatedVfs: true } : { out: '', err: res.message };
        }
        if (flag === '-xzf' && args[1]) {
          const archPath = normalizePath(args[1], currentCwd, userHome);
          const cIdx = args.indexOf('-C');
          const destDir = normalizePath(
            cIdx !== -1 && args[cIdx + 1] ? args[cIdx + 1] : currentCwd,
            currentCwd,
            userHome
          );
          const res = extractArchiveToVfs(archPath, destDir);
          return res.ok ? { out: res.message, mutatedVfs: true } : { out: '', err: res.message };
        }
        return {
          out: '',
          err: 'Kullanım: tar -czf <arsiv.ankatar> <hedef> | tar -xzf <arsiv.ankatar> [-C <hedef_dizin>]',
        };
      }

      case 'power': {
        const mode = (args[0] || '').toLowerCase() as PowerProfile;
        if (!mode) {
          const meta = POWER_PROFILE_META[powerProfile];
          return { out: `Aktif güç profili: ${powerProfile} (${meta.labelTr}, kuantum=${meta.quantumMs} ms)` };
        }
        if (!(mode in POWER_PROFILE_META)) {
          return { out: '', err: 'Kullanım: power [performance | balanced | powersaver]' };
        }
        setPowerProfile(mode);
        const meta = POWER_PROFILE_META[mode];
        return { out: `Güç profili ayarlandı: ${meta.labelTr} (kuantum=${meta.quantumMs} ms)` };
      }

      case 'calc': {
        const expr = args.join(' ');
        if (!expr) return { out: '', err: 'Kullanım: calc 2 + 2 * 5' };
        if (!/^[0-9+\-*/().%\s^]+$/.test(expr)) return { out: '', err: 'Geçersiz ifade' };
        try {
          return { out: String(Function(`"use strict"; return (${expr.replace(/\^/g, '**')})`)()) };
        } catch {
          return { out: '', err: 'Geçersiz matematiksel ifade' };
        }
      }

      case 'reboot':
        rebootSystem();
        return { out: 'Yeniden başlatılıyor...' };

      default: {
        const binNode = getNodeAtPath(liveVfs, `/bin/${cmd}`);
        if (binNode?.type === 'file' && binNode.content?.includes('# ANKA_WASM_PKG:')) {
          const pkgMatch = binNode.content.match(/# ANKA_WASM_PKG:([^\n]+)/);
          const pkgPath = pkgMatch?.[1]?.trim();
          const pkgNode = pkgPath ? getNodeAtPath(liveVfs, pkgPath) : null;
          if (pkgNode?.type === 'file' && pkgNode.content) {
            const firstArgIsFn = args[0] && Number.isNaN(Number(args[0]));
            const fnName = firstArgIsFn ? args[0] : undefined;
            const numArgs = (firstArgIsFn ? args.slice(1) : args)
              .map(Number)
              .filter((n) => !Number.isNaN(n));
            const pkgContent = pkgNode.content;
            return {
              out: '',
              asyncOp: async () => {
                const res = await runWasmOrPackageFromVfsContent(pkgContent, fnName, numArgs);
                if (!res.ok) {
                  appendLines([{ kind: 'error', text: res.error || 'WASM paket çalıştırma hatası' }]);
                  return 1;
                }
                const parts: string[] = [];
                if (res.stdoutText) parts.push(res.stdoutText.trimEnd());
                parts.push(
                  res.invoked
                    ? `[${cmd}] ${res.invoked.fn}(${res.invoked.args.join(', ')}) => ${String(res.invoked.result)}`
                    : `[${cmd}] OK (${res.durationMs} ms)`
                );
                appendLines([{ kind: 'success', text: parts.join('\n') }]);
                return 0;
              },
            };
          }
        }
        return {
          out: '',
          err: `ankash: '${cmd}' komutu bulunamadı. Komut listesi için 'help' yazın.`,
        };
      }
    }
  };

  const executeChain = async (raw: string) => {
    const trimmedRaw = raw.trim();
    if (/^(if|for)\b/.test(trimmedRaw)) {
      const parsed = evaluateIfForScript(trimmedRaw, vfsRef.current, envRef.current, {
        cwd: cwdRef.current,
        user: currentUser.username,
        homeDir: userHome,
        lastExit: lastExitRef.current,
      });
      if (!parsed.ok) {
        appendLines([{ kind: 'error', text: parsed.error || 'Sözdizimi hatası' }]);
        lastExitRef.current = 1;
        return;
      }
      envRef.current = parsed.env;
      setEnvVars(parsed.env);
      for (const subCmd of parsed.commands) {
        await executeChain(subCmd);
      }
      return;
    }

    const chain = splitCommandChain(raw);
    let lastExit = 0;
    let prevOp: '&&' | '||' | ';' | null = null;
    let workingCwd = cwdRef.current;

    for (const seg of chain) {
      if (prevOp === '&&' && lastExit !== 0) {
        prevOp = seg.opAfter;
        continue;
      }
      if (prevOp === '||' && lastExit === 0) {
        prevOp = seg.opAfter;
        continue;
      }

      const segRaw = seg.cmd;
      if (segRaw.endsWith(' &')) {
        const bgCmd = segRaw.slice(0, -2).trim();
        const job = spawnBackgroundJob(bgCmd, 5000);
        appendLines([
          {
            kind: 'info',
            text: `[${job.jobId}] PID ${job.pid} arka planda çalışıyor: ${bgCmd}`,
          },
        ]);
        lastExit = 0;
        lastExitRef.current = 0;
        prevOp = seg.opAfter;
        continue;
      }

      let commandPart = segRaw;
      let redirectMode: 'overwrite' | 'append' | null = null;
      let redirectTarget = '';

      const appendIdx = segRaw.indexOf('>>');
      const overwriteIdx = segRaw.indexOf('>');
      if (appendIdx !== -1) {
        commandPart = segRaw.slice(0, appendIdx).trim();
        redirectTarget = segRaw.slice(appendIdx + 2).trim();
        redirectMode = 'append';
      } else if (overwriteIdx !== -1) {
        commandPart = segRaw.slice(0, overwriteIdx).trim();
        redirectTarget = segRaw.slice(overwriteIdx + 1).trim();
        redirectMode = 'overwrite';
      }

      const pipeParts = splitPipes(commandPart);
      const mainRes = runSingleCommand(pipeParts[0], workingCwd);

      if (mainRes.clear) {
        setLines([]);
        lastExit = 0;
        lastExitRef.current = 0;
        prevOp = seg.opAfter;
        continue;
      }

      if (mainRes.nextCwd) {
        workingCwd = mainRes.nextCwd;
        cwdRef.current = workingCwd;
        setCwd(workingCwd);
      }

      if (mainRes.asyncOp) {
        lastExit = await mainRes.asyncOp();
        lastExitRef.current = lastExit;
        prevOp = seg.opAfter;
        continue;
      }

      if (mainRes.err) {
        appendLines([{ kind: 'error', text: mainRes.err }]);
        lastExit = 1;
        lastExitRef.current = 1;
        prevOp = seg.opAfter;
        continue;
      }

      let finalOut = mainRes.out;
      for (let i = 1; i < pipeParts.length; i++) {
        finalOut = applyPipeStage(finalOut, pipeParts[i], workingCwd);
      }

      if (redirectMode && redirectTarget) {
        const isSudoRedirect = pipeParts[0].trim().startsWith('sudo ');
        const targetPath = normalizePath(redirectTarget, workingCwd, userHome);
        const existing = getNodeAtPath(vfsRef.current, targetPath);
        const nextContent =
          redirectMode === 'append' && existing?.type === 'file'
            ? (existing.content || '') + (existing.content?.endsWith('\n') ? '' : '\n') + finalOut + '\n'
            : finalOut + '\n';
        const wRes = writeFile(targetPath, nextContent, undefined, isSudoRedirect);
        if (!wRes.ok && wRes.error) {
          appendLines([{ kind: 'error', text: wRes.error }]);
          lastExit = 1;
        } else {
          lastExit = 0;
          await waitTick();
        }
        lastExitRef.current = lastExit;
        prevOp = seg.opAfter;
        continue;
      }

      if (finalOut) appendLines([{ kind: 'output', text: finalOut }]);
      lastExit = 0;
      lastExitRef.current = 0;
      if (mainRes.mutatedVfs) {
        await waitTick();
      }
      prevOp = seg.opAfter;
    }
  };

  executeChainRef.current = executeChain;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const raw = input.trim();
    appendLines([{ kind: 'prompt', cwd: displayCwd, text: raw }]);
    setInput('');
    setHistoryIdx(-1);

    if (!raw) return;
    setCmdHistory((prev) => [raw, ...prev.slice(0, 49)]);
    void executeChain(raw);
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'ArrowUp') {
      e.preventDefault();
      if (cmdHistory.length === 0) return;
      const nextIdx = Math.min(historyIdx + 1, cmdHistory.length - 1);
      setHistoryIdx(nextIdx);
      setInput(cmdHistory[nextIdx]);
    } else if (e.key === 'ArrowDown') {
      e.preventDefault();
      if (historyIdx <= 0) {
        setHistoryIdx(-1);
        setInput('');
      } else {
        const nextIdx = historyIdx - 1;
        setHistoryIdx(nextIdx);
        setInput(cmdHistory[nextIdx]);
      }
    } else if (e.key === 'Tab') {
      e.preventDefault();
      const completed = resolveTabCompletion(input, cwd, userHome, vfs, KNOWN_COMMANDS, aliases);
      if (completed !== null) {
        setInput(completed);
      }
    }
  };

  return (
    <div
      className="h-full w-full bg-[var(--anka-terminal-bg)] text-[var(--anka-terminal-fg)] font-mono text-[13px] leading-relaxed flex flex-col cursor-text anka-theme-transition"
      onClick={() => inputRef.current?.focus()}
    >
      {runningSandbox && (
        <div className="px-3 py-1.5 bg-amber-500/15 border-b border-amber-500/30 flex items-center justify-between text-xs text-amber-500 shrink-0">
          <span>Ring 3 Web Worker çalışıyor (Watchdog: 2000 ms)...</span>
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              abortWorkerRef.current?.();
            }}
            className="flex items-center gap-1 px-2 py-0.5 rounded bg-rose-600 text-white hover:bg-rose-500 text-[11px]"
          >
            <Square size={10} />
            <span>Durdur (SIGKILL)</span>
          </button>
        </div>
      )}

      <div className="flex-1 overflow-y-auto os-scroll p-4 space-y-1.5 select-text">
        {lines.map((line) => {
          if (line.kind === 'prompt') {
            return (
              <div key={line.id} className="flex items-start gap-2">
                <span className="text-emerald-600 dark:text-emerald-400 shrink-0 font-medium">
                  {currentUser.username}@anka
                </span>
                <span className="text-[var(--anka-terminal-muted)] shrink-0">:</span>
                <span className="text-[var(--anka-accent)] shrink-0 font-medium">{line.cwd}</span>
                <span className="text-[var(--anka-terminal-muted)] shrink-0">$</span>
                <span className="text-[var(--anka-terminal-fg)] break-all">{line.text}</span>
              </div>
            );
          }
          if (line.kind === 'error') {
            return (
              <pre key={line.id} className="whitespace-pre-wrap text-rose-600 dark:text-rose-400 font-mono text-[13px]">
                {line.text}
              </pre>
            );
          }
          if (line.kind === 'success') {
            return (
              <pre key={line.id} className="whitespace-pre-wrap text-emerald-600 dark:text-emerald-400 font-mono text-[13px]">
                {line.text}
              </pre>
            );
          }
          if (line.kind === 'info') {
            return (
              <pre key={line.id} className="whitespace-pre-wrap text-[var(--anka-terminal-muted)] font-mono text-[12px]">
                {line.text}
              </pre>
            );
          }
          return (
            <pre key={line.id} className="whitespace-pre-wrap text-[var(--anka-terminal-fg)] font-mono text-[13px]">
              {line.text}
            </pre>
          );
        })}

        <form onSubmit={handleSubmit} className="flex items-center gap-2 pt-0.5">
          <span className="text-emerald-600 dark:text-emerald-400 shrink-0 font-medium">
            {currentUser.username}@anka
          </span>
          <span className="text-[var(--anka-terminal-muted)] shrink-0">:</span>
          <span className="text-[var(--anka-accent)] shrink-0 font-medium">{displayCwd}</span>
          <span className="text-[var(--anka-terminal-muted)] shrink-0">$</span>
          <input
            ref={inputRef}
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={handleKeyDown}
            autoFocus
            spellCheck={false}
            autoComplete="off"
            style={{ caretColor: 'var(--anka-accent)' }}
            className="flex-1 bg-transparent outline-none text-[var(--anka-terminal-fg)] font-mono text-[13px]"
          />
        </form>
        <div ref={endRef} />
      </div>
    </div>
  );
};
