import React, { useMemo, useState } from 'react';
import { ArrowLeftRight, GitCompare } from 'lucide-react';
import { useOS } from '../os/kernel';
import { computeLineDiff } from '../os/shellUtils';
import { getNodeAtPath, HOME_PATH, listDir } from '../os/vfs';

export const DiffViewerApp: React.FC<{
  windowId: string;
  launchArgs?: Record<string, string>;
}> = ({ launchArgs }) => {
  const { vfs, currentUser, settings } = useOS();
  const tr = settings.language === 'tr';
  const userHome = currentUser.homeDir || HOME_PATH;

  const allFiles = useMemo(() => {
    const out: string[] = [];
    const walk = (dir: string) => {
      for (const entry of listDir(vfs, dir)) {
        const full = dir === '/' ? `/${entry.name}` : `${dir}/${entry.name}`;
        if (entry.type === 'dir') {
          if (out.length < 150) walk(full);
        } else if (!entry.mimeType?.startsWith('image/')) {
          out.push(full);
        }
      }
    };
    walk(userHome);
    walk('/etc');
    return out;
  }, [vfs, userHome]);

  const [pathA, setPathA] = useState(
    launchArgs?.pathA || allFiles[0] || `${userHome}/Projeler/merhaba.js`
  );
  const [pathB, setPathB] = useState(
    launchArgs?.pathB || allFiles[1] || allFiles[0] || '/etc/os-release'
  );

  const textA = useMemo(() => getNodeAtPath(vfs, pathA)?.content || '', [vfs, pathA]);
  const textB = useMemo(() => getNodeAtPath(vfs, pathB)?.content || '', [vfs, pathB]);

  const diff = useMemo(
    () => computeLineDiff(textA, textB, pathA, pathB),
    [textA, textB, pathA, pathB]
  );

  const diffLines = useMemo(() => diff.diffText.split('\n'), [diff.diffText]);

  return (
    <div className="h-full w-full flex flex-col bg-[var(--anka-surface)] text-[var(--anka-text)] anka-theme-transition">
      <div className="px-4 py-3 border-b border-[var(--anka-border)] bg-[var(--anka-surface-muted)] space-y-2.5">
        <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
          <div className="flex items-center gap-2">
            <GitCompare size={16} className="text-[var(--anka-accent)]" />
            <span className="font-semibold font-display">
              {tr ? 'Kod & Dosya Karşılaştırıcı' : 'Code & File Diff Viewer'}
            </span>
          </div>
          <div className="font-mono text-[11px] text-[var(--anka-text-subtle)] tabular-nums">
            +{diff.added} {tr ? 'eklenen' : 'added'} · -{diff.removed} {tr ? 'silinen' : 'removed'}
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2 text-xs">
          <select
            value={pathA}
            onChange={(e) => setPathA(e.target.value)}
            className="flex-1 min-w-[180px] px-2.5 py-1.5 rounded-lg border border-[var(--anka-border-strong)] bg-[var(--anka-surface)] font-mono outline-none"
          >
            {allFiles.map((f) => (
              <option key={f} value={f}>
                {f}
              </option>
            ))}
          </select>

          <button
            onClick={() => {
              const tmp = pathA;
              setPathA(pathB);
              setPathB(tmp);
            }}
            title={tr ? 'Dosyaları Değiştir' : 'Swap Files'}
            className="p-1.5 rounded-lg border border-[var(--anka-border-strong)] hover:bg-[var(--anka-surface-elevated)]"
          >
            <ArrowLeftRight size={13} />
          </button>

          <select
            value={pathB}
            onChange={(e) => setPathB(e.target.value)}
            className="flex-1 min-w-[180px] px-2.5 py-1.5 rounded-lg border border-[var(--anka-border-strong)] bg-[var(--anka-surface)] font-mono outline-none"
          >
            {allFiles.map((f) => (
              <option key={f} value={f}>
                {f}
              </option>
            ))}
          </select>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto os-scroll p-3 bg-[var(--anka-terminal-bg)] text-[var(--anka-terminal-fg)] font-mono text-xs space-y-0.5 select-text">
        {diff.identical ? (
          <div className="py-12 text-center text-[var(--anka-terminal-muted)]">
            {tr ? 'Seçilen iki dosya içerik olarak birebir aynı.' : 'Both files are identical.'}
          </div>
        ) : (
          diffLines.map((line, idx) => {
            const isAdd = line.startsWith('+ ');
            const isDel = line.startsWith('- ');
            return (
              <div
                key={idx}
                className={`px-2 py-0.5 rounded whitespace-pre-wrap ${
                  isAdd
                    ? 'bg-emerald-500/15 text-emerald-400'
                    : isDel
                      ? 'bg-rose-500/15 text-rose-400'
                      : 'text-[var(--anka-terminal-fg)]/80'
                }`}
              >
                {line}
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
