import React, { useEffect, useMemo, useState } from 'react';
import { useOS } from '../os/kernel';
import { decodeWasmBytes, WASM_B64_PREFIX } from '../os/sandboxRuntime';
import { formatBytes, getNodeAtPath, HOME_PATH, normalizePath } from '../os/vfs';

interface HexViewerAppProps {
  windowId: string;
  launchArgs?: Record<string, string>;
}

export const HexViewerApp: React.FC<HexViewerAppProps> = ({ launchArgs }) => {
  const { vfs, settings, currentUser } = useOS();
  const tr = settings.language === 'tr';
  const userHome = currentUser.homeDir || HOME_PATH;

  const [pathInput, setPathInput] = useState(
    () => launchArgs?.path || '/etc/os-release'
  );

  useEffect(() => {
    if (launchArgs?.path) {
      setPathInput(launchArgs.path);
    }
  }, [launchArgs?.path]);

  const resolvedPath = useMemo(
    () => normalizePath(pathInput, userHome, userHome),
    [pathInput, userHome]
  );

  const node = useMemo(
    () => getNodeAtPath(vfs, resolvedPath),
    [vfs, resolvedPath]
  );

  const rows = useMemo(() => {
    if (!node || node.type !== 'file') return [];
    const content = node.content || '';
    const bytes =
      content.startsWith(WASM_B64_PREFIX) || node.mimeType === 'application/wasm'
        ? decodeWasmBytes(content).slice(0, 4096)
        : new TextEncoder().encode(content.slice(0, 4096));
    const out: { offset: string; hex: string[]; ascii: string }[] = [];
    for (let i = 0; i < bytes.length; i += 16) {
      const slice = Array.from(bytes.slice(i, i + 16));
      out.push({
        offset: i.toString(16).padStart(6, '0'),
        hex: slice.map((b) => b.toString(16).padStart(2, '0')),
        ascii: slice.map((b) => (b >= 32 && b <= 126 ? String.fromCharCode(b) : '.')).join(''),
      });
    }
    return out;
  }, [node]);

  return (
    <div className="h-full w-full flex flex-col bg-[var(--anka-terminal-bg)] text-[var(--anka-terminal-fg)] font-mono text-xs anka-theme-transition">
      <div className="px-3 py-2 border-b border-[var(--anka-border)] bg-[var(--anka-surface)] flex items-center gap-2">
        <span className="text-[var(--anka-text-subtle)]">{tr ? 'Dosya:' : 'File:'}</span>
        <input
          type="text"
          value={pathInput}
          onChange={(e) => setPathInput(e.target.value)}
          className="flex-1 px-2.5 py-1 rounded border border-[var(--anka-border)] bg-[var(--anka-terminal-bg)] text-[var(--anka-terminal-fg)] outline-none focus:border-[var(--anka-accent)]"
        />
        {node && node.type === 'file' && (
          <span className="text-[11px] text-[var(--anka-text-subtle)] tabular-nums shrink-0">
            {formatBytes(node.size)}
          </span>
        )}
      </div>

      <div className="px-3 py-1.5 border-b border-[var(--anka-border)] bg-[var(--anka-surface-muted)] text-[10px] text-[var(--anka-text-subtle)] flex items-center gap-4 tabular-nums">
        <span className="w-12">OFFSET</span>
        <span className="flex-1 tracking-wider">00 01 02 03 04 05 06 07 08 09 0A 0B 0C 0D 0E 0F</span>
        <span>ASCII</span>
      </div>

      <div className="flex-1 overflow-y-auto os-scroll p-3 space-y-1 select-text">
        {!node || node.type !== 'file' ? (
          <div className="text-rose-500 dark:text-rose-400">
            {tr ? 'Dosya bulunamadı' : 'File not found'}
          </div>
        ) : rows.length === 0 ? (
          <div className="text-[var(--anka-text-subtle)]">
            {tr ? 'Boş dosya (0 B)' : 'Empty file (0 B)'}
          </div>
        ) : (
          rows.map((r) => (
            <div key={r.offset} className="flex items-center gap-4 tabular-nums">
              <span className="text-[var(--anka-accent)] w-12 shrink-0">{r.offset}</span>
              <span className="text-[var(--anka-terminal-fg)] flex-1 tracking-wider">
                {r.hex.join(' ').padEnd(47, ' ')}
              </span>
              <span className="text-emerald-600 dark:text-emerald-400 w-16 shrink-0 text-right">
                {r.ascii}
              </span>
            </div>
          ))
        )}
      </div>
    </div>
  );
};
