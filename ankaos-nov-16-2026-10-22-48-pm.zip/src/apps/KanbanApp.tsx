import React, { useEffect, useMemo, useState } from 'react';
import { ChevronLeft, ChevronRight, Plus, Save, Search, Trash2 } from 'lucide-react';
import { useOS } from '../os/kernel';
import { getAppSandboxDir } from '../os/security';
import { getNodeAtPath } from '../os/vfs';

type ColumnId = 'todo' | 'doing' | 'done';
type Priority = 'low' | 'medium' | 'high';

interface TaskItem {
  id: string;
  title: string;
  priority: Priority;
  column: ColumnId;
  createdAt: number;
}

const DEFAULT_TASKS: TaskItem[] = [
  {
    id: 't-1',
    title: 'AnkaKernel MMU Swap havuzunu doğrula',
    priority: 'high',
    column: 'done',
    createdAt: Date.now() - 86400000,
  },
  {
    id: 't-2',
    title: 'Paket Merkezi yeni uygulamaları test et',
    priority: 'medium',
    column: 'doing',
    createdAt: Date.now() - 3600000,
  },
  {
    id: 't-3',
    title: 'ankash betik izinlerini belgele',
    priority: 'low',
    column: 'todo',
    createdAt: Date.now(),
  },
];

export const KanbanApp: React.FC<{ windowId: string }> = () => {
  const { vfs, writeFile, currentUser, settings } = useOS();
  const tr = settings.language === 'tr';
  const boardPath = `${getAppSandboxDir(currentUser.username, 'pkg-kanban')}/board.json`;

  const loadBoardTasks = (): TaskItem[] => {
    const node = getNodeAtPath(vfs, boardPath);
    if (node?.type === 'file' && node.content) {
      try {
        const parsed = JSON.parse(node.content) as TaskItem[];
        if (Array.isArray(parsed)) return parsed;
      } catch {
        // fallback to defaults
      }
    }
    return DEFAULT_TASKS;
  };

  const [tasks, setTasks] = useState<TaskItem[]>(loadBoardTasks);

  useEffect(() => {
    setTasks(loadBoardTasks());
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [boardPath]);

  const [newTitle, setNewTitle] = useState('');
  const [newPriority, setNewPriority] = useState<Priority>('medium');
  const [search, setSearch] = useState('');
  const [savedNotice, setSavedNotice] = useState<string | null>(null);

  const persistBoard = (nextTasks: TaskItem[]) => {
    setTasks(nextTasks);
    const res = writeFile(boardPath, JSON.stringify(nextTasks, null, 2), 'application/json', false, 'pkg-kanban');
    if (res.ok) {
      setSavedNotice(tr ? 'Sandbox VFS güncellendi' : 'Synced to Sandbox VFS');
      setTimeout(() => setSavedNotice(null), 1600);
    }
  };

  const handleAddTask = (e: React.FormEvent) => {
    e.preventDefault();
    const clean = newTitle.trim();
    if (!clean) return;
    const item: TaskItem = {
      id: `task-${Date.now()}-${Math.random().toString(36).slice(2, 5)}`,
      title: clean,
      priority: newPriority,
      column: 'todo',
      createdAt: Date.now(),
    };
    persistBoard([item, ...tasks]);
    setNewTitle('');
  };

  const moveTask = (id: string, dir: -1 | 1) => {
    const order: ColumnId[] = ['todo', 'doing', 'done'];
    const next = tasks.map((task) => {
      if (task.id !== id) return task;
      const idx = order.indexOf(task.column);
      const nextCol = order[Math.max(0, Math.min(2, idx + dir))];
      return { ...task, column: nextCol };
    });
    persistBoard(next);
  };

  const deleteTask = (id: string) => {
    persistBoard(tasks.filter((t) => t.id !== id));
  };

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    if (!q) return tasks;
    return tasks.filter((t) => t.title.toLowerCase().includes(q));
  }, [tasks, search]);

  const columns: { id: ColumnId; titleTr: string; titleEn: string }[] = [
    { id: 'todo', titleTr: 'Yapılacaklar', titleEn: 'To Do' },
    { id: 'doing', titleTr: 'Sürüyor', titleEn: 'In Progress' },
    { id: 'done', titleTr: 'Tamamlandı', titleEn: 'Done' },
  ];

  const priorityLabel = (p: Priority) => {
    if (p === 'high') return tr ? 'Yüksek' : 'High';
    if (p === 'medium') return tr ? 'Orta' : 'Medium';
    return tr ? 'Düşük' : 'Low';
  };

  const priorityColor = (p: Priority) => {
    if (p === 'high') return 'text-rose-600 dark:text-rose-400';
    if (p === 'medium') return 'text-amber-600 dark:text-amber-400';
    return 'text-slate-500 dark:text-slate-400';
  };

  return (
    <div className="h-full w-full flex flex-col bg-[var(--anka-bg)] text-[var(--anka-text)] anka-theme-transition">
      {/* Toolbar */}
      <div className="px-4 py-3 border-b border-[var(--anka-border)] bg-[var(--anka-surface)] flex flex-wrap items-center justify-between gap-3">
        <form onSubmit={handleAddTask} className="flex items-center gap-2 flex-1 min-w-[260px]">
          <input
            type="text"
            value={newTitle}
            onChange={(e) => setNewTitle(e.target.value)}
            placeholder={tr ? 'Yeni görev başlığı...' : 'New task title...'}
            className="flex-1 px-3 py-1.5 rounded-lg text-xs border border-[var(--anka-border-strong)] bg-[var(--anka-surface-muted)] text-[var(--anka-text)] outline-none focus:border-[var(--anka-accent)]"
          />
          <select
            value={newPriority}
            onChange={(e) => setNewPriority(e.target.value as Priority)}
            className="px-2.5 py-1.5 rounded-lg text-xs border border-[var(--anka-border-strong)] bg-[var(--anka-surface-muted)] text-[var(--anka-text)] outline-none focus:border-[var(--anka-accent)]"
          >
            <option value="low">{tr ? 'Düşük' : 'Low'}</option>
            <option value="medium">{tr ? 'Orta' : 'Medium'}</option>
            <option value="high">{tr ? 'Yüksek' : 'High'}</option>
          </select>
          <button
            type="submit"
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium bg-[var(--anka-accent)] text-[var(--anka-accent-fg)] hover:bg-[var(--anka-accent-hover)] whitespace-nowrap transition-colors"
          >
            <Plus size={14} />
            <span>{tr ? 'Görev Ekle' : 'Add Task'}</span>
          </button>
        </form>

        <div className="flex items-center gap-3">
          <div className="relative">
            <Search size={13} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-[var(--anka-text-subtle)]" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder={tr ? 'Görev ara...' : 'Filter...'}
              className="w-36 pl-7 pr-2 py-1.5 rounded-lg text-xs border border-[var(--anka-border-strong)] bg-[var(--anka-surface-muted)] text-[var(--anka-text)] outline-none focus:border-[var(--anka-accent)]"
            />
          </div>
          <button
            onClick={() => persistBoard(tasks)}
            title={boardPath}
            className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs border border-[var(--anka-border-strong)] hover:bg-[var(--anka-surface-elevated)] whitespace-nowrap transition-colors"
          >
            <Save size={13} />
            <span>{tr ? 'Kaydet' : 'Save'}</span>
          </button>
        </div>
      </div>

      {savedNotice && (
        <div className="px-4 py-1 text-[11px] font-mono bg-emerald-500/15 text-emerald-700 dark:text-emerald-300 border-b border-[var(--anka-border)]">
          {savedNotice} · {boardPath}
        </div>
      )}

      {/* 3-Column Kanban Grid */}
      <div className="flex-1 overflow-auto os-scroll p-4 grid grid-cols-1 md:grid-cols-3 gap-4">
        {columns.map((col) => {
          const colTasks = filtered.filter((t) => t.column === col.id);
          return (
            <div
              key={col.id}
              className="flex flex-col rounded-xl border border-[var(--anka-border)] bg-[var(--anka-surface)] overflow-hidden"
            >
              <div className="px-3.5 py-2.5 border-b border-[var(--anka-border)] flex items-center justify-between">
                <span className="text-xs font-semibold">
                  {tr ? col.titleTr : col.titleEn}
                </span>
                <span className="text-xs font-mono tabular-nums text-[var(--anka-text-subtle)]">
                  {colTasks.length}
                </span>
              </div>

              <div className="flex-1 p-3 space-y-2.5 overflow-y-auto os-scroll">
                {colTasks.length === 0 ? (
                  <div className="text-center py-8 text-xs text-[var(--anka-text-subtle)]">
                    {tr ? 'Bu sütunda görev yok' : 'No tasks in this column'}
                  </div>
                ) : (
                  colTasks.map((task) => (
                    <div
                      key={task.id}
                      className="p-3 rounded-lg border border-[var(--anka-border)] bg-[var(--anka-surface-muted)] space-y-2"
                    >
                      <div className="text-xs font-medium leading-snug text-[var(--anka-text)]">
                        {task.title}
                      </div>
                      <div className="flex items-center justify-between text-[11px]">
                        <span className={`font-medium ${priorityColor(task.priority)}`}>
                          {priorityLabel(task.priority)}
                        </span>
                        <div className="flex items-center gap-1">
                          {col.id !== 'todo' && (
                            <button
                              onClick={() => moveTask(task.id, -1)}
                              title={tr ? 'Sola Taşı' : 'Move Left'}
                              className="p-1 rounded hover:bg-[var(--anka-surface-elevated)] text-[var(--anka-text-subtle)]"
                            >
                              <ChevronLeft size={13} />
                            </button>
                          )}
                          {col.id !== 'done' && (
                            <button
                              onClick={() => moveTask(task.id, 1)}
                              title={tr ? 'Sağa Taşı' : 'Move Right'}
                              className="p-1 rounded hover:bg-[var(--anka-surface-elevated)] text-[var(--anka-text-subtle)]"
                            >
                              <ChevronRight size={13} />
                            </button>
                          )}
                          <button
                            onClick={() => deleteTask(task.id)}
                            title={tr ? 'Sil' : 'Delete'}
                            className="p-1 rounded hover:bg-rose-500/15 text-[var(--anka-text-subtle)] hover:text-rose-500"
                          >
                            <Trash2 size={13} />
                          </button>
                        </div>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
