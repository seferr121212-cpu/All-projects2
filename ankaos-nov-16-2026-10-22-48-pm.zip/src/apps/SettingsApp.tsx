import React, { useEffect, useRef, useState } from 'react';
import {
  BellOff,
  Check,
  Cloud,
  Database,
  Download,
  Globe,
  HardDriveDownload,
  Lock,
  Monitor,
  Moon,
  Palette,
  RotateCcw,
  Shield,
  Sun,
  Upload,
  UserPlus,
  Volume2,
} from 'lucide-react';
import { APP_MANIFESTS } from '../os/apps';
import { idbEstimateStorage } from '../os/idbStorage';
import { WALLPAPERS } from '../os/i18n';
import { useOS } from '../os/kernel';
import { downloadSnapshotSync, uploadSnapshotSync } from '../os/net';
import { ACCENT_PALETTES } from '../os/theme';
import { AccentColor, AppId } from '../os/types';
import { formatBytes } from '../os/vfs';
import { AnkaLogo } from '../components/AnkaLogo';

export const SettingsApp: React.FC<{ windowId: string }> = () => {
  const {
    settings,
    updateSettings,
    resetVFS,
    exportSystemSnapshot,
    importSystemSnapshot,
    uptimeSec,
    processes,
    users,
    currentUser,
    setUserPassword,
    createUser,
    grantSandboxPermission,
    revokeSandboxPermission,
  } = useOS();
  const tr = settings.language === 'tr';
  const [confirmReset, setConfirmReset] = useState(false);
  const [newPass, setNewPass] = useState('');
  const [passNotice, setPassNotice] = useState<string | null>(null);
  const [newUsername, setNewUsername] = useState('');
  const [newUserFull, setNewUserFull] = useState('');
  const [userNotice, setUserNotice] = useState<string | null>(null);
  const [snapshotStatus, setSnapshotStatus] = useState<{ ok: boolean; msg: string } | null>(null);
  const [syncKey, setSyncKey] = useState('anka-varsayilan');
  const [syncBusy, setSyncBusy] = useState(false);
  const [idbStats, setIdbStats] = useState<{
    supported: boolean;
    usedBytes: number;
    quotaBytes: number;
  } | null>(null);
  const snapshotInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    void idbEstimateStorage().then(setIdbStats);
  }, []);

  const accentList = Object.values(ACCENT_PALETTES);

  const handleSavePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    await setUserPassword(currentUser.username, newPass.trim() || null);
    setNewPass('');
    setPassNotice(
      newPass.trim()
        ? tr
          ? 'Oturum parolası SHA-256 ile güncellendi.'
          : 'Login password updated (SHA-256).'
        : tr
          ? 'Parola kaldırıldı (doğrudan giriş aktif).'
          : 'Password cleared (instant login enabled).'
    );
    setTimeout(() => setPassNotice(null), 2500);
  };

  const handleCreateUser = async (e: React.FormEvent) => {
    e.preventDefault();
    const res = await createUser(newUsername, newUserFull || newUsername);
    if (!res.ok) {
      setUserNotice(res.error || 'Hata');
    } else {
      setUserNotice(
        tr
          ? `Kullanıcı '${newUsername.trim().toLowerCase()}' oluşturuldu.`
          : `User '${newUsername.trim().toLowerCase()}' created.`
      );
      setNewUsername('');
      setNewUserFull('');
    }
    setTimeout(() => setUserNotice(null), 2500);
  };

  const handleExportSnapshot = () => {
    const json = exportSystemSnapshot();
    const blob = new Blob([json], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `ankaos-snapshot-${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
    setSnapshotStatus({
      ok: true,
      msg: tr
        ? `Snapshot indirildi (${Math.round(json.length / 1024)} KB).`
        : `Snapshot exported (${Math.round(json.length / 1024)} KB).`,
    });
  };

  const handleImportSnapshotFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const text = await file.text();
      const res = importSystemSnapshot(text);
      if (res.ok) {
        setSnapshotStatus({
          ok: true,
          msg: tr ? 'Sistem yedeği başarıyla geri yüklendi!' : 'System snapshot restored!',
        });
      } else {
        setSnapshotStatus({ ok: false, msg: res.error || 'Geçersiz yedek dosyası' });
      }
    } catch {
      setSnapshotStatus({ ok: false, msg: tr ? 'Dosya okunamadı.' : 'Failed to read file.' });
    }
    e.target.value = '';
  };

  const handleCloudPush = async () => {
    if (!syncKey.trim() || syncBusy) return;
    setSyncBusy(true);
    const json = exportSystemSnapshot();
    const res = await uploadSnapshotSync(syncKey.trim(), json);
    setSyncBusy(false);
    if (res.ok) {
      setSnapshotStatus({
        ok: true,
        msg: tr
          ? `Bulut eşitleme tamamlandı: '${res.syncKey}' (${Math.round((res.bytes || json.length) / 1024)} KB).`
          : `Cloud snapshot pushed to '${res.syncKey}' (${Math.round((res.bytes || json.length) / 1024)} KB).`,
      });
    } else {
      setSnapshotStatus({ ok: false, msg: res.error || 'Sunucuya yüklenemedi.' });
    }
  };

  const handleCloudPull = async () => {
    if (!syncKey.trim() || syncBusy) return;
    setSyncBusy(true);
    const res = await downloadSnapshotSync(syncKey.trim());
    setSyncBusy(false);
    if (!res.ok || !res.snapshotJson) {
      setSnapshotStatus({ ok: false, msg: res.error || 'Sunucuda yedek bulunamadı.' });
      return;
    }
    const imp = importSystemSnapshot(res.snapshotJson);
    if (imp.ok) {
      setSnapshotStatus({
        ok: true,
        msg: tr
          ? `Bulut yedeği '${res.syncKey}' başarıyla geri yüklendi!`
          : `Cloud snapshot '${res.syncKey}' restored!`,
      });
    } else {
      setSnapshotStatus({ ok: false, msg: imp.error || 'Yedek uygulanamadı.' });
    }
  };

  return (
    <div className="h-full w-full overflow-y-auto os-scroll bg-[var(--anka-surface)] text-[var(--anka-text)] p-6 space-y-8 anka-theme-transition">
      {/* Appearance */}
      <section className="space-y-5">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div>
            <h2 className="text-base font-semibold font-display">
              {tr ? 'Görünüm, Tema ve CSS Token Sistemi' : 'Appearance, Theme & CSS Tokens'}
            </h2>
            <p className="text-xs text-[var(--anka-text-subtle)] mt-0.5">
              {tr
                ? 'Tüm tercihler localStorage üzerinde kalıcıdır ve CSS değişkenleri üzerinden tüm uygulamalara anında yayılır.'
                : 'Preferences persist in localStorage and propagate live across all apps via CSS variables.'}
            </p>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-3 max-w-md">
          <button
            onClick={() => updateSettings({ theme: 'light' })}
            style={
              settings.theme === 'light'
                ? { borderColor: 'var(--anka-accent)', backgroundColor: 'var(--anka-accent-soft)' }
                : undefined
            }
            className={`flex items-center gap-3 p-3.5 rounded-xl border text-left transition-colors ${
              settings.theme === 'light'
                ? ''
                : 'border-[var(--anka-border)] hover:bg-[var(--anka-surface-muted)]'
            }`}
          >
            <Sun size={18} className="text-amber-500 shrink-0" />
            <div>
              <div className="text-xs font-semibold">{tr ? 'Aydınlık Mod' : 'Light Mode'}</div>
              <div className="text-[11px] text-[var(--anka-text-subtle)]">
                {tr ? 'Yüksek kontrastlı gün ışığı' : 'High-contrast daylight'}
              </div>
            </div>
          </button>

          <button
            onClick={() => updateSettings({ theme: 'dark' })}
            style={
              settings.theme === 'dark'
                ? { borderColor: 'var(--anka-accent)', backgroundColor: 'var(--anka-accent-soft)' }
                : undefined
            }
            className={`flex items-center gap-3 p-3.5 rounded-xl border text-left transition-colors ${
              settings.theme === 'dark'
                ? ''
                : 'border-[var(--anka-border)] hover:bg-[var(--anka-surface-muted)]'
            }`}
          >
            <Moon size={18} className="text-[var(--anka-accent)] shrink-0" />
            <div>
              <div className="text-xs font-semibold">{tr ? 'Karanlık Mod' : 'Dark Mode'}</div>
              <div className="text-[11px] text-[var(--anka-text-subtle)]">
                {tr ? 'Düşük parlama arduvaz' : 'Low-glare slate'}
              </div>
            </div>
          </button>
        </div>

        {/* Dynamic Accent Color Picker */}
        <div className="space-y-2.5 max-w-lg">
          <div className="flex items-center gap-2 text-xs font-semibold">
            <Palette size={14} className="text-[var(--anka-accent)]" />
            <span>{tr ? 'Sistem Vurgu Rengi (Accent)' : 'System Accent Color'}</span>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            {accentList.map((spec) => {
              const selected = settings.accent === spec.id;
              const swatchHex = spec[settings.theme].hex;
              return (
                <button
                  key={spec.id}
                  onClick={() => updateSettings({ accent: spec.id as AccentColor })}
                  style={
                    selected
                      ? { borderColor: swatchHex, backgroundColor: spec[settings.theme].soft }
                      : undefined
                  }
                  className={`flex items-center gap-2 px-3 py-1.5 rounded-lg border text-xs font-medium transition-colors ${
                    selected
                      ? 'text-[var(--anka-text)]'
                      : 'border-[var(--anka-border)] text-[var(--anka-text-muted)] hover:bg-[var(--anka-surface-muted)]'
                  }`}
                >
                  <span
                    className="w-3.5 h-3.5 rounded-full flex items-center justify-center shrink-0"
                    style={{ backgroundColor: swatchHex }}
                  >
                    {selected && <Check size={9} className="text-white" />}
                  </span>
                  <span>{tr ? spec.labelTr : spec.labelEn}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Live CSS Variable Inspection Strip */}
        <div className="max-w-lg rounded-xl border border-[var(--anka-border)] bg-[var(--anka-surface-muted)] p-3 flex flex-wrap items-center justify-between gap-3 text-[11px] font-mono">
          <div className="flex items-center gap-2">
            <span className="w-3 h-3 rounded border border-[var(--anka-border-strong)] bg-[var(--anka-bg)]" />
            <span className="text-[var(--anka-text-subtle)]">--anka-bg</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="w-3 h-3 rounded border border-[var(--anka-border-strong)] bg-[var(--anka-surface)]" />
            <span className="text-[var(--anka-text-subtle)]">--anka-surface</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="w-3 h-3 rounded border border-[var(--anka-border-strong)] bg-[var(--anka-text)]" />
            <span className="text-[var(--anka-text-subtle)]">--anka-text</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="w-3 h-3 rounded bg-[var(--anka-accent)]" />
            <span className="text-[var(--anka-accent)] font-semibold">--anka-accent</span>
          </div>
        </div>
      </section>

      <div className="h-px bg-[var(--anka-border)]" />

      {/* Wallpapers */}
      <section className="space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <h2 className="text-base font-semibold font-display">
            {tr ? 'Masaüstü Duvar Kağıdı' : 'Desktop Wallpaper'}
          </h2>
          {settings.customWallpaperUrl && (
            <button
              onClick={() => updateSettings({ customWallpaperUrl: null })}
              className="px-2.5 py-1 rounded-lg text-xs border border-[var(--anka-border)] hover:bg-[var(--anka-surface-elevated)] text-[var(--anka-accent)]"
            >
              {tr ? 'Özel Duvar Kağıdını Temizle' : 'Clear Custom Wallpaper'}
            </button>
          )}
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          {WALLPAPERS.map((wp) => {
            const selected = !settings.customWallpaperUrl && settings.wallpaperId === wp.id;
            return (
              <button
                key={wp.id}
                onClick={() => updateSettings({ wallpaperId: wp.id, customWallpaperUrl: null })}
                style={
                  selected
                    ? {
                        borderColor: 'var(--anka-accent)',
                        boxShadow: '0 0 0 2px var(--anka-accent-soft)',
                      }
                    : undefined
                }
                className={`group rounded-xl overflow-hidden border text-left transition-all ${
                  selected
                    ? ''
                    : 'border-[var(--anka-border)] hover:border-[var(--anka-border-strong)]'
                }`}
              >
                <div className="aspect-video w-full bg-[var(--anka-surface-elevated)] overflow-hidden">
                  <img
                    src={wp.url}
                    alt={tr ? wp.nameTr : wp.nameEn}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                </div>
                <div className="p-2.5 text-xs font-medium flex items-center justify-between">
                  <span>{tr ? wp.nameTr : wp.nameEn}</span>
                  {selected && (
                    <span className="text-[11px] text-[var(--anka-accent)]">
                      {tr ? 'Aktif' : 'Active'}
                    </span>
                  )}
                </div>
              </button>
            );
          })}
        </div>
      </section>

      <div className="h-px bg-[var(--anka-border)]" />

      {/* Multi-User Accounts & Security */}
      <section className="space-y-4 max-w-lg">
        <div className="flex items-center gap-2">
          <Lock size={16} className="text-[var(--anka-accent)]" />
          <h2 className="text-base font-semibold font-display">
            {tr ? 'Kullanıcı Hesapları ve Güvenlik' : 'User Accounts & Security'}
          </h2>
        </div>

        <p className="text-xs text-[var(--anka-text-subtle)]">
          {tr
            ? `Aktif oturum: ${currentUser.username} (UID ${currentUser.uid}). Toplam ${users.length} sistem hesabı kayıtlı.`
            : `Active session: ${currentUser.username} (UID ${currentUser.uid}). ${users.length} system accounts registered.`}
        </p>

        <form onSubmit={handleSavePassword} className="flex items-center gap-2">
          <input
            type="password"
            value={newPass}
            onChange={(e) => setNewPass(e.target.value)}
            placeholder={
              currentUser.passwordHash
                ? tr
                  ? 'Yeni parola (kaldırmak için boş bırakın)'
                  : 'New password (empty to clear)'
                : tr
                  ? 'Aktif hesap için parola belirle...'
                  : 'Set login password...'
            }
            className="flex-1 px-3 py-2 text-xs rounded-lg border border-[var(--anka-border)] bg-[var(--anka-surface-muted)] outline-none focus:border-[var(--anka-accent)]"
          />
          <button
            type="submit"
            className="px-4 py-2 rounded-lg text-xs font-medium bg-[var(--anka-accent)] hover:bg-[var(--anka-accent-hover)] text-[var(--anka-accent-fg)] transition-colors"
          >
            {tr ? 'Parolayı Güncelle' : 'Update Password'}
          </button>
        </form>
        {passNotice && <div className="text-xs text-emerald-500 font-medium">{passNotice}</div>}

        <form onSubmit={handleCreateUser} className="pt-2 flex flex-wrap items-center gap-2">
          <input
            type="text"
            value={newUsername}
            onChange={(e) => setNewUsername(e.target.value)}
            placeholder={tr ? 'Yeni kullanıcı adı (ör. misafir)' : 'New username'}
            className="w-44 px-3 py-2 text-xs rounded-lg border border-[var(--anka-border)] bg-[var(--anka-surface-muted)] outline-none focus:border-[var(--anka-accent)]"
          />
          <input
            type="text"
            value={newUserFull}
            onChange={(e) => setNewUserFull(e.target.value)}
            placeholder={tr ? 'Ad Soyad' : 'Full Name'}
            className="flex-1 px-3 py-2 text-xs rounded-lg border border-[var(--anka-border)] bg-[var(--anka-surface-muted)] outline-none focus:border-[var(--anka-accent)]"
          />
          <button
            type="submit"
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-lg text-xs font-medium border border-[var(--anka-border)] hover:bg-[var(--anka-surface-elevated)] transition-colors"
          >
            <UserPlus size={14} />
            <span>{tr ? 'Kullanıcı Ekle' : 'Add User'}</span>
          </button>
        </form>
        {userNotice && <div className="text-xs text-[var(--anka-accent)] font-medium">{userNotice}</div>}
      </section>

      <div className="h-px bg-[var(--anka-border)]" />

      {/* Sandbox / İzin Yöneticisi */}
      <section className="space-y-3 max-w-lg">
        <div className="flex items-center gap-2">
          <Shield size={16} className="text-emerald-500" />
          <h2 className="text-base font-semibold font-display">
            {tr ? 'Sandbox & Uygulama İzin Yöneticisi' : 'Sandbox & App Permission Manager'}
          </h2>
        </div>
        <p className="text-xs text-[var(--anka-text-subtle)]">
          {tr
            ? 'Ring 3 uygulamaları varsayılan olarak yalnızca ~/.sandbox/<uygulama> dizinine yazabilir. Belgeler klasörüne erişim sistem çağrısı seviyesinde denetlenir.'
            : 'Ring 3 apps can only write to ~/.sandbox/<app> by default. Document access is gated at the syscall layer.'}
        </p>
        <div className="space-y-2">
          {([
            'editor',
            'notes',
            'paint',
            'browser',
            'wasm-builder',
            'pkg-kanban',
            'pkg-sysbench',
            'pkg-calendar',
            'pkg-recorder',
            'pkg-nettools',
          ] as AppId[]).map((appId) => {
            const hasDocs = (settings.sandboxGrants?.[appId] || []).includes('docs:rw');
            const manifest = APP_MANIFESTS[appId];
            return (
              <div
                key={appId}
                className="flex items-center justify-between px-3 py-2.5 rounded-xl border border-[var(--anka-border)] text-xs"
              >
                <div>
                  <div className="font-semibold">{tr ? manifest.nameTr : manifest.nameEn}</div>
                  <div className="text-[11px] font-mono text-[var(--anka-text-subtle)]">
                    Sandbox: ~/.sandbox/{appId}
                  </div>
                </div>
                <button
                  onClick={() =>
                    hasDocs
                      ? revokeSandboxPermission(appId, 'docs:rw')
                      : grantSandboxPermission(appId, 'docs:rw')
                  }
                  className={`px-3 py-1 rounded-md font-medium transition-colors ${
                    hasDocs
                      ? 'bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 hover:bg-emerald-500/25'
                      : 'bg-[var(--anka-surface-muted)] text-[var(--anka-text-subtle)] hover:text-[var(--anka-text)]'
                  }`}
                >
                  {hasDocs ? 'Belgeler İzni: Açık' : 'Belgeler İzni: Kapalı'}
                </button>
              </div>
            );
          })}
        </div>
      </section>

      <div className="h-px bg-[var(--anka-border)]" />

      {/* Language, Sound & Desktop Icons */}
      <section className="space-y-4">
        <h2 className="text-base font-semibold font-display">
          {tr ? 'Dil, Ses ve Masaüstü' : 'Language, Audio & Desktop'}
        </h2>

        <div className="flex flex-wrap items-center gap-6">
          <div className="flex items-center gap-2">
            <Globe size={16} className="text-[var(--anka-text-subtle)]" />
            <span className="text-xs font-medium">{tr ? 'Dil:' : 'Language:'}</span>
            <div className="flex items-center gap-1 p-1 bg-[var(--anka-surface-muted)] border border-[var(--anka-border)] rounded-lg">
              <button
                onClick={() => updateSettings({ language: 'tr' })}
                className={`px-3 py-1 text-xs font-medium rounded-md transition-colors ${
                  settings.language === 'tr'
                    ? 'bg-[var(--anka-surface)] text-[var(--anka-text)] shadow-sm'
                    : 'text-[var(--anka-text-subtle)]'
                }`}
              >
                Türkçe
              </button>
              <button
                onClick={() => updateSettings({ language: 'en' })}
                className={`px-3 py-1 text-xs font-medium rounded-md transition-colors ${
                  settings.language === 'en'
                    ? 'bg-[var(--anka-surface)] text-[var(--anka-text)] shadow-sm'
                    : 'text-[var(--anka-text-subtle)]'
                }`}
              >
                English
              </button>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <Volume2 size={16} className="text-[var(--anka-text-subtle)]" />
            <span className="text-xs font-medium">{tr ? 'Ses:' : 'Volume:'}</span>
            <input
              type="range"
              min={0}
              max={100}
              value={settings.muted ? 0 : settings.volume}
              onChange={(e) =>
                updateSettings({ volume: Number(e.target.value), muted: false })
              }
              style={{ accentColor: 'var(--anka-accent)' }}
              className="w-28"
            />
            <span className="text-xs font-mono tabular-nums text-[var(--anka-text-subtle)]">
              {settings.muted ? '0%' : `${settings.volume}%`}
            </span>
          </div>

          <label className="flex items-center gap-2 text-xs font-medium cursor-pointer">
            <input
              type="checkbox"
              checked={settings.showDesktopIcons}
              onChange={(e) => updateSettings({ showDesktopIcons: e.target.checked })}
              style={{ accentColor: 'var(--anka-accent)' }}
              className="rounded"
            />
            <span>{tr ? 'Masaüstü simgelerini göster' : 'Show desktop icons'}</span>
          </label>

          <label className="flex items-center gap-2 text-xs font-medium cursor-pointer">
            <input
              type="checkbox"
              checked={Boolean(settings.doNotDisturb)}
              onChange={(e) => updateSettings({ doNotDisturb: e.target.checked })}
              style={{ accentColor: 'var(--anka-accent)' }}
              className="rounded"
            />
            <BellOff size={14} className="text-amber-500" />
            <span>{tr ? 'Rahatsız Etme Modu (Bildirim Bannerlarını Gizle)' : 'Do Not Disturb (Silence Toasts)'}</span>
          </label>
        </div>
      </section>

      <div className="h-px bg-[var(--anka-border)]" />

      {/* System Info & Reset */}
      <section className="space-y-4">
        <div className="flex items-center gap-2">
          <Monitor size={16} className="text-[var(--anka-accent)]" />
          <h2 className="text-base font-semibold font-display">
            {tr ? 'Sistem Bilgisi' : 'System Information'}
          </h2>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 text-xs border border-[var(--anka-border)] bg-[var(--anka-surface-muted)] rounded-xl p-4">
          <div className="flex items-center gap-2.5">
            <AnkaLogo size={24} />
            <div>
              <div className="text-[var(--anka-text-subtle)]">{tr ? 'İşletim Sistemi' : 'OS'}</div>
              <div className="font-semibold mt-0.5">AnkaOS 3.5 (Kuzgun)</div>
            </div>
          </div>
          <div>
            <div className="text-[var(--anka-text-subtle)]">{tr ? 'Çekirdek' : 'Kernel'}</div>
            <div className="font-semibold mt-0.5 font-mono">AnkaKernel 6.1.0</div>
          </div>
          <div>
            <div className="text-[var(--anka-text-subtle)]">{tr ? 'Aktif Süreçler' : 'Processes'}</div>
            <div className="font-semibold mt-0.5 tabular-nums">{processes.length}</div>
          </div>
          <div>
            <div className="text-[var(--anka-text-subtle)]">{tr ? 'Çalışma Süresi' : 'Uptime'}</div>
            <div className="font-semibold mt-0.5 tabular-nums">{uptimeSec}s</div>
          </div>
        </div>

        {/* Snapshot Backup & Restore */}
        <div className="rounded-xl border border-[var(--anka-border)] bg-[var(--anka-surface-muted)] p-4 space-y-3 max-w-xl">
          <div className="flex items-center gap-2">
            <HardDriveDownload size={15} className="text-[var(--anka-accent)]" />
            <span className="text-xs font-semibold">
              {tr ? 'Sistem Yedekleme ve Geri Yükleme (JSON Snapshot)' : 'System Snapshot Backup & Restore'}
            </span>
          </div>
          <p className="text-xs text-[var(--anka-text-subtle)]">
            {tr
              ? 'Tüm sanal dosya sistemini (VFS), kullanıcı hesaplarını, kurulu paketleri ve tema ayarlarını tek bir JSON dosyası olarak dışa veya içe aktarın.'
              : 'Export or restore the entire VFS, user accounts, installed packages, and theme settings as a single JSON file.'}
          </p>
          <div className="flex flex-wrap items-center gap-2">
            <button
              onClick={handleExportSnapshot}
              className="flex items-center gap-1.5 px-3.5 py-2 rounded-lg text-xs font-medium bg-[var(--anka-accent)] text-[var(--anka-accent-fg)] hover:bg-[var(--anka-accent-hover)] transition-colors"
            >
              <Download size={14} />
              <span>{tr ? 'Snapshot Dışa Aktar (.json)' : 'Export Snapshot (.json)'}</span>
            </button>
            <button
              onClick={() => snapshotInputRef.current?.click()}
              className="flex items-center gap-1.5 px-3.5 py-2 rounded-lg text-xs font-medium border border-[var(--anka-border-strong)] hover:bg-[var(--anka-surface-elevated)] transition-colors"
            >
              <Upload size={14} />
              <span>{tr ? 'Yedekten Geri Yükle' : 'Restore from JSON'}</span>
            </button>
            <input
              ref={snapshotInputRef}
              type="file"
              accept=".json,application/json"
              onChange={handleImportSnapshotFile}
              className="hidden"
            />
          </div>
          {snapshotStatus && (
            <div
              className={`text-xs font-medium ${
                snapshotStatus.ok ? 'text-emerald-500' : 'text-rose-500'
              }`}
            >
              {snapshotStatus.msg}
            </div>
          )}

          {/* IndexedDB Quota & Cloud Snapshot Sync */}
          <div className="pt-3 border-t border-[var(--anka-border)] space-y-2.5">
            <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
              <span className="font-semibold flex items-center gap-1.5">
                <Database size={13} className="text-emerald-500" />
                <span>{tr ? 'IndexedDB Kalıcı Depolama' : 'IndexedDB Persistent Storage'}</span>
              </span>
              <span className="font-mono text-[11px] tabular-nums text-[var(--anka-text-subtle)]">
                {idbStats
                  ? `${formatBytes(idbStats.usedBytes)} / ${formatBytes(idbStats.quotaBytes || 50 * 1024 * 1024)} · ${
                      idbStats.supported ? 'IDB Aktif' : 'LocalStorage Yedek'
                    }`
                  : '...'}
              </span>
            </div>

            <div className="flex flex-wrap items-center gap-2 pt-1">
              <Cloud size={14} className="text-[var(--anka-accent)] shrink-0" />
              <input
                type="text"
                value={syncKey}
                onChange={(e) => setSyncKey(e.target.value)}
                placeholder={tr ? 'Eşitleme anahtarı...' : 'Sync key...'}
                className="flex-1 min-w-[140px] px-2.5 py-1.5 rounded-lg border border-[var(--anka-border-strong)] bg-[var(--anka-surface)] text-xs font-mono outline-none focus:border-[var(--anka-accent)]"
              />
              <button
                onClick={() => void handleCloudPush()}
                disabled={syncBusy || !syncKey.trim()}
                className="px-3 py-1.5 rounded-lg text-xs font-medium bg-emerald-600 text-white hover:bg-emerald-500 disabled:opacity-50 whitespace-nowrap shrink-0"
              >
                {tr ? 'Sunucuya Yükle' : 'Push to Server'}
              </button>
              <button
                onClick={() => void handleCloudPull()}
                disabled={syncBusy || !syncKey.trim()}
                className="px-3 py-1.5 rounded-lg text-xs font-medium border border-[var(--anka-border-strong)] hover:bg-[var(--anka-surface-elevated)] disabled:opacity-50 whitespace-nowrap shrink-0"
              >
                {tr ? 'Sunucudan İndir' : 'Pull from Server'}
              </button>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-3">
          {!confirmReset ? (
            <button
              onClick={() => setConfirmReset(true)}
              className="flex items-center gap-2 px-3.5 py-2 rounded-lg text-xs font-medium border border-rose-300 dark:border-rose-900 text-rose-600 dark:text-rose-400 hover:bg-rose-500/10 transition-colors"
            >
              <RotateCcw size={14} />
              <span>{tr ? 'Dosya Sistemini Fabrika Ayarlarına Sıfırla' : 'Reset Filesystem to Defaults'}</span>
            </button>
          ) : (
            <div className="flex items-center gap-2">
              <span className="text-xs text-rose-500 font-medium">
                {tr ? 'Tüm dosya değişiklikleri silinecek. Emin misiniz?' : 'All custom files will be reset. Confirm?'}
              </span>
              <button
                onClick={() => {
                  resetVFS();
                  setConfirmReset(false);
                }}
                className="px-3 py-1.5 rounded-lg text-xs font-medium bg-rose-600 text-white hover:bg-rose-500"
              >
                {tr ? 'Evet, Sıfırla' : 'Yes, Reset'}
              </button>
              <button
                onClick={() => setConfirmReset(false)}
                className="px-3 py-1.5 rounded-lg text-xs text-[var(--anka-text-subtle)] hover:text-[var(--anka-text)]"
              >
                {tr ? 'Vazgeç' : 'Cancel'}
              </button>
            </div>
          )}
        </div>
      </section>
    </div>
  );
};
