import React, { useEffect, useMemo, useState } from 'react';
import {
  Binary,
  ChevronRight,
  ClipboardPaste,
  Copy,
  Cpu,
  Download,
  ExternalLink,
  FileAudio,
  FileCode2,
  FileDiff,
  FileText,
  Folder,
  FolderOpen,
  FolderPlus,
  Globe,
  HardDrive,
  Home,
  Image as ImageIcon,
  LayoutGrid,
  List,
  Monitor,
  Music,
  Pencil,
  Plus,
  RotateCcw,
  Scissors,
  Search,
  Shield,
  Terminal,
  Trash2,
  Upload,
  X,
} from 'lucide-react';
import { useOS } from '../os/kernel';
import { VFSNode } from '../os/types';
import {
  formatBytes,
  getNodeAtPath,
  HOME_PATH,
  listDir,
  normalizePath,
  TRASH_INDEX_FILENAME,
} from '../os/vfs';

interface FilesAppProps {
  windowId: string;
  launchArgs?: Record<string, string>;
}

const VFS_DRAG_MIME = 'application/x-ankaos-path';

export const FilesApp: React.FC<FilesAppProps> = ({ launchArgs }) => {
  const {
    vfs,
    clipboard,
    setClipboard,
    makeDir,
    writeFile,
    deleteNode,
    renameNode,
    copyNode,
    moveNode,
    trashNode,
    restoreTrashItem,
    emptyTrash,
    chmodNode,
    openFileWithDefaultApp,
    launchApp,
    installedPackages,
    settings,
    updateSettings,
    pushNotification,
    currentUser,
  } = useOS();

  const tr = settings.language === 'tr';
  const userHome = currentUser.homeDir || HOME_PATH;
  const trashPath = `${userHome}/.Trash`;

  const [currentPath, setCurrentPath] = useState<string>(
    () => normalizePath(launchArgs?.path || userHome, '/', userHome)
  );
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [search, setSearch] = useState('');
  const [selectedName, setSelectedName] = useState<string | null>(null);
  const [creatingType, setCreatingType] = useState<'dir' | 'file' | null>(null);
  const [newItemName, setNewItemName] = useState('');
  const [renamingName, setRenamingName] = useState<string | null>(null);
  const [renameValue, setRenameValue] = useState('');
  const [propsNodeName, setPropsNodeName] = useState<string | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [dropTargetPath, setDropTargetPath] = useState<string | null>(null);
  const [externalDragOver, setExternalDragOver] = useState(false);
  const [itemMenu, setItemMenu] = useState<{
    x: number;
    y: number;
    node: VFSNode;
  } | null>(null);

  const isInTrash = currentPath === trashPath;

  useEffect(() => {
    if (launchArgs?.path) {
      setCurrentPath(normalizePath(launchArgs.path, '/', userHome));
      setSelectedName(null);
    }
  }, [launchArgs?.path, userHome]);

  useEffect(() => {
    if (!itemMenu) return;
    const close = () => setItemMenu(null);
    window.addEventListener('click', close);
    return () => window.removeEventListener('click', close);
  }, [itemMenu]);

  const trashCount = useMemo(
    () => listDir(vfs, trashPath).filter((n) => n.name !== TRASH_INDEX_FILENAME).length,
    [vfs, trashPath]
  );

  const entries = useMemo(() => {
    const raw = listDir(vfs, currentPath).filter(
      (n) => !(isInTrash && n.name === TRASH_INDEX_FILENAME)
    );
    if (!search.trim()) return raw;
    const q = search.toLowerCase();
    return raw.filter((n) => n.name.toLowerCase().includes(q));
  }, [vfs, currentPath, isInTrash, search]);

  const breadcrumbs = useMemo(() => {
    if (currentPath === '/') return [{ label: '/', path: '/' }];
    const parts = currentPath.split('/').filter(Boolean);
    const list = [{ label: '/', path: '/' }];
    let acc = '';
    for (const part of parts) {
      acc += '/' + part;
      list.push({ label: part, path: acc });
    }
    return list;
  }, [currentPath]);

  const sidebarItems = [
    { label: tr ? 'Ana Dizin' : 'Home', path: userHome, icon: Home },
    { label: tr ? 'Masaüstü' : 'Desktop', path: `${userHome}/Masaüstü`, icon: Folder },
    { label: tr ? 'Belgeler' : 'Documents', path: `${userHome}/Belgeler`, icon: FileText },
    { label: tr ? 'Projeler' : 'Projects', path: `${userHome}/Projeler`, icon: FileCode2 },
    { label: tr ? 'Resimler' : 'Pictures', path: `${userHome}/Resimler`, icon: ImageIcon },
    { label: tr ? 'Müzik' : 'Music', path: `${userHome}/Müzik`, icon: Music },
    { label: tr ? 'İndirilenler' : 'Downloads', path: `${userHome}/İndirilenler`, icon: Download },
    {
      label: tr ? `Çöp Kutusu${trashCount ? ` (${trashCount})` : ''}` : `Trash${trashCount ? ` (${trashCount})` : ''}`,
      path: trashPath,
      icon: Trash2,
    },
    { label: '/proc', path: '/proc', icon: Cpu },
    { label: tr ? 'Kök (/)' : 'Root (/)', path: '/', icon: HardDrive },
  ];

  const getItemPath = (name: string) =>
    currentPath === '/' ? `/${name}` : `${currentPath}/${name}`;

  const handleOpen = (node: VFSNode) => {
    if (isInTrash) return;
    const path = getItemPath(node.name);
    if (node.type === 'dir') {
      setCurrentPath(path);
      setSelectedName(null);
      setSearch('');
      setErrorMsg(null);
    } else {
      openFileWithDefaultApp(path);
    }
  };

  const handleCreateSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const clean = newItemName.trim();
    if (!clean) {
      setCreatingType(null);
      return;
    }
    const targetPath = getItemPath(clean);
    const res =
      creatingType === 'dir' ? makeDir(targetPath) : writeFile(targetPath, '');
    if (!res.ok) setErrorMsg(res.error || 'İşlem başarısız');
    else {
      setErrorMsg(null);
      setCreatingType(null);
      setNewItemName('');
    }
  };

  const handleRenameSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!renamingName) return;
    const res = renameNode(getItemPath(renamingName), renameValue);
    if (!res.ok) setErrorMsg(res.error || 'Yeniden adlandırılamadı');
    else {
      setErrorMsg(null);
      setRenamingName(null);
      setSelectedName(renameValue.trim());
    }
  };

  const handleDeleteSelected = (targetName = selectedName) => {
    if (!targetName) return;
    const target = getItemPath(targetName);
    const res = isInTrash ? deleteNode(target) : trashNode(target);
    if (!res.ok) setErrorMsg(res.error || 'Silinemedi');
    else {
      setSelectedName(null);
      setErrorMsg(null);
    }
  };

  const handleRestoreSelected = (targetName = selectedName) => {
    if (!targetName || !isInTrash) return;
    const res = restoreTrashItem(targetName);
    if (!res.ok) setErrorMsg(res.error || 'Geri yüklenemedi');
    else {
      setSelectedName(null);
      setErrorMsg(null);
    }
  };

  const handlePaste = () => {
    if (!clipboard || clipboard.kind !== 'vfs' || !clipboard.path) return;
    const srcName = clipboard.path.split('/').pop() || 'kopya';
    const destPath = getItemPath(srcName);
    if (clipboard.mode === 'cut') {
      const res = moveNode(clipboard.path, currentPath);
      if (!res.ok) setErrorMsg(res.error || 'Taşınamadı');
      else {
        setClipboard(null);
        setErrorMsg(null);
      }
      return;
    }
    const res = copyNode(clipboard.path, destPath);
    if (!res.ok) {
      setErrorMsg(res.error || 'Yapıştırılamadı');
      return;
    }
    setErrorMsg(null);
  };

  // Internal VFS Drag & Drop handlers
  const handleDragStartItem = (e: React.DragEvent, itemName: string) => {
    if (currentPath === '/proc' || currentPath === '/dev') {
      e.preventDefault();
      return;
    }
    const full = getItemPath(itemName);
    e.dataTransfer.setData(VFS_DRAG_MIME, full);
    e.dataTransfer.effectAllowed = 'move';
  };

  const handleDropOnFolder = (e: React.DragEvent, targetDirPath: string) => {
    e.preventDefault();
    e.stopPropagation();
    setDropTargetPath(null);
    setExternalDragOver(false);

    if (targetDirPath === '/proc' || targetDirPath === '/dev') return;
    const vfsSrc = e.dataTransfer.getData(VFS_DRAG_MIME);
    if (!vfsSrc) return;

    if (targetDirPath === trashPath) {
      const res = trashNode(vfsSrc);
      if (!res.ok) setErrorMsg(res.error || 'Çöp kutusuna taşınamadı');
      else {
        setSelectedName(null);
        setErrorMsg(null);
      }
      return;
    }

    const res = moveNode(vfsSrc, targetDirPath);
    if (!res.ok) setErrorMsg(res.error || 'Taşınamadı');
    else {
      setSelectedName(null);
      setErrorMsg(null);
    }
  };

  // External host OS file drop onto current directory
  const handleDropOnCanvas = async (e: React.DragEvent) => {
    e.preventDefault();
    setExternalDragOver(false);
    setDropTargetPath(null);

    const vfsSrc = e.dataTransfer.getData(VFS_DRAG_MIME);
    if (vfsSrc) {
      const parentOfSrc = vfsSrc.slice(0, vfsSrc.lastIndexOf('/')) || '/';
      if (parentOfSrc !== currentPath) {
        const res = moveNode(vfsSrc, currentPath);
        if (!res.ok) setErrorMsg(res.error || 'Taşınamadı');
      }
      return;
    }

    const files = Array.from(e.dataTransfer.files || []);
    if (files.length === 0) return;

    for (const file of files) {
      const dest = getItemPath(file.name);
      if (file.type.startsWith('image/') || file.type.startsWith('audio/')) {
        const dataUrl = await new Promise<string>((resolve) => {
          const reader = new FileReader();
          reader.onload = () => resolve(typeof reader.result === 'string' ? reader.result : '');
          reader.readAsDataURL(file);
        });
        const res = writeFile(dest, dataUrl, file.type || 'application/octet-stream');
        if (!res.ok) setErrorMsg(res.error || 'Yükleme başarısız');
      } else {
        const text = await file.text();
        const res = writeFile(dest, text, file.type || undefined);
        if (!res.ok) setErrorMsg(res.error || 'Yükleme başarısız');
      }
    }
  };

  const handleCanvasKeyDown = (e: React.KeyboardEvent<HTMLDivElement>) => {
    const tag = (e.target as HTMLElement)?.tagName;
    if (tag === 'INPUT' || tag === 'TEXTAREA') return;

    if (e.key === 'Escape') {
      setItemMenu(null);
      setPropsNodeName(null);
      return;
    }

    if (e.key === 'Backspace' && currentPath !== '/') {
      e.preventDefault();
      const parts = currentPath.split('/').filter(Boolean);
      parts.pop();
      setCurrentPath('/' + parts.join('/'));
      setSelectedName(null);
      return;
    }

    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'v' && !isInTrash) {
      e.preventDefault();
      handlePaste();
      return;
    }

    if (!selectedName) return;

    if (e.key === 'Enter') {
      const node = entries.find((x) => x.name === selectedName);
      if (node) {
        e.preventDefault();
        handleOpen(node);
      }
    } else if (e.key === 'Delete') {
      e.preventDefault();
      handleDeleteSelected();
    } else if (e.key === 'F2' && !isInTrash) {
      e.preventDefault();
      setRenamingName(selectedName);
      setRenameValue(selectedName);
    } else if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'c' && !isInTrash) {
      e.preventDefault();
      setClipboard({ kind: 'vfs', mode: 'copy', path: getItemPath(selectedName) });
    } else if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'x' && !isInTrash) {
      e.preventDefault();
      setClipboard({ kind: 'vfs', mode: 'cut', path: getItemPath(selectedName) });
    }
  };

  const openItemContextMenu = (e: React.MouseEvent, item: VFSNode) => {
    e.preventDefault();
    e.stopPropagation();
    setSelectedName(item.name);
    setItemMenu({
      x: Math.min(e.clientX, window.innerWidth - 230),
      y: Math.min(e.clientY, window.innerHeight - 320),
      node: item,
    });
  };

  const isImageNode = (node: VFSNode) =>
    Boolean(node.mimeType?.startsWith('image/') || /\.(png|jpg|jpeg|webp|svg)$/i.test(node.name));

  const isAudioNode = (node: VFSNode) =>
    Boolean(
      node.mimeType?.startsWith('audio/') ||
        /\.(ankasynth|webm|wav|mp3|ogg|m4a|flac|aac)$/i.test(node.name)
    );

  const renderIcon = (node: VFSNode, size = 20) => {
    if (node.type === 'dir') return <Folder size={size} className="text-[var(--anka-accent)] shrink-0" />;
    if (isImageNode(node)) {
      return <ImageIcon size={size} className="text-amber-500 shrink-0" />;
    }
    if (isAudioNode(node)) {
      return <FileAudio size={size} className="text-rose-500 shrink-0" />;
    }
    if (/\.(wasm|wat|wast|ankawasm)$/i.test(node.name)) {
      return <Cpu size={size} className="text-amber-500 shrink-0" />;
    }
    if (/\.html?$/i.test(node.name)) {
      return <Globe size={size} className="text-indigo-500 shrink-0" />;
    }
    if (/\.(js|ts|json|sh|ankashrc)$/i.test(node.name)) {
      return <FileCode2 size={size} className="text-emerald-500 shrink-0" />;
    }
    return <FileText size={size} className="text-[var(--anka-text-subtle)] shrink-0" />;
  };

  const currentNode = getNodeAtPath(vfs, currentPath);
  const propsNode = propsNodeName ? getNodeAtPath(vfs, getItemPath(propsNodeName)) : null;

  return (
    <div
      tabIndex={0}
      onKeyDown={handleCanvasKeyDown}
      className="h-full w-full flex bg-[var(--anka-surface)] text-[var(--anka-text)] relative outline-none anka-theme-transition"
    >
      {/* Sidebar */}
      <aside className="w-48 shrink-0 border-r border-[var(--anka-border)] bg-[var(--anka-surface-muted)] p-3 flex flex-col justify-between overflow-y-auto os-scroll">
        <div className="space-y-1">
          <div className="px-2 py-1 text-[11px] font-medium text-[var(--anka-text-subtle)]">
            {tr ? 'Konumlar' : 'Locations'}
          </div>
          {sidebarItems.map((item) => {
            const Icon = item.icon;
            const active = currentPath === item.path;
            const isDropHighlight = dropTargetPath === item.path;
            return (
              <button
                key={item.path}
                onClick={() => {
                  setCurrentPath(item.path);
                  setSelectedName(null);
                  setErrorMsg(null);
                }}
                onDragOver={(e) => {
                  if (item.path === '/proc') return;
                  if (e.dataTransfer.types.includes(VFS_DRAG_MIME)) {
                    e.preventDefault();
                    setDropTargetPath(item.path);
                  }
                }}
                onDragLeave={() => {
                  if (dropTargetPath === item.path) setDropTargetPath(null);
                }}
                onDrop={(e) => handleDropOnFolder(e, item.path)}
                className={`w-full flex items-center gap-2.5 px-2.5 py-2 rounded-lg text-xs font-medium transition-colors whitespace-nowrap ${
                  isDropHighlight
                    ? 'ring-2 ring-[var(--anka-accent)] bg-[var(--anka-accent-soft)] text-[var(--anka-accent)]'
                    : active
                      ? 'bg-[var(--anka-accent-soft)] text-[var(--anka-accent)]'
                      : 'text-[var(--anka-text-muted)] hover:bg-[var(--anka-surface-elevated)] hover:text-[var(--anka-text)]'
                }`}
              >
                <Icon size={15} />
                <span className="truncate">{item.label}</span>
              </button>
            );
          })}
        </div>

        <button
          onClick={() => launchApp('terminal', { cwd: currentPath })}
          className="mt-3 w-full flex items-center justify-center gap-2 px-3 py-2 rounded-lg text-xs font-medium border border-[var(--anka-border-strong)] hover:bg-[var(--anka-surface-elevated)] transition-colors whitespace-nowrap shrink-0"
        >
          <Terminal size={14} />
          <span>{tr ? 'Uçbirimde Aç' : 'Open in Terminal'}</span>
        </button>
      </aside>

      {/* Main Content */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Toolbar */}
        <div className="px-4 py-2.5 border-b border-[var(--anka-border)] flex items-center justify-between gap-2">
          <div className="flex items-center gap-1 text-xs overflow-x-auto min-w-0">
            {breadcrumbs.map((bc, idx) => (
              <React.Fragment key={bc.path}>
                {idx > 0 && <ChevronRight size={13} className="text-[var(--anka-text-subtle)] shrink-0" />}
                <button
                  onClick={() => setCurrentPath(bc.path)}
                  className="px-1.5 py-1 rounded hover:bg-[var(--anka-surface-elevated)] text-[var(--anka-text)] font-medium whitespace-nowrap"
                >
                  {bc.label}
                </button>
              </React.Fragment>
            ))}
          </div>

          <div className="flex items-center gap-1.5 shrink-0">
            <div className="relative">
              <Search size={13} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-[var(--anka-text-subtle)]" />
              <input
                type="text"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder={tr ? 'Ara...' : 'Filter...'}
                className="w-28 pl-7 pr-2 py-1.5 text-xs rounded-lg border border-[var(--anka-border-strong)] bg-[var(--anka-surface-muted)] text-[var(--anka-text)] outline-none focus:border-[var(--anka-accent)]"
              />
            </div>

            {!isInTrash && (
              <>
                <button
                  onClick={() => {
                    setCreatingType('dir');
                    setNewItemName('');
                  }}
                  title={tr ? 'Yeni Klasör' : 'New Folder'}
                  className="p-1.5 rounded-lg border border-[var(--anka-border-strong)] hover:bg-[var(--anka-surface-elevated)]"
                >
                  <FolderPlus size={14} />
                </button>
                <button
                  onClick={() => {
                    setCreatingType('file');
                    setNewItemName('');
                  }}
                  title={tr ? 'Yeni Dosya' : 'New File'}
                  className="p-1.5 rounded-lg border border-[var(--anka-border-strong)] hover:bg-[var(--anka-surface-elevated)]"
                >
                  <Plus size={14} />
                </button>
              </>
            )}

            {isInTrash && trashCount > 0 && (
              <button
                onClick={() => {
                  const res = emptyTrash();
                  if (!res.ok) setErrorMsg(res.error || 'Boşaltılamadı');
                  setSelectedName(null);
                }}
                className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-xs font-medium border border-rose-300 dark:border-rose-900/60 text-rose-600 dark:text-rose-400 hover:bg-rose-500/10"
              >
                <Trash2 size={13} />
                <span>{tr ? 'Çöpü Boşalt' : 'Empty Trash'}</span>
              </button>
            )}

            {clipboard?.kind === 'vfs' && !isInTrash && (
              <button
                onClick={handlePaste}
                title={tr ? 'Yapıştır' : 'Paste'}
                className="p-1.5 rounded-lg border border-[var(--anka-accent)] text-[var(--anka-accent)] hover:bg-[var(--anka-accent-soft)]"
              >
                <ClipboardPaste size={14} />
              </button>
            )}

            {selectedName && (
              <>
                {isInTrash ? (
                  <button
                    onClick={() => handleRestoreSelected()}
                    title={tr ? 'Geri Yükle' : 'Restore'}
                    className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-xs font-medium bg-emerald-600 text-white hover:bg-emerald-500"
                  >
                    <RotateCcw size={13} />
                    <span>{tr ? 'Geri Yükle' : 'Restore'}</span>
                  </button>
                ) : (
                  <>
                    <button
                      onClick={() =>
                        setClipboard({ kind: 'vfs', mode: 'copy', path: getItemPath(selectedName) })
                      }
                      title={tr ? 'Kopyala' : 'Copy'}
                      className="p-1.5 rounded-lg border border-[var(--anka-border-strong)] hover:bg-[var(--anka-surface-elevated)]"
                    >
                      <Copy size={14} />
                    </button>
                    <button
                      onClick={() =>
                        setClipboard({ kind: 'vfs', mode: 'cut', path: getItemPath(selectedName) })
                      }
                      title={tr ? 'Kes' : 'Cut'}
                      className="p-1.5 rounded-lg border border-[var(--anka-border-strong)] hover:bg-[var(--anka-surface-elevated)]"
                    >
                      <Scissors size={14} />
                    </button>
                    <button
                      onClick={() => setPropsNodeName(selectedName)}
                      title={tr ? 'Özellikler ve İzinler' : 'Properties & Permissions'}
                      className="p-1.5 rounded-lg border border-[var(--anka-border-strong)] hover:bg-[var(--anka-surface-elevated)]"
                    >
                      <Shield size={14} />
                    </button>
                    {installedPackages.includes('pkg-hex') &&
                      getNodeAtPath(vfs, getItemPath(selectedName))?.type === 'file' && (
                        <button
                          onClick={() => launchApp('pkg-hex', { path: getItemPath(selectedName) })}
                          title={tr ? 'Hex İnceleyicide Aç' : 'Open in Hex Inspector'}
                          className="p-1.5 rounded-lg border border-[var(--anka-border-strong)] hover:bg-[var(--anka-surface-elevated)] text-amber-500"
                        >
                          <Binary size={14} />
                        </button>
                      )}
                    <button
                      onClick={() => {
                        setRenamingName(selectedName);
                        setRenameValue(selectedName);
                      }}
                      title={tr ? 'Yeniden Adlandır (F2)' : 'Rename (F2)'}
                      className="p-1.5 rounded-lg border border-[var(--anka-border-strong)] hover:bg-[var(--anka-surface-elevated)]"
                    >
                      <Pencil size={14} />
                    </button>
                  </>
                )}

                <button
                  onClick={() => handleDeleteSelected()}
                  title={isInTrash ? (tr ? 'Kalıcı Sil' : 'Delete Permanently') : (tr ? 'Çöp Kutusuna Taşı (Del)' : 'Move to Trash (Del)')}
                  className="p-1.5 rounded-lg border border-rose-300 dark:border-rose-900/60 text-rose-600 dark:text-rose-400 hover:bg-rose-500/10"
                >
                  <Trash2 size={14} />
                </button>
              </>
            )}

            <div className="flex items-center border border-[var(--anka-border-strong)] rounded-lg p-0.5 bg-[var(--anka-surface-muted)]">
              <button
                onClick={() => setViewMode('grid')}
                className={`p-1 rounded ${
                  viewMode === 'grid'
                    ? 'bg-[var(--anka-surface)] text-[var(--anka-text)] shadow-sm'
                    : 'text-[var(--anka-text-subtle)]'
                }`}
              >
                <LayoutGrid size={14} />
              </button>
              <button
                onClick={() => setViewMode('list')}
                className={`p-1 rounded ${
                  viewMode === 'list'
                    ? 'bg-[var(--anka-surface)] text-[var(--anka-text)] shadow-sm'
                    : 'text-[var(--anka-text-subtle)]'
                }`}
              >
                <List size={14} />
              </button>
            </div>
          </div>
        </div>

        {(creatingType || renamingName || errorMsg) && (
          <div className="px-4 py-2 border-b border-[var(--anka-border)] bg-[var(--anka-surface-muted)] flex items-center gap-3 text-xs">
            {creatingType && (
              <form onSubmit={handleCreateSubmit} className="flex items-center gap-2 flex-1">
                <span className="font-medium text-[var(--anka-text-muted)]">
                  {creatingType === 'dir' ? (tr ? 'Yeni Klasör:' : 'New Folder:') : tr ? 'Yeni Dosya:' : 'New File:'}
                </span>
                <input
                  autoFocus
                  type="text"
                  value={newItemName}
                  onChange={(e) => setNewItemName(e.target.value)}
                  placeholder={creatingType === 'dir' ? 'klasor_adi' : 'not.txt'}
                  className="px-2.5 py-1 rounded border border-[var(--anka-border-strong)] bg-[var(--anka-surface)] text-[var(--anka-text)] outline-none focus:border-[var(--anka-accent)]"
                />
                <button
                  type="submit"
                  className="px-3 py-1 rounded bg-[var(--anka-accent)] text-[var(--anka-accent-fg)] font-medium hover:bg-[var(--anka-accent-hover)]"
                >
                  {tr ? 'Oluştur' : 'Create'}
                </button>
                <button
                  type="button"
                  onClick={() => setCreatingType(null)}
                  className="px-2 py-1 text-[var(--anka-text-subtle)] hover:text-[var(--anka-text)]"
                >
                  {tr ? 'İptal' : 'Cancel'}
                </button>
              </form>
            )}

            {renamingName && (
              <form onSubmit={handleRenameSubmit} className="flex items-center gap-2 flex-1">
                <span className="font-medium text-[var(--anka-text-muted)]">
                  {tr ? 'Yeni ad:' : 'Rename to:'}
                </span>
                <input
                  autoFocus
                  type="text"
                  value={renameValue}
                  onChange={(e) => setRenameValue(e.target.value)}
                  className="px-2.5 py-1 rounded border border-[var(--anka-border-strong)] bg-[var(--anka-surface)] text-[var(--anka-text)] outline-none focus:border-[var(--anka-accent)]"
                />
                <button
                  type="submit"
                  className="px-3 py-1 rounded bg-[var(--anka-accent)] text-[var(--anka-accent-fg)] font-medium hover:bg-[var(--anka-accent-hover)]"
                >
                  {tr ? 'Kaydet' : 'Save'}
                </button>
                <button
                  type="button"
                  onClick={() => setRenamingName(null)}
                  className="px-2 py-1 text-[var(--anka-text-subtle)] hover:text-[var(--anka-text)]"
                >
                  {tr ? 'İptal' : 'Cancel'}
                </button>
              </form>
            )}

            {errorMsg && <span className="text-rose-500 font-medium">{errorMsg}</span>}
          </div>
        )}

        {/* File Canvas (Supports External & Internal Drag-and-Drop) */}
        <div
          className={`flex-1 overflow-y-auto os-scroll p-4 relative transition-colors ${
            externalDragOver ? 'bg-[var(--anka-accent-soft)]' : ''
          }`}
          onClick={() => {
            setSelectedName(null);
            setItemMenu(null);
          }}
          onDragOver={(e) => {
            if (isInTrash || currentPath === '/proc' || currentPath === '/dev') return;
            e.preventDefault();
            if (e.dataTransfer.types.includes('Files')) {
              setExternalDragOver(true);
            }
          }}
          onDragLeave={(e) => {
            if (e.currentTarget === e.target) setExternalDragOver(false);
          }}
          onDrop={handleDropOnCanvas}
        >
          {externalDragOver && (
            <div className="pointer-events-none mb-3 px-3 py-2 rounded-lg border border-dashed border-[var(--anka-accent)] bg-[var(--anka-surface)] text-xs text-[var(--anka-accent)] flex items-center gap-2">
              <Upload size={14} />
              <span>{tr ? 'Dosyaları bu klasöre içe aktarmak için bırakın' : 'Drop files here to import into VFS'}</span>
            </div>
          )}

          {!currentNode || entries.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-center text-[var(--anka-text-subtle)] space-y-2">
              {isInTrash ? <Trash2 size={36} className="opacity-40" /> : <Folder size={36} className="opacity-40" />}
              <p className="text-sm font-medium text-[var(--anka-text-muted)]">
                {search
                  ? tr
                    ? 'Aramanızla eşleşen öğe yok'
                    : 'No matching items'
                  : isInTrash
                    ? tr
                      ? 'Çöp kutusu boş'
                      : 'Trash is empty'
                    : tr
                      ? 'Bu klasör boş — dışarıdan dosya sürükleyip bırakabilirsiniz'
                      : 'This folder is empty — drag & drop files here'}
              </p>
            </div>
          ) : viewMode === 'grid' ? (
            <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 gap-3">
              {entries.map((item) => {
                const isSelected = selectedName === item.name;
                const itemPath = getItemPath(item.name);
                const isDropFolder = item.type === 'dir' && dropTargetPath === itemPath;
                return (
                  <button
                    key={item.id}
                    draggable={currentPath !== '/proc' && currentPath !== '/dev'}
                    onDragStart={(e) => handleDragStartItem(e, item.name)}
                    onDragOver={(e) => {
                      if (item.type === 'dir' && e.dataTransfer.types.includes(VFS_DRAG_MIME)) {
                        e.preventDefault();
                        e.stopPropagation();
                        setDropTargetPath(itemPath);
                      }
                    }}
                    onDragLeave={() => {
                      if (dropTargetPath === itemPath) setDropTargetPath(null);
                    }}
                    onDrop={(e) => {
                      if (item.type === 'dir') handleDropOnFolder(e, itemPath);
                    }}
                    onClick={(e) => {
                      e.stopPropagation();
                      setSelectedName(item.name);
                      setItemMenu(null);
                    }}
                    onContextMenu={(e) => openItemContextMenu(e, item)}
                    onDoubleClick={() => handleOpen(item)}
                    className={`group flex flex-col items-center p-3 rounded-xl border text-center transition-colors ${
                      isDropFolder
                        ? 'ring-2 ring-[var(--anka-accent)] bg-[var(--anka-accent-soft)] border-[var(--anka-accent)]'
                        : isSelected
                          ? 'bg-[var(--anka-accent-soft)] border-[var(--anka-accent)]'
                          : 'border-transparent hover:bg-[var(--anka-surface-muted)]'
                    }`}
                  >
                    <div className="mb-2">{renderIcon(item, 32)}</div>
                    <span className="text-xs font-medium text-[var(--anka-text)] truncate w-full">
                      {item.name}
                    </span>
                    <span className="text-[11px] text-[var(--anka-text-subtle)] mt-0.5 tabular-nums">
                      {item.type === 'dir'
                        ? `${Object.keys(item.children || {}).length} ${tr ? 'öğe' : 'items'}`
                        : formatBytes(item.size)}
                    </span>
                  </button>
                );
              })}
            </div>
          ) : (
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="border-b border-[var(--anka-border)] text-[var(--anka-text-subtle)]">
                  <th className="py-2 px-2 font-medium">{tr ? 'Ad' : 'Name'}</th>
                  <th className="py-2 px-2 font-medium">{tr ? 'Sahip' : 'Owner'}</th>
                  <th className="py-2 px-2 font-medium">{tr ? 'İzinler' : 'Permissions'}</th>
                  <th className="py-2 px-2 font-medium text-right">{tr ? 'Boyut' : 'Size'}</th>
                </tr>
              </thead>
              <tbody>
                {entries.map((item) => {
                  const isSelected = selectedName === item.name;
                  const itemPath = getItemPath(item.name);
                  const isDropFolder = item.type === 'dir' && dropTargetPath === itemPath;
                  return (
                    <tr
                      key={item.id}
                      draggable={currentPath !== '/proc' && currentPath !== '/dev'}
                      onDragStart={(e) => handleDragStartItem(e, item.name)}
                      onDragOver={(e) => {
                        if (item.type === 'dir' && e.dataTransfer.types.includes(VFS_DRAG_MIME)) {
                          e.preventDefault();
                          e.stopPropagation();
                          setDropTargetPath(itemPath);
                        }
                      }}
                      onDragLeave={() => {
                        if (dropTargetPath === itemPath) setDropTargetPath(null);
                      }}
                      onDrop={(e) => {
                        if (item.type === 'dir') handleDropOnFolder(e, itemPath);
                      }}
                      onClick={(e) => {
                        e.stopPropagation();
                        setSelectedName(item.name);
                        setItemMenu(null);
                      }}
                      onContextMenu={(e) => openItemContextMenu(e, item)}
                      onDoubleClick={() => handleOpen(item)}
                      className={`border-b border-[var(--anka-border)] cursor-pointer ${
                        isDropFolder
                          ? 'bg-[var(--anka-accent-soft)] ring-1 ring-[var(--anka-accent)]'
                          : isSelected
                            ? 'bg-[var(--anka-accent-soft)]'
                            : 'hover:bg-[var(--anka-surface-muted)]'
                      }`}
                    >
                      <td className="py-2 px-2 flex items-center gap-2 font-medium">
                        {renderIcon(item, 16)}
                        <span>{item.name}</span>
                      </td>
                      <td className="py-2 px-2 text-[var(--anka-text-subtle)]">{item.owner}</td>
                      <td className="py-2 px-2 font-mono text-[var(--anka-text-subtle)]">{item.permissions}</td>
                      <td className="py-2 px-2 text-right tabular-nums text-[var(--anka-text-subtle)]">
                        {item.type === 'dir' ? '—' : formatBytes(item.size)}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          )}
        </div>

        <div className="px-4 py-1.5 border-t border-[var(--anka-border)] bg-[var(--anka-surface-muted)] text-[11px] text-[var(--anka-text-subtle)] flex items-center justify-between tabular-nums">
          <span>
            {entries.length} {tr ? 'öğe' : 'items'}
          </span>
          <span>
            {selectedName
              ? `${tr ? 'Seçili:' : 'Selected:'} ${selectedName}`
              : isInTrash
                ? tr
                  ? 'Geri yüklemek veya kalıcı silmek için öğe seçin'
                  : 'Select an item to restore or delete permanently'
                : tr
                  ? 'Sağ tık: Birlikte Aç · Sürükle-bırak ile taşı'
                  : 'Right-click: Open With · Drag & drop to move'}
          </span>
        </div>
      </div>

      {/* Right-Click File/Folder Context Menu */}
      {itemMenu && (
        <div
          style={{ left: itemMenu.x, top: itemMenu.y }}
          onClick={(e) => e.stopPropagation()}
          className="fixed z-50 w-56 rounded-xl border border-[var(--anka-border)] bg-[var(--anka-glass)] backdrop-blur-xl shadow-2xl p-1.5 text-xs text-[var(--anka-text)] space-y-0.5"
        >
          {isInTrash ? (
            <>
              <button
                onClick={() => {
                  handleRestoreSelected(itemMenu.node.name);
                  setItemMenu(null);
                }}
                className="w-full flex items-center gap-2 px-2.5 py-1.5 rounded-lg hover:bg-emerald-500/15 text-emerald-500 text-left font-medium"
              >
                <RotateCcw size={13} />
                <span>{tr ? 'Özgün Konumuna Geri Yükle' : 'Restore Item'}</span>
              </button>
              <button
                onClick={() => {
                  handleDeleteSelected(itemMenu.node.name);
                  setItemMenu(null);
                }}
                className="w-full flex items-center gap-2 px-2.5 py-1.5 rounded-lg hover:bg-rose-500/15 text-rose-500 text-left"
              >
                <Trash2 size={13} />
                <span>{tr ? 'Kalıcı Olarak Sil' : 'Delete Permanently'}</span>
              </button>
            </>
          ) : (
            <>
              <button
                onClick={() => {
                  handleOpen(itemMenu.node);
                  setItemMenu(null);
                }}
                className="w-full flex items-center gap-2 px-2.5 py-1.5 rounded-lg hover:bg-[var(--anka-surface-elevated)] text-left font-medium"
              >
                <FolderOpen size={13} className="text-[var(--anka-accent)]" />
                <span>{tr ? 'Varsayılan ile Aç' : 'Open'}</span>
              </button>

              {itemMenu.node.type === 'dir' ? (
                <button
                  onClick={() => {
                    launchApp('terminal', { cwd: getItemPath(itemMenu.node.name) });
                    setItemMenu(null);
                  }}
                  className="w-full flex items-center gap-2 px-2.5 py-1.5 rounded-lg hover:bg-[var(--anka-surface-elevated)] text-left"
                >
                  <Terminal size={13} />
                  <span>{tr ? 'Uçbirimde Aç' : 'Open in Terminal'}</span>
                </button>
              ) : (
                <>
                  <div className="px-2.5 pt-1 text-[10px] font-semibold text-[var(--anka-text-subtle)]">
                    {tr ? 'Birlikte Aç...' : 'Open With...'}
                  </div>
                  <button
                    onClick={() => {
                      launchApp('editor', { path: getItemPath(itemMenu.node.name) });
                      setItemMenu(null);
                    }}
                    className="w-full flex items-center gap-2 px-2.5 py-1.5 rounded-lg hover:bg-[var(--anka-surface-elevated)] text-left"
                  >
                    <FileCode2 size={13} />
                    <span>{tr ? 'Kod Düzenleyici' : 'Code Editor'}</span>
                  </button>
                  {installedPackages.includes('pkg-markdown') && (
                    <button
                      onClick={() => {
                        launchApp('pkg-markdown', { path: getItemPath(itemMenu.node.name) });
                        setItemMenu(null);
                      }}
                      className="w-full flex items-center gap-2 px-2.5 py-1.5 rounded-lg hover:bg-[var(--anka-surface-elevated)] text-left"
                    >
                      <FileText size={13} />
                      <span>{tr ? 'Markdown Okuyucu' : 'Markdown Reader'}</span>
                    </button>
                  )}
                  {installedPackages.includes('pkg-hex') && (
                    <button
                      onClick={() => {
                        launchApp('pkg-hex', { path: getItemPath(itemMenu.node.name) });
                        setItemMenu(null);
                      }}
                      className="w-full flex items-center gap-2 px-2.5 py-1.5 rounded-lg hover:bg-[var(--anka-surface-elevated)] text-left"
                    >
                      <Binary size={13} className="text-amber-500" />
                      <span>{tr ? 'Hex İnceleyici' : 'Hex Inspector'}</span>
                    </button>
                  )}
                  {installedPackages.includes('pkg-diff') && (
                    <button
                      onClick={() => {
                        launchApp('pkg-diff', { left: getItemPath(itemMenu.node.name) });
                        setItemMenu(null);
                      }}
                      className="w-full flex items-center gap-2 px-2.5 py-1.5 rounded-lg hover:bg-[var(--anka-surface-elevated)] text-left"
                    >
                      <FileDiff size={13} className="text-sky-500" />
                      <span>{tr ? 'Dosya Karşılaştırıcı' : 'Diff Viewer'}</span>
                    </button>
                  )}
                  {isImageNode(itemMenu.node) && itemMenu.node.content && (
                    <button
                      onClick={() => {
                        updateSettings({ customWallpaperUrl: itemMenu.node.content || null });
                        pushNotification(
                          tr ? 'Duvar Kağıdı Güncellendi' : 'Wallpaper Updated',
                          itemMenu.node.name,
                          'settings'
                        );
                        setItemMenu(null);
                      }}
                      className="w-full flex items-center gap-2 px-2.5 py-1.5 rounded-lg hover:bg-[var(--anka-surface-elevated)] text-left"
                    >
                      <Monitor size={13} className="text-[var(--anka-accent)]" />
                      <span>{tr ? 'Duvar Kağıdı Yap' : 'Set as Wallpaper'}</span>
                    </button>
                  )}
                  {/\.(wat|wast|wasm|ankawasm)$/i.test(itemMenu.node.name) && (
                    <button
                      onClick={() => {
                        launchApp('wasm-builder', { path: getItemPath(itemMenu.node.name) });
                        setItemMenu(null);
                      }}
                      className="w-full flex items-center gap-2 px-2.5 py-1.5 rounded-lg hover:bg-[var(--anka-surface-elevated)] text-left"
                    >
                      <ExternalLink size={13} className="text-amber-500" />
                      <span>WASM Studio</span>
                    </button>
                  )}
                </>
              )}

              <div className="h-px bg-[var(--anka-border)] my-1" />
              <button
                onClick={() => {
                  setClipboard({ kind: 'vfs', mode: 'copy', path: getItemPath(itemMenu.node.name) });
                  setItemMenu(null);
                }}
                className="w-full flex items-center gap-2 px-2.5 py-1.5 rounded-lg hover:bg-[var(--anka-surface-elevated)] text-left"
              >
                <Copy size={13} />
                <span>{tr ? 'Kopyala' : 'Copy'}</span>
              </button>
              <button
                onClick={() => {
                  setClipboard({ kind: 'vfs', mode: 'cut', path: getItemPath(itemMenu.node.name) });
                  setItemMenu(null);
                }}
                className="w-full flex items-center gap-2 px-2.5 py-1.5 rounded-lg hover:bg-[var(--anka-surface-elevated)] text-left"
              >
                <Scissors size={13} />
                <span>{tr ? 'Kes' : 'Cut'}</span>
              </button>
              <button
                onClick={() => {
                  setRenamingName(itemMenu.node.name);
                  setRenameValue(itemMenu.node.name);
                  setItemMenu(null);
                }}
                className="w-full flex items-center gap-2 px-2.5 py-1.5 rounded-lg hover:bg-[var(--anka-surface-elevated)] text-left"
              >
                <Pencil size={13} />
                <span>{tr ? 'Yeniden Adlandır' : 'Rename'}</span>
              </button>
              <button
                onClick={() => {
                  setPropsNodeName(itemMenu.node.name);
                  setItemMenu(null);
                }}
                className="w-full flex items-center gap-2 px-2.5 py-1.5 rounded-lg hover:bg-[var(--anka-surface-elevated)] text-left"
              >
                <Shield size={13} />
                <span>{tr ? 'Özellikler & İzinler' : 'Properties'}</span>
              </button>
              <div className="h-px bg-[var(--anka-border)] my-1" />
              <button
                onClick={() => {
                  handleDeleteSelected(itemMenu.node.name);
                  setItemMenu(null);
                }}
                className="w-full flex items-center gap-2 px-2.5 py-1.5 rounded-lg hover:bg-rose-500/10 text-rose-500 text-left"
              >
                <Trash2 size={13} />
                <span>{tr ? 'Çöp Kutusuna Taşı' : 'Move to Trash'}</span>
              </button>
            </>
          )}
        </div>
      )}

      {/* Properties / Permissions Modal */}
      {propsNode && (
        <div
          onClick={() => setPropsNodeName(null)}
          className="absolute inset-0 bg-slate-950/45 backdrop-blur-xs flex items-center justify-center p-4 z-20"
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="w-full max-w-sm rounded-xl border border-[var(--anka-border-strong)] bg-[var(--anka-surface)] text-[var(--anka-text)] shadow-2xl p-4 space-y-4 text-xs"
          >
            <div className="flex items-center justify-between border-b border-[var(--anka-border)] pb-2.5">
              <span className="font-semibold text-sm">{propsNode.name}</span>
              <button
                onClick={() => setPropsNodeName(null)}
                className="text-[var(--anka-text-subtle)] hover:text-[var(--anka-text)]"
              >
                <X size={15} />
              </button>
            </div>
            <div className="space-y-1.5">
              <div className="flex justify-between">
                <span className="text-[var(--anka-text-subtle)]">{tr ? 'Tür:' : 'Type:'}</span>
                <span>{propsNode.type === 'dir' ? 'Klasör' : propsNode.mimeType || 'Dosya'}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-[var(--anka-text-subtle)]">{tr ? 'Sahip:' : 'Owner:'}</span>
                <span className="font-mono">{propsNode.owner}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-[var(--anka-text-subtle)]">{tr ? 'İzinler:' : 'Permissions:'}</span>
                <span className="font-mono">{propsNode.permissions}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-[var(--anka-text-subtle)]">{tr ? 'Boyut:' : 'Size:'}</span>
                <span className="tabular-nums">{formatBytes(propsNode.size)}</span>
              </div>
            </div>

            {propsNode.type === 'file' && (
              <div className="flex items-center gap-2 pt-2 border-t border-[var(--anka-border)]">
                <button
                  onClick={() => chmodNode(getItemPath(propsNode.name), '755')}
                  className="flex-1 py-1.5 rounded-lg border border-[var(--anka-border-strong)] hover:bg-[var(--anka-surface-elevated)] font-mono"
                >
                  chmod 755 (+x)
                </button>
                <button
                  onClick={() => chmodNode(getItemPath(propsNode.name), '644')}
                  className="flex-1 py-1.5 rounded-lg border border-[var(--anka-border-strong)] hover:bg-[var(--anka-surface-elevated)] font-mono"
                >
                  chmod 644 (-x)
                </button>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
