import React, { useCallback, useEffect, useState } from 'react';
import { Bomb, Flag, RotateCcw, Trophy } from 'lucide-react';
import { useOS } from '../os/kernel';

type Difficulty = 'easy' | 'medium' | 'hard';
type GameStatus = 'READY' | 'PLAYING' | 'WON' | 'LOST';

interface Cell {
  row: number;
  col: number;
  isMine: boolean;
  isRevealed: boolean;
  isFlagged: boolean;
  adjacent: number;
}

const DIFFICULTIES: Record<
  Difficulty,
  { rows: number; cols: number; mines: number; labelTr: string; labelEn: string }
> = {
  easy: { rows: 9, cols: 9, mines: 10, labelTr: 'Kolay (9×9)', labelEn: 'Easy (9×9)' },
  medium: { rows: 12, cols: 12, mines: 22, labelTr: 'Orta (12×12)', labelEn: 'Medium (12×12)' },
  hard: { rows: 14, cols: 16, mines: 38, labelTr: 'Zor (14×16)', labelEn: 'Hard (14×16)' },
};

const NUM_COLORS: Record<number, string> = {
  1: 'text-sky-600 dark:text-sky-400',
  2: 'text-emerald-600 dark:text-emerald-400',
  3: 'text-rose-600 dark:text-rose-400',
  4: 'text-indigo-600 dark:text-indigo-400',
  5: 'text-amber-700 dark:text-amber-400',
  6: 'text-teal-600 dark:text-teal-400',
  7: 'text-slate-800 dark:text-slate-200',
  8: 'text-slate-500 dark:text-slate-400',
};

function createEmptyGrid(rows: number, cols: number): Cell[][] {
  return Array.from({ length: rows }, (_, r) =>
    Array.from({ length: cols }, (_, c) => ({
      row: r,
      col: c,
      isMine: false,
      isRevealed: false,
      isFlagged: false,
      adjacent: 0,
    }))
  );
}

function plantMines(
  grid: Cell[][],
  mines: number,
  safeRow: number,
  safeCol: number
): Cell[][] {
  const rows = grid.length;
  const cols = grid[0].length;
  const next = grid.map((row) => row.map((cell) => ({ ...cell })));

  const candidates: [number, number][] = [];
  for (let r = 0; r < rows; r++) {
    for (let c = 0; c < cols; c++) {
      if (Math.abs(r - safeRow) <= 1 && Math.abs(c - safeCol) <= 1) continue;
      candidates.push([r, c]);
    }
  }

  for (let i = candidates.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [candidates[i], candidates[j]] = [candidates[j], candidates[i]];
  }

  for (let i = 0; i < Math.min(mines, candidates.length); i++) {
    const [mr, mc] = candidates[i];
    next[mr][mc].isMine = true;
  }

  for (let r = 0; r < rows; r++) {
    for (let c = 0; c < cols; c++) {
      if (next[r][c].isMine) continue;
      let count = 0;
      for (let dr = -1; dr <= 1; dr++) {
        for (let dc = -1; dc <= 1; dc++) {
          const nr = r + dr;
          const nc = c + dc;
          if (nr >= 0 && nr < rows && nc >= 0 && nc < cols && next[nr][nc].isMine) {
            count += 1;
          }
        }
      }
      next[r][c].adjacent = count;
    }
  }

  return next;
}

function playTone(freq: number, durationMs: number, muted: boolean) {
  if (muted || typeof window === 'undefined' || !window.AudioContext) return;
  try {
    const ctx = new window.AudioContext();
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'sine';
    osc.frequency.value = freq;
    gain.gain.value = 0.05;
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start();
    gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + durationMs / 1000);
    osc.stop(ctx.currentTime + durationMs / 1000);
    setTimeout(() => void ctx.close(), durationMs + 50);
  } catch {
    // Audio unavailable
  }
}

export const MinesweeperApp: React.FC<{ windowId: string }> = () => {
  const { settings } = useOS();
  const tr = settings.language === 'tr';

  const [difficulty, setDifficulty] = useState<Difficulty>('easy');
  const [grid, setGrid] = useState<Cell[][]>(() =>
    createEmptyGrid(DIFFICULTIES.easy.rows, DIFFICULTIES.easy.cols)
  );
  const [status, setStatus] = useState<GameStatus>('READY');
  const [flagMode, setFlagMode] = useState(false);
  const [seconds, setSeconds] = useState(0);
  const [bestTimes, setBestTimes] = useState<Record<Difficulty, number | null>>(() => {
    try {
      const raw = localStorage.getItem('ankaos_mines_best_v1');
      return raw ? JSON.parse(raw) : { easy: null, medium: null, hard: null };
    } catch {
      return { easy: null, medium: null, hard: null };
    }
  });

  const cfg = DIFFICULTIES[difficulty];

  const resetGame = useCallback((diff: Difficulty = difficulty) => {
    const nextCfg = DIFFICULTIES[diff];
    setDifficulty(diff);
    setGrid(createEmptyGrid(nextCfg.rows, nextCfg.cols));
    setStatus('READY');
    setSeconds(0);
    setFlagMode(false);
  }, [difficulty]);

  useEffect(() => {
    if (status !== 'PLAYING') return;
    const id = window.setInterval(() => setSeconds((s) => s + 1), 1000);
    return () => window.clearInterval(id);
  }, [status]);

  const flaggedCount = grid.flat().filter((c) => c.isFlagged).length;
  const remainingMines = cfg.mines - flaggedCount;

  const checkWin = (board: Cell[][]) => {
    for (const row of board) {
      for (const cell of row) {
        if (!cell.isMine && !cell.isRevealed) return false;
      }
    }
    return true;
  };

  const revealCell = (r: number, c: number) => {
    if (status === 'WON' || status === 'LOST') return;
    let working = grid.map((row) => row.map((cell) => ({ ...cell })));
    if (working[r][c].isFlagged || working[r][c].isRevealed) return;

    if (status === 'READY') {
      working = plantMines(working, cfg.mines, r, c);
      setStatus('PLAYING');
    }

    if (working[r][c].isMine) {
      for (const row of working) {
        for (const cell of row) {
          if (cell.isMine) cell.isRevealed = true;
        }
      }
      setGrid(working);
      setStatus('LOST');
      playTone(140, 260, settings.muted);
      return;
    }

    const queue: [number, number][] = [[r, c]];
    while (queue.length > 0) {
      const [cr, cc] = queue.shift()!;
      const cell = working[cr][cc];
      if (cell.isRevealed || cell.isFlagged) continue;
      cell.isRevealed = true;
      if (cell.adjacent === 0) {
        for (let dr = -1; dr <= 1; dr++) {
          for (let dc = -1; dc <= 1; dc++) {
            const nr = cr + dr;
            const nc = cc + dc;
            if (
              nr >= 0 &&
              nr < cfg.rows &&
              nc >= 0 &&
              nc < cfg.cols &&
              !working[nr][nc].isRevealed
            ) {
              queue.push([nr, nc]);
            }
          }
        }
      }
    }

    if (checkWin(working)) {
      setGrid(working);
      setStatus('WON');
      playTone(660, 220, settings.muted);
      const prevBest = bestTimes[difficulty];
      if (prevBest === null || seconds < prevBest) {
        const nextBest = { ...bestTimes, [difficulty]: seconds };
        setBestTimes(nextBest);
        try {
          localStorage.setItem('ankaos_mines_best_v1', JSON.stringify(nextBest));
        } catch {
          // ignore
        }
      }
      return;
    }

    playTone(420, 45, settings.muted);
    setGrid(working);
  };

  const toggleFlag = (r: number, c: number) => {
    if (status === 'WON' || status === 'LOST') return;
    const target = grid[r][c];
    if (target.isRevealed) return;
    const next = grid.map((row) => row.map((cell) => ({ ...cell })));
    next[r][c].isFlagged = !next[r][c].isFlagged;
    setGrid(next);
    playTone(300, 40, settings.muted);
  };

  return (
    <div className="h-full w-full flex flex-col bg-[var(--anka-bg)] text-[var(--anka-text)] select-none anka-theme-transition">
      {/* Header Controls */}
      <div className="px-4 py-2.5 border-b border-[var(--anka-border)] bg-[var(--anka-surface)] flex flex-wrap items-center justify-between gap-2">
        <div className="flex items-center gap-1 p-1 rounded-lg bg-[var(--anka-surface-muted)] border border-[var(--anka-border)]">
          {(['easy', 'medium', 'hard'] as Difficulty[]).map((d) => (
            <button
              key={d}
              onClick={() => resetGame(d)}
              className={`px-2.5 py-1 rounded-md text-xs font-medium whitespace-nowrap transition-colors ${
                difficulty === d
                  ? 'bg-[var(--anka-surface)] text-[var(--anka-text)] shadow-sm'
                  : 'text-[var(--anka-text-subtle)] hover:text-[var(--anka-text)]'
              }`}
            >
              {tr ? DIFFICULTIES[d].labelTr : DIFFICULTIES[d].labelEn}
            </button>
          ))}
        </div>

        <div className="flex items-center gap-2 text-xs font-mono tabular-nums">
          <span className="text-rose-600 dark:text-rose-400 font-semibold">
            {tr ? 'Mayın' : 'Mines'}: {remainingMines}
          </span>
          <span className="text-[var(--anka-text-subtle)]">·</span>
          <span className="text-[var(--anka-accent)] font-semibold">{seconds}s</span>
          {bestTimes[difficulty] !== null && (
            <>
              <span className="text-[var(--anka-text-subtle)]">·</span>
              <span className="text-amber-600 dark:text-amber-400 flex items-center gap-1">
                <Trophy size={12} /> {bestTimes[difficulty]}s
              </span>
            </>
          )}
        </div>

        <div className="flex items-center gap-1.5">
          <button
            onClick={() => setFlagMode((v) => !v)}
            className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-medium border transition-colors ${
              flagMode
                ? 'bg-amber-500 text-slate-950 border-amber-500'
                : 'border-[var(--anka-border-strong)] hover:bg-[var(--anka-surface-elevated)]'
            }`}
          >
            <Flag size={13} />
            <span>{tr ? 'Bayrak Modu' : 'Flag Mode'}</span>
          </button>
          <button
            onClick={() => resetGame(difficulty)}
            className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-medium bg-[var(--anka-accent)] text-[var(--anka-accent-fg)] hover:bg-[var(--anka-accent-hover)] transition-colors"
          >
            <RotateCcw size={13} />
            <span>{tr ? 'Yeni Oyun' : 'New Game'}</span>
          </button>
        </div>
      </div>

      {/* Board */}
      <div className="flex-1 overflow-auto os-scroll p-4 flex flex-col items-center justify-center gap-3">
        {(status === 'WON' || status === 'LOST') && (
          <div
            className={`px-4 py-2 rounded-lg text-xs font-semibold flex items-center gap-3 border ${
              status === 'WON'
                ? 'bg-emerald-500/15 border-emerald-500/40 text-emerald-700 dark:text-emerald-300'
                : 'bg-rose-500/15 border-rose-500/40 text-rose-700 dark:text-rose-300'
            }`}
          >
            <span>
              {status === 'WON'
                ? tr
                  ? `Tebrikler! ${seconds} saniyede tüm mayınları temizlediniz.`
                  : `Cleared all mines in ${seconds}s!`
                : tr
                  ? 'Mayına bastınız! Tekrar deneyin.'
                  : 'Hit a mine! Try again.'}
            </span>
            <button
              onClick={() => resetGame(difficulty)}
              className="underline font-bold hover:opacity-80"
            >
              {tr ? 'Tekrar Oyna' : 'Play Again'}
            </button>
          </div>
        )}

        <div
          className="grid gap-1 p-2.5 rounded-xl border border-[var(--anka-border)] bg-[var(--anka-surface-muted)] shadow-sm"
          style={{ gridTemplateColumns: `repeat(${cfg.cols}, minmax(26px, 30px))` }}
        >
          {grid.map((row) =>
            row.map((cell) => {
              const revealed = cell.isRevealed;
              return (
                <button
                  key={`${cell.row}-${cell.col}`}
                  onClick={() =>
                    flagMode ? toggleFlag(cell.row, cell.col) : revealCell(cell.row, cell.col)
                  }
                  onContextMenu={(e) => {
                    e.preventDefault();
                    toggleFlag(cell.row, cell.col);
                  }}
                  className={`w-7 h-7 rounded text-xs font-bold font-mono flex items-center justify-center transition-colors ${
                    revealed
                      ? cell.isMine
                        ? 'bg-rose-600 text-white'
                        : 'bg-[var(--anka-surface)] border border-[var(--anka-border)]'
                      : 'bg-[var(--anka-surface-elevated)] hover:opacity-85 border border-[var(--anka-border-strong)]'
                  }`}
                >
                  {revealed ? (
                    cell.isMine ? (
                      <Bomb size={14} />
                    ) : cell.adjacent > 0 ? (
                      <span className={NUM_COLORS[cell.adjacent] || ''}>{cell.adjacent}</span>
                    ) : null
                  ) : cell.isFlagged ? (
                    <Flag size={13} className="text-amber-500" />
                  ) : null}
                </button>
              );
            })
          )}
        </div>

        <p className="text-[11px] text-[var(--anka-text-subtle)]">
          {tr
            ? 'Sol tık: Hücre aç · Sağ tık (veya Bayrak Modu): Mayın işaretle'
            : 'Left click: Reveal · Right click (or Flag Mode): Mark mine'}
        </p>
      </div>
    </div>
  );
};
