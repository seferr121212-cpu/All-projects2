import React, { useEffect, useState } from 'react';
import { Flag, Pause, Play, RotateCcw } from 'lucide-react';
import { useOS } from '../os/kernel';

export const TimerApp: React.FC<{ windowId: string }> = () => {
  const { settings } = useOS();
  const tr = settings.language === 'tr';

  const [ms, setMs] = useState(0);
  const [running, setRunning] = useState(false);
  const [laps, setLaps] = useState<number[]>([]);

  useEffect(() => {
    if (!running) return;
    const start = Date.now() - ms;
    const id = window.setInterval(() => setMs(Date.now() - start), 40);
    return () => window.clearInterval(id);
  }, [running]);

  const formatMs = (val: number) => {
    const m = Math.floor(val / 60000);
    const s = Math.floor((val % 60000) / 1000);
    const cs = Math.floor((val % 1000) / 10);
    return `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}.${String(cs).padStart(2, '0')}`;
  };

  return (
    <div className="h-full w-full flex flex-col bg-[var(--anka-surface)] text-[var(--anka-text)] p-5 space-y-5 anka-theme-transition">
      <div className="text-center py-6 rounded-xl border border-[var(--anka-border)] bg-[var(--anka-surface-muted)]">
        <div className="text-4xl font-semibold font-mono tabular-nums">{formatMs(ms)}</div>
      </div>

      <div className="flex items-center justify-center gap-3">
        <button
          onClick={() => setRunning((r) => !r)}
          className="px-4 py-2 rounded-xl bg-[var(--anka-accent)] text-[var(--anka-accent-fg)] text-xs font-semibold flex items-center gap-1.5 hover:bg-[var(--anka-accent-hover)] transition-colors"
        >
          {running ? <Pause size={14} /> : <Play size={14} />}
          <span>{running ? (tr ? 'Durdur' : 'Pause') : tr ? 'Başlat' : 'Start'}</span>
        </button>
        <button
          onClick={() => running && setLaps((l) => [ms, ...l])}
          className="px-3 py-2 rounded-xl border border-[var(--anka-border-strong)] text-xs font-medium flex items-center gap-1.5 hover:bg-[var(--anka-surface-elevated)] transition-colors"
        >
          <Flag size={14} />
          <span>{tr ? 'Tur' : 'Lap'}</span>
        </button>
        <button
          onClick={() => {
            setRunning(false);
            setMs(0);
            setLaps([]);
          }}
          className="px-3 py-2 rounded-xl border border-[var(--anka-border-strong)] text-xs font-medium flex items-center gap-1.5 hover:bg-[var(--anka-surface-elevated)] transition-colors"
        >
          <RotateCcw size={14} />
          <span>{tr ? 'Sıfırla' : 'Reset'}</span>
        </button>
      </div>

      <div className="flex-1 overflow-y-auto os-scroll space-y-1.5 text-xs font-mono tabular-nums">
        {laps.map((l, idx) => (
          <div
            key={idx}
            className="flex justify-between px-3 py-2 rounded-lg bg-[var(--anka-surface-muted)] border border-[var(--anka-border)]"
          >
            <span className="text-[var(--anka-text-subtle)]">
              {tr ? 'Tur' : 'Lap'} #{laps.length - idx}
            </span>
            <span>{formatMs(l)}</span>
          </div>
        ))}
      </div>
    </div>
  );
};
