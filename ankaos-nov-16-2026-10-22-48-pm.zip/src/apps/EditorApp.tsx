import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  ChevronDown,
  ChevronUp,
  Columns2,
  Cpu,
  Eye,
  FileCode2,
  FilePlus,
  FileText,
  Folder,
  FolderOpen,
  FolderSearch,
  Hammer,
  Play,
  Plus,
  Replace,
  Save,
  Search,
  Square,
  Terminal,
  X,
} from 'lucide-react';
import { detectLanguageFromPath, highlightCode } from '../os/highlight';
import { useOS } from '../os/kernel';
import { executeSandboxedJS } from '../os/sandboxRuntime';
import { getNodeAtPath, HOME_PATH, listDir, normalizePath } from '../os/vfs';
import { compileWatToWasm, runWasmOrPackageFromVfsContent } from '../os/wasmCompiler';

interface EditorAppProps {
  windowId: string;
  launchArgs?: Record<string, string>;
}

interface EditorTab {
  id: string;
  filePath: string;
  content: string;
  savedContent: string;
  isUntitled?: boolean;
}

function makeTabId(): string {
  return `tab-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;
}

export const EditorApp: React.FC<EditorAppProps> = ({ windowId, launchArgs }) => {
  const { vfs, writeFile, chmodNode, launchApp, updateWindowTitle, settings, currentUser } = useOS();
  const tr = settings.language === 'tr';
  const userHome = currentUser.homeDir || HOME_PATH;

  const initialPath = launchArgs?.path
    ? normalizePath(launchArgs.path, userHome, userHome)
    : `${userHome}/Projeler/merhaba.js`;

  const [tabs, setTabs] = useState<EditorTab[]>(() => {
    const node = getNodeAtPath(vfs, initialPath);
    const text = node?.type === 'file' ? node.content || '' : '';
    return [
      {
        id: 'tab-initial',
        filePath: initialPath,
        content: text,
        savedContent: text,
      },
    ];
  });
  const [activeTabId, setActiveTabId] = useState<string>('tab-initial');
  const [consoleOutput, setConsoleOutput] = useState<string[]>([]);
  const [showConsole, setShowConsole] = useState(false);
  const [isRunning, setIsRunning] = useState(false);
  const [saveAsOpen, setSaveAsOpen] = useState(false);
  const [saveAsPath, setSaveAsPath] = useState(initialPath);
  const [statusNote, setStatusNote] = useState<string | null>(null);
  const [findOpen, setFindOpen] = useState(false);
  const [findQuery, setFindQuery] = useState('');
  const [replaceQuery, setReplaceQuery] = useState('');
  const [findCaseSensitive, setFindCaseSensitive] = useState(false);
  const [activeMatchIdx, setActiveMatchIdx] = useState(0);
  const [cursorPos, setCursorPos] = useState({ line: 1, col: 1 });
  const [openPickerOpen, setOpenPickerOpen] = useState(false);
  const [pickerDir, setPickerDir] = useState(userHome);
  const [htmlPreviewOpen, setHtmlPreviewOpen] = useState(false);
  const [splitTabId, setSplitTabId] = useState<string | null>(null);
  const [globalFindOpen, setGlobalFindOpen] = useState(false);
  const [globalQuery, setGlobalQuery] = useState('');

  const abortRunnerRef = useRef<(() => void) | null>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const preRef = useRef<HTMLPreElement>(null);
  const gutterRef = useRef<HTMLDivElement>(null);
  const splitTextareaRef = useRef<HTMLTextAreaElement>(null);
  const splitPreRef = useRef<HTMLPreElement>(null);
  const splitGutterRef = useRef<HTMLDivElement>(null);
  const findInputRef = useRef<HTMLInputElement>(null);

  const activeTab = useMemo(
    () => tabs.find((t) => t.id === activeTabId) || tabs[0],
    [tabs, activeTabId]
  );

  // Open or focus tab when launchArgs.path changes
  useEffect(() => {
    if (!launchArgs?.path) return;
    const norm = normalizePath(launchArgs.path, userHome, userHome);
    const node = getNodeAtPath(vfs, norm);
    const text = node?.type === 'file' ? node.content || '' : '';

    setTabs((prev) => {
      const existing = prev.find((t) => t.filePath === norm);
      if (existing) {
        setActiveTabId(existing.id);
        return prev;
      }
      // Replace clean untitled tab if present
      if (
        prev.length === 1 &&
        prev[0].isUntitled &&
        prev[0].content === prev[0].savedContent
      ) {
        const replaced: EditorTab = {
          id: prev[0].id,
          filePath: norm,
          content: text,
          savedContent: text,
        };
        setActiveTabId(replaced.id);
        return [replaced];
      }
      const nextTab: EditorTab = {
        id: makeTabId(),
        filePath: norm,
        content: text,
        savedContent: text,
      };
      setActiveTabId(nextTab.id);
      return [...prev, nextTab];
    });
  }, [launchArgs?.path, userHome]);

  const isDirty = activeTab.content !== activeTab.savedContent;
  const isJavaScript = /\.(js|mjs)$/i.test(activeTab.filePath);
  const isWat = /\.(wat|wast)$/i.test(activeTab.filePath);
  const isWasm = /\.(wasm|ankawasm)$/i.test(activeTab.filePath);
  const isHtml = /\.(html|htm)$/i.test(activeTab.filePath);
  const isShell = /\.(sh|ankashrc)$/i.test(activeTab.filePath) || activeTab.filePath.startsWith('/bin/');
  const lang = useMemo(() => detectLanguageFromPath(activeTab.filePath), [activeTab.filePath]);

  useEffect(() => {
    const fileName = activeTab.filePath.split('/').pop() || 'Adsız';
    updateWindowTitle(
      windowId,
      `${fileName}${isDirty ? ' *' : ''} — ${tr ? 'Kod Düzenleyici' : 'Code Editor'}`
    );
  }, [activeTab.filePath, isDirty, windowId, tr, updateWindowTitle]);

  useEffect(() => {
    return () => {
      abortRunnerRef.current?.();
    };
  }, []);

  const updateTabContent = (tabId: string, nextContent: string) => {
    setTabs((prev) =>
      prev.map((t) => (t.id === tabId ? { ...t, content: nextContent } : t))
    );
  };

  const updateActiveContent = (nextContent: string) => {
    updateTabContent(activeTab.id, nextContent);
  };

  const openVfsFileInTab = (rawPath: string) => {
    const norm = normalizePath(rawPath, userHome, userHome);
    const node = getNodeAtPath(vfs, norm);
    if (!node || node.type !== 'file') return;
    const text = node.content || '';
    setTabs((prev) => {
      const existing = prev.find((t) => t.filePath === norm);
      if (existing) {
        setActiveTabId(existing.id);
        return prev;
      }
      const nextTab: EditorTab = {
        id: makeTabId(),
        filePath: norm,
        content: text,
        savedContent: text,
      };
      setActiveTabId(nextTab.id);
      return [...prev, nextTab];
    });
    setOpenPickerOpen(false);
  };

  const updateCursorTracking = (el: HTMLTextAreaElement | null) => {
    if (!el) return;
    const pos = el.selectionStart || 0;
    const before = el.value.slice(0, pos);
    const lines = before.split('\n');
    setCursorPos({
      line: lines.length,
      col: (lines[lines.length - 1]?.length || 0) + 1,
    });
  };

  const findMatches = useMemo(() => {
    if (!findQuery) return [];
    const hay = findCaseSensitive ? activeTab.content : activeTab.content.toLowerCase();
    const needle = findCaseSensitive ? findQuery : findQuery.toLowerCase();
    const indices: number[] = [];
    let pos = 0;
    while (pos <= hay.length - needle.length) {
      const idx = hay.indexOf(needle, pos);
      if (idx === -1) break;
      indices.push(idx);
      pos = idx + Math.max(1, needle.length);
    }
    return indices;
  }, [activeTab.content, findQuery, findCaseSensitive]);

  const jumpToMatch = (idx: number) => {
    if (findMatches.length === 0) return;
    const wrapped = ((idx % findMatches.length) + findMatches.length) % findMatches.length;
    setActiveMatchIdx(wrapped);
    const start = findMatches[wrapped];
    const end = start + findQuery.length;
    const ta = textareaRef.current;
    if (ta) {
      ta.focus();
      ta.setSelectionRange(start, end);
      updateCursorTracking(ta);
    }
  };

  const handleReplaceCurrent = () => {
    if (findMatches.length === 0 || !findQuery) return;
    const wrapped = activeMatchIdx % findMatches.length;
    const pos = findMatches[wrapped];
    const next =
      activeTab.content.slice(0, pos) +
      replaceQuery +
      activeTab.content.slice(pos + findQuery.length);
    updateActiveContent(next);
  };

  const handleReplaceAll = () => {
    if (findMatches.length === 0 || !findQuery) return;
    const escaped = findQuery.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    const rx = new RegExp(escaped, findCaseSensitive ? 'g' : 'gi');
    updateActiveContent(activeTab.content.replace(rx, replaceQuery));
    setStatusNote(tr ? `${findMatches.length} değişiklik yapıldı` : `Replaced ${findMatches.length}`);
    setTimeout(() => setStatusNote(null), 1800);
  };

  const handleNewTab = () => {
    const untitledNum = tabs.filter((t) => t.isUntitled).length + 1;
    const newPath = `${userHome}/Projeler/adsiz_${untitledNum}.js`;
    const newTab: EditorTab = {
      id: makeTabId(),
      filePath: newPath,
      content: '// Yeni AnkaOS betiği\nconsole.log("Merhaba AnkaOS!");\n',
      savedContent: '',
      isUntitled: true,
    };
    setTabs((prev) => [...prev, newTab]);
    setActiveTabId(newTab.id);
  };

  const handleCloseTab = (tabId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setTabs((prev) => {
      if (prev.length <= 1) {
        const blank: EditorTab = {
          id: makeTabId(),
          filePath: `${userHome}/Projeler/adsiz.js`,
          content: '',
          savedContent: '',
          isUntitled: true,
        };
        setActiveTabId(blank.id);
        return [blank];
      }
      const idx = prev.findIndex((t) => t.id === tabId);
      const filtered = prev.filter((t) => t.id !== tabId);
      if (tabId === activeTabId) {
        const nextActive = filtered[Math.max(0, idx - 1)] || filtered[0];
        setActiveTabId(nextActive.id);
      }
      return filtered;
    });
  };

  const handleSave = () => {
    const res = writeFile(activeTab.filePath, activeTab.content, undefined, false, 'editor');
    if (res.ok) {
      setTabs((prev) =>
        prev.map((t) =>
          t.id === activeTab.id ? { ...t, savedContent: t.content, isUntitled: false } : t
        )
      );
      setStatusNote(tr ? 'Kaydedildi' : 'Saved');
      setTimeout(() => setStatusNote(null), 1800);
    } else {
      setStatusNote(res.error || 'Hata');
    }
  };

  const handleSaveAs = (e: React.FormEvent) => {
    e.preventDefault();
    const norm = normalizePath(saveAsPath, userHome, userHome);
    const res = writeFile(norm, activeTab.content, undefined, false, 'editor');
    if (res.ok) {
      setTabs((prev) =>
        prev.map((t) =>
          t.id === activeTab.id
            ? { ...t, filePath: norm, savedContent: t.content, isUntitled: false }
            : t
        )
      );
      setSaveAsOpen(false);
      setStatusNote(tr ? 'Farklı kaydedildi' : 'Saved as new file');
      setTimeout(() => setStatusNote(null), 1800);
    } else {
      setStatusNote(res.error || 'Kaydedilemedi');
    }
  };

  const handleRunJS = async () => {
    if (isRunning) return;
    setShowConsole(true);
    setIsRunning(true);
    setConsoleOutput([
      `[INFO] Ring 3 Web Worker başlatılıyor (Watchdog: 2000 ms)...`,
    ]);

    const { promise, abort } = executeSandboxedJS(activeTab.content, {
      timeoutMs: 2000,
      onLog: (line) => {
        setConsoleOutput((prev) => [...prev, line]);
      },
    });
    abortRunnerRef.current = abort;

    const result = await promise;
    abortRunnerRef.current = null;
    setIsRunning(false);

    if (result.ok) {
      setConsoleOutput((prev) => [
        ...prev,
        ...(result.logs.length === 0 ? [tr ? '(Çıktı üretilmedi)' : '(No output)'] : []),
        `[OK] ${result.runtime} tamamlandı (${result.durationMs} ms)`,
      ]);
    } else {
      setConsoleOutput((prev) => [
        ...prev,
        `[HATA] ${result.error || 'Çalıştırma hatası'} (${result.durationMs} ms)`,
      ]);
    }
  };

  const handleRunWasm = async () => {
    setShowConsole(true);
    setConsoleOutput(['[INFO] WebAssembly modülü doğrulanıyor ve yükleniyor...']);
    const res = await runWasmOrPackageFromVfsContent(activeTab.content);
    if (!res.ok) {
      setConsoleOutput([`[HATA] ${res.error}`]);
      return;
    }
    const lines = [
      `[OK] WebAssembly.instantiate başarılı (${res.byteLength} bayt, ${res.durationMs} ms)`,
      `[INFO] Dışa aktarılanlar: ${res.exportsList.join(', ') || '(yok)'}`,
    ];
    if (res.invoked) {
      lines.push(
        `[SONUÇ] ${res.invoked.fn}(${res.invoked.args.join(', ')}) => ${String(res.invoked.result)}`
      );
    }
    setConsoleOutput(lines);
  };

  const handleCompileWat = () => {
    setShowConsole(true);
    const compiled = compileWatToWasm(activeTab.content);
    if (!compiled.ok || !compiled.base64Content) {
      setConsoleOutput([`[HATA] WAT derleme başarısız: ${compiled.error || 'Bilinmeyen hata'}`]);
      return;
    }
    const targetWasm = activeTab.filePath.replace(/\.(wat|wast)$/i, '.wasm');
    const wRes = writeFile(targetWasm, compiled.base64Content, 'application/wasm', false, 'editor');
    if (wRes.ok) {
      chmodNode(targetWasm, '+x', false);
    }
    setConsoleOutput([
      `[OK] WAT -> WASM derlendi (${compiled.sizeBytes} B, ${compiled.compileTimeMs} ms)`,
      wRes.ok
        ? `[VFS] İkili kaydedildi: ${targetWasm}`
        : `[UYARI] VFS yazma hatası: ${wRes.error || 'İzin yok'}`,
      `[INFO] Dışa aktarılanlar: ${compiled.exports.map((e) => e.name).join(', ') || '(yok)'}`,
    ]);
  };

  const handleStopRunner = () => {
    abortRunnerRef.current?.();
    abortRunnerRef.current = null;
    setIsRunning(false);
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 's') {
      e.preventDefault();
      handleSave();
    } else if ((e.ctrlKey || e.metaKey) && (e.key.toLowerCase() === 'f' || e.key.toLowerCase() === 'h')) {
      e.preventDefault();
      setFindOpen(true);
      setTimeout(() => findInputRef.current?.focus(), 30);
    } else if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'o') {
      e.preventDefault();
      setOpenPickerOpen(true);
    } else if (e.key === 'Tab') {
      e.preventDefault();
      const target = e.currentTarget;
      const start = target.selectionStart;
      const end = target.selectionEnd;
      const next = activeTab.content.slice(0, start) + '  ' + activeTab.content.slice(end);
      updateActiveContent(next);
      requestAnimationFrame(() => {
        target.selectionStart = target.selectionEnd = start + 2;
        updateCursorTracking(target);
      });
    }
  };

  const handleScroll = () => {
    const ta = textareaRef.current;
    if (!ta) return;
    if (preRef.current) {
      preRef.current.scrollTop = ta.scrollTop;
      preRef.current.scrollLeft = ta.scrollLeft;
    }
    if (gutterRef.current) {
      gutterRef.current.scrollTop = ta.scrollTop;
    }
  };

  const handleSplitScroll = () => {
    const ta = splitTextareaRef.current;
    if (!ta) return;
    if (splitPreRef.current) {
      splitPreRef.current.scrollTop = ta.scrollTop;
      splitPreRef.current.scrollLeft = ta.scrollLeft;
    }
    if (splitGutterRef.current) {
      splitGutterRef.current.scrollTop = ta.scrollTop;
    }
  };

  const lineCount = useMemo(
    () => Math.max(1, activeTab.content.split('\n').length),
    [activeTab.content]
  );

  const highlightedNodes = useMemo(
    () => highlightCode(activeTab.content, lang),
    [activeTab.content, lang]
  );

  const splitTab = useMemo(() => {
    if (!splitTabId) return null;
    return tabs.find((t) => t.id === splitTabId) || activeTab;
  }, [splitTabId, tabs, activeTab]);

  const splitLang = useMemo(
    () => (splitTab ? detectLanguageFromPath(splitTab.filePath) : 'text'),
    [splitTab]
  );

  const splitLineCount = useMemo(
    () => (splitTab ? Math.max(1, splitTab.content.split('\n').length) : 1),
    [splitTab]
  );

  const splitHighlightedNodes = useMemo(
    () => (splitTab ? highlightCode(splitTab.content, splitLang) : null),
    [splitTab, splitLang]
  );

  const globalSearchHits = useMemo(() => {
    const q = globalQuery.trim().toLowerCase();
    if (!globalFindOpen || q.length < 2) return [];
    const results: Array<{ path: string; line: number; preview: string }> = [];
    const visited = new Set<string>();

    const scanDir = (dirPath: string) => {
      if (results.length >= 60 || visited.has(dirPath)) return;
      visited.add(dirPath);
      const entries = listDir(vfs, dirPath);
      for (const entry of entries) {
        if (results.length >= 60) break;
        const full = dirPath === '/' ? `/${entry.name}` : `${dirPath}/${entry.name}`;
        if (entry.type === 'dir') {
          if (entry.name === '.Trash' || entry.name === 'Resimler' || entry.name === 'Müzik') continue;
          scanDir(full);
          continue;
        }
        if (
          entry.mimeType?.startsWith('image/') ||
          entry.mimeType?.startsWith('audio/') ||
          /\.(wasm|png|jpg|jpeg|webp|ankasynth|webm)$/i.test(entry.name)
        ) {
          continue;
        }
        const content = entry.content || '';
        const lines = content.split('\n');
        for (let idx = 0; idx < lines.length; idx++) {
          if (lines[idx].toLowerCase().includes(q)) {
            results.push({
              path: full,
              line: idx + 1,
              preview: lines[idx].trim().slice(0, 110),
            });
            if (results.length >= 60) break;
          }
        }
      }
    };

    scanDir(userHome);
    scanDir('/etc');
    return results;
  }, [globalFindOpen, globalQuery, vfs, userHome]);

  return (
    <div className="h-full w-full flex flex-col bg-[var(--anka-surface)] text-[var(--anka-text)] anka-theme-transition">
      {/* Multi-Tab Strip */}
      <div className="flex items-center gap-1 px-2 pt-1.5 border-b border-[var(--anka-border)] bg-[var(--anka-bg)] overflow-x-auto os-scroll shrink-0">
        {tabs.map((tab) => {
          const active = tab.id === activeTab.id;
          const dirty = tab.content !== tab.savedContent;
          const fileName = tab.filePath.split('/').pop() || 'adsiz';
          return (
            <div
              key={tab.id}
              onClick={() => setActiveTabId(tab.id)}
              className={`group flex items-center gap-2 px-3 py-1.5 rounded-t-lg text-xs cursor-pointer border border-b-0 transition-colors shrink-0 ${
                active
                  ? 'bg-[var(--anka-surface-muted)] border-[var(--anka-border)] text-[var(--anka-text)] font-medium'
                  : 'bg-transparent border-transparent text-[var(--anka-text-subtle)] hover:bg-[var(--anka-surface)] hover:text-[var(--anka-text)]'
              }`}
            >
              <FileCode2 size={12} className={active ? 'text-[var(--anka-accent)]' : 'opacity-60'} />
              <span className="max-w-[140px] truncate">{fileName}</span>
              {dirty && <span className="w-1.5 h-1.5 rounded-full bg-amber-500 shrink-0" />}
              <button
                onClick={(e) => handleCloseTab(tab.id, e)}
                title={tr ? 'Sekmeyi Kapat' : 'Close Tab'}
                className="p-0.5 rounded hover:bg-[var(--anka-surface-elevated)] text-[var(--anka-text-subtle)] hover:text-[var(--anka-text)]"
              >
                <X size={11} />
              </button>
            </div>
          );
        })}
        <button
          onClick={handleNewTab}
          title={tr ? 'Yeni Sekme' : 'New Tab'}
          className="p-1.5 mb-0.5 rounded-md text-[var(--anka-text-subtle)] hover:text-[var(--anka-text)] hover:bg-[var(--anka-surface)] transition-colors shrink-0"
        >
          <Plus size={13} />
        </button>
      </div>

      {/* Toolbar */}
      <div className="px-3 py-2 border-b border-[var(--anka-border)] bg-[var(--anka-surface-muted)] flex items-center justify-between gap-3">
        <div className="flex items-center gap-2 min-w-0">
          <span className="text-xs font-mono text-[var(--anka-text-muted)] truncate">
            {activeTab.filePath}
          </span>
          {isDirty && (
            <span className="text-[11px] text-amber-600 dark:text-amber-400 font-medium shrink-0">
              · {tr ? 'Değiştirildi' : 'Modified'}
            </span>
          )}
          {statusNote && (
            <span className="text-[11px] text-emerald-600 dark:text-emerald-400 font-medium shrink-0">
              · {statusNote}
            </span>
          )}
        </div>

        <div className="flex items-center gap-1.5 shrink-0">
          <button
            onClick={() => {
              setPickerDir(userHome);
              setOpenPickerOpen(true);
            }}
            title={tr ? 'VFS Dosyası Aç (Ctrl+O)' : 'Open VFS File (Ctrl+O)'}
            className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-xs font-medium border border-[var(--anka-border-strong)] hover:bg-[var(--anka-surface-elevated)] transition-colors"
          >
            <FolderOpen size={13} />
            <span>{tr ? 'Aç' : 'Open'}</span>
          </button>

          <button
            onClick={() => {
              setFindOpen((v) => !v);
              setTimeout(() => findInputRef.current?.focus(), 30);
            }}
            title={tr ? 'Bul ve Değiştir (Ctrl+F)' : 'Find & Replace (Ctrl+F)'}
            className={`p-1.5 rounded-lg border text-xs transition-colors ${
              findOpen
                ? 'border-[var(--anka-accent)] bg-[var(--anka-accent-soft)] text-[var(--anka-accent)]'
                : 'border-[var(--anka-border-strong)] hover:bg-[var(--anka-surface-elevated)]'
            }`}
          >
            <Search size={13} />
          </button>

          <button
            onClick={() => setGlobalFindOpen(true)}
            title={tr ? 'Tüm VFS Dosyalarında Ara' : 'Find Across VFS Files'}
            className="flex items-center gap-1 px-2 py-1.5 rounded-lg border border-[var(--anka-border-strong)] hover:bg-[var(--anka-surface-elevated)] text-xs font-medium transition-colors whitespace-nowrap"
          >
            <FolderSearch size={13} />
            <span className="hidden lg:inline">{tr ? 'VFS Ara' : 'VFS Find'}</span>
          </button>

          <button
            onClick={() => {
              if (splitTabId) {
                setSplitTabId(null);
              } else {
                setHtmlPreviewOpen(false);
                const other = tabs.find((t) => t.id !== activeTab.id);
                setSplitTabId(other ? other.id : activeTab.id);
              }
            }}
            title={tr ? 'Bölünmüş Görünüm' : 'Split View'}
            className={`p-1.5 rounded-lg border text-xs transition-colors ${
              splitTabId
                ? 'border-[var(--anka-accent)] bg-[var(--anka-accent-soft)] text-[var(--anka-accent)]'
                : 'border-[var(--anka-border-strong)] hover:bg-[var(--anka-surface-elevated)]'
            }`}
          >
            <Columns2 size={13} />
          </button>

          <button
            onClick={() => {
              setSaveAsPath(activeTab.filePath);
              setSaveAsOpen((v) => !v);
            }}
            className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-medium border border-[var(--anka-border-strong)] hover:bg-[var(--anka-surface-elevated)] transition-colors"
          >
            <FilePlus size={13} />
            <span>{tr ? 'Farklı Kaydet' : 'Save As'}</span>
          </button>

          <button
            onClick={handleSave}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium bg-[var(--anka-accent)] text-[var(--anka-accent-fg)] hover:bg-[var(--anka-accent-hover)] transition-colors"
          >
            <Save size={13} />
            <span>{tr ? 'Kaydet' : 'Save'}</span>
          </button>

          {isHtml && (
            <button
              onClick={() => setHtmlPreviewOpen((v) => !v)}
              className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-medium border transition-colors ${
                htmlPreviewOpen
                  ? 'border-[var(--anka-accent)] bg-[var(--anka-accent-soft)] text-[var(--anka-accent)]'
                  : 'border-[var(--anka-border-strong)] hover:bg-[var(--anka-surface-elevated)]'
              }`}
            >
              <Eye size={13} />
              <span>{tr ? 'Canlı Önizleme' : 'Live Preview'}</span>
            </button>
          )}

          {isShell && (
            <button
              onClick={() => launchApp('terminal', { cwd: userHome })}
              className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-medium bg-emerald-600 text-white hover:bg-emerald-500 transition-colors"
            >
              <Terminal size={13} />
              <span>{tr ? 'Uçbirimde Çalıştır' : 'Open Terminal'}</span>
            </button>
          )}

          {isJavaScript && !isRunning && (
            <button
              onClick={handleRunJS}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium bg-emerald-600 text-white hover:bg-emerald-500 transition-colors"
            >
              <Play size={13} />
              <span>{tr ? 'Worker Çalıştır' : 'Run Worker'}</span>
            </button>
          )}

          {isJavaScript && isRunning && (
            <button
              onClick={handleStopRunner}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium bg-rose-600 text-white hover:bg-rose-500 transition-colors"
            >
              <Square size={12} />
              <span>{tr ? 'Durdur (SIGKILL)' : 'Stop (SIGKILL)'}</span>
            </button>
          )}

          {isWasm && (
            <button
              onClick={handleRunWasm}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium bg-amber-600 text-white hover:bg-amber-500 transition-colors"
            >
              <Cpu size={13} />
              <span>{tr ? 'WASM Çalıştır' : 'Run WASM'}</span>
            </button>
          )}

          {isWat && (
            <>
              <button
                onClick={handleCompileWat}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium bg-emerald-600 text-white hover:bg-emerald-500 transition-colors"
              >
                <Hammer size={13} />
                <span>{tr ? 'WASM Derle' : 'Compile WASM'}</span>
              </button>
              <button
                onClick={() => launchApp('wasm-builder', { path: activeTab.filePath })}
                className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-medium bg-amber-600 text-white hover:bg-amber-500 transition-colors"
              >
                <Cpu size={13} />
                <span>WASM Studio</span>
              </button>
            </>
          )}
        </div>
      </div>

      {/* Find & Replace Bar */}
      {findOpen && (
        <div className="px-3 py-2 border-b border-[var(--anka-border)] bg-[var(--anka-surface-muted)] flex flex-wrap items-center gap-2 text-xs">
          <div className="flex items-center gap-1.5">
            <Search size={13} className="text-[var(--anka-text-subtle)]" />
            <input
              ref={findInputRef}
              type="text"
              value={findQuery}
              onChange={(e) => {
                setFindQuery(e.target.value);
                setActiveMatchIdx(0);
              }}
              onKeyDown={(e) => {
                if (e.key === 'Enter') {
                  e.preventDefault();
                  jumpToMatch(e.shiftKey ? activeMatchIdx - 1 : activeMatchIdx + 1);
                } else if (e.key === 'Escape') {
                  setFindOpen(false);
                }
              }}
              placeholder={tr ? 'Bul...' : 'Find...'}
              className="w-40 px-2.5 py-1 rounded border border-[var(--anka-border-strong)] bg-[var(--anka-surface)] font-mono outline-none focus:border-[var(--anka-accent)]"
            />
            <span className="font-mono text-[11px] text-[var(--anka-text-subtle)] tabular-nums w-14 text-center">
              {findMatches.length > 0
                ? `${(activeMatchIdx % findMatches.length) + 1}/${findMatches.length}`
                : '0/0'}
            </span>
            <button
              onClick={() => jumpToMatch(activeMatchIdx - 1)}
              className="p-1 rounded hover:bg-[var(--anka-surface-elevated)]"
              title={tr ? 'Önceki' : 'Previous'}
            >
              <ChevronUp size={13} />
            </button>
            <button
              onClick={() => jumpToMatch(activeMatchIdx + 1)}
              className="p-1 rounded hover:bg-[var(--anka-surface-elevated)]"
              title={tr ? 'Sonraki' : 'Next'}
            >
              <ChevronDown size={13} />
            </button>
            <button
              onClick={() => setFindCaseSensitive((v) => !v)}
              className={`px-1.5 py-0.5 rounded font-mono text-[11px] border ${
                findCaseSensitive
                  ? 'border-[var(--anka-accent)] bg-[var(--anka-accent-soft)] text-[var(--anka-accent)]'
                  : 'border-[var(--anka-border)] text-[var(--anka-text-subtle)]'
              }`}
              title={tr ? 'Büyük/Küçük Harf Duyarlı' : 'Case Sensitive'}
            >
              Aa
            </button>
          </div>
          <div className="flex items-center gap-1.5">
            <Replace size={13} className="text-[var(--anka-text-subtle)]" />
            <input
              type="text"
              value={replaceQuery}
              onChange={(e) => setReplaceQuery(e.target.value)}
              placeholder={tr ? 'Değiştir...' : 'Replace...'}
              className="w-36 px-2.5 py-1 rounded border border-[var(--anka-border-strong)] bg-[var(--anka-surface)] font-mono outline-none focus:border-[var(--anka-accent)]"
            />
            <button
              onClick={handleReplaceCurrent}
              disabled={findMatches.length === 0}
              className="px-2 py-1 rounded border border-[var(--anka-border-strong)] hover:bg-[var(--anka-surface-elevated)] disabled:opacity-40"
            >
              {tr ? 'Değiştir' : 'Replace'}
            </button>
            <button
              onClick={handleReplaceAll}
              disabled={findMatches.length === 0}
              className="px-2 py-1 rounded border border-[var(--anka-border-strong)] hover:bg-[var(--anka-surface-elevated)] disabled:opacity-40"
            >
              {tr ? 'Tümünü' : 'All'}
            </button>
          </div>
          <button
            onClick={() => setFindOpen(false)}
            className="ml-auto p-1 text-[var(--anka-text-subtle)] hover:text-[var(--anka-text)]"
          >
            <X size={13} />
          </button>
        </div>
      )}

      {/* Save As Bar */}
      {saveAsOpen && (
        <form
          onSubmit={handleSaveAs}
          className="px-3 py-2 border-b border-[var(--anka-border)] bg-[var(--anka-surface-muted)] flex items-center gap-2 text-xs"
        >
          <span className="font-medium text-[var(--anka-text-muted)]">
            {tr ? 'Hedef Yol:' : 'Target Path:'}
          </span>
          <input
            autoFocus
            type="text"
            value={saveAsPath}
            onChange={(e) => setSaveAsPath(e.target.value)}
            className="flex-1 px-2.5 py-1 rounded border border-[var(--anka-border-strong)] bg-[var(--anka-surface)] text-[var(--anka-text)] font-mono outline-none focus:border-[var(--anka-accent)]"
          />
          <button
            type="submit"
            className="px-3 py-1 rounded bg-[var(--anka-accent)] text-[var(--anka-accent-fg)] font-medium hover:bg-[var(--anka-accent-hover)]"
          >
            {tr ? 'Onayla' : 'Confirm'}
          </button>
          <button
            type="button"
            onClick={() => setSaveAsOpen(false)}
            className="px-2 py-1 text-[var(--anka-text-subtle)] hover:text-[var(--anka-text)]"
          >
            {tr ? 'İptal' : 'Cancel'}
          </button>
        </form>
      )}

      {/* Editor Area with Synchronized Syntax Highlighting Overlay + Optional HTML Split Preview */}
      <div className="flex-1 flex min-h-0 overflow-hidden bg-[var(--anka-surface)] relative">
        <div
          ref={gutterRef}
          className="w-12 shrink-0 py-3 pr-2 text-right font-mono text-xs leading-6 text-[var(--anka-text-subtle)] bg-[var(--anka-surface-muted)] border-r border-[var(--anka-border)] overflow-hidden select-none tabular-nums"
        >
          {Array.from({ length: lineCount }, (_, i) => (
            <div key={i}>{i + 1}</div>
          ))}
        </div>

        <div className="relative flex-1 min-w-0 h-full overflow-hidden">
          <pre
            ref={preRef}
            aria-hidden="true"
            className="absolute inset-0 m-0 p-3 font-mono text-[13px] leading-6 whitespace-pre overflow-hidden pointer-events-none select-none text-[var(--anka-text)]"
          >
            {highlightedNodes}
          </pre>
          <textarea
            ref={textareaRef}
            value={activeTab.content}
            onChange={(e) => {
              updateActiveContent(e.target.value);
              updateCursorTracking(e.currentTarget);
            }}
            onClick={(e) => updateCursorTracking(e.currentTarget)}
            onKeyUp={(e) => updateCursorTracking(e.currentTarget)}
            onScroll={handleScroll}
            onKeyDown={handleKeyDown}
            spellCheck={false}
            wrap="off"
            style={{ caretColor: 'var(--anka-accent)' }}
            className="relative z-10 w-full h-full p-3 font-mono text-[13px] leading-6 bg-transparent text-transparent outline-none resize-none overflow-auto os-scroll select-text selection:bg-sky-500/30 whitespace-pre"
          />
        </div>

        {splitTab && (
          <div className="w-1/2 border-l border-[var(--anka-border)] flex flex-col min-w-0 bg-[var(--anka-surface)]">
            <div className="px-2.5 py-1 bg-[var(--anka-surface-muted)] border-b border-[var(--anka-border)] flex items-center justify-between gap-2 text-[11px]">
              <select
                value={splitTab.id}
                onChange={(e) => setSplitTabId(e.target.value)}
                className="min-w-0 flex-1 bg-transparent font-mono text-[var(--anka-text)] outline-none cursor-pointer truncate"
              >
                {tabs.map((t) => (
                  <option key={t.id} value={t.id} className="bg-[var(--anka-surface)] text-[var(--anka-text)]">
                    {t.filePath}
                  </option>
                ))}
              </select>
              <button
                onClick={() => setSplitTabId(null)}
                className="p-0.5 rounded hover:bg-[var(--anka-surface-elevated)] text-[var(--anka-text-subtle)] shrink-0"
              >
                <X size={12} />
              </button>
            </div>
            <div className="flex-1 flex min-h-0 overflow-hidden">
              <div
                ref={splitGutterRef}
                className="w-10 shrink-0 py-3 pr-2 text-right font-mono text-xs leading-6 text-[var(--anka-text-subtle)] bg-[var(--anka-surface-muted)] border-r border-[var(--anka-border)] overflow-hidden select-none tabular-nums"
              >
                {Array.from({ length: splitLineCount }, (_, i) => (
                  <div key={i}>{i + 1}</div>
                ))}
              </div>
              <div className="relative flex-1 min-w-0 h-full overflow-hidden">
                <pre
                  ref={splitPreRef}
                  aria-hidden="true"
                  className="absolute inset-0 m-0 p-3 font-mono text-[13px] leading-6 whitespace-pre overflow-hidden pointer-events-none select-none text-[var(--anka-text)]"
                >
                  {splitHighlightedNodes}
                </pre>
                <textarea
                  ref={splitTextareaRef}
                  value={splitTab.content}
                  onChange={(e) => updateTabContent(splitTab.id, e.target.value)}
                  onScroll={handleSplitScroll}
                  spellCheck={false}
                  wrap="off"
                  style={{ caretColor: 'var(--anka-accent)' }}
                  className="relative z-10 w-full h-full p-3 font-mono text-[13px] leading-6 bg-transparent text-transparent outline-none resize-none overflow-auto os-scroll select-text selection:bg-sky-500/30 whitespace-pre"
                />
              </div>
            </div>
          </div>
        )}

        {!splitTab && isHtml && htmlPreviewOpen && (
          <div className="w-1/2 border-l border-[var(--anka-border)] flex flex-col bg-white">
            <div className="px-3 py-1 text-[11px] font-medium bg-[var(--anka-surface-muted)] text-[var(--anka-text-subtle)] border-b border-[var(--anka-border)] flex items-center justify-between">
              <span>{tr ? 'HTML Canlı Önizleme' : 'Live HTML Preview'}</span>
              <button
                onClick={() => setHtmlPreviewOpen(false)}
                className="hover:text-[var(--anka-text)]"
              >
                <X size={12} />
              </button>
            </div>
            <iframe
              title="HTML Live Preview"
              sandbox="allow-scripts"
              srcDoc={activeTab.content}
              className="flex-1 w-full border-0 bg-white"
            />
          </div>
        )}

        {/* Global VFS Search Modal */}
        {globalFindOpen && (
          <div
            onClick={() => setGlobalFindOpen(false)}
            className="absolute inset-0 z-30 bg-slate-950/50 backdrop-blur-xs flex items-center justify-center p-4"
          >
            <div
              onClick={(e) => e.stopPropagation()}
              className="w-full max-w-lg rounded-2xl border border-[var(--anka-border)] bg-[var(--anka-surface)] shadow-2xl overflow-hidden flex flex-col max-h-[82%]"
            >
              <div className="px-4 py-2.5 border-b border-[var(--anka-border)] bg-[var(--anka-surface-muted)] flex items-center gap-2 text-xs">
                <FolderSearch size={14} className="text-[var(--anka-accent)] shrink-0" />
                <input
                  autoFocus
                  type="text"
                  value={globalQuery}
                  onChange={(e) => setGlobalQuery(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Escape') setGlobalFindOpen(false);
                  }}
                  placeholder={tr ? 'VFS içinde metin ara (en az 2 karakter)...' : 'Search across VFS files (min 2 chars)...'}
                  className="flex-1 bg-transparent font-mono outline-none text-[var(--anka-text)]"
                />
                <span className="text-[11px] font-mono text-[var(--anka-text-subtle)] tabular-nums shrink-0">
                  {globalSearchHits.length} {tr ? 'sonuç' : 'hits'}
                </span>
                <button
                  onClick={() => setGlobalFindOpen(false)}
                  className="p-1 text-[var(--anka-text-subtle)] hover:text-[var(--anka-text)]"
                >
                  <X size={14} />
                </button>
              </div>
              <div className="flex-1 overflow-y-auto os-scroll p-2 space-y-1 text-xs">
                {globalQuery.trim().length < 2 ? (
                  <p className="text-center text-[var(--anka-text-subtle)] py-6">
                    {tr
                      ? '~/ ve /etc altındaki tüm metin ve kaynak dosyalarında arama yapın.'
                      : 'Search all text and source files under ~ and /etc.'}
                  </p>
                ) : globalSearchHits.length === 0 ? (
                  <p className="text-center text-[var(--anka-text-subtle)] py-6">
                    {tr ? 'Eşleşen içerik bulunamadı.' : 'No matching lines found.'}
                  </p>
                ) : (
                  globalSearchHits.map((hit, idx) => (
                    <button
                      key={`${hit.path}:${hit.line}:${idx}`}
                      onClick={() => {
                        openVfsFileInTab(hit.path);
                        setFindQuery(globalQuery);
                        setGlobalFindOpen(false);
                      }}
                      className="w-full text-left px-3 py-2 rounded-lg hover:bg-[var(--anka-surface-elevated)] space-y-0.5 transition-colors"
                    >
                      <div className="flex items-center justify-between gap-2 font-mono text-[11px]">
                        <span className="text-[var(--anka-accent)] truncate">{hit.path}</span>
                        <span className="text-[var(--anka-text-subtle)] tabular-nums shrink-0">
                          :{hit.line}
                        </span>
                      </div>
                      <div className="font-mono text-[11px] text-[var(--anka-text-muted)] truncate">
                        {hit.preview}
                      </div>
                    </button>
                  ))
                )}
              </div>
            </div>
          </div>
        )}

        {/* VFS File Picker Modal */}
        {openPickerOpen && (
          <div
            onClick={() => setOpenPickerOpen(false)}
            className="absolute inset-0 z-30 bg-slate-950/50 backdrop-blur-xs flex items-center justify-center p-4"
          >
            <div
              onClick={(e) => e.stopPropagation()}
              className="w-full max-w-md rounded-2xl border border-[var(--anka-border)] bg-[var(--anka-surface)] shadow-2xl overflow-hidden flex flex-col max-h-[80%]"
            >
              <div className="px-4 py-2.5 border-b border-[var(--anka-border)] bg-[var(--anka-surface-muted)] flex items-center justify-between gap-2 text-xs">
                <div className="font-mono truncate font-semibold">{pickerDir}</div>
                <div className="flex items-center gap-1.5 shrink-0">
                  {pickerDir !== '/' && (
                    <button
                      onClick={() => {
                        const parent = pickerDir.split('/').slice(0, -1).join('/') || '/';
                        setPickerDir(parent);
                      }}
                      className="px-2 py-0.5 rounded border border-[var(--anka-border)] hover:bg-[var(--anka-surface-elevated)]"
                    >
                      ..
                    </button>
                  )}
                  <button
                    onClick={() => setOpenPickerOpen(false)}
                    className="p-1 text-[var(--anka-text-subtle)] hover:text-[var(--anka-text)]"
                  >
                    <X size={14} />
                  </button>
                </div>
              </div>
              <div className="flex-1 overflow-y-auto os-scroll p-2 space-y-1 text-xs">
                {listDir(vfs, pickerDir).map((entry) => {
                  const full = pickerDir === '/' ? `/${entry.name}` : `${pickerDir}/${entry.name}`;
                  return (
                    <button
                      key={entry.id}
                      onClick={() => {
                        if (entry.type === 'dir') setPickerDir(full);
                        else openVfsFileInTab(full);
                      }}
                      className="w-full flex items-center gap-2.5 px-3 py-2 rounded-lg hover:bg-[var(--anka-surface-elevated)] text-left"
                    >
                      {entry.type === 'dir' ? (
                        <Folder size={14} className="text-sky-500 shrink-0" />
                      ) : (
                        <FileText size={14} className="text-[var(--anka-text-subtle)] shrink-0" />
                      )}
                      <span className="truncate flex-1">{entry.name}</span>
                    </button>
                  );
                })}
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Runner Console */}
      {showConsole && (
        <div className="h-44 border-t border-[var(--anka-terminal-border)] bg-[var(--anka-terminal-bg)] text-[var(--anka-terminal-fg)] flex flex-col">
          <div className="px-3 py-1.5 border-b border-[var(--anka-terminal-border)] flex items-center justify-between text-xs text-[var(--anka-terminal-muted)]">
            <div className="flex items-center gap-2">
              <Terminal size={13} />
              <span>{tr ? 'Ring 3 İzole Çalıştırma Çıktısı' : 'Ring 3 Sandbox Console'}</span>
              {isRunning && (
                <span className="text-[11px] text-amber-500 font-mono">· Çalışıyor...</span>
              )}
            </div>
            <button
              onClick={() => setShowConsole(false)}
              className="hover:text-[var(--anka-terminal-fg)]"
            >
              {tr ? 'Gizle' : 'Hide'}
            </button>
          </div>
          <div className="flex-1 overflow-y-auto os-scroll p-3 font-mono text-xs space-y-1 select-text">
            {consoleOutput.map((line, idx) => (
              <div
                key={idx}
                className={
                  line.startsWith('[HATA]')
                    ? 'text-rose-600 dark:text-rose-400'
                    : line.startsWith('[UYARI]')
                      ? 'text-amber-600 dark:text-amber-400'
                      : line.startsWith('[INFO]')
                        ? 'text-[var(--anka-terminal-muted)]'
                        : line.startsWith('[OK]') || line.startsWith('[SONUÇ]')
                          ? 'text-emerald-600 dark:text-emerald-300 font-medium'
                          : 'text-[var(--anka-terminal-fg)]'
                }
              >
                {line}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Status Bar */}
      <div className="px-3 py-1 border-t border-[var(--anka-border)] bg-[var(--anka-surface-muted)] text-[11px] text-[var(--anka-text-subtle)] flex items-center justify-between tabular-nums">
        <span>
          Satır {cursorPos.line}, Sütun {cursorPos.col} · {lineCount} {tr ? 'satır' : 'lines'} ·{' '}
          {activeTab.content.length} {tr ? 'karakter' : 'chars'} · {lang.toUpperCase()}
        </span>
        <span>Ctrl+F {tr ? 'Bul' : 'Find'} · Ctrl+O {tr ? 'Aç' : 'Open'} · Ctrl+S {tr ? 'Kaydet' : 'Save'}</span>
      </div>
    </div>
  );
};
