import React, { useMemo, useState } from 'react';
import { BookOpen, Edit3, FolderOpen, ListTree, X } from 'lucide-react';
import { useOS } from '../os/kernel';
import { getNodeAtPath, HOME_PATH, listDir, normalizePath } from '../os/vfs';

interface MarkdownViewerAppProps {
  windowId: string;
  launchArgs?: Record<string, string>;
}

const DEFAULT_MD = `# AnkaOS Belge Okuyucu

AnkaOS **Belge & Markdown Okuyucu**, VFS üzerindeki tüm \`.md\` ve metin belgelerini biçimlendirilmiş şekilde görüntüler.

## Özellikler

- Başlık hiyerarşisi (\`#\`, \`##\`, \`###\`) ve otomatik **İçindekiler** dizini
- Kod blokları ve satır içi \`monospace\` vurgulama
- Tablo ve alıntı blokları desteği

> İpucu: Dosyalar uygulamasında herhangi bir \`.md\` dosyasına çift tıkladığınızda doğrudan bu okuyucu ile açılır.

\`\`\`wat
(module
  (func (export "topla") (param i32 i32) (result i32)
    local.get 0
    local.get 1
    i32.add))
\`\`\`
`;

function renderInlineMarkdown(text: string): React.ReactNode[] {
  const tokens = text.split(/(`[^`]+`|\*\*[^*]+\*\*|\*[^*]+\*|\[[^\]]+\]\([^)]+\))/g);
  return tokens.map((tok, i) => {
    if (tok.startsWith('`') && tok.endsWith('`') && tok.length >= 2) {
      return (
        <code
          key={i}
          className="px-1.5 py-0.5 rounded bg-[var(--anka-surface-muted)] border border-[var(--anka-border)] font-mono text-[0.88em] text-[var(--anka-accent)]"
        >
          {tok.slice(1, -1)}
        </code>
      );
    }
    if (tok.startsWith('**') && tok.endsWith('**') && tok.length >= 4) {
      return (
        <strong key={i} className="font-semibold text-[var(--anka-text)]">
          {tok.slice(2, -2)}
        </strong>
      );
    }
    if (tok.startsWith('*') && tok.endsWith('*') && tok.length >= 2) {
      return <em key={i}>{tok.slice(1, -1)}</em>;
    }
    const linkMatch = tok.match(/^\[([^\]]+)\]\(([^)]+)\)$/);
    if (linkMatch) {
      return (
        <span key={i} className="text-[var(--anka-accent)] underline underline-offset-2">
          {linkMatch[1]} ({linkMatch[2]})
        </span>
      );
    }
    return <React.Fragment key={i}>{tok}</React.Fragment>;
  });
}

export const MarkdownViewerApp: React.FC<MarkdownViewerAppProps> = ({ launchArgs }) => {
  const { vfs, launchApp, currentUser, settings } = useOS();
  const tr = settings.language === 'tr';
  const userHome = currentUser.homeDir || HOME_PATH;

  const [currentPath, setCurrentPath] = useState<string>(
    launchArgs?.path ? normalizePath(launchArgs.path, userHome, userHome) : ''
  );
  const [pickerOpen, setPickerOpen] = useState(false);
  const [pickerDir, setPickerDir] = useState(userHome);

  const rawMarkdown = useMemo(() => {
    if (!currentPath) return DEFAULT_MD;
    const node = getNodeAtPath(vfs, currentPath);
    return node?.type === 'file' ? node.content || '' : DEFAULT_MD;
  }, [vfs, currentPath]);

  const headings = useMemo(() => {
    const list: Array<{ level: number; text: string; id: string }> = [];
    let inFence = false;
    rawMarkdown.split('\n').forEach((line, idx) => {
      if (line.trim().startsWith('```')) {
        inFence = !inFence;
        return;
      }
      if (inFence) return;
      const m = line.match(/^(#{1,3})\s+(.+)$/);
      if (m) {
        list.push({ level: m[1].length, text: m[2].trim(), id: `md-h-${idx}` });
      }
    });
    return list;
  }, [rawMarkdown]);

  const renderedBlocks = useMemo(() => {
    const lines = rawMarkdown.split('\n');
    const nodes: React.ReactNode[] = [];
    let i = 0;

    while (i < lines.length) {
      const line = lines[i];
      if (line.trim().startsWith('```')) {
        const lang = line.trim().slice(3).trim() || 'text';
        const codeLines: string[] = [];
        i++;
        while (i < lines.length && !lines[i].trim().startsWith('```')) {
          codeLines.push(lines[i]);
          i++;
        }
        nodes.push(
          <div
            key={`code-${i}`}
            className="rounded-xl border border-[var(--anka-terminal-border)] bg-[var(--anka-terminal-bg)] overflow-hidden my-3"
          >
            <div className="px-3 py-1 text-[10px] font-mono text-[var(--anka-terminal-muted)] border-b border-[var(--anka-terminal-border)]">
              {lang}
            </div>
            <pre className="p-3 font-mono text-xs text-[var(--anka-terminal-fg)] overflow-x-auto os-scroll">
              {codeLines.join('\n')}
            </pre>
          </div>
        );
        i++;
        continue;
      }

      const hMatch = line.match(/^(#{1,4})\s+(.+)$/);
      if (hMatch) {
        const lvl = hMatch[1].length;
        const text = hMatch[2].trim();
        const cls =
          lvl === 1
            ? 'text-2xl font-display font-bold mt-4 mb-2 pb-1.5 border-b border-[var(--anka-border)]'
            : lvl === 2
              ? 'text-lg font-display font-semibold mt-5 mb-2'
              : 'text-base font-semibold mt-4 mb-1.5';
        nodes.push(
          <div key={`h-${i}`} id={`md-h-${i}`} className={cls}>
            {renderInlineMarkdown(text)}
          </div>
        );
        i++;
        continue;
      }

      if (line.trim().startsWith('>')) {
        nodes.push(
          <blockquote
            key={`bq-${i}`}
            className="border-l-2 border-[var(--anka-accent)] pl-3 py-1 my-2 text-xs italic text-[var(--anka-text-muted)] bg-[var(--anka-surface-muted)] rounded-r-lg"
          >
            {renderInlineMarkdown(line.replace(/^\s*>\s?/, ''))}
          </blockquote>
        );
        i++;
        continue;
      }

      if (/^\s*[-*]\s+/.test(line)) {
        const items: string[] = [];
        while (i < lines.length && /^\s*[-*]\s+/.test(lines[i])) {
          items.push(lines[i].replace(/^\s*[-*]\s+/, ''));
          i++;
        }
        nodes.push(
          <ul key={`ul-${i}`} className="list-disc pl-5 space-y-1 text-sm text-[var(--anka-text-muted)] my-2">
            {items.map((it, idx) => (
              <li key={idx}>{renderInlineMarkdown(it)}</li>
            ))}
          </ul>
        );
        continue;
      }

      if (!line.trim()) {
        i++;
        continue;
      }

      nodes.push(
        <p key={`p-${i}`} className="text-sm leading-relaxed text-[var(--anka-text-muted)] my-2">
          {renderInlineMarkdown(line)}
        </p>
      );
      i++;
    }
    return nodes;
  }, [rawMarkdown]);

  return (
    <div className="h-full w-full flex flex-col bg-[var(--anka-surface)] text-[var(--anka-text)] anka-theme-transition">
      <div className="px-4 py-2.5 border-b border-[var(--anka-border)] bg-[var(--anka-surface-muted)] flex items-center justify-between gap-2 text-xs">
        <div className="flex items-center gap-2 min-w-0">
          <BookOpen size={15} className="text-[var(--anka-accent)] shrink-0" />
          <span className="font-mono truncate">
            {currentPath || (tr ? 'Yerleşik Kılavuz Belgesi' : 'Built-in Reader Guide')}
          </span>
        </div>
        <div className="flex items-center gap-1.5 shrink-0">
          <button
            onClick={() => setPickerOpen(true)}
            className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border border-[var(--anka-border-strong)] hover:bg-[var(--anka-surface-elevated)]"
          >
            <FolderOpen size={13} />
            <span>{tr ? 'Dosya Aç' : 'Open File'}</span>
          </button>
          {currentPath && (
            <button
              onClick={() => launchApp('editor', { path: currentPath })}
              className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-[var(--anka-accent)] text-[var(--anka-accent-fg)] hover:bg-[var(--anka-accent-hover)]"
            >
              <Edit3 size={13} />
              <span>{tr ? 'Düzenle' : 'Edit'}</span>
            </button>
          )}
        </div>
      </div>

      <div className="flex-1 min-h-0 flex">
        {headings.length > 0 && (
          <aside className="hidden sm:flex w-52 border-r border-[var(--anka-border)] bg-[var(--anka-bg)] p-3 flex-col gap-2 overflow-y-auto os-scroll shrink-0">
            <div className="flex items-center gap-1.5 text-[11px] font-semibold text-[var(--anka-text-subtle)] uppercase tracking-wider">
              <ListTree size={12} />
              <span>{tr ? 'İçindekiler' : 'Contents'}</span>
            </div>
            <div className="space-y-1 text-xs">
              {headings.map((h) => (
                <a
                  key={h.id}
                  href={`#${h.id}`}
                  style={{ paddingLeft: `${(h.level - 1) * 10 + 6}px` }}
                  className="block py-1 pr-2 rounded hover:bg-[var(--anka-surface-elevated)] text-[var(--anka-text-muted)] hover:text-[var(--anka-text)] truncate"
                >
                  {h.text}
                </a>
              ))}
            </div>
          </aside>
        )}

        <main className="flex-1 overflow-y-auto os-scroll p-6">
          <article className="max-w-2xl mx-auto">{renderedBlocks}</article>
        </main>
      </div>

      {pickerOpen && (
        <div
          onClick={() => setPickerOpen(false)}
          className="fixed inset-0 z-50 bg-slate-950/50 backdrop-blur-xs flex items-center justify-center p-4"
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="w-full max-w-md rounded-2xl border border-[var(--anka-border)] bg-[var(--anka-surface)] shadow-2xl overflow-hidden flex flex-col max-h-[75%]"
          >
            <div className="px-4 py-2.5 border-b border-[var(--anka-border)] bg-[var(--anka-surface-muted)] flex items-center justify-between text-xs">
              <span className="font-mono font-semibold truncate">{pickerDir}</span>
              <div className="flex items-center gap-1.5">
                {pickerDir !== '/' && (
                  <button
                    onClick={() => setPickerDir(pickerDir.split('/').slice(0, -1).join('/') || '/')}
                    className="px-2 py-0.5 rounded border border-[var(--anka-border)]"
                  >
                    ..
                  </button>
                )}
                <button onClick={() => setPickerOpen(false)} className="p-1">
                  <X size={14} />
                </button>
              </div>
            </div>
            <div className="flex-1 overflow-y-auto os-scroll p-2 space-y-1 text-xs">
              {listDir(vfs, pickerDir).map((entry) => {
                const full = pickerDir === '/' ? `/${entry.name}` : `${pickerDir}/${entry.name}`;
                return (
                  <button
                    key={entry.id}
                    onClick={() => {
                      if (entry.type === 'dir') setPickerDir(full);
                      else {
                        setCurrentPath(full);
                        setPickerOpen(false);
                      }
                    }}
                    className="w-full flex items-center justify-between px-3 py-2 rounded-lg hover:bg-[var(--anka-surface-elevated)] text-left"
                  >
                    <span className="truncate">{entry.name}{entry.type === 'dir' ? '/' : ''}</span>
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
