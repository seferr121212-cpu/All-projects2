import React, { useMemo, useState } from 'react';
import {
  ArrowDown,
  ArrowUp,
  Clock,
  Cpu,
  Database,
  Globe,
  HardDrive,
  Layers,
  Monitor,
  Network,
  Pause,
  Play,
  Plus,
  Radio,
  RefreshCw,
  RotateCcw,
  ScrollText,
  Search,
  Server,
  Shield,
  Trash2,
  Wrench,
  XCircle,
} from 'lucide-react';
import { computeDiskUsage } from '../os/archive';
import { useOS } from '../os/kernel';
import { getMemorySummary } from '../os/mmu';
import { LiveDnsResponse, resolveDnsLive } from '../os/net';
import { KERNEL_SPACE_BOUNDARY_HEX } from '../os/security';
import { FsckReport } from '../os/types';
import { formatBytes, HOME_PATH } from '../os/vfs';

export const SystemMonitorApp: React.FC<{ windowId: string }> = () => {
  const {
    processes,
    schedulerStats,
    ioQueueStats,
    ioQueueTasks,
    compositorStats,
    attemptKernelMemoryAccess,
    forkProcess,
    triggerCowWriteFault,
    networkInterfaces,
    frames,
    swapSlots,
    syscalls,
    killProcess,
    signalProcess,
    reniceProcess,
    metricsHistory,
    kernelLogs,
    clearKernelLogs,
    uptimeSec,
    settings,
    services,
    controlService,
    cronJobs,
    addCronJob,
    removeCronJob,
    toggleCronJob,
    runCronJobNow,
    vfs,
    currentUser,
    runDiskCheck,
    netStatus,
    refreshNetStatus,
    daemonTelemetry,
  } = useOS();
  const tr = settings.language === 'tr';
  const [tab, setTab] = useState<
    'processes' | 'mmu' | 'services' | 'storage' | 'io_sec' | 'network' | 'syscalls' | 'logs'
  >('processes');
  const [feedback, setFeedback] = useState<string | null>(null);
  const [cronName, setCronName] = useState('');
  const [cronInterval, setCronInterval] = useState('60');
  const [cronCmd, setCronCmd] = useState('fsck --quick');
  const [fsckResult, setFsckResult] = useState<FsckReport | null>(null);
  const [dnsProbeHost, setDnsProbeHost] = useState('wikipedia.org');
  const [dnsResult, setDnsResult] = useState<LiveDnsResponse | null>(null);
  const [dnsLoading, setDnsLoading] = useState(false);
  const [logFilter, setLogFilter] = useState('');
  const [logLevelFilter, setLogLevelFilter] = useState<'ALL' | 'INFO' | 'WARN' | 'ERR'>('ALL');
  const [syscallFilter, setSyscallFilter] = useState('');

  const userHome = currentUser.homeDir || HOME_PATH;
  const homeUsage = useMemo(() => computeDiskUsage(vfs, userHome), [vfs, userHome]);
  const rootUsage = useMemo(() => computeDiskUsage(vfs, '/'), [vfs]);

  const latest = metricsHistory[metricsHistory.length - 1] || { cpu: 5, ram: 8 };
  const memSummary = getMemorySummary(frames, swapSlots);

  const showToast = (msg: string) => {
    setFeedback(msg);
    setTimeout(() => setFeedback(null), 3200);
  };

  const buildPolyline = (values: number[]) => {
    const w = 440;
    const h = 110;
    if (values.length === 0) return '';
    return values
      .map((val, idx) => {
        const x = (idx / Math.max(1, values.length - 1)) * w;
        const y = h - (Math.min(100, Math.max(0, val)) / 100) * (h - 10) - 5;
        return `${x.toFixed(1)},${y.toFixed(1)}`;
      })
      .join(' ');
  };

  const handleKill = (pid: number) => {
    const res = killProcess(pid);
    showToast(
      !res.ok && res.error
        ? res.error
        : tr
          ? `PID ${pid} sonlandırıldı ve MMU çerçeveleri serbest bırakıldı`
          : `Killed PID ${pid} and freed MMU frames`
    );
  };

  const firstUserProc = processes.find((p) => p.privilegeRing === 3);

  return (
    <div className="h-full w-full flex flex-col bg-[var(--anka-surface)] text-[var(--anka-text)] anka-theme-transition">
      {/* Header Tabs */}
      <div className="px-4 py-2.5 border-b border-[var(--anka-border)] bg-[var(--anka-surface)] flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-1 p-1 bg-[var(--anka-surface-muted)] border border-[var(--anka-border)] rounded-lg overflow-x-auto">
          <button
            onClick={() => setTab('processes')}
            className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
              tab === 'processes'
                ? 'bg-[var(--anka-surface)] text-[var(--anka-text)] shadow-sm'
                : 'text-[var(--anka-text-subtle)] hover:text-[var(--anka-text)]'
            }`}
          >
            {tr ? `Süreçler (${processes.length})` : `Processes (${processes.length})`}
          </button>
          <button
            onClick={() => setTab('mmu')}
            className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
              tab === 'mmu'
                ? 'bg-[var(--anka-surface)] text-[var(--anka-text)] shadow-sm'
                : 'text-[var(--anka-text-subtle)] hover:text-[var(--anka-text)]'
            }`}
          >
            {tr ? 'MMU (CoW) & Zamanlayıcı' : 'MMU (CoW) & Scheduler'}
          </button>
          <button
            onClick={() => setTab('services')}
            className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
              tab === 'services'
                ? 'bg-[var(--anka-surface)] text-[var(--anka-text)] shadow-sm'
                : 'text-[var(--anka-text-subtle)] hover:text-[var(--anka-text)]'
            }`}
          >
            {tr ? 'Servisler & Cron' : 'Services & Cron'}
          </button>
          <button
            onClick={() => setTab('storage')}
            className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
              tab === 'storage'
                ? 'bg-[var(--anka-surface)] text-[var(--anka-text)] shadow-sm'
                : 'text-[var(--anka-text-subtle)] hover:text-[var(--anka-text)]'
            }`}
          >
            {tr ? 'Depolama (du/fsck)' : 'Storage'}
          </button>
          <button
            onClick={() => setTab('io_sec')}
            className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
              tab === 'io_sec'
                ? 'bg-[var(--anka-surface)] text-[var(--anka-text)] shadow-sm'
                : 'text-[var(--anka-text-subtle)] hover:text-[var(--anka-text)]'
            }`}
          >
            {tr ? 'G/Ç Kuyruğu & Güvenlik' : 'I/O Queue & Security'}
          </button>
          <button
            onClick={() => setTab('network')}
            className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
              tab === 'network'
                ? 'bg-[var(--anka-surface)] text-[var(--anka-text)] shadow-sm'
                : 'text-[var(--anka-text-subtle)] hover:text-[var(--anka-text)]'
            }`}
          >
            {tr ? 'Ağ & İnternet' : 'Network'}
          </button>
          <button
            onClick={() => setTab('syscalls')}
            className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
              tab === 'syscalls'
                ? 'bg-[var(--anka-surface)] text-[var(--anka-text)] shadow-sm'
                : 'text-[var(--anka-text-subtle)] hover:text-[var(--anka-text)]'
            }`}
          >
            Syscalls
          </button>
          <button
            onClick={() => setTab('logs')}
            className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
              tab === 'logs'
                ? 'bg-[var(--anka-surface)] text-[var(--anka-text)] shadow-sm'
                : 'text-[var(--anka-text-subtle)] hover:text-[var(--anka-text)]'
            }`}
          >
            dmesg
          </button>
        </div>

        <div className="text-xs text-[var(--anka-text-subtle)] tabular-nums flex items-center gap-3">
          <span>CPU: {latest.cpu}%</span>
          <span>·</span>
          <span>
            RAM: {memSummary.usedMB} MB ({memSummary.usagePct}%)
          </span>
          <span>·</span>
          <span>{uptimeSec}s</span>
        </div>
      </div>

      {feedback && (
        <div className="px-4 py-1.5 text-xs bg-amber-500/10 text-amber-600 dark:text-amber-400 border-b border-[var(--anka-border)]">
          {feedback}
        </div>
      )}

      <div className="flex-1 overflow-y-auto os-scroll p-4 bg-[var(--anka-surface)]">
        {tab === 'processes' && (
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="border-b border-[var(--anka-border)] text-[var(--anka-text-subtle)]">
                <th className="py-2 px-2 font-medium">PID</th>
                <th className="py-2 px-2 font-medium">Ring</th>
                <th className="py-2 px-2 font-medium">{tr ? 'Süreç & ASLR Stack' : 'Process & ASLR Stack'}</th>
                <th className="py-2 px-2 font-medium text-right">PRI</th>
                <th className="py-2 px-2 font-medium text-right">CPU %</th>
                <th className="py-2 px-2 font-medium text-right">{tr ? 'Bellek' : 'Memory'}</th>
                <th className="py-2 px-2 font-medium text-right">{tr ? 'İşlem' : 'Action'}</th>
              </tr>
            </thead>
            <tbody>
              {processes.map((proc) => (
                <tr
                  key={proc.pid}
                  className="border-b border-[var(--anka-border)] hover:bg-[var(--anka-surface-muted)]"
                >
                  <td className="py-2.5 px-2 font-mono tabular-nums text-[var(--anka-text-subtle)]">{proc.pid}</td>
                  <td className="py-2.5 px-2">
                    <span
                      className={`px-1.5 py-0.5 rounded text-[10px] font-mono font-semibold ${
                        proc.privilegeRing === 0
                          ? 'bg-amber-500/15 text-amber-600 dark:text-amber-400'
                          : 'bg-[var(--anka-accent-soft)] text-[var(--anka-accent)]'
                      }`}
                    >
                      R{proc.privilegeRing}
                    </span>
                  </td>
                  <td className="py-2.5 px-2">
                    <div className="flex items-center gap-1.5">
                      <span className="font-medium text-[var(--anka-text)]">{proc.name}</span>
                      {proc.isForeground && proc.state === 'running' && (
                        <span className="px-1.5 py-0.2 rounded text-[10px] font-mono bg-emerald-500/15 text-emerald-600 dark:text-emerald-400">
                          FG
                        </span>
                      )}
                      {proc.state === 'stopped' && (
                        <span className="px-1.5 py-0.2 rounded text-[10px] font-mono bg-amber-500/15 text-amber-600 dark:text-amber-400">
                          STOP
                        </span>
                      )}
                    </div>
                    <div className="text-[11px] font-mono text-[var(--anka-text-subtle)] truncate max-w-xs">
                      {proc.aslrLayout ? `Stack ${proc.aslrLayout.stackBase}` : proc.command}
                    </div>
                  </td>
                  <td className="py-2.5 px-2 text-right font-mono tabular-nums text-[var(--anka-text-subtle)]">
                    <div className="inline-flex items-center gap-1">
                      {!proc.isSystem && (
                        <button
                          onClick={() => {
                            const nextPri = Math.max(-20, proc.priority - 2);
                            const r = reniceProcess(proc.pid, nextPri);
                            if (r.ok) showToast(`PID ${proc.pid} renice -> ${nextPri}`);
                          }}
                          title={tr ? 'Önceliği Artır (-2)' : 'Higher priority (-2)'}
                          className="p-0.5 rounded hover:bg-[var(--anka-surface-elevated)] text-[var(--anka-accent)]"
                        >
                          <ArrowUp size={11} />
                        </button>
                      )}
                      <span className="w-6 text-center">{proc.priority}</span>
                      {!proc.isSystem && (
                        <button
                          onClick={() => {
                            const nextPri = Math.min(19, proc.priority + 2);
                            const r = reniceProcess(proc.pid, nextPri);
                            if (r.ok) showToast(`PID ${proc.pid} renice -> ${nextPri}`);
                          }}
                          title={tr ? 'Önceliği Düşür (+2)' : 'Lower priority (+2)'}
                          className="p-0.5 rounded hover:bg-[var(--anka-surface-elevated)] text-[var(--anka-text-subtle)]"
                        >
                          <ArrowDown size={11} />
                        </button>
                      )}
                    </div>
                  </td>
                  <td className="py-2.5 px-2 text-right font-mono tabular-nums">
                    {proc.cpu.toFixed(1)}%
                  </td>
                  <td className="py-2.5 px-2 text-right font-mono tabular-nums">
                    {proc.pagesAllocated}p · {proc.memoryMB} MB
                  </td>
                  <td className="py-2.5 px-2 text-right">
                    {proc.isSystem ? (
                      <span className="text-[11px] text-[var(--anka-text-subtle)]">
                        {tr ? 'Çekirdek' : 'Kernel'}
                      </span>
                    ) : (
                      <div className="inline-flex items-center gap-1">
                        <button
                          onClick={() => {
                            const sig = proc.state === 'stopped' ? 'SIGCONT' : 'SIGSTOP';
                            const res = signalProcess(proc.pid, sig);
                            showToast(res.message);
                          }}
                          className="inline-flex items-center gap-1 px-2 py-1 rounded text-amber-600 dark:text-amber-400 hover:bg-amber-500/10 font-medium transition-colors"
                          title={proc.state === 'stopped' ? 'SIGCONT' : 'SIGSTOP'}
                        >
                          {proc.state === 'stopped' ? <Play size={12} /> : <Pause size={12} />}
                          <span>
                            {proc.state === 'stopped'
                              ? tr
                                ? 'Devam'
                                : 'Resume'
                              : tr
                                ? 'Duraklat'
                                : 'Stop'}
                          </span>
                        </button>
                        <button
                          onClick={() => handleKill(proc.pid)}
                          className="inline-flex items-center gap-1 px-2 py-1 rounded text-rose-600 dark:text-rose-400 hover:bg-rose-500/10 font-medium transition-colors"
                        >
                          <XCircle size={13} />
                          <span>{tr ? 'Sonlandır' : 'Kill'}</span>
                        </button>
                      </div>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}

        {tab === 'mmu' && (
          <div className="space-y-5">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="p-4 rounded-xl border border-[var(--anka-border)] bg-[var(--anka-surface-muted)] space-y-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Cpu size={16} className="text-[var(--anka-accent)]" />
                    <h3 className="text-sm font-semibold">
                      {tr ? 'Preemptive Priority Zamanlayıcı' : 'Preemptive Priority Scheduler'}
                    </h3>
                  </div>
                  <span className="text-lg font-semibold font-mono tabular-nums text-[var(--anka-accent)]">
                    {latest.cpu}%
                  </span>
                </div>
                <svg viewBox="0 0 440 110" className="w-full h-24 overflow-visible">
                  <polyline
                    fill="none"
                    stroke="var(--anka-accent)"
                    strokeWidth="2.5"
                    strokeLinejoin="round"
                    points={buildPolyline(metricsHistory.map((m) => m.cpu))}
                  />
                </svg>
                <div className="text-[11px] text-[var(--anka-text-subtle)] flex justify-between font-mono tabular-nums">
                  <span>Kesinti (Preempt): {schedulerStats.preemptions}</span>
                  <span>Bağlam: {schedulerStats.contextSwitches}</span>
                  <span>Kuantum: {schedulerStats.quantumMs} ms</span>
                </div>
              </div>

              <div className="p-4 rounded-xl border border-[var(--anka-border)] bg-[var(--anka-surface-muted)] space-y-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <HardDrive size={16} className="text-emerald-500" />
                    <h3 className="text-sm font-semibold">
                      {tr ? 'Fiziksel RAM & Copy-on-Write' : 'Physical RAM & CoW'}
                    </h3>
                  </div>
                  <span className="text-lg font-semibold font-mono tabular-nums text-emerald-600 dark:text-emerald-400">
                    {memSummary.usedMB} MB
                  </span>
                </div>
                <svg viewBox="0 0 440 110" className="w-full h-24 overflow-visible">
                  <polyline
                    fill="none"
                    stroke="#10b981"
                    strokeWidth="2.5"
                    strokeLinejoin="round"
                    points={buildPolyline(metricsHistory.map((m) => m.ram))}
                  />
                </svg>
                <div className="text-[11px] text-[var(--anka-text-subtle)] flex flex-wrap justify-between gap-2 font-mono tabular-nums">
                  <span>Ortak CoW: {memSummary.cowSharedFrames} sf</span>
                  <span>Tasarruf: {memSummary.cowSavedMB} MB</span>
                  <span>Swap: {memSummary.swapUsedMB}/{memSummary.swapTotalMB} MB</span>
                  <span>Boş: {memSummary.freeMB} MB</span>
                </div>
              </div>
            </div>

            <div className="p-4 rounded-xl border border-[var(--anka-border)] bg-[var(--anka-surface-muted)] space-y-3">
              <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
                <span className="font-semibold">
                  {tr
                    ? 'MMU Sayfa Çerçeveleri (Mavi: Çekirdek, Yeşil: Kullanıcı, Mor: CoW Paylaşımlı)'
                    : 'MMU Page Frames (Blue: Kernel, Green: User, Violet: CoW Shared)'}
                </span>
                <div className="flex items-center gap-2">
                  {firstUserProc && (
                    <>
                      <button
                        onClick={() => {
                          const r = forkProcess(firstUserProc.pid);
                          showToast(r.message);
                        }}
                        className="px-2.5 py-1 rounded-md text-[11px] font-medium bg-violet-600 text-white hover:bg-violet-500"
                      >
                        CoW Fork (PID {firstUserProc.pid})
                      </button>
                      <button
                        onClick={() => {
                          const r = triggerCowWriteFault(firstUserProc.pid);
                          showToast(r.message);
                        }}
                        className="px-2.5 py-1 rounded-md text-[11px] font-medium border border-[var(--anka-border-strong)] hover:bg-[var(--anka-surface-elevated)]"
                      >
                        CoW Yazma Testi
                      </button>
                    </>
                  )}
                </div>
              </div>
              <div className="grid grid-cols-16 gap-1">
                {frames.map((frame) => {
                  const isCow = frame.isCopyOnWrite && frame.cowSharedWith.length > 0;
                  const isKernel = frame.pid !== null && frame.pid < 100;
                  const isUser = frame.pid !== null && frame.pid >= 100;
                  return (
                    <div
                      key={frame.frameIndex}
                      title={
                        frame.pid !== null
                          ? `Çerçeve #${frame.frameIndex}: PID ${frame.pid} (${frame.processName}) · ref=${frame.refCount}${
                              isCow ? ` · CoW shared=[${frame.cowSharedWith.join(',')}]` : ''
                            }`
                          : `Çerçeve #${frame.frameIndex}: Boş (32 MB)`
                      }
                      className={`h-5 rounded-sm transition-colors ${
                        isCow
                          ? 'bg-violet-500'
                          : isKernel
                            ? 'bg-sky-600'
                            : isUser
                              ? 'bg-emerald-500'
                              : 'bg-[var(--anka-surface-elevated)]'
                      }`}
                    />
                  );
                })}
              </div>
            </div>
          </div>
        )}

        {tab === 'io_sec' && (
          <div className="space-y-4">
            {/* Ring 0/3 & ASLR Security Summary */}
            <div className="p-4 rounded-xl border border-[var(--anka-border)] bg-[var(--anka-surface-muted)] space-y-3">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div className="flex items-center gap-2">
                  <Shield size={16} className="text-[var(--anka-accent)]" />
                  <h3 className="text-sm font-semibold">
                    {tr ? 'Ring 0 / Ring 3 Bellek Yalıtımı & ASLR' : 'Ring 0 / Ring 3 Isolation & ASLR'}
                  </h3>
                </div>
                {firstUserProc && (
                  <button
                    onClick={() => {
                      const res = attemptKernelMemoryAccess(
                        firstUserProc.pid,
                        KERNEL_SPACE_BOUNDARY_HEX
                      );
                      showToast(res.message);
                    }}
                    className="px-3 py-1.5 rounded-lg text-xs font-medium bg-rose-600 text-white hover:bg-rose-500"
                  >
                    {tr
                      ? `Ring 3 Çekirdek Erişim Testi (PID ${firstUserProc.pid})`
                      : `Test Ring 3 Kernel Access (PID ${firstUserProc.pid})`}
                  </button>
                )}
              </div>
              <p className="text-xs text-[var(--anka-text-muted)]">
                Çekirdek sınırı <span className="font-mono text-[var(--anka-accent)]">{KERNEL_SPACE_BOUNDARY_HEX}</span>.
                Ring 3 uygulamaları yalnızca rastgeleleştirilmiş ASLR Stack/Heap alanlarına ve kendi Sandbox dizinlerine yazabilir.
              </p>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-[11px] font-mono">
                {processes.slice(0, 6).map((p) => (
                  <div
                    key={p.pid}
                    className="p-2.5 rounded-lg bg-[var(--anka-surface)] border border-[var(--anka-border)] flex items-center justify-between gap-2"
                  >
                    <span className="font-semibold">
                      R{p.privilegeRing} · {p.name} ({p.pid})
                    </span>
                    <span className="text-[var(--anka-text-subtle)] truncate">
                      Heap {p.aslrLayout?.heapBase.slice(0, 12)} · Stack {p.aslrLayout?.stackBase.slice(0, 12)}
                    </span>
                  </div>
                ))}
              </div>
            </div>

            {/* Async I/O Queue */}
            <div className="p-4 rounded-xl border border-[var(--anka-border)] bg-[var(--anka-surface-muted)] space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Layers size={16} className="text-emerald-500" />
                  <h3 className="text-sm font-semibold">
                    {tr ? 'Asenkron Disk G/Ç Kuyruğu (Async I/O Queue)' : 'Async Disk I/O Queue'}
                  </h3>
                </div>
                <div className="text-xs font-mono text-[var(--anka-text-subtle)] tabular-nums flex gap-3">
                  <span>Bekleyen: {ioQueueStats.queuedCount}</span>
                  <span>Tamamlanan: {ioQueueStats.completedCount}</span>
                  <span>Ort. Gecikme: {ioQueueStats.avgLatencyMs} ms</span>
                </div>
              </div>
              <div className="rounded-lg border border-[var(--anka-terminal-border)] bg-[var(--anka-terminal-bg)] text-[var(--anka-terminal-fg)] p-3 font-mono text-[11px] space-y-1 max-h-48 overflow-y-auto os-scroll">
                {ioQueueTasks.length === 0 ? (
                  <div className="text-[var(--anka-terminal-muted)]">G/Ç kuyruğu boş (dosya yazıldığında otomatik dolar).</div>
                ) : (
                  ioQueueTasks.slice(0, 12).map((task) => (
                    <div key={task.id} className="flex items-center gap-3 tabular-nums">
                      <span className="text-[var(--anka-accent)] w-12 uppercase">{task.op}</span>
                      <span className="text-amber-600 dark:text-amber-400 w-14 uppercase">{task.priority}</span>
                      <span className="text-[var(--anka-terminal-fg)] flex-1 truncate">{task.path}</span>
                      <span className="text-emerald-600 dark:text-emerald-400">
                        {task.status} {task.latencyMs ? `(${task.latencyMs}ms)` : ''}
                      </span>
                    </div>
                  ))
                )}
              </div>
            </div>

            {/* Live Double-Buffered Compositor Telemetry */}
            <div className="p-4 rounded-xl border border-[var(--anka-border)] bg-[var(--anka-surface-muted)] space-y-2">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Monitor size={16} className="text-indigo-500" />
                  <h3 className="text-sm font-semibold">
                    {tr ? 'Double-Buffered Kompozitör (ankawm)' : 'Double-Buffered Compositor'}
                  </h3>
                </div>
                <span className="text-xs font-mono text-emerald-600 dark:text-emerald-400">
                  {compositorStats.vsyncHz} Hz VSync
                </span>
              </div>
              <div className="grid grid-cols-3 gap-3 text-xs font-mono tabular-nums pt-1">
                <div className="p-2.5 rounded-lg bg-[var(--anka-surface)] border border-[var(--anka-border)]">
                  <div className="text-[10px] text-[var(--anka-text-subtle)] uppercase">Tampon Kare #</div>
                  <div className="text-sm font-semibold text-[var(--anka-accent)]">{compositorStats.frameId}</div>
                </div>
                <div className="p-2.5 rounded-lg bg-[var(--anka-surface)] border border-[var(--anka-border)]">
                  <div className="text-[10px] text-[var(--anka-text-subtle)] uppercase">Aktif Yüzey</div>
                  <div className="text-sm font-semibold text-emerald-600 dark:text-emerald-400">
                    {compositorStats.surfaceCount} pencere
                  </div>
                </div>
                <div className="p-2.5 rounded-lg bg-[var(--anka-surface)] border border-[var(--anka-border)]">
                  <div className="text-[10px] text-[var(--anka-text-subtle)] uppercase">Buffer Takası</div>
                  <div className="text-sm font-semibold text-indigo-600 dark:text-indigo-400">
                    {compositorStats.lastSwapMs.toFixed(2)} ms
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {tab === 'services' && (
          <div className="space-y-5">
            <div className="p-4 rounded-xl border border-[var(--anka-border)] bg-[var(--anka-surface-muted)] space-y-2.5">
              <div className="flex items-center justify-between gap-2">
                <div className="flex items-center gap-2">
                  <Radio size={16} className="text-emerald-500" />
                  <h3 className="text-sm font-semibold">
                    {tr ? 'ankad Web Worker & BroadcastChannel IPC' : 'ankad Web Worker & BroadcastChannel IPC'}
                  </h3>
                </div>
                <span className="text-xs font-mono text-emerald-600 dark:text-emerald-400">
                  {daemonTelemetry?.mode === 'web-worker' ? 'Ring 3 Blob Worker' : daemonTelemetry?.mode === 'fallback' ? 'Main-Thread Fallback' : '...'}
                </span>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 text-xs font-mono tabular-nums">
                <div className="p-2.5 rounded-lg bg-[var(--anka-surface)] border border-[var(--anka-border)]">
                  <div className="text-[10px] text-[var(--anka-text-subtle)] uppercase">IPC Kanalı</div>
                  <div className="font-semibold text-[var(--anka-accent)] truncate">
                    {daemonTelemetry?.channelName || 'ankaos-ipc-bus'}
                  </div>
                </div>
                <div className="p-2.5 rounded-lg bg-[var(--anka-surface)] border border-[var(--anka-border)]">
                  <div className="text-[10px] text-[var(--anka-text-subtle)] uppercase">Worker Nabzı</div>
                  <div className="font-semibold text-emerald-600 dark:text-emerald-400">
                    {daemonTelemetry ? `${daemonTelemetry.ticks} tick` : '0 tick'}
                  </div>
                </div>
                <div className="p-2.5 rounded-lg bg-[var(--anka-surface)] border border-[var(--anka-border)]">
                  <div className="text-[10px] text-[var(--anka-text-subtle)] uppercase">Son Sinyal</div>
                  <div className="font-semibold text-[var(--anka-text)]">
                    {daemonTelemetry?.lastBeatAt
                      ? new Date(daemonTelemetry.lastBeatAt).toLocaleTimeString('tr-TR')
                      : '-'}
                  </div>
                </div>
              </div>
            </div>

            <div className="p-4 rounded-xl border border-[var(--anka-border)] bg-[var(--anka-surface-muted)] space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Server size={16} className="text-[var(--anka-accent)]" />
                  <h3 className="text-sm font-semibold">
                    {tr ? 'Sistem Servisleri (ankactl)' : 'System Daemons (ankactl)'}
                  </h3>
                </div>
                <span className="text-xs font-mono text-[var(--anka-text-subtle)] tabular-nums">
                  {services.filter((s) => s.status === 'active').length}/{services.length}{' '}
                  {tr ? 'aktif' : 'active'}
                </span>
              </div>
              <div className="space-y-2">
                {services.map((svc) => (
                  <div
                    key={svc.name}
                    className="p-3 rounded-lg border border-[var(--anka-border)] bg-[var(--anka-surface)] flex flex-wrap items-center justify-between gap-3 text-xs"
                  >
                    <div className="min-w-0">
                      <div className="flex items-center gap-2 font-mono">
                        <span className="font-semibold text-[var(--anka-text)]">{svc.name}</span>
                        <span
                          className={
                            svc.status === 'active'
                              ? 'text-emerald-600 dark:text-emerald-400'
                              : 'text-amber-600 dark:text-amber-400'
                          }
                        >
                          {svc.status}
                        </span>
                        {svc.pid && (
                          <span className="text-[var(--anka-text-subtle)]">PID {svc.pid}</span>
                        )}
                      </div>
                      <div className="text-[11px] text-[var(--anka-text-subtle)] mt-0.5">
                        {tr ? svc.descriptionTr : svc.descriptionEn}
                      </div>
                    </div>
                    <div className="flex items-center gap-1.5">
                      {svc.status === 'active' ? (
                        <button
                          onClick={() => showToast(controlService(svc.name, 'stop').message)}
                          disabled={svc.essential}
                          className="px-2.5 py-1 rounded-md border border-[var(--anka-border-strong)] hover:bg-[var(--anka-surface-elevated)] disabled:opacity-40"
                        >
                          {tr ? 'Durdur' : 'Stop'}
                        </button>
                      ) : (
                        <button
                          onClick={() => showToast(controlService(svc.name, 'start').message)}
                          className="px-2.5 py-1 rounded-md bg-emerald-600 text-white hover:bg-emerald-500"
                        >
                          {tr ? 'Başlat' : 'Start'}
                        </button>
                      )}
                      <button
                        onClick={() => showToast(controlService(svc.name, 'restart').message)}
                        className="px-2.5 py-1 rounded-md border border-[var(--anka-border-strong)] hover:bg-[var(--anka-surface-elevated)] flex items-center gap-1"
                      >
                        <RotateCcw size={11} />
                        <span>{tr ? 'Yenile' : 'Restart'}</span>
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="p-4 rounded-xl border border-[var(--anka-border)] bg-[var(--anka-surface-muted)] space-y-3">
              <div className="flex items-center gap-2">
                <Clock size={16} className="text-amber-500" />
                <h3 className="text-sm font-semibold">
                  {tr ? 'Zamanlanmış Görevler (crond)' : 'Scheduled Cron Tasks'}
                </h3>
              </div>

              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  if (!cronCmd.trim()) return;
                  const job = addCronJob(
                    cronName || cronCmd,
                    Number(cronInterval) || 60,
                    cronCmd
                  );
                  setCronName('');
                  showToast(`Cron görevi eklendi: ${job.name}`);
                }}
                className="flex flex-wrap gap-2 text-xs"
              >
                <input
                  type="text"
                  value={cronName}
                  onChange={(e) => setCronName(e.target.value)}
                  placeholder={tr ? 'Görev adı' : 'Job name'}
                  className="px-2.5 py-1.5 rounded-lg border border-[var(--anka-border-strong)] bg-[var(--anka-surface)] text-[var(--anka-text)] outline-none w-36"
                />
                <input
                  type="number"
                  min={5}
                  max={3600}
                  value={cronInterval}
                  onChange={(e) => setCronInterval(e.target.value)}
                  className="px-2.5 py-1.5 rounded-lg border border-[var(--anka-border-strong)] bg-[var(--anka-surface)] text-[var(--anka-text)] outline-none w-20 font-mono"
                  title={tr ? 'Aralık (saniye)' : 'Interval (sec)'}
                />
                <input
                  type="text"
                  value={cronCmd}
                  onChange={(e) => setCronCmd(e.target.value)}
                  placeholder="fsck --quick"
                  className="flex-1 min-w-[160px] px-2.5 py-1.5 rounded-lg border border-[var(--anka-border-strong)] bg-[var(--anka-surface)] text-[var(--anka-text)] outline-none font-mono"
                />
                <button
                  type="submit"
                  className="px-3 py-1.5 rounded-lg bg-[var(--anka-accent)] text-[var(--anka-accent-fg)] font-medium hover:bg-[var(--anka-accent-hover)] flex items-center gap-1"
                >
                  <Plus size={13} />
                  <span>{tr ? 'Ekle' : 'Add'}</span>
                </button>
              </form>

              <div className="space-y-2">
                {cronJobs.map((job) => (
                  <div
                    key={job.id}
                    className="p-3 rounded-lg border border-[var(--anka-border)] bg-[var(--anka-surface)] flex flex-wrap items-center justify-between gap-2 text-xs"
                  >
                    <div className="min-w-0">
                      <div className="font-semibold">
                        {job.name}{' '}
                        <span className="font-mono text-[11px] text-[var(--anka-accent)]">
                          ({job.intervalSec}s)
                        </span>
                      </div>
                      <div className="text-[11px] font-mono text-[var(--anka-text-subtle)]">
                        {job.command} · {tr ? 'Çalışma' : 'Runs'}: {job.runCount} · {job.lastResult || '-'}
                      </div>
                    </div>
                    <div className="flex items-center gap-1.5">
                      <button
                        onClick={() => showToast(runCronJobNow(job.id))}
                        className="px-2 py-1 rounded-md border border-[var(--anka-border-strong)] hover:bg-[var(--anka-surface-elevated)]"
                      >
                        {tr ? 'Çalıştır' : 'Run'}
                      </button>
                      <button
                        onClick={() => toggleCronJob(job.id)}
                        className="px-2 py-1 rounded-md border border-[var(--anka-border-strong)] hover:bg-[var(--anka-surface-elevated)]"
                      >
                        {job.enabled ? (tr ? 'Pasif Et' : 'Disable') : tr ? 'Etkinleştir' : 'Enable'}
                      </button>
                      <button
                        onClick={() => removeCronJob(job.id)}
                        className="p-1 rounded-md text-rose-500 hover:bg-rose-500/10"
                      >
                        <Trash2 size={13} />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {tab === 'storage' && (
          <div className="space-y-5">
            <div className="p-4 rounded-xl border border-[var(--anka-border)] bg-[var(--anka-surface-muted)] space-y-3">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div className="flex items-center gap-2">
                  <Database size={16} className="text-[var(--anka-accent)]" />
                  <h3 className="text-sm font-semibold">
                    {tr ? `Ev Dizini Disk Kullanımı (${userHome})` : `Disk Usage (${userHome})`}
                  </h3>
                </div>
                <span className="text-xs font-mono tabular-nums text-[var(--anka-text-subtle)]">
                  {homeUsage ? `${formatBytes(homeUsage.totalBytes)} · ${homeUsage.totalFiles} dosya` : '-'}
                  {rootUsage ? ` · Toplam VFS: ${formatBytes(rootUsage.totalBytes)}` : ''}
                </span>
              </div>

              {homeUsage && (
                <div className="space-y-2">
                  {homeUsage.entries.map((entry) => {
                    const pct = Math.max(
                      3,
                      Math.round((entry.bytes / Math.max(1, homeUsage.totalBytes)) * 100)
                    );
                    return (
                      <div key={entry.path} className="space-y-1 text-xs">
                        <div className="flex items-center justify-between font-mono">
                          <span>
                            {entry.name}
                            {entry.type === 'dir' ? '/' : ''}
                          </span>
                          <span className="tabular-nums text-[var(--anka-text-subtle)]">
                            {formatBytes(entry.bytes)} · {entry.fileCount} dosya
                          </span>
                        </div>
                        <div className="h-2 rounded-full bg-[var(--anka-surface)] overflow-hidden">
                          <div
                            className="h-full bg-[var(--anka-accent)] rounded-full"
                            style={{ width: `${pct}%` }}
                          />
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>

            <div className="p-4 rounded-xl border border-[var(--anka-border)] bg-[var(--anka-surface-muted)] space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Wrench size={16} className="text-emerald-500" />
                  <h3 className="text-sm font-semibold">
                    {tr ? 'VFS Bütünlük Denetimi & Onarım (fsck)' : 'VFS Integrity Check & Repair (fsck)'}
                  </h3>
                </div>
                <button
                  onClick={() => {
                    const report = runDiskCheck(true);
                    setFsckResult(report);
                    showToast(
                      `fsck tamamlandı: ${report.checkedNodes} düğüm, ${report.repairedCount} onarım`
                    );
                  }}
                  className="px-3 py-1.5 rounded-lg text-xs font-medium bg-[var(--anka-accent)] text-[var(--anka-accent-fg)] hover:bg-[var(--anka-accent-hover)]"
                >
                  {tr ? 'fsck Çalıştır' : 'Run fsck'}
                </button>
              </div>
              {fsckResult ? (
                <div className="text-xs font-mono space-y-1 p-3 rounded-lg bg-[var(--anka-surface)] border border-[var(--anka-border)]">
                  <div>
                    Durum: {fsckResult.healthy ? 'SAĞLIKLI' : 'SORUNLU'} · İncelenen:{' '}
                    {fsckResult.checkedNodes} · Bulunan: {fsckResult.issuesFound} · Onarılan:{' '}
                    {fsckResult.repairedCount}
                  </div>
                  {fsckResult.details.length === 0 ? (
                    <div className="text-emerald-500">Dosya sistemi bütünlüğü hatasız doğrulandı.</div>
                  ) : (
                    fsckResult.details.map((d, i) => (
                      <div key={i} className="text-amber-500">
                        {d}
                      </div>
                    ))
                  )}
                </div>
              ) : (
                <p className="text-xs text-[var(--anka-text-subtle)]">
                  Tüm VFS düğümlerini, dosya boyutlarını, eksik sistem klasörlerini (~/İndirilenler, ~/.Trash, ~/.sandbox) denetler ve onarır.
                </p>
              )}
            </div>
          </div>
        )}

        {tab === 'network' && (
          <div className="space-y-4">
            {/* Live Internet & DNS Check */}
            <div className="p-4 rounded-xl border border-[var(--anka-border)] bg-[var(--anka-surface-muted)] space-y-3">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div className="flex items-center gap-2">
                  <Globe size={16} className="text-[var(--anka-accent)]" />
                  <h3 className="text-sm font-semibold">
                    {tr ? 'Canlı İnternet Köprüsü & DNS Çözümleme' : 'Live Internet Bridge & DNS'}
                  </h3>
                </div>
                <button
                  onClick={() => void refreshNetStatus()}
                  className="px-3 py-1 rounded-lg text-xs border border-[var(--anka-border-strong)] hover:bg-[var(--anka-surface-elevated)] flex items-center gap-1"
                >
                  <RefreshCw size={12} />
                  <span>{tr ? 'Bağlantıyı Test Et' : 'Probe Link'}</span>
                </button>
              </div>
              <div className="text-xs font-mono text-[var(--anka-text-subtle)] tabular-nums">
                {netStatus === null
                  ? 'Kontrol ediliyor...'
                  : netStatus.online
                    ? `DURUM: ÇEVRİMİÇİ · RTT: ${netStatus.rttMs} ms · DNS: ${netStatus.dnsOk ? 'OK' : 'ERR'} · Gateway IP: ${netStatus.gatewayIp || '-'}`
                    : `DURUM: ÇEVRİMDIŞI (${netStatus.error || 'Bağlantı yok'})`}
              </div>

              <form
                onSubmit={async (e) => {
                  e.preventDefault();
                  if (!dnsProbeHost.trim()) return;
                  setDnsLoading(true);
                  const res = await resolveDnsLive(dnsProbeHost.trim());
                  setDnsResult(res);
                  setDnsLoading(false);
                }}
                className="flex gap-2 text-xs"
              >
                <input
                  type="text"
                  value={dnsProbeHost}
                  onChange={(e) => setDnsProbeHost(e.target.value)}
                  placeholder="wikipedia.org"
                  className="flex-1 px-3 py-1.5 rounded-lg border border-[var(--anka-border-strong)] bg-[var(--anka-surface)] font-mono outline-none"
                />
                <button
                  type="submit"
                  disabled={dnsLoading}
                  className="px-3 py-1.5 rounded-lg bg-[var(--anka-accent)] text-[var(--anka-accent-fg)] font-medium hover:bg-[var(--anka-accent-hover)]"
                >
                  {dnsLoading ? '...' : 'nslookup'}
                </button>
              </form>

              {dnsResult && (
                <div className="p-3 rounded-lg bg-[var(--anka-surface)] border border-[var(--anka-border)] text-xs font-mono space-y-1">
                  {dnsResult.ok ? (
                    <>
                      <div>
                        {dnsResult.host} ({dnsResult.tookMs} ms)
                      </div>
                      <div>A (IPv4): {dnsResult.v4?.join(', ') || '-'}</div>
                      <div>AAAA (IPv6): {dnsResult.v6?.join(', ') || '-'}</div>
                    </>
                  ) : (
                    <div className="text-rose-500">{dnsResult.error || 'DNS başarısız'}</div>
                  )}
                </div>
              )}
            </div>

            {networkInterfaces.map((ifc) => (
              <div
                key={ifc.name}
                className="p-4 rounded-xl border border-[var(--anka-border)] bg-[var(--anka-surface-muted)] flex items-center justify-between gap-4"
              >
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-[var(--anka-accent-soft)] text-[var(--anka-accent)] flex items-center justify-center">
                    <Network size={18} />
                  </div>
                  <div>
                    <div className="text-sm font-semibold font-mono">
                      {ifc.name} · {ifc.ip}
                    </div>
                    <div className="text-xs text-[var(--anka-text-subtle)] font-mono">
                      MAC {ifc.mac} · Mask {ifc.netmask}
                    </div>
                  </div>
                </div>
                <div className="text-right text-xs font-mono tabular-nums space-y-0.5">
                  <div className="text-emerald-600 dark:text-emerald-400 font-medium">{ifc.status}</div>
                  <div className="text-[var(--anka-text-subtle)]">
                    RX: {ifc.rxBytes} B ({ifc.rxPackets} pkt)
                  </div>
                  <div className="text-[var(--anka-text-subtle)]">
                    TX: {ifc.txBytes} B ({ifc.txPackets} pkt)
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

        {tab === 'syscalls' && (
          <div className="space-y-3">
            <div className="flex items-center gap-2 text-xs">
              <div className="relative flex-1 max-w-xs">
                <Search
                  size={13}
                  className="absolute left-2.5 top-1/2 -translate-y-1/2 text-[var(--anka-text-subtle)]"
                />
                <input
                  type="text"
                  value={syscallFilter}
                  onChange={(e) => setSyscallFilter(e.target.value)}
                  placeholder={tr ? 'Sistem çağrısı filtrele (sys_write, PID)...' : 'Filter syscalls...'}
                  className="w-full pl-8 pr-3 py-1.5 rounded-lg border border-[var(--anka-border)] bg-[var(--anka-surface-muted)] outline-none focus:border-[var(--anka-accent)]"
                />
              </div>
              <span className="text-[var(--anka-text-subtle)] font-mono tabular-nums">
                {syscalls.length} {tr ? 'kayıt' : 'records'}
              </span>
            </div>
            <div className="rounded-xl border border-[var(--anka-terminal-border)] bg-[var(--anka-terminal-bg)] text-[var(--anka-terminal-fg)] p-3 font-mono text-xs space-y-1.5">
              {syscalls.length === 0 ? (
                <div className="text-[var(--anka-terminal-muted)] py-4 text-center">
                  {tr ? 'Henüz sistem çağrısı kaydedilmedi.' : 'No syscalls recorded yet.'}
                </div>
              ) : (
                syscalls
                  .filter((sc) => {
                    const q = syscallFilter.trim().toLowerCase();
                    if (!q) return true;
                    return (
                      sc.name.toLowerCase().includes(q) ||
                      sc.args.toLowerCase().includes(q) ||
                      String(sc.pid).includes(q)
                    );
                  })
                  .map((sc) => (
                    <div key={sc.id} className="flex items-center gap-3 tabular-nums">
                      <span className="text-[var(--anka-terminal-muted)] shrink-0">
                        {new Date(sc.timestamp).toLocaleTimeString('tr-TR')}
                      </span>
                      <span className="text-amber-600 dark:text-amber-400 shrink-0 w-7">R{sc.ring ?? 3}</span>
                      <span className="text-[var(--anka-accent)] shrink-0 w-16">PID:{sc.pid}</span>
                      <span className="text-emerald-600 dark:text-emerald-400 shrink-0 w-36 truncate">{sc.name}</span>
                      <span className="text-[var(--anka-terminal-fg)] truncate flex-1">{sc.args}</span>
                      <span className={sc.status === 'OK' ? 'text-emerald-600 dark:text-emerald-400' : 'text-rose-600 dark:text-rose-400'}>
                        {sc.status}
                      </span>
                    </div>
                  ))
              )}
            </div>
          </div>
        )}

        {tab === 'logs' && (
          <div className="space-y-3">
            <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
              <div className="flex items-center gap-2 flex-1 min-w-[200px]">
                <div className="relative flex-1 max-w-xs">
                  <Search
                    size={13}
                    className="absolute left-2.5 top-1/2 -translate-y-1/2 text-[var(--anka-text-subtle)]"
                  />
                  <input
                    type="text"
                    value={logFilter}
                    onChange={(e) => setLogFilter(e.target.value)}
                    placeholder={tr ? 'dmesg içinde ara (mmu, vfs, sched)...' : 'Search dmesg...'}
                    className="w-full pl-8 pr-3 py-1.5 rounded-lg border border-[var(--anka-border)] bg-[var(--anka-surface-muted)] outline-none focus:border-[var(--anka-accent)]"
                  />
                </div>
                <div className="flex items-center gap-1 p-0.5 rounded-lg bg-[var(--anka-surface-muted)] border border-[var(--anka-border)]">
                  {(['ALL', 'INFO', 'WARN', 'ERR'] as const).map((lvl) => (
                    <button
                      key={lvl}
                      onClick={() => setLogLevelFilter(lvl)}
                      className={`px-2 py-1 rounded text-[11px] font-mono ${
                        logLevelFilter === lvl
                          ? 'bg-[var(--anka-surface)] text-[var(--anka-text)] shadow-sm font-medium'
                          : 'text-[var(--anka-text-subtle)]'
                      }`}
                    >
                      {lvl}
                    </button>
                  ))}
                </div>
              </div>
              <button
                onClick={() => {
                  clearKernelLogs();
                  showToast(tr ? 'dmesg tamponu temizlendi' : 'dmesg buffer cleared');
                }}
                className="px-2.5 py-1.5 rounded-lg border border-[var(--anka-border-strong)] hover:bg-[var(--anka-surface-elevated)] flex items-center gap-1"
              >
                <Trash2 size={12} />
                <span>{tr ? 'Temizle' : 'Clear'}</span>
              </button>
            </div>
            <div className="rounded-xl border border-[var(--anka-terminal-border)] bg-[var(--anka-terminal-bg)] text-[var(--anka-terminal-fg)] p-3 font-mono text-xs space-y-1.5">
              <div className="flex items-center gap-2 text-[var(--anka-terminal-muted)] pb-2 border-b border-[var(--anka-terminal-border)]">
                <ScrollText size={14} />
                <span>AnkaKernel Ring Buffer</span>
              </div>
              {kernelLogs
                .filter((log) => {
                  if (logLevelFilter !== 'ALL' && log.level !== logLevelFilter) return false;
                  const q = logFilter.trim().toLowerCase();
                  if (!q) return true;
                  return (
                    log.subsystem.toLowerCase().includes(q) ||
                    log.message.toLowerCase().includes(q)
                  );
                })
                .map((log) => (
                  <div key={log.id} className="flex items-start gap-2.5 leading-relaxed">
                    <span className="text-[var(--anka-terminal-muted)] tabular-nums shrink-0">
                      [{String(log.uptimeSec).padStart(4, '0')}.000]
                    </span>
                    <span
                      className={`shrink-0 ${
                        log.level === 'ERR'
                          ? 'text-rose-600 dark:text-rose-400'
                          : log.level === 'WARN'
                            ? 'text-amber-600 dark:text-amber-400'
                            : 'text-[var(--anka-accent)]'
                      }`}
                    >
                      {log.subsystem}:
                    </span>
                    <span className="text-[var(--anka-terminal-fg)]">{log.message}</span>
                  </div>
                ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
