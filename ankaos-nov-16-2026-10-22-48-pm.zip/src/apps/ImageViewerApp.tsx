import React, { useEffect, useState } from 'react';
import { Download, Image as ImageIcon, Monitor, RotateCw, ZoomIn, ZoomOut } from 'lucide-react';
import { useOS } from '../os/kernel';
import { formatBytes, getNodeAtPath, HOME_PATH, listDir, normalizePath } from '../os/vfs';

interface ImageViewerAppProps {
  windowId: string;
  launchArgs?: Record<string, string>;
}

export const ImageViewerApp: React.FC<ImageViewerAppProps> = ({ launchArgs }) => {
  const { vfs, settings, updateSettings, pushNotification, currentUser } = useOS();
  const tr = settings.language === 'tr';
  const userHome = currentUser.homeDir || HOME_PATH;

  const pictures = listDir(vfs, `${userHome}/Resimler`).filter(
    (n) =>
      n.type === 'file' &&
      (n.mimeType?.startsWith('image/') || /\.(png|jpg|jpeg|webp|svg)$/i.test(n.name))
  );

  const initialPath = launchArgs?.path
    ? normalizePath(launchArgs.path, userHome, userHome)
    : pictures[0]
      ? `${userHome}/Resimler/${pictures[0].name}`
      : '';

  const [selectedPath, setSelectedPath] = useState(initialPath);
  const [zoom, setZoom] = useState(1);
  const [rotation, setRotation] = useState(0);

  useEffect(() => {
    if (launchArgs?.path) {
      setSelectedPath(normalizePath(launchArgs.path, userHome, userHome));
      setZoom(1);
      setRotation(0);
    }
  }, [launchArgs?.path, userHome]);

  const node = selectedPath ? getNodeAtPath(vfs, selectedPath) : null;
  const src = node?.content || '';

  const handleSetWallpaper = () => {
    if (!src) return;
    updateSettings({ customWallpaperUrl: src });
    pushNotification(
      tr ? 'Duvar Kağıdı Güncellendi' : 'Wallpaper Updated',
      node?.name || selectedPath,
      'settings'
    );
  };

  const handleDownload = () => {
    if (!src || !node) return;
    const a = document.createElement('a');
    a.href = src;
    a.download = node.name;
    a.click();
  };

  return (
    <div className="h-full w-full flex flex-col bg-[var(--anka-bg)] text-[var(--anka-text)] anka-theme-transition">
      {/* Toolbar */}
      <div className="px-4 py-2 border-b border-[var(--anka-border)] bg-[var(--anka-surface)] flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2 min-w-0">
          <ImageIcon size={15} className="text-amber-500 shrink-0" />
          <span className="text-xs font-medium truncate">
            {node ? node.name : tr ? 'Görsel seçilmedi' : 'No image selected'}
          </span>
          {node && (
            <span className="text-[11px] text-[var(--anka-text-subtle)] tabular-nums shrink-0">
              · {formatBytes(node.size)}
            </span>
          )}
        </div>

        <div className="flex items-center gap-1.5 shrink-0">
          {src && (
            <>
              <button
                onClick={handleSetWallpaper}
                title={tr ? 'Masaüstü Duvar Kağıdı Yap' : 'Set as Desktop Wallpaper'}
                className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg border border-[var(--anka-border)] hover:bg-[var(--anka-surface-elevated)] text-xs font-medium transition-colors whitespace-nowrap"
              >
                <Monitor size={13} className="text-[var(--anka-accent)]" />
                <span>{tr ? 'Duvar Kağıdı Yap' : 'Set Wallpaper'}</span>
              </button>
              <button
                onClick={handleDownload}
                title={tr ? 'Bilgisayara İndir' : 'Download'}
                className="p-1.5 rounded-lg border border-[var(--anka-border)] hover:bg-[var(--anka-surface-elevated)] transition-colors"
              >
                <Download size={14} />
              </button>
              <button
                onClick={() => setRotation((r) => (r + 90) % 360)}
                title={tr ? '90° Döndür' : 'Rotate 90°'}
                className="p-1.5 rounded-lg border border-[var(--anka-border)] hover:bg-[var(--anka-surface-elevated)] transition-colors"
              >
                <RotateCw size={14} />
              </button>
            </>
          )}
          <button
            onClick={() => setZoom((z) => Math.max(0.25, Number((z - 0.25).toFixed(2))))}
            className="p-1.5 rounded-lg border border-[var(--anka-border)] hover:bg-[var(--anka-surface-elevated)] transition-colors"
          >
            <ZoomOut size={14} />
          </button>
          <span className="text-xs font-mono tabular-nums w-11 text-center">
            {Math.round(zoom * 100)}%
          </span>
          <button
            onClick={() => setZoom((z) => Math.min(3, Number((z + 0.25).toFixed(2))))}
            className="p-1.5 rounded-lg border border-[var(--anka-border)] hover:bg-[var(--anka-surface-elevated)] transition-colors"
          >
            <ZoomIn size={14} />
          </button>
        </div>
      </div>

      {/* Viewport */}
      <div className="flex-1 overflow-auto os-scroll flex items-center justify-center p-6 bg-[var(--anka-bg)]">
        {src ? (
          <img
            src={src}
            alt={node?.name || 'Görsel'}
            referrerPolicy="no-referrer"
            style={{
              transform: `scale(${zoom}) rotate(${rotation}deg)`,
              transformOrigin: 'center',
            }}
            className="max-w-full max-h-full object-contain rounded-lg shadow-lg transition-transform duration-150 border border-[var(--anka-border)]"
          />
        ) : (
          <div className="text-center text-[var(--anka-text-subtle)] text-sm">
            {tr ? 'Görüntülenecek görsel bulunamadı.' : 'No image to display.'}
          </div>
        )}
      </div>

      {/* Filmstrip */}
      {pictures.length > 0 && (
        <div className="px-3 py-2 border-t border-[var(--anka-border)] bg-[var(--anka-surface)] flex items-center gap-2 overflow-x-auto os-scroll">
          {pictures.map((pic) => {
            const pPath = `${userHome}/Resimler/${pic.name}`;
            const active = pPath === selectedPath;
            return (
              <button
                key={pic.id}
                onClick={() => {
                  setSelectedPath(pPath);
                  setZoom(1);
                  setRotation(0);
                }}
                className={`px-2.5 py-1 rounded-md text-xs whitespace-nowrap transition-colors ${
                  active
                    ? 'bg-[var(--anka-accent)] text-[var(--anka-accent-fg)]'
                    : 'bg-[var(--anka-surface-elevated)] text-[var(--anka-text-muted)] hover:text-[var(--anka-text)]'
                }`}
              >
                {pic.name}
              </button>
            );
          })}
        </div>
      )}
    </div>
  );
};
