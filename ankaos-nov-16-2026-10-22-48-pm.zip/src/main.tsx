import { createRoot } from 'react-dom/client';
import App from './App.tsx';
import './index.css';
import { hydrateThemeFromStorage } from './os/theme.ts';

// İlk boyama (first paint) öncesinde localStorage üzerindeki tema/vurgu tercihini senkronize et
hydrateThemeFromStorage();

createRoot(document.getElementById('root')!).render(<App />);
