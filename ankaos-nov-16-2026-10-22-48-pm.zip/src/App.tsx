import React from 'react';
import { BootScreen } from './components/BootScreen';
import { Desktop } from './components/Desktop';
import { LockScreen } from './components/LockScreen';
import { OSProvider, useOS } from './os/kernel';

const OSShell: React.FC = () => {
  const { bootPhase } = useOS();

  if (bootPhase === 'booting' || bootPhase === 'shutdown') {
    return <BootScreen />;
  }

  if (bootPhase === 'locked') {
    return <LockScreen />;
  }

  return <Desktop />;
};

export default function App() {
  return (
    <OSProvider>
      <OSShell />
    </OSProvider>
  );
}
