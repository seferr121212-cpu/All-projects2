import { RAD, r3, sinir } from './utils';

export type Pt = [number, number];

export const G = {
  segNokta(px: number, py: number, x1: number, y1: number, x2: number, y2: number) {
    const dx = x2 - x1;
    const dy = y2 - y1;
    const L2 = dx * dx + dy * dy;
    let t = L2 ? ((px - x1) * dx + (py - y1) * dy) / L2 : 0;
    t = sinir(t, 0, 1);
    const x = x1 + t * dx;
    const y = y1 + t * dy;
    return { t, x, y, d: Math.hypot(px - x, py - y) };
  },

  alan(p: Pt[]): number {
    let s = 0;
    for (let i = 0; i < p.length; i++) {
      const a = p[i];
      const b = p[(i + 1) % p.length];
      s += a[0] * b[1] - b[0] * a[1];
    }
    return s / 2;
  },

  cevre(p: Pt[]): number {
    let s = 0;
    for (let i = 0; i < p.length; i++) {
      const a = p[i];
      const b = p[(i + 1) % p.length];
      s += Math.hypot(b[0] - a[0], b[1] - a[1]);
    }
    return s;
  },

  merkez(p: Pt[]): Pt {
    if (!p.length) return [0, 0];
    const A = G.alan(p);
    if (Math.abs(A) < 1e-9) {
      let x = 0;
      let y = 0;
      p.forEach(q => {
        x += q[0];
        y += q[1];
      });
      return [x / p.length, y / p.length];
    }
    let cx = 0;
    let cy = 0;
    for (let i = 0; i < p.length; i++) {
      const a = p[i];
      const b = p[(i + 1) % p.length];
      const f = a[0] * b[1] - b[0] * a[1];
      cx += (a[0] + b[0]) * f;
      cy += (a[1] + b[1]) * f;
    }
    const c: Pt = [cx / (6 * A), cy / (6 * A)];
    return G.icinde(c[0], c[1], p) ? c : G.icNokta(p);
  },

  icNokta(p: Pt[]): Pt {
    const b = G.bbox(p);
    const y = (b.y1 + b.y2) / 2;
    const xs: number[] = [];
    for (let i = 0; i < p.length; i++) {
      const a = p[i];
      const c = p[(i + 1) % p.length];
      if ((a[1] > y) !== (c[1] > y)) xs.push(a[0] + ((y - a[1]) / (c[1] - a[1])) * (c[0] - a[0]));
    }
    xs.sort((a, b) => a - b);
    let en = 0;
    let x = (b.x1 + b.x2) / 2;
    for (let i = 0; i + 1 < xs.length; i += 2) {
      if (xs[i + 1] - xs[i] > en) {
        en = xs[i + 1] - xs[i];
        x = (xs[i] + xs[i + 1]) / 2;
      }
    }
    return [x, y];
  },

  icinde(x: number, y: number, p: Pt[]): boolean {
    let ic = false;
    for (let i = 0, j = p.length - 1; i < p.length; j = i++) {
      const a = p[i];
      const b = p[j];
      if ((a[1] > y) !== (b[1] > y) && x < ((b[0] - a[0]) * (y - a[1])) / (b[1] - a[1]) + a[0]) ic = !ic;
    }
    return ic;
  },

  bbox(pts: Pt[]) {
    let x1 = Infinity;
    let y1 = Infinity;
    let x2 = -Infinity;
    let y2 = -Infinity;
    for (const p of pts) {
      if (p[0] < x1) x1 = p[0];
      if (p[0] > x2) x2 = p[0];
      if (p[1] < y1) y1 = p[1];
      if (p[1] > y2) y2 = p[1];
    }
    return { x1, y1, x2, y2, w: x2 - x1, h: y2 - y1 };
  },

  ucgenle(p: Pt[]): [number, number, number][] {
    const n = p.length;
    if (n < 3) return [];
    const idx = [...Array(n).keys()];
    if (G.alan(p) < 0) idx.reverse();
    const tri: [number, number, number][] = [];
    const cap = (a: Pt, b: Pt, c: Pt) => (b[0] - a[0]) * (c[1] - a[1]) - (b[1] - a[1]) * (c[0] - a[0]);
    const icUc = (P: Pt, a: Pt, b: Pt, c: Pt) => cap(a, b, P) >= -1e-12 && cap(b, c, P) >= -1e-12 && cap(c, a, P) >= -1e-12;
    let g = 0;
    while (idx.length > 3 && g < 5000) {
      g++;
      let kesti = false;
      for (let i = 0; i < idx.length; i++) {
        const ia = idx[(i + idx.length - 1) % idx.length];
        const ib = idx[i];
        const ic = idx[(i + 1) % idx.length];
        const a = p[ia];
        const b = p[ib];
        const c = p[ic];
        if (cap(a, b, c) <= 1e-12) continue;
        let bos = true;
        for (const j of idx) {
          if (j === ia || j === ib || j === ic) continue;
          const q = p[j];
          if ((q[0] === a[0] && q[1] === a[1]) || (q[0] === b[0] && q[1] === b[1]) || (q[0] === c[0] && q[1] === c[1])) continue;
          if (icUc(q, a, b, c)) {
            bos = false;
            break;
          }
        }
        if (!bos) continue;
        tri.push([ia, ib, ic]);
        idx.splice(i, 1);
        kesti = true;
        break;
      }
      if (!kesti) break;
    }
    if (idx.length === 3) tri.push([idx[0], idx[1], idx[2]]);
    return tri;
  },

  sadelestir(p: Pt[], tol: number): Pt[] {
    if (p.length < 4) return p;
    const dp = (a: Pt[], lo: number, hi: number, out: Pt[]) => {
      let en = 0;
      let ei = -1;
      const A = a[lo];
      const B = a[hi];
      for (let i = lo + 1; i < hi; i++) {
        const d = G.segNokta(a[i][0], a[i][1], A[0], A[1], B[0], B[1]).d;
        if (d > en) {
          en = d;
          ei = i;
        }
      }
      if (en > tol) {
        dp(a, lo, ei, out);
        dp(a, ei, hi, out);
      } else out.push(A);
    };
    let u = 0;
    for (let i = 1; i < p.length; i++) {
      if (Math.hypot(p[i][0] - p[0][0], p[i][1] - p[0][1]) > Math.hypot(p[u][0] - p[0][0], p[u][1] - p[0][1])) u = i;
    }
    const a1 = p.slice(0, u + 1);
    const a2 = p.slice(u).concat([p[0]]);
    const out: Pt[] = [];
    dp(a1, 0, a1.length - 1, out);
    dp(a2, 0, a2.length - 1, out);
    return out;
  },

  donder(lx: number, ly: number, r: number): Pt {
    const c = Math.cos(r * RAD);
    const s = Math.sin(r * RAD);
    return [lx * c - ly * s, lx * s + ly * c];
  },

  /** İki doğru parçasının veya sonsuz doğrunun kesişimi */
  dogruKesisim(x1: number, y1: number, x2: number, y2: number, x3: number, y3: number, x4: number, y4: number, sinirli = true) {
    const den = (x1 - x2) * (y3 - y4) - (y1 - y2) * (x3 - x4);
    if (Math.abs(den) < 1e-9) return null;
    const t = ((x1 - x3) * (y3 - y4) - (y1 - y3) * (x3 - x4)) / den;
    const u = ((x1 - x3) * (y1 - y2) - (y1 - y3) * (x1 - x2)) / den;
    if (sinirli && (t < -1e-6 || t > 1 + 1e-6 || u < -1e-6 || u > 1 + 1e-6)) return null;
    return { x: r3(x1 + t * (x2 - x1)), y: r3(y1 + t * (y2 - y1)), t, u };
  },

  /** Kavisli duvar örnek noktaları (quadratic Bezier / yay yaklaşımı) */
  egriNoktalar(x1: number, y1: number, x2: number, y2: number, egri = 0, adim = 14): Pt[] {
    if (!egri || Math.abs(egri) < 0.01) return [[x1, y1], [x2, y2]];
    const mx = (x1 + x2) / 2;
    const my = (y1 + y2) / 2;
    const L = Math.hypot(x2 - x1, y2 - y1) || 1;
    const nx = -(y2 - y1) / L;
    const ny = (x2 - x1) / L;
    const cx = mx + nx * egri * 2;
    const cy = my + ny * egri * 2;
    const out: Pt[] = [];
    for (let i = 0; i <= adim; i++) {
      const t = i / adim;
      const mt = 1 - t;
      out.push([
        r3(mt * mt * x1 + 2 * mt * t * cx + t * t * x2),
        r3(mt * mt * y1 + 2 * mt * t * cy + t * t * y2),
      ]);
    }
    return out;
  },

  /** Poligon kenar bazlı içe ofset (imar çekme sınırı için: ön kenar farklı mesafe alabilir) */
  cekmePoligon(pts: Pt[], mesafeler: number[]): Pt[] | null {
    if (pts.length < 3) return null;
    const ccw = G.alan(pts) > 0;
    const lines: { x1: number; y1: number; x2: number; y2: number }[] = [];
    for (let i = 0; i < pts.length; i++) {
      const a = pts[i];
      const b = pts[(i + 1) % pts.length];
      const dx = b[0] - a[0];
      const dy = b[1] - a[1];
      const L = Math.hypot(dx, dy);
      if (L < 1e-6) continue;
      // içeri bakan birim normal
      const nx = ccw ? -dy / L : dy / L;
      const ny = ccw ? dx / L : -dx / L;
      const d = mesafeler[i] ?? mesafeler[0] ?? 3;
      lines.push({ x1: a[0] + nx * d, y1: a[1] + ny * d, x2: b[0] + nx * d, y2: b[1] + ny * d });
    }
    if (lines.length < 3) return null;
    const out: Pt[] = [];
    for (let i = 0; i < lines.length; i++) {
      const l1 = lines[(i + lines.length - 1) % lines.length];
      const l2 = lines[i];
      const k = G.dogruKesisim(l1.x1, l1.y1, l1.x2, l1.y2, l2.x1, l2.y1, l2.x2, l2.y2, false);
      if (k) out.push([r3(k.x), r3(k.y)]);
    }
    return out.length >= 3 && Math.abs(G.alan(out)) > 0.2 ? out : null;
  },
};

export function delikli(dis: Pt[], delikler: Pt[][]): Pt[] {
  let o = G.alan(dis) > 0 ? dis.slice() : dis.slice().reverse();
  const hs = delikler
    .map(h => (G.alan(h) > 0 ? h.slice().reverse() : h.slice()))
    .filter(h => h.length >= 3 && h.every(q => G.icinde(q[0], q[1], o)));
  hs.sort((a, b) => Math.max(...b.map(q => q[0])) - Math.max(...a.map(q => q[0])));
  for (const h of hs) {
    let mi = 0;
    h.forEach((q, i) => {
      if (q[0] > h[mi][0]) mi = i;
    });
    const M = h[mi];
    let en = Infinity;
    let ei = -1;
    for (let i = 0; i < o.length; i++) {
      const a = o[i];
      const b = o[(i + 1) % o.length];
      if ((a[1] > M[1]) === (b[1] > M[1])) continue;
      const x = a[0] + ((M[1] - a[1]) / (b[1] - a[1])) * (b[0] - a[0]);
      if (x >= M[0] && x - M[0] < en) {
        en = x - M[0];
        ei = a[0] > b[0] ? i : (i + 1) % o.length;
      }
    }
    if (ei < 0) continue;
    const hd = h.slice(mi).concat(h.slice(0, mi));
    hd.push(M);
    o = o.slice(0, ei + 1).concat(hd, [o[ei]], o.slice(ei + 1));
  }
  return o;
}

export function dikdortgenlere(pts: Pt[]): { x1: number; x2: number; y1: number; y2: number }[] | null {
  for (let i = 0; i < pts.length; i++) {
    const a = pts[i];
    const b = pts[(i + 1) % pts.length];
    if (Math.abs(a[0] - b[0]) > 0.02 && Math.abs(a[1] - b[1]) > 0.02) return null;
  }
  const tek = (v: number[]) => [...new Set(v.map(x => Math.round(x * 100) / 100))].sort((a, b) => a - b);
  const xs = tek(pts.map(q => q[0]));
  const ys = tek(pts.map(q => q[1]));
  const nx = xs.length - 1;
  const ny = ys.length - 1;
  if (nx < 1 || ny < 1 || nx * ny > 900) return null;
  const ic: number[][] = [];
  for (let i = 0; i < nx; i++) {
    ic.push([]);
    for (let j = 0; j < ny; j++) {
      ic[i].push(G.icinde((xs[i] + xs[i + 1]) / 2, (ys[j] + ys[j + 1]) / 2, pts) ? 1 : 0);
    }
  }
  const dolu = (i0: number, i1: number, j0: number, j1: number) => {
    for (let i = i0; i <= i1; i++) for (let j = j0; j <= j1; j++) if (!ic[i][j]) return false;
    return true;
  };
  const kapli = ic.map(r => r.map(() => 0));
  const sonuc: { x1: number; x2: number; y1: number; y2: number }[] = [];
  for (let g = 0; g < 50; g++) {
    let en: [number, number, number, number] | null = null;
    let ea = 0;
    for (let i0 = 0; i0 < nx; i0++)
      for (let j0 = 0; j0 < ny; j0++) {
        if (!ic[i0][j0]) continue;
        for (let i1 = i0; i1 < nx && ic[i1][j0]; i1++)
          for (let j1 = j0; j1 < ny; j1++) {
            if (!dolu(i0, i1, j0, j1)) break;
            let yeni = false;
            for (let i = i0; i <= i1 && !yeni; i++) for (let j = j0; j <= j1; j++) if (!kapli[i][j]) { yeni = true; break; }
            const a = (xs[i1 + 1] - xs[i0]) * (ys[j1 + 1] - ys[j0]);
            if (yeni && a > ea) {
              ea = a;
              en = [i0, i1, j0, j1];
            }
          }
      }
    if (!en) break;
    const [i0, i1, j0, j1] = en;
    for (let i = i0; i <= i1; i++) for (let j = j0; j <= j1; j++) kapli[i][j] = 1;
    sonuc.push({ x1: xs[i0], x2: xs[i1 + 1], y1: ys[j0], y2: ys[j1 + 1] });
  }
  return sonuc;
}
