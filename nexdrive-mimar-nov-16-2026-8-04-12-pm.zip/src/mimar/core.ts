import { BLOK, MOB, PARA_BIRIM, mobOlcu, odaZemini } from './catalog';
import { G, Pt } from './geometry';
import { boruCakismaBul } from './mep';
import { DEPO } from './storage';
import type { Aciklik, Duvar, DurumS, Kat, Mobilya, Proje } from './types';
import { RAD, bildir, fmt, kopya, r3, sinir } from './utils';

export function yeniProje(ad = 'Yeni proje'): Proje {
  const k = Math.random().toString(36).slice(2, 10);
  return {
    id: Math.random().toString(36).slice(2, 10),
    ad,
    surum: 2,
    olusturma: Date.now(),
    guncelleme: Date.now(),
    cizen: '',
    firma: 'NexDrive Engineering',
    adres: '',
    ada: '',
    parsel: '',
    paftaNo: 'M-01',
    revizyon: 'Rev.0',
    katlar: [{ id: k, ad: 'Zemin Kat', h: 2.8, d: 0.15, sira: 0 }],
    duvarlar: [],
    aciklar: [],
    odalar: [],
    mobilya: [],
    kirisler: [],
    olculer: [],
    yazilar: [],
    dis: [],
    akslar: [],
    kesitler: [],
    tesisat: [],
    borular: [],
    arsa: null,
    altlik: null,
    cati: { tip: 'kirma', egim: 30, sacak: 0.6, renk: '#b5533c', baca: true, oluk: true, catiPencere: false },
    cephe: {
      renk: '#efe6d4',
      dogramaRenk: '#f4f4f2',
      malzeme: 'gazbeton',
      icMalzeme: 'gazbeton',
      mantolama: true,
      subasman: 0.45,
      kaplama: 'siva',
    },
    ayar: {
      temelDerinlik: 1.5,
      maxTaks: 0.4,
      maxKaks: 1.2,
      kabarma: 1.25,
      kamyon: 16,
      binaKot: null,
      kuzey: 0,
      enlem: 41.01,
      boylam: 28.98,
      tarih: '06-21',
      saat: 14,
      golge: true,
      cekmeOn: 5,
      cekmeYan: 3,
      cekmeArka: 3,
      onCepheKenar: 2,
      kdvOran: 20,
      muteahhitOran: 0,
      paraBirimi: 'TRY',
      kurUsd: 36.5,
      kurEur: 39.5,
      gizliKalemler: [],
      ozelKalemler: [],
    },
    fiyat: {},
  };
}

export const S: DurumS = {
  p: null,
  katId: null,
  arac: 'sec',
  secili: null,
  cokluSecili: [],
  pano: [],
  gorunum: 'plan',
  disiplin: 'tumu',
  katmanlar: {
    duvarlar: true,
    mobilya: true,
    akslar: true,
    sihhiBoru: true,
    elektrikHatti: true,
    dogalgazHatti: true,
    olculer: true,
    arazi: true,
  },
  zoningGoster: false,
  duvarK: 0.25,
  duvarTur: 'dis',
  duvarEgri: 0,
  grid: 0.05,
  orto: true,
  olcuGoster: true,
  mobTip: 'kanepe',
  mobRot: 0,
  disTip: 'agac',
  kapiTip: 'kapi',
  pencere: { g: 1.4, h: 1.4, p: 0.9 },
  kapi: { g: 0.9, h: 2.1 },
  aksYon: 'd',
  tesTip: 'priz',
  tesisatGoster: true,
  boruGoster: true,
  boruTur: 'temiz_su_soguk',
  boruCap: 20,
  boruKot: 0.15,
  kolonBoyut: 0.3,
  d3Kirli: true,
  d3Tesisat: true,
  d3Aks: false,
  d3Xray: false,
  d3OlcMod: false,
  d3OlcNoktalar: [],
};

export const P = (): Proje => S.p!;
export const kat = (id = S.katId || ''): Kat => P().katlar.find(k => k.id === id) || P().katlar[0];
export const katIdx = (id = S.katId || ''): number => Math.max(0, P().katlar.findIndex(k => k.id === id));
export const katDuvar = (id = S.katId || ''): Duvar[] => P().duvarlar.filter(w => w.kat === id);
export const duvar = (id: string): Duvar | undefined => P().duvarlar.find(w => w.id === id);

export function duvarBoy(w: Duvar): number {
  const chord = Math.hypot(w.x2 - w.x1, w.y2 - w.y1);
  if (!w.egri || Math.abs(w.egri) < 0.01) return chord;
  const pts = G.egriNoktalar(w.x1, w.y1, w.x2, w.y2, w.egri, 16);
  let L = 0;
  for (let i = 0; i + 1 < pts.length; i++) L += Math.hypot(pts[i + 1][0] - pts[i][0], pts[i + 1][1] - pts[i][1]);
  return L;
}

/** Zemin (ilk bodrum olmayan kat) subasman kotundadır; bodrum katlar negatif kota iner. */
export function zeminKatIndeks(): number {
  const p = P();
  const z = p.katlar.findIndex(k => (k.sira ?? 0) >= 0);
  return z >= 0 ? z : 0;
}

export function katTaban(i: number): number {
  const p = P();
  const sub = p.cephe.subasman || 0;
  const zIdx = zeminKatIndeks();
  if (i === zIdx) return sub;
  if (i > zIdx) {
    let y = sub;
    for (let j = zIdx; j < i; j++) y += p.katlar[j].h + p.katlar[j + 1].d;
    return y;
  }
  let y = sub;
  for (let j = zIdx - 1; j >= i; j--) y -= p.katlar[j].h + p.katlar[j + 1].d;
  return y;
}

export function paraYaz(tlTutar: number, kurGoster = true): string {
  const p = S.p;
  const pb = p?.ayar.paraBirimi || 'TRY';
  const sem = PARA_BIRIM[pb].sembol;
  let val = tlTutar || 0;
  if (kurGoster && pb === 'USD') val = val / (p?.ayar.kurUsd || 36.5);
  if (kurGoster && pb === 'EUR') val = val / (p?.ayar.kurEur || 39.5);
  return Number(val).toLocaleString('tr-TR', { maximumFractionDigits: pb === 'TRY' ? 0 : 2 }) + ' ' + sem;
}

/** Duvar boyu/uçları değiştiğinde açıklıkların duvar içinde kalmasını garantiler */
export function acikDogrula(duvarId: string): void {
  const p = P();
  const w = duvar(duvarId);
  if (!w) return;
  const L = Math.hypot(w.x2 - w.x1, w.y2 - w.y1);
  if (L < 0.08) {
    p.aciklar = p.aciklar.filter(a => a.duvar !== duvarId);
    return;
  }
  p.aciklar
    .filter(a => a.duvar === duvarId)
    .forEach(a => {
      if (a.g > L - 0.06) a.g = r3(Math.max(0.3, L - 0.06));
      const minT = (a.g / 2 + 0.02) / L;
      const maxT = 1 - minT;
      a.t = r3(sinir(a.t, minT, Math.max(minT, maxT)));
    });
}

export function tumAciklariDogrula(katId?: string): void {
  const p = P();
  p.duvarlar.filter(w => !katId || w.kat === katId).forEach(w => acikDogrula(w.id));
}

export function duvarEkle(
  katId: string,
  x1: number,
  y1: number,
  x2: number,
  y2: number,
  k: number,
  tur: 'dis' | 'ic',
  egri = 0,
): Duvar[] {
  [x1, y1, x2, y2] = [x1, y1, x2, y2].map(r3);
  const L = Math.hypot(x2 - x1, y2 - y1);
  if (L < 0.05) return [];
  if (Math.abs(egri) > 0.01) {
    const w: Duvar = { id: Math.random().toString(36).slice(2, 10), kat: katId, x1, y1, x2, y2, k, tur, egri: r3(egri) };
    P().duvarlar.push(w);
    return [w];
  }
  const ux = (x2 - x1) / L;
  const uy = (y2 - y1) / L;
  let ar: [number, number][] = [[0, L]];
  for (const w of P().duvarlar.filter(w => w.kat === katId && !w.egri)) {
    const d1 = Math.abs((w.x1 - x1) * uy - (w.y1 - y1) * ux);
    const d2 = Math.abs((w.x2 - x1) * uy - (w.y2 - y1) * ux);
    if (d1 > 0.02 || d2 > 0.02) continue;
    let a = (w.x1 - x1) * ux + (w.y1 - y1) * uy;
    let b = (w.x2 - x1) * ux + (w.y2 - y1) * uy;
    if (a > b) [a, b] = [b, a];
    ar = ar.flatMap(([s, e]) => {
      if (b <= s + 0.01 || a >= e - 0.01) return [[s, e] as [number, number]];
      const r: [number, number][] = [];
      if (a > s + 0.05) r.push([s, a]);
      if (b < e - 0.05) r.push([b, e]);
      return r;
    });
  }
  return ar.map(([s, e]) => {
    const w: Duvar = {
      id: Math.random().toString(36).slice(2, 10),
      kat: katId,
      x1: r3(x1 + ux * s),
      y1: r3(y1 + uy * s),
      x2: r3(x1 + ux * e),
      y2: r3(y1 + uy * e),
      k,
      tur,
    };
    P().duvarlar.push(w);
    return w;
  });
}

export function uctaBagli(w: Duvar, x: number, y: number): Duvar | null {
  for (const o of P().duvarlar) {
    if (o === w || o.kat !== w.kat) continue;
    if (G.segNokta(x, y, o.x1, o.y1, o.x2, o.y2).d < Math.max(o.k / 2, 0.02) + 0.01) return o;
  }
  return null;
}

export function duvarParcalari(w: Duvar): { L: number; tam: [number, number][]; acik: { a: Aciklik; s: number; e: number }[] } {
  const L = Math.hypot(w.x2 - w.x1, w.y2 - w.y1);
  const A = P()
    .aciklar.filter(a => a.duvar === w.id)
    .map(a => {
      const m = sinir(a.t, 0, 1) * L;
      const g = Math.min(a.g, Math.max(0.2, L - 0.02));
      return { a, s: sinir(m - g / 2, 0, L), e: sinir(m + g / 2, 0, L) };
    })
    .sort((x, y) => x.s - y.s);
  const tam: [number, number][] = [];
  let c = 0;
  for (const o of A) {
    if (o.s > c + 0.005) tam.push([c, o.s]);
    c = Math.max(c, o.e);
  }
  if (c < L - 0.005) tam.push([c, L]);
  return { L, tam, acik: A };
}

export function dikHizala(p: Pt[], tol = 0.12): Pt[] {
  const kume = (v: number[]) => {
    const s = [...v].sort((a, b) => a - b);
    const g: number[][] = [];
    for (const x of s) {
      const l = g[g.length - 1];
      if (l && x - l[l.length - 1] <= tol) l.push(x);
      else g.push([x]);
    }
    return g.map(k => [k[0], k[k.length - 1], k.reduce((a, b) => a + b, 0) / k.length]);
  };
  const kx = kume(p.map(q => q[0]));
  const ky = kume(p.map(q => q[1]));
  const es = (k: number[][], v: number) => {
    const c = k.find(c => v >= c[0] - 1e-9 && v <= c[1] + 1e-9);
    return c ? c[2] : v;
  };
  let o = p.map(q => [es(kx, q[0]), es(ky, q[1])] as Pt);
  o = o.filter((q, i) => {
    const n = o[(i + 1) % o.length];
    return Math.hypot(n[0] - q[0], n[1] - q[1]) > 1e-6;
  });
  const t: Pt[] = [];
  for (let i = 0; i < o.length; i++) {
    const a = o[(i + o.length - 1) % o.length];
    const m = o[i];
    const z = o[(i + 1) % o.length];
    if (Math.abs((m[0] - a[0]) * (z[1] - a[1]) - (m[1] - a[1]) * (z[0] - a[0])) > 1e-6) t.push(m);
  }
  return t.length >= 3 ? t : p;
}

export function odaBul(
  katId: string,
  px: number,
  py: number,
  filtre?: (w: Duvar) => boolean,
): { pts?: Pt[]; alan?: number; acik?: boolean; duvar?: boolean } | null {
  const W = P().duvarlar.filter(w => w.kat === katId && (!filtre || filtre(w)));
  if (!W.length) return null;
  const pts: Pt[] = [];
  W.forEach(w => {
    pts.push([w.x1, w.y1], [w.x2, w.y2]);
    if (w.egri) G.egriNoktalar(w.x1, w.y1, w.x2, w.y2, w.egri, 10).forEach(q => pts.push(q));
  });
  const b = G.bbox(pts);
  b.x1 -= 0.5;
  b.y1 -= 0.5;
  b.x2 += 0.5;
  b.y2 += 0.5;
  if (px < b.x1 || px > b.x2 || py < b.y1 || py > b.y2) return { acik: true };
  let c = 0.05;
  let nx = Math.ceil((b.x2 - b.x1) / c);
  let ny = Math.ceil((b.y2 - b.y1) / c);
  while (nx * ny > 3e6) {
    c *= 1.5;
    nx = Math.ceil((b.x2 - b.x1) / c);
    ny = Math.ceil((b.y2 - b.y1) / c);
  }
  const g = new Uint8Array(nx * ny);
  for (const w of W) {
    const r = w.k / 2 + 0.002;
    const segs = G.egriNoktalar(w.x1, w.y1, w.x2, w.y2, w.egri || 0, w.egri ? 14 : 1);
    for (let s = 0; s + 1 < segs.length; s++) {
      const [ax, ay] = segs[s];
      const [bx, by] = segs[s + 1];
      const i0 = Math.max(0, Math.floor((Math.min(ax, bx) - r - b.x1) / c));
      const i1 = Math.min(nx - 1, Math.ceil((Math.max(ax, bx) + r - b.x1) / c));
      const j0 = Math.max(0, Math.floor((Math.min(ay, by) - r - b.y1) / c));
      const j1 = Math.min(ny - 1, Math.ceil((Math.max(ay, by) + r - b.y1) / c));
      for (let j = j0; j <= j1; j++) {
        for (let i = i0; i <= i1; i++) {
          const x = b.x1 + (i + 0.5) * c;
          const y = b.y1 + (j + 0.5) * c;
          if (G.segNokta(x, y, ax, ay, bx, by).d <= r) g[j * nx + i] = 1;
        }
      }
    }
  }
  const si = Math.floor((px - b.x1) / c);
  const sj = Math.floor((py - b.y1) / c);
  if (g[sj * nx + si]) return { duvar: true };
  const q = new Int32Array(nx * ny);
  let h = 0;
  let t = 0;
  q[t++] = sj * nx + si;
  g[sj * nx + si] = 2;
  let sayi = 0;
  while (h < t) {
    const k = q[h++];
    const i = k % nx;
    const j = (k - i) / nx;
    sayi++;
    if (i === 0 || j === 0 || i === nx - 1 || j === ny - 1) return { acik: true };
    for (const n of [k - 1, k + 1, k - nx, k + nx]) {
      if (!g[n]) {
        g[n] = 2;
        q[t++] = n;
      }
    }
  }
  const kenar = new Map<string, [number, number][]>();
  const ekle = (a: [number, number], bb: [number, number]) => {
    const ka = a[0] + ',' + a[1];
    let list = kenar.get(ka);
    if (!list) {
      list = [];
      kenar.set(ka, list);
    }
    list.push(bb);
  };
  for (let j = 0; j < ny; j++) {
    for (let i = 0; i < nx; i++) {
      if (g[j * nx + i] !== 2) continue;
      if (g[(j - 1) * nx + i] !== 2) ekle([i, j], [i + 1, j]);
      if (g[j * nx + i + 1] !== 2) ekle([i + 1, j], [i + 1, j + 1]);
      if (g[(j + 1) * nx + i] !== 2) ekle([i + 1, j + 1], [i, j + 1]);
      if (g[j * nx + i - 1] !== 2) ekle([i, j + 1], [i, j]);
    }
  }
  const donguler: [number, number][][] = [];
  for (const [ka, list] of kenar) {
    while (list.length) {
      const bas = ka.split(',').map(Number) as [number, number];
      const d: [number, number][] = [bas];
      let cur = list.pop()!;
      let sinirr = 0;
      while (sinirr++ < 200000) {
        if (cur[0] === bas[0] && cur[1] === bas[1]) break;
        d.push(cur);
        const l = kenar.get(cur[0] + ',' + cur[1]);
        if (!l || !l.length) break;
        cur = l.pop()!;
      }
      donguler.push(d);
    }
  }
  let en: [number, number][] | null = null;
  let ea = 0;
  for (const d of donguler) {
    const a = Math.abs(G.alan(d));
    if (a > ea) {
      ea = a;
      en = d;
    }
  }
  if (!en) return null;
  let p = en.map(v => [b.x1 + v[0] * c, b.y1 + v[1] * c] as Pt);
  const temiz: Pt[] = [];
  for (let i = 0; i < p.length; i++) {
    const a = p[(i + p.length - 1) % p.length];
    const m = p[i];
    const z = p[(i + 1) % p.length];
    if (Math.abs((m[0] - a[0]) * (z[1] - a[1]) - (m[1] - a[1]) * (z[0] - a[0])) > 1e-9) temiz.push(m);
  }
  p = dikHizala(G.sadelestir(temiz, c * 1.6)).map(v => [r3(v[0]), r3(v[1])] as Pt);
  if (G.alan(p) < 0) p.reverse();
  return { pts: p, alan: sayi * c * c };
}

export function katOturum(katId: string): Pt[] | null {
  const D = P().duvarlar.filter(w => w.kat === katId && w.tur === 'dis');
  if (D.length < 3) return null;
  const pts: Pt[] = [];
  D.forEach(w => pts.push([w.x1, w.y1], [w.x2, w.y2]));
  const b = G.bbox(pts);
  const aday: Pt[] = [[b.x1 + b.w / 2, b.y1 + b.h / 2]];
  P()
    .odalar.filter(o => o.kat === katId)
    .forEach(o => aday.push(G.merkez(o.pts)));
  for (let i = 1; i < 6; i++) {
    aday.push([b.x1 + (b.w * i) / 6, b.y1 + b.h / 2], [b.x1 + b.w / 2, b.y1 + (b.h * i) / 6]);
  }
  for (const [x, y] of aday) {
    const r = odaBul(katId, x, y, w => w.tur === 'dis');
    if (r && r.pts && r.pts.length >= 3) return r.pts;
  }
  return null;
}

export function odalariGuncelle(katId: string): void {
  const p = P();
  tumAciklariDogrula(katId);
  for (const o of p.odalar.filter(o => o.kat === katId)) {
    const m = G.merkez(o.pts);
    const r = odaBul(katId, m[0], m[1]);
    if (r && r.pts && r.pts.length >= 3) {
      o.pts = r.pts;
    } else {
      // Oda bölündüyse kenar yakınından tekrar dene
      const c2 = G.icNokta(o.pts);
      const r2 = odaBul(katId, c2[0], c2[1]);
      if (r2 && r2.pts && r2.pts.length >= 3) o.pts = r2.pts;
    }
  }
}

/* Merdiven & Kirişler & Akslar */
export function merdivenler(katId: string) {
  return P()
    .mobilya.filter(m => m.kat === katId && MOB[m.tip]?.ozel?.startsWith('merdiven'))
    .map(m => {
      const { w, d } = mobOlcu(m);
      return {
        m,
        w,
        d,
        tip: MOB[m.tip].ozel as 'merdiven' | 'merdiven_l' | 'merdiven_u' | 'merdiven_doner',
        pts: [
          [-w / 2, -d / 2],
          [w / 2, -d / 2],
          [w / 2, d / 2],
          [-w / 2, d / 2],
        ].map(q => {
          const t = G.donder(q[0], q[1], m.r || 0);
          return [m.x + t[0], m.y + t[1]] as Pt;
        }),
      };
    });
}

export function merdivenYuk(md: ReturnType<typeof merdivenler>[number], x: number, y: number): number | null {
  const t = G.donder(x - md.m.x, y - md.m.y, -(md.m.r || 0));
  if (Math.abs(t[0]) > md.w / 2 || Math.abs(t[1]) > md.d / 2) return null;
  if (md.tip === 'merdiven') return (md.d / 2 - t[1]) / md.d;
  if (md.tip === 'merdiven_l') {
    const u = (t[0] + md.w / 2) / md.w;
    const v = (md.d / 2 - t[1]) / md.d;
    return sinir((u + v) * 0.55, 0, 1);
  }
  if (md.tip === 'merdiven_u') {
    const v = (md.d / 2 - t[1]) / md.d;
    return t[0] < 0 ? v * 0.48 : 0.52 + (1 - v) * 0.48;
  }
  const ang = (Math.atan2(t[1], t[0]) + Math.PI) / (2 * Math.PI);
  return sinir(ang, 0, 1);
}

export function aksAdlari(): Record<string, string> {
  const A = P().akslar || [];
  const d = A.filter(a => a.yon === 'd').sort((a, b) => a.k - b.k);
  const y = A.filter(a => a.yon === 'y').sort((a, b) => a.k - b.k);
  const ad: Record<string, string> = {};
  d.forEach((a, i) => (ad[a.id] = String(i + 1)));
  y.forEach((a, i) => (ad[a.id] = 'ABCDEFGHIJKLMNOPRSTUVYZ'[i] || 'Y' + i));
  return ad;
}

export function kirisListesi(katId: string) {
  const p = P();
  const kol = p.mobilya.filter(o => o.kat === katId && o.tip === 'kolon');
  const sonuc: { a: { x: number; y: number }; b: { x: number; y: number }; L: number; w: number; h: number; ozel?: boolean; id?: string }[] = [];
  for (const a of p.akslar || []) {
    const s = kol
      .filter(o => Math.abs((a.yon === 'd' ? o.x : o.y) - a.k) < 0.05)
      .sort((u, v) => (a.yon === 'd' ? u.y - v.y : u.x - v.x));
    for (let i = 0; i + 1 < s.length; i++) {
      const L = Math.hypot(s[i + 1].x - s[i].x, s[i + 1].y - s[i].y);
      if (L <= 9) sonuc.push({ a: s[i], b: s[i + 1], L, w: 0.25, h: 0.5 });
    }
  }
  for (const k of p.kirisler || []) {
    if (k.kat !== katId) continue;
    const L = Math.hypot(k.x2 - k.x1, k.y2 - k.y1);
    if (L > 0.1) sonuc.push({ a: { x: k.x1, y: k.y1 }, b: { x: k.x2, y: k.y2 }, L, w: k.w || 0.25, h: k.h || 0.5, ozel: true, id: k.id });
  }
  return sonuc;
}

/* Arazi */
export const ARAZI = {
  noktalar() {
    return P().dis.filter(d => d.tip === 'kot');
  },
  var() {
    return this.noktalar().length > 0;
  },
  z(x: number, y: number): number {
    const N = this.noktalar();
    if (!N.length) return 0;
    let sw = 0;
    let sz = 0;
    for (const n of N) {
      const nx = n.x ?? 0;
      const ny = n.y ?? 0;
      const d2 = (nx - x) ** 2 + (ny - y) ** 2;
      if (d2 < 1e-4) return n.kot ?? 0;
      const w = 1 / d2;
      sw += w;
      sz += w * (n.kot ?? 0);
    }
    return sz / sw;
  },
  oturum() {
    const k0 = P().katlar[zeminKatIndeks()]?.id || P().katlar[0].id;
    return katOturum(k0);
  },
  ayakIzi() {
    const k0 = P().katlar[0].id;
    const W = P().duvarlar.filter(w => w.kat === k0);
    if (!W.length) return null;
    const o = katOturum(k0);
    if (o) return { pts: o, k: Math.max(...W.filter(w => w.tur === 'dis').map(w => w.k), 0.2) };
    const pts: Pt[] = [];
    W.forEach(w => pts.push([w.x1, w.y1], [w.x2, w.y2]));
    const b = G.bbox(pts);
    return {
      pts: [
        [b.x1, b.y1],
        [b.x2, b.y1],
        [b.x2, b.y2],
        [b.x1, b.y2],
      ] as Pt[],
      k: 0.25,
    };
  },
  kenarUzak(x: number, y: number, pts: Pt[]) {
    let en = Infinity;
    for (let i = 0; i < pts.length; i++) {
      const a = pts[i];
      const b = pts[(i + 1) % pts.length];
      en = Math.min(en, G.segNokta(x, y, a[0], a[1], b[0], b[1]).d);
    }
    return en;
  },
  padIcinde(x: number, y: number, iz: { pts: Pt[]; k: number }, pay: number) {
    return G.icinde(x, y, iz.pts) || this.kenarUzak(x, y, iz.pts) <= iz.k + pay;
  },
  otoKot() {
    const iz = this.ayakIzi();
    const sub = P().cephe.subasman || 0;
    if (!iz || !this.var()) return sub;
    const b = G.bbox(iz.pts);
    let s = 0;
    let n = 0;
    for (let x = b.x1; x <= b.x2; x += 0.5) {
      for (let y = b.y1; y <= b.y2; y += 0.5) {
        if (G.icinde(x, y, iz.pts)) {
          s += this.z(x, y);
          n++;
        }
      }
    }
    return (n ? s / n : this.z(b.x1 + b.w / 2, b.y1 + b.h / 2)) + sub;
  },
  binaKot() {
    const a = P().ayar.binaKot;
    return a == null ? this.otoKot() : +a;
  },
  taban() {
    return this.binaKot() - (P().cephe.subasman || 0);
  },
  dunyaY(x: number, y: number) {
    return this.z(x, y) - this.taban();
  },
  hafriyat(binaKot?: number) {
    const p = P();
    const iz = this.ayakIzi();
    if (!iz) return null;
    const bodrumDerinlik = p.katlar
      .filter(k => (k.sira ?? 0) < 0)
      .reduce((s, k) => s + k.h + k.d, 0);
    const base = (binaKot ?? this.binaKot()) - (p.cephe.subasman || 0) - bodrumDerinlik;
    const taban = base - p.ayar.temelDerinlik;
    const c = 0.25;
    const b = G.bbox(iz.pts);
    const pay = 1;
    let yarma = 0;
    let dolgu = 0;
    let alan = 0;
    let ic = 0;
    for (let x = b.x1 - iz.k - pay + c / 2; x < b.x2 + iz.k + pay; x += c) {
      for (let y = b.y1 - iz.k - pay + c / 2; y < b.y2 + iz.k + pay; y += c) {
        if (!this.padIcinde(x, y, iz, pay)) continue;
        const z = this.z(x, y);
        alan += c * c;
        yarma += Math.max(0, z - taban) * c * c;
        dolgu += Math.max(0, base - z) * c * c;
        if (G.icinde(x, y, iz.pts)) ic += c * c;
      }
    }
    return { yarma, dolgu, alan, ic, base, taban };
  },
  dengeliKot() {
    if (!this.var()) return null;
    const N = this.noktalar().map(n => n.kot ?? 0);
    const sub = P().cephe.subasman || 0;
    let lo = Math.min(...N) - 3 + sub;
    let hi = Math.max(...N) + 3 + sub;
    for (let i = 0; i < 40; i++) {
      const m = (lo + hi) / 2;
      const h = this.hafriyat(m)!;
      const f = h.yarma - P().ayar.temelDerinlik * h.alan - h.dolgu;
      if (f > 0) lo = m;
      else hi = m;
    }
    return Math.round(((lo + hi) / 2) * 100) / 100;
  },
};

export function cekmePoligonHesap(): Pt[] | null {
  const p = P();
  if (!p.arsa || p.arsa.pts.length < 3) return null;
  const pts = p.arsa.pts;
  const onIdx = sinir(p.ayar.onCepheKenar ?? Math.min(2, pts.length - 1), 0, pts.length - 1);
  const arkaIdx = (onIdx + Math.floor(pts.length / 2)) % pts.length;
  const mes = pts.map((_, i) =>
    i === onIdx ? p.ayar.cekmeOn ?? 5 : i === arkaIdx ? p.ayar.cekmeArka ?? p.ayar.cekmeYan ?? 3 : p.ayar.cekmeYan ?? 3,
  );
  return G.cekmePoligon(pts, mes);
}

/* Güneş konumu ve analizi */
export function gunesKonum(tarih?: string, saat?: number) {
  const a = P().ayar;
  const [ay, gun] = String(tarih || a.tarih || '06-21').split('-').map(Number);
  const N = Math.floor((Date.UTC(2026, (ay || 6) - 1, gun || 21) - Date.UTC(2026, 0, 0)) / 864e5);
  const dek = 23.44 * Math.sin((2 * Math.PI * (284 + N)) / 365) * RAD;
  const B = (2 * Math.PI * (N - 81)) / 364;
  const eot = 9.87 * Math.sin(2 * B) - 7.53 * Math.cos(B) - 1.5 * Math.sin(B);
  const gs = (saat ?? a.saat ?? 14) + ((a.boylam ?? 29) - 45) / 15 + eot / 60;
  const H = 15 * (gs - 12) * RAD;
  const f = (a.enlem ?? 41) * RAD;
  const el = Math.asin(Math.sin(f) * Math.sin(dek) + Math.cos(f) * Math.cos(dek) * Math.cos(H));
  const az = Math.atan2(Math.sin(H), Math.cos(H) * Math.sin(f) - Math.tan(dek) * Math.cos(f)) + Math.PI;
  const k = a.kuzey || 0;
  const kz = G.donder(0, -1, k);
  const dg = G.donder(1, 0, k);
  const E = Math.cos(el) * Math.sin(az);
  const Nn = Math.cos(el) * Math.cos(az);
  return { el, az, yon: [E * dg[0] + Nn * kz[0], Math.sin(el), E * dg[1] + Nn * kz[1]] as [number, number, number] };
}

export function gunesAnalizi(tarih?: string) {
  const p = P();
  const sonuc: { kat: string; oda: string; saat: number; bas: number | null; son: number | null; pencere: number }[] = [];
  p.katlar.forEach(K => {
    const otur = katOturum(K.id);
    const odalar = p.odalar.filter(o => o.kat === K.id);
    const pen: { oda: (typeof odalar)[number]; n: [number, number]; g: number }[] = [];
    p.aciklar.forEach(a => {
      if (a.tur === 'kapi' || a.tur === 'cift_kapi') return;
      const w = duvar(a.duvar);
      if (!w || w.kat !== K.id || w.tur !== 'dis') return;
      const L = Math.hypot(w.x2 - w.x1, w.y2 - w.y1);
      const ux = (w.x2 - w.x1) / L;
      const uy = (w.y2 - w.y1) / L;
      const mx = w.x1 + ux * a.t * L;
      const my = w.y1 + uy * a.t * L;
      const d = w.k / 2 + 0.3;
      let n: [number, number] = [-uy, ux];
      const disNokta: [number, number] = [mx + n[0] * d, my + n[1] * d];
      if (otur ? G.icinde(disNokta[0], disNokta[1], otur) : odalar.some(o => G.icinde(disNokta[0], disNokta[1], o.pts))) {
        n = [uy, -ux];
      }
      const ic: [number, number] = [mx - n[0] * d, my - n[1] * d];
      const oda = odalar.find(o => G.icinde(ic[0], ic[1], o.pts));
      if (oda) pen.push({ oda, n, g: a.g * a.h });
    });
    odalar.forEach(o => {
      const P_ = pen.filter(x => x.oda === o);
      if (!P_.length) {
        sonuc.push({ kat: K.ad, oda: o.ad, saat: 0, bas: null, son: null, pencere: 0 });
        return;
      }
      let n = 0;
      let bas: number | null = null;
      let son: number | null = null;
      for (let h = 5; h <= 21; h += 0.25) {
        const g = gunesKonum(tarih, h);
        if (g.el < 3 * RAD) continue;
        const L = Math.hypot(g.yon[0], g.yon[2]) || 1;
        const s = [g.yon[0] / L, g.yon[2] / L];
        if (P_.some(x => x.n[0] * s[0] + x.n[1] * s[1] > 0.17)) {
          n += 0.25;
          if (bas == null) bas = h;
          son = h;
        }
      }
      sonuc.push({ kat: K.ad, oda: o.ad, saat: n, bas, son, pencere: P_.length });
    });
  });
  return sonuc;
}

/* Plan kontrolü */
const KONTROL_VARS = {
  salon: { alan: 12, dar: 2.7 },
  yatak: { alan: 9, dar: 2.5 },
  mutfak: { alan: 3.3, dar: 1.5 },
  banyo: { alan: 3, dar: 1.5 },
  wc: { alan: 1.2, dar: 0.9 },
  koridor: 1.1,
  girisKapi: 1.0,
  icKapi: 0.8,
  penOran: 8,
  minKatH: 2.6,
  merdivenRiht: 0.19,
  merdivenGen: 1.0,
};

export function odaTuru(ad: string) {
  const a = ad.toLocaleLowerCase('tr');
  if (/teras|balkon/.test(a)) return 'dis';
  if (/salon|oturma/.test(a)) return 'salon';
  if (/yatak|çocuk|misafir|çalışma|giyinme/.test(a)) return 'yatak';
  if (/mutfak/.test(a)) return 'mutfak';
  if (/wc|tuvalet/.test(a)) return 'wc';
  if (/banyo|duş/.test(a)) return 'banyo';
  if (/koridor|hol|antre/.test(a)) return 'koridor';
  return 'diger';
}

export function planKontrol(taksVal?: number, kaksVal?: number, arsaAVal?: number) {
  const p = P();
  const K = Object.assign({}, KONTROL_VARS);
  const L: { sev: 'hata' | 'uyari' | 'bilgi'; mesaj: string; sec: { tur: string; id: string } | null; kat: string; nokta?: Pt }[] = [];
  const ekle = (sev: 'hata' | 'uyari' | 'bilgi', mesaj: string, sec: { tur: string; id: string } | null, katId: string, nokta?: Pt) =>
    L.push({ sev, mesaj, sec, kat: katId, nokta });
  const katAd = (id: string) => p.katlar.find(k => k.id === id)?.ad || '';

  p.katlar.forEach(k => {
    if (k.h < K.minKatH) ekle('uyari', `${k.ad}: kat yüksekliği ${fmt(k.h)} m — en az ${fmt(K.minKatH)} m önerilir`, null, k.id);
  });

  const acikOda: { a: Aciklik; w: Duvar; mx: number; my: number; odalar: (ReturnType<typeof p.odalar.find>)[] }[] = [];
  p.aciklar.forEach(a => {
    const w = duvar(a.duvar);
    if (!w) return;
    const Lw = Math.hypot(w.x2 - w.x1, w.y2 - w.y1) || 1;
    const ux = (w.x2 - w.x1) / Lw;
    const uy = (w.y2 - w.y1) / Lw;
    const mx = w.x1 + ux * a.t * Lw;
    const my = w.y1 + uy * a.t * Lw;
    const d = w.k / 2 + 0.2;
    const odalar = [
      [mx - uy * d, my + ux * d],
      [mx + uy * d, my - ux * d],
    ].map(q => p.odalar.find(o => o.kat === w.kat && G.icinde(q[0], q[1], o.pts)));
    acikOda.push({ a, w, mx, my, odalar });
  });

  p.odalar.forEach(o => {
    const tur = odaTuru(o.ad);
    const A = Math.abs(G.alan(o.pts));
    const b = G.bbox(o.pts);
    const dar = Math.min(b.w, b.h);
    const sec = { tur: 'oda', id: o.id };
    const nk = G.merkez(o.pts);
    const ka = p.katlar.length > 1 ? katAd(o.kat) + ' · ' : '';
    if (tur === 'dis') return;
    const lim = K[tur as keyof typeof K] as { alan?: number; dar?: number } | number | undefined;
    if (typeof lim === 'object') {
      if (lim.alan && A < lim.alan) ekle('uyari', `${ka}${o.ad}: ${fmt(A)} m² — en az ${fmt(lim.alan, 1)} m² önerilir`, sec, o.kat, nk);
      if (lim.dar && dar < lim.dar - 0.01) ekle('uyari', `${ka}${o.ad}: dar kenar ${fmt(dar)} m — en az ${fmt(lim.dar)} m önerilir`, sec, o.kat, nk);
    }
    if (tur === 'koridor' && dar < K.koridor - 0.01) {
      ekle('uyari', `${ka}${o.ad}: genişlik ${fmt(dar)} m — en az ${fmt(K.koridor)} m önerilir`, sec, o.kat, nk);
    }
    const bagli = acikOda.filter(x => x.odalar.includes(o));
    const kapi = bagli.filter(x => x.a.tur !== 'pencere' && x.a.tur !== 'cati_pencere');
    if (!kapi.length) ekle('hata', `${ka}${o.ad}: kapısı yok — odaya erişim sağlanamıyor`, sec, o.kat, nk);
    const pen = bagli.filter(x => x.a.tur !== 'kapi' && x.a.tur !== 'cift_kapi' && x.w.tur === 'dis');
    const penA = pen.reduce((s, x) => s + x.a.g * x.a.h, 0);
    if (['salon', 'yatak', 'mutfak'].includes(tur)) {
      if (!pen.length) ekle('hata', `${ka}${o.ad}: dışarıya bakan pencere yok`, sec, o.kat, nk);
      else if (penA < A / K.penOran) {
        ekle('uyari', `${ka}${o.ad}: pencere alanı ${fmt(penA)} m² — taban alanının 1/${K.penOran}’i (${fmt(A / K.penOran)} m²) önerilir`, sec, o.kat, nk);
      }
    }
    if ((tur === 'banyo' || tur === 'wc') && !pen.length) {
      ekle('bilgi', `${ka}${o.ad}: penceresiz — mekanik havalandırma (aspiratör/şaft) gerekir`, sec, o.kat, nk);
    }
  });

  acikOda.forEach(x => {
    if (x.a.tur !== 'kapi' && x.a.tur !== 'cift_kapi') return;
    const sec = { tur: 'acik', id: x.a.id };
    if (x.w.tur === 'dis' && x.odalar.some(o => !o) && x.a.g < K.girisKapi - 0.001 && x.a.g < 2) {
      ekle('uyari', `Dış kapı ${fmt(x.a.g * 100, 0)} cm — en az ${fmt(K.girisKapi * 100, 0)} cm önerilir`, sec, x.w.kat, [x.mx, x.my]);
    }
    if (x.w.tur === 'ic' && x.a.g < K.icKapi - 0.001) {
      ekle('uyari', `İç kapı ${fmt(x.a.g * 100, 0)} cm — en az ${fmt(K.icKapi * 100, 0)} cm önerilir`, sec, x.w.kat, [x.mx, x.my]);
    }
  });

  p.duvarlar.forEach(w => {
    for (const u of [1, 2] as const) {
      const x = w[u === 1 ? 'x1' : 'x2'];
      const y = w[u === 1 ? 'y1' : 'y2'];
      if (!uctaBagli(w, x, y)) {
        ekle('bilgi', `${p.katlar.length > 1 ? katAd(w.kat) + ' · ' : ''}Boşta duvar ucu — oda kapanmamış olabilir`, { tur: 'duvar', id: w.id }, w.kat, [x, y]);
        break;
      }
    }
  });

  if (p.katlar.length > 1) {
    p.katlar.slice(0, -1).forEach((k, i) => {
      const md = merdivenler(k.id);
      if (!md.length) ekle('hata', `${k.ad} → ${p.katlar[i + 1].ad}: merdiven yok`, null, k.id);
      md.forEach(m => {
        const H = k.h + p.katlar[i + 1].d;
        const n = m.m.basamak || Math.max(2, Math.round(H / 0.175));
        const riht = H / n;
        const basamak = (m.tip === 'merdiven_u' ? m.d * 1.6 : m.tip === 'merdiven_l' ? m.w + m.d * 0.5 : m.d) / n;
        const sec = { tur: 'mobilya', id: m.m.id };
        if (riht > K.merdivenRiht) {
          ekle('uyari', `Merdiven rıht yüksekliği ${fmt(riht * 100, 1)} cm — en fazla ${fmt(K.merdivenRiht * 100, 0)} cm`, sec, k.id, [m.m.x, m.m.y]);
        }
        if (2 * riht + basamak < 0.6 || 2 * riht + basamak > 0.66) {
          ekle('bilgi', `Merdiven adım ölçüsü 2h+b = ${fmt((2 * riht + basamak) * 100, 0)} cm (rahat 60–66 cm) · ${n} basamak`, sec, k.id, [m.m.x, m.m.y]);
        }
        if (m.w < K.merdivenGen - 0.001) {
          ekle('uyari', `Merdiven genişliği ${fmt(m.w * 100, 0)} cm — en az ${fmt(K.merdivenGen * 100, 0)} cm önerilir`, sec, k.id, [m.m.x, m.m.y]);
        }
      });
    });
  }

  // İmar çekme kontrolü: ön cephe vs yan/arka cephe ayrımı
  const arsaA = arsaAVal ?? (p.arsa ? Math.abs(G.alan(p.arsa.pts)) : 0);
  if (arsaA && p.arsa) {
    if ((taksVal || 0) > p.ayar.maxTaks) ekle('hata', `TAKS ${fmt(taksVal || 0)} — imar sınırı ${fmt(p.ayar.maxTaks)} aşılıyor`, { tur: 'arsa', id: 'arsa' }, p.katlar[0].id);
    if ((kaksVal || 0) > p.ayar.maxKaks) ekle('hata', `KAKS ${fmt(kaksVal || 0)} — imar sınırı ${fmt(p.ayar.maxKaks)} aşılıyor`, { tur: 'arsa', id: 'arsa' }, p.katlar[0].id);
    const W = p.duvarlar.filter(w => w.tur === 'dis');
    const pts = p.arsa.pts;
    const onIdx = sinir(p.ayar.onCepheKenar ?? Math.min(2, pts.length - 1), 0, pts.length - 1);
    const arkaIdx = (onIdx + Math.floor(pts.length / 2)) % pts.length;
    let disariTas = false;
    let minOn = Infinity;
    let minYan = Infinity;
    let nkOn: Pt | undefined;
    let nkYan: Pt | undefined;
    let nkDis: Pt | undefined;

    W.forEach(w => {
      for (const u of [1, 2] as const) {
        const x = w[u === 1 ? 'x1' : 'x2'];
        const y = w[u === 1 ? 'y1' : 'y2'];
        if (!G.icinde(x, y, pts)) {
          disariTas = true;
          nkDis = [x, y];
        }
        for (let ei = 0; ei < pts.length; ei++) {
          const a = pts[ei];
          const b = pts[(ei + 1) % pts.length];
          const d = G.segNokta(x, y, a[0], a[1], b[0], b[1]).d - w.k / 2;
          if (ei === onIdx) {
            if (d < minOn) { minOn = d; nkOn = [x, y]; }
          } else {
            const lim = ei === arkaIdx ? (p.ayar.cekmeArka ?? p.ayar.cekmeYan ?? 3) : (p.ayar.cekmeYan ?? 3);
            if (d < lim && d < minYan) { minYan = d; nkYan = [x, y]; }
          }
        }
      }
    });
    if (W.length && disariTas) ekle('hata', 'Bina arsa sınırının dışına taşıyor', { tur: 'arsa', id: 'arsa' }, p.katlar[0].id, nkDis);
    else {
      if (W.length && minOn < (p.ayar.cekmeOn ?? 5) - 0.01) {
        ekle('uyari', `Ön bahçe çekme mesafesi ${fmt(minOn)} m — yönetmelik/ayar ${fmt(p.ayar.cekmeOn ?? 5)} m altında`, { tur: 'arsa', id: 'arsa' }, p.katlar[0].id, nkOn);
      }
      if (W.length && minYan < Infinity) {
        ekle('uyari', `Yan/arka bahçe çekme mesafesi ${fmt(minYan)} m — sınır (${fmt(p.ayar.cekmeYan ?? 3)} m) ihlali`, { tur: 'arsa', id: 'arsa' }, p.katlar[0].id, nkYan);
      }
    }
  }

  // Tesisat ve boru kontrolleri
  if ((p.tesisat || []).length && !p.tesisat.some(t => t.tip === 'pano')) {
    ekle('uyari', 'Tesisatta sigorta panosu yok', null, p.katlar[0].id);
  }
  if ((p.tesisat || []).length && !(p.borular || []).length) {
    ekle('bilgi', 'Tesisat noktaları var ancak boru/kablo döşeme hattı çizilmemiş — “Otomatik boru döşe” kullanabilirsin', null, p.katlar[0].id);
  }
  boruCakismaBul().forEach(c => {
    ekle('uyari', `MEP Çakışma · ${c.mesaj}`, null, c.katId, [c.x, c.y]);
  });
  p.mobilya
    .filter(m => m.tip === 'kolon')
    .forEach(m => {
      const { w, d } = mobOlcu(m);
      if (Math.min(w, d) < 0.25) {
        ekle('uyari', `Kolon ${fmt(w * 100, 0)}×${fmt(d * 100, 0)} cm — en küçük boyut 25 cm olmalı`, { tur: 'mobilya', id: m.id }, m.kat, [m.x, m.y]);
      }
    });

  const sira = { hata: 0, uyari: 1, bilgi: 2 };
  return L.sort((a, b) => sira[a.sev] - sira[b.sev]);
}

/* Geçmiş (Undo/Redo) ve Kaydetme */
let _kz = 0;
let _onRefresh: (() => void) | null = null;
export function baglaYenile(fn: () => void) {
  _onRefresh = fn;
}

export function kaydetGecikmeli() {
  clearTimeout(_kz);
  const dk = document.querySelector('#dKayit');
  if (dk) dk.textContent = 'Kaydediliyor…';
  _kz = window.setTimeout(() => {
    const p = S.p;
    if (!p) return;
    p.guncelleme = Date.now();
    const d = DEPO.oku();
    d.projeler[p.id] = p;
    d.son = p.id;
    if (DEPO.yaz(d) && dk) {
      dk.textContent = 'Kaydedildi · ' + new Date().toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit' });
    }
  }, 450);
}

export const GECMIS = {
  y: [] as string[],
  i: [] as string[],
  kaydet() {
    if (!S.p) return;
    this.y.push(JSON.stringify(S.p));
    if (this.y.length > 100) this.y.shift();
    this.i = [];
    this.dugme();
  },
  geri() {
    if (!this.y.length || !S.p) return;
    this.i.push(JSON.stringify(S.p));
    S.p = JSON.parse(this.y.pop()!) as Proje;
    this.sonra();
  },
  ileri() {
    if (!this.i.length || !S.p) return;
    this.y.push(JSON.stringify(S.p));
    S.p = JSON.parse(this.i.pop()!) as Proje;
    this.sonra();
  },
  sifirla() {
    this.y = [];
    this.i = [];
    this.dugme();
  },
  sonra() {
    if (S.p && !S.p.katlar.some(k => k.id === S.katId)) S.katId = S.p.katlar[0].id;
    S.secili = null;
    S.cokluSecili = [];
    S.d3Kirli = true;
    kaydetGecikmeli();
    _onRefresh?.();
    this.dugme();
  },
  dugme() {
    const g = document.querySelector('#bGeri') as HTMLButtonElement | null;
    const i = document.querySelector('#bIleri') as HTMLButtonElement | null;
    if (g) g.disabled = !this.y.length;
    if (i) i.disabled = !this.i.length;
  },
};

export function degistir<T>(fn: () => T, sessiz = false): T {
  GECMIS.kaydet();
  const r = fn();
  S.d3Kirli = true;
  kaydetGecikmeli();
  if (!sessiz) _onRefresh?.();
  return r;
}

export function blokAdetM2(malzemeKey: string, duvarKalinlik: number): number {
  const B = BLOK[malzemeKey] || BLOK.gazbeton;
  // Duvar kalınlığına göre blok sarfiyat çarpanı (örn. 10cm iç duvar vs 25cm dış duvar)
  const carpan = sinir(duvarKalinlik / (B.bazK || 0.2), 0.5, 2.0);
  return B.m2 * carpan;
}

export function bildirimGoster(msg: string) {
  bildir(msg);
}
