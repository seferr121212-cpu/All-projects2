import { ACIK_ALAN_ODA, BORU_TIPLERI, DIS, MOB, ZEMIN, mobOlcu } from './catalog';
import { ARAZI, P, S, cekmePoligonHesap, duvarBoy, duvarParcalari, gunesKonum, kat, katOturum, katTaban, kirisListesi, merdivenler } from './core';
import { G, Pt, dikdortgenlere } from './geometry';
import { boruCakismaBul } from './mep';
import { MeshHedef, agac3DEkle, araba3DEkle, cali3DEkle, mobilya3DEkle, tesisat3DEkle } from './models3d';

function alanDikdortgen(pts: Pt[], delikler: Pt[][] = []): { x0: number; y0: number; x1: number; y1: number }[] {
  const raw = dikdortgenlere(pts);
  let rects: { x0: number; y0: number; x1: number; y1: number }[];
  if (raw && raw.length) {
    rects = raw.map(r => ({ x0: r.x1, y0: r.y1, x1: r.x2, y1: r.y2 }));
  } else {
    const b = G.bbox(pts);
    rects = [{ x0: b.x1, y0: b.y1, x1: b.x2, y1: b.y2 }];
  }
  if (!delikler.length) return rects;
  // Merdiven/şaft deliklerini temizleyen grid kesme
  let cur = rects;
  for (const d of delikler) {
    const hb = G.bbox(d);
    const next: { x0: number; y0: number; x1: number; y1: number }[] = [];
    for (const r of cur) {
      if (hb.x2 <= r.x0 + 0.02 || hb.x1 >= r.x1 - 0.02 || hb.y2 <= r.y0 + 0.02 || hb.y1 >= r.y1 - 0.02) {
        next.push(r);
        continue;
      }
      if (hb.x1 > r.x0 + 0.05) next.push({ x0: r.x0, y0: r.y0, x1: hb.x1, y1: r.y1 });
      if (hb.x2 < r.x1 - 0.05) next.push({ x0: hb.x2, y0: r.y0, x1: r.x1, y1: r.y1 });
      const sx0 = Math.max(r.x0, hb.x1);
      const sx1 = Math.min(r.x1, hb.x2);
      if (sx1 > sx0 + 0.05) {
        if (hb.y1 > r.y0 + 0.05) next.push({ x0: sx0, y0: r.y0, x1: sx1, y1: hb.y1 });
        if (hb.y2 < r.y1 - 0.05) next.push({ x0: sx0, y0: hb.y2, x1: sx1, y1: r.y1 });
      }
    }
    cur = next;
  }
  return cur;
}
import { kesitDuzlemHesap } from './plan2d';
import type { Kesit } from './types';
import { RAD, fmt, sinir } from './utils';

const M4 = {
  ident: () => new Float32Array([1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1]),
  mult(a: Float32Array, b: Float32Array) {
    const o = new Float32Array(16);
    for (let i = 0; i < 4; i++) {
      for (let j = 0; j < 4; j++) {
        o[j * 4 + i] =
          a[i] * b[j * 4] + a[i + 4] * b[j * 4 + 1] + a[i + 8] * b[j * 4 + 2] + a[i + 12] * b[j * 4 + 3];
      }
    }
    return o;
  },
  persp(fov: number, asp: number, n: number, f: number) {
    const t = 1 / Math.tan(fov / 2);
    const nf = 1 / (n - f);
    return new Float32Array([t / asp, 0, 0, 0, 0, t, 0, 0, 0, 0, (f + n) * nf, -1, 0, 0, 2 * f * n * nf, 0]);
  },
  ortog(l: number, r: number, b: number, t: number, n: number, f: number) {
    return new Float32Array([
      2 / (r - l), 0, 0, 0,
      0, 2 / (t - b), 0, 0,
      0, 0, -2 / (f - n), 0,
      -(r + l) / (r - l), -(t + b) / (t - b), -(f + n) / (f - n), 1,
    ]);
  },
  bak(e: [number, number, number], c: [number, number, number], u: [number, number, number]) {
    let zx = e[0] - c[0];
    let zy = e[1] - c[1];
    let zz = e[2] - c[2];
    let L = Math.hypot(zx, zy, zz) || 1;
    zx /= L; zy /= L; zz /= L;
    let xx = u[1] * zz - u[2] * zy;
    let xy = u[2] * zx - u[0] * zz;
    let xz = u[0] * zy - u[1] * zx;
    L = Math.hypot(xx, xy, xz) || 1;
    xx /= L; xy /= L; xz /= L;
    const yx = zy * xz - zz * xy;
    const yy = zz * xx - zx * xz;
    const yz = zx * xy - zy * xx;
    return new Float32Array([
      xx, yx, zx, 0,
      xy, yy, zy, 0,
      xz, yz, zz, 0,
      -(xx * e[0] + xy * e[1] + xz * e[2]),
      -(yx * e[0] + yy * e[1] + yz * e[2]),
      -(zx * e[0] + zy * e[1] + zz * e[2]),
      1,
    ]);
  },
};

export const hexRenk = (h: string): [number, number, number] => [
  parseInt(h.slice(1, 3), 16) / 255,
  parseInt(h.slice(3, 5), 16) / 255,
  parseInt(h.slice(5, 7), 16) / 255,
];

const ZEMIN_MT: Record<string, number> = { parke: 2, laminat: 2, seramik: 3, mermer: 4, deck: 2, beton: 1, hali: 5 };
export const KAPLAMA: Record<string, string> = { siva: 'Düz sıva', tugla: 'Tuğla örgü', tas: 'Doğal taş', ahsap: 'Ahşap yalıbaskı' };
export const MT: Record<string, number> = { siva: 0, tugla: 6, tas: 7, ahsap: 2 };

export interface D3HitBox {
  min: [number, number, number];
  max: [number, number, number];
  tur: string;
  id: string;
  ad: string;
  detay?: string;
}

class Mesh implements MeshHedef {
  o: number[] = [];
  s: number[] = [];
  hits: D3HitBox[] = [];

  pushHitBox(hit: Omit<D3HitBox, 'min' | 'max'> | undefined, min: [number, number, number], max: [number, number, number]) {
    if (!hit) return;
    this.hits.push({ ...hit, min, max });
  }

  private pushHit(hit: Omit<D3HitBox, 'min' | 'max'> | undefined, xs: number[], ys: number[], zs: number[]) {
    if (!hit) return;
    this.hits.push({
      ...hit,
      min: [Math.min(...xs), Math.min(...ys), Math.min(...zs)],
      max: [Math.max(...xs), Math.max(...ys), Math.max(...zs)],
    });
  }

  tri(
    p: [number, number, number],
    q: [number, number, number],
    r: [number, number, number],
    c: [number, number, number],
    a = 1,
    mt = 0,
  ) {
    const ux = q[0] - p[0], uy = q[1] - p[1], uz = q[2] - p[2];
    const vx = r[0] - p[0], vy = r[1] - p[1], vz = r[2] - p[2];
    let nx = uy * vz - uz * vy;
    let ny = uz * vx - ux * vz;
    let nz = ux * vy - uy * vx;
    const L = Math.hypot(nx, ny, nz) || 1;
    nx /= L; ny /= L; nz /= L;
    const B = a < 1 ? this.s : this.o;
    for (const v of [p, q, r]) B.push(v[0], v[1], v[2], nx, ny, nz, c[0], c[1], c[2], a, mt);
  }

  triSmooth(
    p: [number, number, number],
    np: [number, number, number],
    q: [number, number, number],
    nq: [number, number, number],
    r: [number, number, number],
    nr: [number, number, number],
    c: [number, number, number],
    a = 1,
    mt = 0,
  ) {
    const B = a < 1 ? this.s : this.o;
    const pairs: [[number, number, number], [number, number, number]][] = [[p, np], [q, nq], [r, nr]];
    for (const [v, n] of pairs) {
      const L = Math.hypot(n[0], n[1], n[2]) || 1;
      B.push(v[0], v[1], v[2], n[0] / L, n[1] / L, n[2] / L, c[0], c[1], c[2], a, mt);
    }
  }

  quadSmooth(
    p: [number, number, number],
    np: [number, number, number],
    q: [number, number, number],
    nq: [number, number, number],
    r: [number, number, number],
    nr: [number, number, number],
    s: [number, number, number],
    ns: [number, number, number],
    c: [number, number, number],
    a = 1,
    mt = 0,
  ) {
    this.triSmooth(p, np, q, nq, r, nr, c, a, mt);
    this.triSmooth(p, np, r, nr, s, ns, c, a, mt);
  }

  quad(
    p: [number, number, number],
    q: [number, number, number],
    r: [number, number, number],
    s: [number, number, number],
    c: [number, number, number],
    a = 1,
    mt = 0,
  ) {
    this.tri(p, q, r, c, a, mt);
    this.tri(p, r, s, c, a, mt);
  }

  kutu(
    x0: number,
    y0: number,
    z0: number,
    x1: number,
    y1: number,
    z1: number,
    c: [number, number, number],
    a = 1,
    mt = 0,
    hit?: Omit<D3HitBox, 'min' | 'max'>,
  ) {
    const P0: [number, number, number] = [x0, y0, z0];
    const P1: [number, number, number] = [x1, y0, z0];
    const P2: [number, number, number] = [x1, y1, z0];
    const P3: [number, number, number] = [x0, y1, z0];
    const P4: [number, number, number] = [x0, y0, z1];
    const P5: [number, number, number] = [x1, y0, z1];
    const P6: [number, number, number] = [x1, y1, z1];
    const P7: [number, number, number] = [x0, y1, z1];
    this.quad(P3, P2, P1, P0, c, a, mt);
    this.quad(P4, P5, P6, P7, c, a, mt);
    this.quad(P0, P1, P5, P4, c, a, mt);
    this.quad(P2, P3, P7, P6, c, a, mt);
    this.quad(P1, P2, P6, P5, c, a, mt);
    this.quad(P3, P0, P4, P7, c, a, mt);
    this.pushHit(hit, [x0, x1], [y0, y1], [z0, z1]);
  }

  kutuD(
    cx: number,
    cy: number,
    cz: number,
    w: number,
    d: number,
    h: number,
    rDeg: number,
    c: [number, number, number],
    a = 1,
    mt = 0,
    hit?: Omit<D3HitBox, 'min' | 'max'>,
  ) {
    const R = rDeg * RAD;
    const cs = Math.cos(R);
    const sn = Math.sin(R);
    const pt = (lx: number, ly: number, lz: number): [number, number, number] => [cx + lx * cs - cz * 0 - ly * sn, cy + lz, cz + lx * sn + ly * cs];
    const hw = w / 2;
    const hd = d / 2;
    const B0 = pt(-hw, -hd, 0), B1 = pt(hw, -hd, 0), B2 = pt(hw, hd, 0), B3 = pt(-hw, hd, 0);
    const T0 = pt(-hw, -hd, h), T1 = pt(hw, -hd, h), T2 = pt(hw, hd, h), T3 = pt(-hw, hd, h);
    this.quad(B3, B2, B1, B0, c, a, mt);
    this.quad(T0, T1, T2, T3, c, a, mt);
    this.quad(B0, B1, T1, T0, c, a, mt);
    this.quad(B2, B3, T3, T2, c, a, mt);
    this.quad(B1, B2, T2, T1, c, a, mt);
    this.quad(B3, B0, T0, T3, c, a, mt);
    const pts = [B0, B1, B2, B3, T0, T1, T2, T3];
    this.pushHit(hit, pts.map(p => p[0]), pts.map(p => p[1]), pts.map(p => p[2]));
  }

  duvarSeg(
    x1: number,
    z1: number,
    x2: number,
    z2: number,
    k: number,
    y0: number,
    y1: number,
    cDis: [number, number, number],
    cIc: [number, number, number],
    mtDis = 0,
    mtIc = 0,
    hit?: Omit<D3HitBox, 'min' | 'max'>,
    alpha = 1,
  ) {
    const dx = x2 - x1;
    const dz = z2 - z1;
    const L = Math.hypot(dx, dz) || 1;
    const nx = (-dz / L) * (k / 2);
    const nz = (dx / L) * (k / 2);
    const B0: [number, number, number] = [x1 + nx, y0, z1 + nz];
    const B1: [number, number, number] = [x2 + nx, y0, z2 + nz];
    const B2: [number, number, number] = [x2 - nx, y0, z2 - nz];
    const B3: [number, number, number] = [x1 - nx, y0, z1 - nz];
    const T0: [number, number, number] = [x1 + nx, y1, z1 + nz];
    const T1: [number, number, number] = [x2 + nx, y1, z2 + nz];
    const T2: [number, number, number] = [x2 - nx, y1, z2 - nz];
    const T3: [number, number, number] = [x1 - nx, y1, z1 - nz];
    this.quad(T0, T1, T2, T3, cIc, alpha);
    this.quad(B3, B2, B1, B0, cIc, alpha);
    this.quad(B0, B1, T1, T0, cDis, alpha, mtDis);
    this.quad(B2, B3, T3, T2, cIc, alpha, mtIc);
    this.quad(B1, B2, T2, T1, cDis, alpha, mtDis);
    this.quad(B3, B0, T0, T3, cDis, alpha, mtDis);
    this.pushHit(hit, [B0[0], B1[0], B2[0], B3[0]], [y0, y1], [B0[2], B1[2], B2[2], B3[2]]);
  }

  boruSeg(
    x1: number,
    y1: number,
    z1: number,
    x2: number,
    y2: number,
    z2: number,
    r: number,
    c: [number, number, number],
    hit?: Omit<D3HitBox, 'min' | 'max'>,
  ) {
    const dx = x2 - x1;
    const dy = y2 - y1;
    const dz = z2 - z1;
    const L = Math.hypot(dx, dy, dz);
    if (L < 0.005) return;
    const ux = dx / L, uy = dy / L, uz = dz / L;
    // Ortogonal iki vektör
    let px = 0, py = 1, pz = 0;
    if (Math.abs(uy) > 0.9) {
      px = 1; py = 0; pz = 0;
    }
    let ax = uy * pz - uz * py;
    let ay = uz * px - ux * pz;
    let az = ux * py - uy * px;
    const al = Math.hypot(ax, ay, az) || 1;
    ax = (ax / al) * r; ay = (ay / al) * r; az = (az / al) * r;
    const bx = (uy * az - uz * ay);
    const by = (uz * ax - ux * az);
    const bz = (ux * ay - uy * ax);
    const bl = Math.hypot(bx, by, bz) || 1;
    const cx = (bx / bl) * r, cy = (by / bl) * r, cz = (bz / bl) * r;

    const SEG = 8;
    const ring = (ox: number, oy: number, oz: number): { pts: [number, number, number][]; nrms: [number, number, number][] } => {
      const pts: [number, number, number][] = [];
      const nrms: [number, number, number][] = [];
      for (let i = 0; i < SEG; i++) {
        const ang = (i / SEG) * Math.PI * 2;
        const ca = Math.cos(ang), sa = Math.sin(ang);
        const nx = (ax / r) * ca + (cx / r) * sa;
        const ny = (ay / r) * ca + (cy / r) * sa;
        const nz = (az / r) * ca + (cz / r) * sa;
        pts.push([ox + nx * r, oy + ny * r, oz + nz * r]);
        nrms.push([nx, ny, nz]);
      }
      return { pts, nrms };
    };
    const A = ring(x1, y1, z1);
    const B = ring(x2, y2, z2);
    for (let i = 0; i < SEG; i++) {
      const ni = (i + 1) % SEG;
      this.quadSmooth(A.pts[i], A.nrms[i], A.pts[ni], A.nrms[ni], B.pts[ni], B.nrms[ni], B.pts[i], B.nrms[i], c, 1, 8);
    }
    const nStart: [number, number, number] = [-ux, -uy, -uz];
    const nEnd: [number, number, number] = [ux, uy, uz];
    for (let i = 1; i + 1 < SEG; i++) {
      this.triSmooth([x1, y1, z1], nStart, A.pts[i + 1], nStart, A.pts[i], nStart, c, 1, 8);
      this.triSmooth([x2, y2, z2], nEnd, B.pts[i], nEnd, B.pts[i + 1], nEnd, c, 1, 8);
    }
    this.pushHit(hit, [x1 - r, x1 + r, x2 - r, x2 + r], [y1 - r, y1 + r, y2 - r, y2 + r], [z1 - r, z1 + r, z2 - r, z2 + r]);
  }

  catiUcgen(
    x0: number,
    z0: number,
    x1: number,
    z1: number,
    y: number,
    h: number,
    tip: string,
    c: [number, number, number],
  ) {
    const cx = (x0 + x1) / 2;
    const cz = (z0 + z1) / 2;
    const yk = y + h;
    const B0: [number, number, number] = [x0, y, z0];
    const B1: [number, number, number] = [x1, y, z0];
    const B2: [number, number, number] = [x1, y, z1];
    const B3: [number, number, number] = [x0, y, z1];
    this.quad(B0, B1, B2, B3, [0.45, 0.45, 0.48]);
    if (tip === 'tek') {
      const T0: [number, number, number] = [x0, yk, z0];
      const T1: [number, number, number] = [x1, yk, z0];
      this.quad(B3, B2, T1, T0, c, 1, 1);
      this.tri(B0, T0, B3, [0.9, 0.88, 0.84]);
      this.tri(B1, B2, T1, [0.9, 0.88, 0.84]);
      this.quad(B0, B1, T1, T0, [0.9, 0.88, 0.84]);
    } else if (tip === 'besik') {
      if (x1 - x0 >= z1 - z0) {
        const A: [number, number, number] = [x0, yk, cz];
        const B: [number, number, number] = [x1, yk, cz];
        this.quad(B0, B1, B, A, c, 1, 1);
        this.quad(B2, B3, A, B, c, 1, 1);
        this.tri(B3, B0, A, [0.9, 0.88, 0.84]);
        this.tri(B1, B2, B, [0.9, 0.88, 0.84]);
      } else {
        const A: [number, number, number] = [cx, yk, z0];
        const B: [number, number, number] = [cx, yk, z1];
        this.quad(B1, B2, B, A, c, 1, 1);
        this.quad(B3, B0, A, B, c, 1, 1);
        this.tri(B0, B1, A, [0.9, 0.88, 0.84]);
        this.tri(B2, B3, B, [0.9, 0.88, 0.84]);
      }
    } else {
      const uz = Math.max(0, Math.abs(x1 - x0) - Math.abs(z1 - z0)) / 2;
      const vz = Math.max(0, Math.abs(z1 - z0) - Math.abs(x1 - x0)) / 2;
      if (x1 - x0 >= z1 - z0) {
        const A: [number, number, number] = [x0 + (x1 - x0) / 2 - uz, yk, cz];
        const B: [number, number, number] = [x0 + (x1 - x0) / 2 + uz, yk, cz];
        this.quad(B0, B1, B, A, c, 1, 1);
        this.quad(B2, B3, A, B, c, 1, 1);
        this.tri(B3, B0, A, c, 1, 1);
        this.tri(B1, B2, B, c, 1, 1);
      } else {
        const A: [number, number, number] = [cx, yk, z0 + (z1 - z0) / 2 - vz];
        const B: [number, number, number] = [cx, yk, z0 + (z1 - z0) / 2 + vz];
        this.quad(B1, B2, B, A, c, 1, 1);
        this.quad(B3, B0, A, B, c, 1, 1);
        this.tri(B0, B1, A, c, 1, 1);
        this.tri(B2, B3, B, c, 1, 1);
      }
    }
  }

  poligonCati(pts: Pt[], y: number, h: number, c: [number, number, number]) {
    const cx = pts.reduce((s, q) => s + q[0], 0) / pts.length;
    const cz = pts.reduce((s, q) => s + q[1], 0) / pts.length;
    const apex: [number, number, number] = [cx, y + h, cz];
    for (let i = 0; i < pts.length; i++) {
      const a = pts[i];
      const b = pts[(i + 1) % pts.length];
      this.tri([a[0], y, a[1]], [b[0], y, b[1]], apex, c, 1, 1);
      this.tri([b[0], y, b[1]], [a[0], y, a[1]], [cx, y, cz], [0.45, 0.45, 0.48]);
    }
  }

  dikUcgen(
    x0: number,
    z0: number,
    x1: number,
    z1: number,
    y0: number,
    y1: number,
    c: [number, number, number],
    a = 1,
    mt = 0,
    hit?: Omit<D3HitBox, 'min' | 'max'>,
  ) {
    this.kutu(Math.min(x0, x1), y0, Math.min(z0, z1), Math.max(x0, x1), y1, Math.max(z0, z1), c, a, mt, hit);
  }

  silindir(
    cx: number,
    cy: number,
    cz: number,
    r0: number,
    r1: number,
    h: number,
    seg: number,
    c: [number, number, number],
    a = 1,
  ) {
    for (let i = 0; i < seg; i++) {
      const a0 = (i / seg) * Math.PI * 2;
      const a1 = ((i + 1) / seg) * Math.PI * 2;
      const p0: [number, number, number] = [cx + Math.cos(a0) * r0, cy, cz + Math.sin(a0) * r0];
      const p1: [number, number, number] = [cx + Math.cos(a1) * r0, cy, cz + Math.sin(a1) * r0];
      const p2: [number, number, number] = [cx + Math.cos(a1) * r1, cy + h, cz + Math.sin(a1) * r1];
      const p3: [number, number, number] = [cx + Math.cos(a0) * r1, cy + h, cz + Math.sin(a0) * r1];
      this.quad(p0, p1, p2, p3, c, a);
      this.tri([cx, cy + h, cz], p3, p2, c, a);
    }
  }
}

const GL_VS = `
attribute vec3 aPos,aNor,aCol;attribute float aAlp,aMat;
uniform mat4 uVP,uLS;
varying vec3 vN,vC,vW;varying float vA,vM;varying vec4 vLS;
void main(){vN=aNor;vC=aCol;vW=aPos;vA=aAlp;vM=aMat;vLS=uLS*vec4(aPos,1.0);gl_Position=uVP*vec4(aPos,1.0);}
`;

const GL_FS = `
precision mediump float;
varying vec3 vN,vC,vW;varying float vA,vM;varying vec4 vLS;
uniform vec3 uSun,uCam,uSky,uSunC;
uniform vec4 uKes;
uniform float uKesOfset,uGunduz;
uniform sampler2D uSMap;
uniform int uGolge;
uniform vec3 uPointPos[8];
uniform int uPointCount;

float tex(vec3 w,vec3 n,float m){
  if(m<0.5||m>7.5)return 1.0;
  vec2 uv=abs(n.y)>0.7?w.xz:abs(n.x)>0.7?w.zy:w.xy;
  if(m<1.5){float r=sin(uv.y*22.0),s=sin(uv.x*16.0+floor(uv.y*3.5)*1.5);return 0.9+0.1*step(0.0,r)*step(0.0,s);}
  if(m<2.5){return 0.91+0.07*sin(uv.x*24.0)*cos(uv.y*4.5)+0.04*sin(uv.y*42.0);}
  if(m<3.5){float gx=abs(fract(uv.x*2.2)-0.5),gy=abs(fract(uv.y*2.2)-0.5);return (gx<0.025||gy<0.025)?0.76:1.0;}
  if(m<4.5){return 0.92+0.08*sin(uv.x*5.5+sin(uv.y*4.2)*2.2);}
  if(m<5.5){return 0.95+0.05*sin(uv.x*70.0)*cos(uv.y*70.0);}
  if(m<6.5){float r=fract(uv.y*8.0),c=fract(uv.x*4.0+0.5*floor(uv.y*8.0));return (r<0.12||c<0.08)?0.72:0.95+0.05*sin(floor(uv.x*4.0)+floor(uv.y*8.0));}
  float r=fract(uv.y*4.5),c=fract(uv.x*3.0+0.4*floor(uv.y*4.5));return (r<0.08||c<0.06)?0.68:0.88+0.12*sin(uv.x*6.0+uv.y*3.0);
}

float gHesap(vec4 lp,vec3 N,vec3 L){
  if(uGolge==0)return 1.0;
  vec3 p=lp.xyz/lp.w*0.5+0.5;
  if(p.x<0.01||p.x>0.99||p.y<0.01||p.y>0.99||p.z>1.0)return 1.0;
  float b=max(0.0016*(1.0-dot(N,L)),0.0005),s=0.0,t=1.0/2048.0;
  for(int x=-1;x<=1;x++)for(int y=-1;y<=1;y++)s+=step(p.z-b,texture2D(uSMap,p.xy+vec2(float(x),float(y))*t).r);
  return 0.36+0.64*(s/9.0);
}

void main(){
  float kDist=dot(vW,uKes.xyz)+uKes.w+uKesOfset;
  if(uKes.w<999.0&&kDist>0.0)discard;
  vec3 N=normalize(vN);if(!gl_FrontFacing)N=-N;
  vec3 L=normalize(uSun),V=normalize(uCam-vW),H=normalize(L+V);
  float d=max(dot(N,L),0.0),g=gHesap(vLS,N,L);
  float ndv=max(dot(N,V),0.0);
  float fresnel=pow(1.0-ndv,3.0);

  // Malzeme bazlı PBR-benzeri speküler, parlaklık ve kadife parlama
  float shininess=32.0;
  float specStr=vA<1.0?0.72:0.08;
  float metalRef=0.0;
  float sheen=0.0;
  float emissive=0.0;
  if(vM>7.5&&vM<8.5){shininess=72.0;specStr=0.82;metalRef=0.32;} // Krom/Alaşım
  else if(vM>8.5&&vM<9.5){shininess=56.0;specStr=0.72;metalRef=0.25;} // Pirinç/Bakır
  else if(vM>9.5&&vM<10.5){shininess=60.0;specStr=0.45;} // Seramik/Lake
  else if(vM>10.5&&vM<11.5){shininess=8.0;specStr=0.02;sheen=0.22;} // Kumaş/Kadife
  else if(vM>11.5&&vM<12.5){emissive=0.85;specStr=0.15;} // LED/Ekran/Ampul
  else if(vM>12.5){shininess=12.0;specStr=0.03;} // Mat Kauçuk/Döküm

  float spec=pow(max(dot(N,H),0.0),shininess)*specStr*g;
  vec3 hemi=mix(vec3(0.45,0.43,0.40),uSky*0.85+0.24,N.y*0.5+0.5)*uGunduz;
  vec3 c=vC*tex(vW,N,vM);

  // İç mekan nokta ışık kaynakları
  vec3 ptLit=vec3(0.0);
  if(uGunduz<0.92){
    float nightStr=clamp(1.0-uGunduz,0.22,1.0);
    for(int i=0;i<8;i++){
      if(i>=uPointCount)break;
      vec3 dL=uPointPos[i]-vW;
      float dist=length(dL);
      float att=1.0/(1.0+0.18*dist+0.09*dist*dist);
      float nd=max(dot(N,normalize(dL)),0.15);
      ptLit+=vec3(1.0,0.88,0.65)*att*nd*1.15*nightStr;
    }
  }

  vec3 specCol=mix(uSunC,c*uSunC,metalRef);
  vec3 envRef=uSky*uGunduz*(fresnel*(metalRef+sheen+(vA<1.0?0.35:0.04)));
  vec3 R=c*(hemi*(0.66+0.15*uGunduz)+uSunC*d*0.72*g)+spec*specCol+c*ptLit+envRef+c*emissive;

  // Kesit kenarı belirginleştirme
  if(uKes.w<999.0&&abs(kDist)<0.04){
    R=mix(R,vec3(0.14,0.16,0.2),0.55);
  }

  float dist=length(uCam-vW);
  R=mix(R,uSky*uGunduz,clamp((dist-35.0)/95.0,0.0,0.65));
  gl_FragColor=vec4(R,vA);
}
`;

export const D3 = {
  gl: null as WebGLRenderingContext | null,
  pr: null as WebGLProgram | null,
  spr: null as WebGLProgram | null,
  sfb: null as WebGLFramebuffer | null,
  stex: null as WebGLTexture | null,
  bo: null as WebGLBuffer | null,
  bs: null as WebGLBuffer | null,
  no: 0,
  ns: 0,
  w: 0,
  h: 0,
  _cepheGiz: false,
  _kesitKur: false,
  mod: 'orbit' as 'orbit' | 'gez' | 'kesit',
  orto: false,
  ortoKay: [0, 0, 0] as [number, number, number],
  ortoBoy: 24,
  kesit: 'kat' as string,
  kesitC: null as string | null,
  kesitOfset: 0,
  kam: { yaw: 0.72, pitch: 0.48, dist: 20, t: [5, 1.4, 4] as [number, number, number] },
  gez: { p: [5, 1.65, 5] as [number, number, number], yaw: 0, pitch: 0 },
  tuslar: new Set<string>(),
  sonVP: null as Float32Array | null,
  lastProj: null as Float32Array | null,
  lastView: null as Float32Array | null,
  hits: [] as D3HitBox[],
  pointLights: [] as number[],

  baslat(canvas: HTMLCanvasElement) {
    const gl = canvas.getContext('webgl', { antialias: true, preserveDrawingBuffer: true });
    if (!gl) return;
    this.gl = gl;
    const derle = (t: number, s: string) => {
      const x = gl.createShader(t)!;
      gl.shaderSource(x, s);
      gl.compileShader(x);
      if (!gl.getShaderParameter(x, gl.COMPILE_STATUS)) throw new Error(gl.getShaderInfoLog(x) || 'shader error');
      return x;
    };
    const prog = (vs: string, fs: string) => {
      const p = gl.createProgram()!;
      gl.attachShader(p, derle(gl.VERTEX_SHADER, vs));
      gl.attachShader(p, derle(gl.FRAGMENT_SHADER, fs));
      gl.linkProgram(p);
      return p;
    };
    this.pr = prog(GL_VS, GL_FS);
    this.spr = prog(
      'attribute vec3 aPos;uniform mat4 uLS;void main(){gl_Position=uLS*vec4(aPos,1.0);}',
      'precision mediump float;void main(){gl_FragColor=vec4(1.0);}',
    );
    gl.enable(gl.DEPTH_TEST);
    gl.enable(gl.BLEND);
    gl.blendFunc(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA);
    gl.getExtension('WEBGL_depth_texture');
    const st = gl.createTexture();
    gl.bindTexture(gl.TEXTURE_2D, st);
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.DEPTH_COMPONENT, 2048, 2048, 0, gl.DEPTH_COMPONENT, gl.UNSIGNED_INT, null);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.NEAREST);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.NEAREST);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
    const fb = gl.createFramebuffer();
    gl.bindFramebuffer(gl.FRAMEBUFFER, fb);
    gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.DEPTH_ATTACHMENT, gl.TEXTURE_2D, st, 0);
    gl.bindFramebuffer(gl.FRAMEBUFFER, null);
    this.sfb = fb;
    this.stex = st;
    this.bo = gl.createBuffer();
    this.bs = gl.createBuffer();
    this.boyut(canvas);
  },

  boyut(canvas: HTMLCanvasElement) {
    if (!this.gl) return;
    const r = canvas.getBoundingClientRect();
    const dpr = Math.min(2, window.devicePixelRatio || 1);
    this.w = Math.max(1, Math.round(r.width * dpr));
    this.h = Math.max(1, Math.round(r.height * dpr));
    canvas.width = this.w;
    canvas.height = this.h;
    this.gl.viewport(0, 0, this.w, this.h);
  },

  sahneKur() {
    const p = P();
    const m = new Mesh();
    this.hits = [];
    this.pointLights = [];
    const cDuvar = hexRenk(p.cephe.renk || '#efe6d4');
    const cIc: [number, number, number] = [0.95, 0.94, 0.92];
    const cCati = hexRenk(p.cati.renk || '#b5533c');
    const cBeton: [number, number, number] = [0.75, 0.76, 0.77];
    const cPencere = hexRenk(p.cephe.dogramaRenk || '#f4f4f2');
    const cCam: [number, number, number] = [0.55, 0.78, 0.9];
    const mtDis = MT[p.cephe.kaplama] || 0;
    const araziVar = ARAZI.var();
    const sub = p.cephe.subasman || 0;
    const bKot = araziVar ? ARAZI.binaKot() - sub : 0;

    // Zemin / arazi
    if (araziVar) {
      const pts: Pt[] = ARAZI.noktalar().map(n => [n.x ?? 0, n.y ?? 0]);
      if (p.arsa) pts.push(...p.arsa.pts);
      p.duvarlar.forEach(w => pts.push([w.x1, w.y1], [w.x2, w.y2]));
      const b = G.bbox(pts);
      const x0 = b.x1 - 12, y0 = b.y1 - 12, x1 = b.x2 + 12, y1 = b.y2 + 12;
      const g = 32;
      const sx = (x1 - x0) / g;
      const sy = (y1 - y0) / g;
      const iz = ARAZI.ayakIzi();
      const icinde = (x: number, y: number) => iz && ARAZI.padIcinde(x, y, iz, 0.35);
      const zt = (x: number, y: number) => (icinde(x, y) ? bKot : ARAZI.z(x, y));
      const cA: [number, number, number] = [0.5, 0.63, 0.42];
      const cY: [number, number, number] = [0.68, 0.65, 0.56];
      const Z: number[][] = [];
      for (let i = 0; i <= g; i++) {
        Z.push([]);
        for (let j = 0; j <= g; j++) Z[i].push(zt(x0 + i * sx, y0 + j * sy));
      }
      for (let i = 0; i < g; i++) {
        for (let j = 0; j < g; j++) {
          const p0: [number, number, number] = [x0 + i * sx, Z[i][j], y0 + j * sy];
          const p1: [number, number, number] = [x0 + (i + 1) * sx, Z[i + 1][j], y0 + j * sy];
          const p2: [number, number, number] = [x0 + (i + 1) * sx, Z[i + 1][j + 1], y0 + (j + 1) * sy];
          const p3: [number, number, number] = [x0 + i * sx, Z[i][j + 1], y0 + (j + 1) * sy];
          const mx = (p0[0] + p2[0]) / 2;
          const my = (p0[2] + p2[2]) / 2;
          const col = icinde(mx, my) ? cY : cA;
          m.tri(p0, p2, p1, col);
          m.tri(p0, p3, p2, col);
        }
      }
    } else {
      m.kutu(-60, -0.05, -60, 60, 0, 60, [0.55, 0.67, 0.48]);
    }

    // Arsa + çekme çizgisi
    if (p.arsa && p.arsa.pts.length >= 3) {
      const q = p.arsa.pts;
      for (let i = 0; i < q.length; i++) {
        const a = q[i];
        const b = q[(i + 1) % q.length];
        const ya = (araziVar ? ARAZI.z(a[0], a[1]) : 0) + 0.04;
        const yb = (araziVar ? ARAZI.z(b[0], b[1]) : 0) + 0.04;
        const dx = b[0] - a[0], dz = b[1] - a[1], L = Math.hypot(dx, dz) || 1;
        const nx = (-dz / L) * 0.04, nz = (dx / L) * 0.04;
        m.quad([a[0] + nx, ya, a[1] + nz], [b[0] + nx, yb, b[1] + nz], [b[0] - nx, yb + 0.02, b[1] - nz], [a[0] - nx, ya + 0.02, a[1] - nz], [0.9, 0.68, 0.2]);
      }
      const cek = cekmePoligonHesap();
      if (cek) {
        for (let i = 0; i < cek.length; i++) {
          const a = cek[i];
          const b = cek[(i + 1) % cek.length];
          const ya = (araziVar ? ARAZI.z(a[0], a[1]) : 0) + 0.05;
          m.duvarSeg(a[0], a[1], b[0], b[1], 0.04, ya, ya + 0.03, [0.25, 0.75, 0.78], [0.25, 0.75, 0.78]);
        }
      }
    }

    // Dış öğeler
    if (!this._cepheGiz) {
      for (const d of p.dis || []) {
        const dy = araziVar ? ARAZI.z(d.x ?? d.x1 ?? 0, d.y ?? d.y1 ?? 0) : 0;
        if (d.tip === 'agac') {
          agac3DEkle(m, d.x!, dy, d.y!, d.cap || 3.5);
        } else if (d.tip === 'cali') {
          cali3DEkle(m, d.x!, dy, d.y!, d.cap || 1);
        } else if (d.tip === 'cit') {
          const h = d.h || 1.5;
          const x1 = d.x1!, y1 = d.y1!, x2 = d.x2!, y2 = d.y2!;
          const Lc = Math.hypot(x2 - x1, y2 - y1) || 1;
          // Alt beton kaide
          m.duvarSeg(x1, y1, x2, y2, 0.22, dy, dy + Math.min(0.45, h * 0.35), [0.68, 0.66, 0.62], [0.68, 0.66, 0.62], 7, 7);
          // Yatay ahşap/antrasit çıta şeritleri
          const zStart = dy + Math.min(0.45, h * 0.35) + 0.06;
          for (let cz = zStart; cz < dy + h - 0.05; cz += 0.16) {
            m.duvarSeg(x1, y1, x2, y2, 0.05, cz, Math.min(dy + h, cz + 0.11), [0.46, 0.32, 0.2], [0.46, 0.32, 0.2], 2, 2);
          }
          // Ritmik taş/beton babalar + şapka
          const nPost = Math.max(1, Math.round(Lc / 2.5));
          for (let pi = 0; pi <= nPost; pi++) {
            const t = pi / nPost;
            const px = x1 + (x2 - x1) * t, pz = y1 + (y2 - y1) * t;
            m.kutu(px - 0.15, dy, pz - 0.15, px + 0.15, dy + h + 0.06, pz + 0.15, [0.64, 0.63, 0.60], 1, 7);
            m.kutu(px - 0.18, dy + h + 0.06, pz - 0.18, px + 0.18, dy + h + 0.11, pz + 0.18, [0.42, 0.44, 0.47]);
          }
        } else if (d.tip === 'araba') {
          araba3DEkle(m, d.x!, dy, d.y!, d.r || 0);
        } else if (DIS[d.tip]?.alan) {
          const x0 = Math.min(d.x1!, d.x2!), y0 = Math.min(d.y1!, d.y2!);
          const x1 = Math.max(d.x1!, d.x2!), y1 = Math.max(d.y1!, d.y2!);
          const zy = araziVar ? ARAZI.z((x0 + x1) / 2, (y0 + y1) / 2) : 0;
          const col = hexRenk(DIS[d.tip].r3 || '#6fa24f');
          if (d.tip === 'havuz') {
            // Havuz taban seramiği + yarı şeffaf su + 4 kenar mermer küpeşte + paslanmaz havuz merdiveni
            m.kutu(x0, zy, y0, x1, zy + 0.015, y1, [0.16, 0.56, 0.78], 1, 3);
            m.kutu(x0, zy + 0.02, y0, x1, zy + 0.075, y1, col, 0.78, 10);
            const cKup: [number, number, number] = [0.89, 0.88, 0.85];
            m.kutu(x0 - 0.24, zy, y0 - 0.24, x1 + 0.24, zy + 0.11, y0, cKup, 1, 4);
            m.kutu(x0 - 0.24, zy, y1, x1 + 0.24, zy + 0.11, y1 + 0.24, cKup, 1, 4);
            m.kutu(x0 - 0.24, zy, y0, x0, zy + 0.11, y1, cKup, 1, 4);
            m.kutu(x1, zy, y0, x1 + 0.24, zy + 0.11, y1, cKup, 1, 4);
            const lx = x0 + 0.55;
            if (x1 - x0 > 1.2) {
              m.boruSeg(lx - 0.2, zy + 0.08, y0 - 0.12, lx - 0.2, zy + 0.65, y0 + 0.12, 0.018, [0.82, 0.85, 0.89]);
              m.boruSeg(lx + 0.2, zy + 0.08, y0 - 0.12, lx + 0.2, zy + 0.65, y0 + 0.12, 0.018, [0.82, 0.85, 0.89]);
            }
          } else {
            m.kutu(x0, zy + 0.005, y0, x1, zy + 0.03, y1, col);
          }
        }
      }
    }

    // Katlar
    let enAltTaban = 0;
    p.katlar.forEach((_, idx) => (enAltTaban = Math.min(enAltTaban, katTaban(idx))));
    const bodrumVar = p.katlar.some(k => (k.sira ?? 0) < 0);

    // Subasman
    const otur0 = katOturum(p.katlar[0]?.id);
    if (sub > 0 && !bodrumVar) {
      if (otur0) {
        for (const r of alanDikdortgen(otur0)) m.kutu(r.x0 - 0.12, bKot, r.y0 - 0.12, r.x1 + 0.12, bKot + sub, r.y1 + 0.12, [0.52, 0.54, 0.57], 1, 7);
      } else if (p.duvarlar.length) {
        const b = G.bbox(p.duvarlar.flatMap(w => [[w.x1, w.y1], [w.x2, w.y2]] as Pt[]));
        m.kutu(b.x1 - 0.25, bKot, b.y1 - 0.25, b.x2 + 0.25, bKot + sub, b.y2 + 0.25, [0.52, 0.54, 0.57], 1, 7);
      }
    }

    p.katlar.forEach((K, idx) => {
      const y0 = bKot + katTaban(idx);
      const y1 = y0 + K.h;
      const otur = katOturum(K.id);

      // Odalar (zemin kaplama)
      for (const o of p.odalar.filter(o => o.kat === K.id)) {
        const col = hexRenk((ZEMIN[o.zemin] || ZEMIN.parke).r3);
        const mtZ = ZEMIN_MT[o.zemin] || 0;
        const rects = alanDikdortgen(o.pts);
        for (const r of rects) {
          m.kutu(r.x0, y0, r.y0, r.x1, y0 + 0.025, r.y1, col, 1, mtZ, {
            tur: 'oda',
            id: o.id,
            ad: o.ad,
            detay: `${fmt(Math.abs(G.alan(o.pts)))} m² · ${ZEMIN[o.zemin]?.ad || o.zemin}`,
          });
        }
        // Balkon / Teras korkulukları (dış kenarlarda duvar yoksa cam + küpeşte)
        if (ACIK_ALAN_ODA(o.ad)) {
          const katDuv = p.duvarlar.filter(w => w.kat === K.id);
          for (let ei = 0; ei < o.pts.length; ei++) {
            const a = o.pts[ei];
            const b = o.pts[(ei + 1) % o.pts.length];
            const mx = (a[0] + b[0]) / 2;
            const my = (a[1] + b[1]) / 2;
            const duvarVar = katDuv.some(w => G.segNokta(mx, my, w.x1, w.y1, w.x2, w.y2).d < w.k / 2 + 0.25);
            if (!duvarVar && Math.hypot(b[0] - a[0], b[1] - a[1]) > 0.3) {
              m.duvarSeg(a[0], a[1], b[0], b[1], 0.03, y0 + 0.03, y0 + 0.92, cCam, cCam, 0, 0);
              m.duvarSeg(a[0], a[1], b[0], b[1], 0.06, y0 + 0.92, y0 + 0.97, [0.22, 0.25, 0.29], [0.22, 0.25, 0.29]);
            }
          }
        }
      }

      // Kat döşemesi
      const xrayAlpha = S.d3Xray ? 0.22 : 1;
      if (idx > 0 && otur) {
        const md = merdivenler(p.katlar[idx - 1].id);
        for (const r of alanDikdortgen(otur, md.map(q => q.pts))) {
          m.kutu(r.x0 - 0.12, y0 - K.d, r.y0 - 0.12, r.x1 + 0.12, y0, r.y1 + 0.12, cBeton, S.d3Xray ? 0.35 : 1);
        }
        // Balkon/çıkma altı tavan soffit kaplaması
        const altOtur = katOturum(p.katlar[idx - 1].id);
        if (altOtur) {
          for (const r of alanDikdortgen(otur)) {
            const mx = (r.x0 + r.x1) / 2;
            const my = (r.y0 + r.y1) / 2;
            if (!G.icinde(mx, my, altOtur)) {
              m.kutu(r.x0 - 0.12, y0 - K.d - 0.04, r.y0 - 0.12, r.x1 + 0.12, y0 - K.d, r.y1 + 0.12, cDuvar, S.d3Xray ? 0.35 : 1, mtDis);
            }
          }
        }
      }

      // Kolonlar ve kirişler
      for (const o of p.mobilya.filter(o => o.kat === K.id && o.tip === 'kolon')) {
        const { w, d } = mobOlcu(o);
        m.kutuD(o.x, y0, o.y, w, d, K.h, o.r || 0, cBeton, S.d3Xray ? 0.35 : 1, 0, {
          tur: 'mobilya',
          id: o.id,
          ad: 'Taşıyıcı Kolon',
          detay: `${fmt(w * 100, 0)}×${fmt(d * 100, 0)} cm`,
        });
      }
      for (const k of kirisListesi(K.id)) {
        m.duvarSeg(k.a.x, k.a.y, k.b.x, k.b.y, k.w || 0.25, y1 - (k.h || 0.45), y1, cBeton, cBeton, 0, 0, undefined, S.d3Xray ? 0.35 : 1);
      }

      // Duvarlar + Açıklıklar
      for (const w of p.duvarlar.filter(w => w.kat === K.id)) {
        const cDis = w.tur === 'dis' ? cDuvar : cIc;
        const md = w.tur === 'dis' ? mtDis : 0;
        const duvHit = S.d3Xray
          ? undefined
          : {
              tur: 'duvar',
              id: w.id,
              ad: w.tur === 'dis' ? 'Dış Duvar' : 'İç Duvar',
              detay: `Boy: ${fmt(duvarBoy(w))} m · Kalınlık: ${fmt(w.k * 100, 0)} cm`,
            };

        if (w.egri && Math.abs(w.egri) > 0.01) {
          const pts = G.egriNoktalar(w.x1, w.y1, w.x2, w.y2, w.egri, 14);
          for (let s = 0; s + 1 < pts.length; s++) {
            m.duvarSeg(pts[s][0], pts[s][1], pts[s + 1][0], pts[s + 1][1], w.k, y0, y1, cDis, cIc, md, 0, s === 0 ? duvHit : undefined, xrayAlpha);
          }
          continue;
        }

        const pr = duvarParcalari(w);
        const ux = (w.x2 - w.x1) / (pr.L || 1);
        const uy = (w.y2 - w.y1) / (pr.L || 1);
        for (const [s, e] of pr.tam) {
          m.duvarSeg(w.x1 + ux * s, w.y1 + uy * s, w.x1 + ux * e, w.y1 + uy * e, w.k, y0, y1, cDis, cIc, md, 0, duvHit, xrayAlpha);
        }
        for (const { a, s, e } of pr.acik) {
          const x1 = w.x1 + ux * s, z1 = w.y1 + uy * s;
          const x2 = w.x1 + ux * e, z2 = w.y1 + uy * e;
          const yb = y0 + a.p;
          const yt = Math.min(y1, yb + a.h);
          if (a.p > 0.01) m.duvarSeg(x1, z1, x2, z2, w.k, y0, yb, cDis, cIc, md, 0, undefined, xrayAlpha);
          if (yt < y1 - 0.01) m.duvarSeg(x1, z1, x2, z2, w.k, yt, y1, cDis, cIc, md, 0, undefined, xrayAlpha);

          const cCer = a.renk ? hexRenk(a.renk) : cPencere;
          const acikHit = {
            tur: 'acik',
            id: a.id,
            ad: a.tur === 'pencere' ? 'Pencere' : a.tur === 'balkon' ? 'Balkon Kapısı' : a.tur === 'surme' ? 'Sürme Cam Kapı' : a.tur === 'cift_kapi' ? 'Çift Kanat Kapı' : 'Kapı',
            detay: `${fmt(a.g * 100, 0)}×${fmt(a.h * 100, 0)} cm`,
          };

          if (a.tur === 'pencere' || a.tur === 'balkon' || a.tur === 'surme' || a.tur === 'cati_pencere') {
            m.duvarSeg(x1, z1, x2, z2, 0.06, yb, yb + 0.05, cCer, cCer, 0, 0, acikHit);
            m.duvarSeg(x1, z1, x2, z2, 0.06, yt - 0.05, yt, cCer, cCer);
            m.duvarSeg(x1, z1, x1 + ux * 0.05, z1 + uy * 0.05, 0.06, yb, yt, cCer, cCer);
            m.duvarSeg(x2 - ux * 0.05, z2 - uy * 0.05, x2, z2, 0.06, yb, yt, cCer, cCer);
            // Mermer / alüminyum denizlik (pencere alt taşı)
            if (a.tur === 'pencere') {
              m.duvarSeg(x1 - ux * 0.03, z1 - uy * 0.03, x2 + ux * 0.03, z2 + uy * 0.03, w.k + 0.07, yb - 0.03, yb + 0.005, [0.88, 0.87, 0.85], [0.88, 0.87, 0.85], 4, 4);
            }
            if (a.tur === 'surme' || a.g > 1.3) {
              const mx = (x1 + x2) / 2, mz = (z1 + z2) / 2;
              m.duvarSeg(mx - ux * 0.02, mz - uy * 0.02, mx + ux * 0.02, mz + uy * 0.02, 0.055, yb, yt, cCer, cCer);
            }
            const dx = x2 - x1, dz = z2 - z1;
            const nx = (-dz / (Math.hypot(dx, dz) || 1)) * 0.015;
            const nz = (dx / (Math.hypot(dx, dz) || 1)) * 0.015;
            m.quad([x1 + nx, yb + 0.05, z1 + nz], [x2 + nx, yb + 0.05, z2 + nz], [x2 + nx, yt - 0.05, z2 + nz], [x1 + nx, yt - 0.05, z1 + nz], cCam, 0.35);
            if (a.panjur) {
              m.duvarSeg(x1, z1, x2, z2, w.k + 0.04, yt - 0.02, Math.min(y1, yt + 0.16), [0.3, 0.33, 0.37], [0.3, 0.33, 0.37]);
            }
          } else {
            const cKap: [number, number, number] = w.tur === 'dis' ? [0.24, 0.27, 0.32] : [0.76, 0.59, 0.4];
            const cKulp: [number, number, number] = [0.84, 0.86, 0.89];
            m.duvarSeg(x1, z1, x2, z2, 0.07, yt - 0.05, yt, cKap, cKap);
            m.duvarSeg(x1, z1, x1 + ux * 0.05, z1 + uy * 0.05, 0.07, yb, yt, cKap, cKap);
            m.duvarSeg(x2 - ux * 0.05, z2 - uy * 0.05, x2, z2, 0.07, yb, yt, cKap, cKap);
            if (a.tur === 'cift_kapi') {
              const mx = (x1 + x2) / 2, mz = (z1 + z2) / 2;
              m.duvarSeg(x1 + ux * 0.05, z1 + uy * 0.05, mx - ux * 0.01, mz - uy * 0.01, 0.04, yb + 0.01, yt - 0.05, cKap, cKap, 2, 2, acikHit);
              m.duvarSeg(mx + ux * 0.01, mz + uy * 0.01, x2 - ux * 0.05, z2 - uy * 0.05, 0.04, yb + 0.01, yt - 0.05, cKap, cKap, 2, 2);
              m.kutu(mx - 0.06, yb + 0.98, mz - 0.05, mx + 0.06, yb + 1.04, mz + 0.05, cKulp, 1, 8);
            } else {
              m.duvarSeg(x1 + ux * 0.05, z1 + uy * 0.05, x2 - ux * 0.05, z2 - uy * 0.05, 0.04, yb + 0.01, yt - 0.05, cKap, cKap, w.tur === 'dis' ? 0 : 2, 2, acikHit);
              const kx = x2 - ux * 0.14, kz = z2 - uy * 0.14;
              m.kutu(kx - 0.04, yb + 0.98, kz - 0.055, kx + 0.04, yb + 1.03, kz + 0.055, cKulp, 1, 8);
            }
          }
        }
      }

      // Mobilyalar ve Merdivenler
      for (const o of p.mobilya.filter(o => o.kat === K.id)) {
        const T = MOB[o.tip];
        if (!T || T.ozel === 'kolon') continue;
        const mobHit = { tur: 'mobilya', id: o.id, ad: T.ad, detay: T.k };
        if (T.ozel?.startsWith('merdiven')) {
          const { w, d } = mobOlcu(o);
          const H = K.h + (p.katlar[idx + 1]?.d || 0.15);
          const n = o.basamak || Math.max(8, Math.round(H / 0.175));
          const dh = H / n;
          const cRiht: [number, number, number] = [0.91, 0.89, 0.86];
          const cBas: [number, number, number] = [0.74, 0.57, 0.38];
          const cKork: [number, number, number] = [0.22, 0.24, 0.28];
          const rotPt = (lx: number, ly: number) => {
            const t = G.donder(lx, ly, o.r || 0);
            return [o.x + t[0], o.y + t[1]] as [number, number];
          };
          if (T.ozel === 'merdiven') {
            const db = d / n;
            for (let i = 0; i < n; i++) {
              const ly = d / 2 - db * (i + 0.5);
              const t = G.donder(0, ly, o.r || 0);
              const by = y0 + i * dh;
              m.kutuD(o.x + t[0], by, o.y + t[1], w, db * 0.94, Math.max(0.04, dh - 0.035), o.r || 0, cRiht, 1, 0, i === 0 ? mobHit : undefined);
              m.kutuD(o.x + t[0], by + dh - 0.04, o.y + t[1], w + 0.02, db + 0.025, 0.04, o.r || 0, cBas, 1, 2);
              if (i % 3 === 0 || i === n - 1) {
                const kp = rotPt(w / 2 - 0.04, ly);
                m.kutuD(kp[0], by + dh, kp[1], 0.03, 0.03, 0.88, o.r || 0, cKork);
              }
            }
            const hp0 = rotPt(w / 2 - 0.04, d / 2 - db * 0.5);
            const hp1 = rotPt(w / 2 - 0.04, -d / 2 + db * 0.5);
            m.boruSeg(hp0[0], y0 + dh + 0.88, hp0[1], hp1[0], y0 + H + 0.88, hp1[1], 0.022, cKork);
            // Cam korkuluk paneli
            m.quad(
              [hp0[0], y0 + dh + 0.06, hp0[1]],
              [hp1[0], y0 + H + 0.06, hp1[1]],
              [hp1[0], y0 + H + 0.86, hp1[1]],
              [hp0[0], y0 + dh + 0.86, hp0[1]],
              cCam,
              0.28,
            );
          } else if (T.ozel === 'merdiven_u') {
            const half = Math.floor(n / 2);
            const colW = w * 0.46;
            const runD = d - colW * 0.9;
            const db1 = runD / half;
            for (let i = 0; i < half; i++) {
              const ly = d / 2 - db1 * (i + 0.5);
              const t = G.donder(-w * 0.27, ly, o.r || 0);
              const by = y0 + i * dh;
              m.kutuD(o.x + t[0], by, o.y + t[1], colW, db1 * 0.94, Math.max(0.04, dh - 0.035), o.r || 0, cRiht, 1, 0, i === 0 ? mobHit : undefined);
              m.kutuD(o.x + t[0], by + dh - 0.04, o.y + t[1], colW + 0.02, db1 + 0.02, 0.04, o.r || 0, cBas, 1, 2);
            }
            // Sahanlık
            const ts = G.donder(0, -d / 2 + colW * 0.45, o.r || 0);
            m.kutuD(o.x + ts[0], y0 + (half - 0.5) * dh, o.y + ts[1], w, colW * 0.9, dh, o.r || 0, cBas, 1, 2);
            const rem = n - half;
            const db2 = runD / rem;
            for (let i = 0; i < rem; i++) {
              const ly = -d / 2 + colW * 0.9 + db2 * (i + 0.5);
              const t = G.donder(w * 0.27, ly, o.r || 0);
              const by = y0 + (half + i) * dh;
              m.kutuD(o.x + t[0], by, o.y + t[1], colW, db2 * 0.94, Math.max(0.04, dh - 0.035), o.r || 0, cRiht);
              m.kutuD(o.x + t[0], by + dh - 0.04, o.y + t[1], colW + 0.02, db2 + 0.02, 0.04, o.r || 0, cBas, 1, 2);
            }
            const pA0 = rotPt(-0.04, d / 2 - db1 * 0.5);
            const pA1 = rotPt(-0.04, -d / 2 + colW * 0.9);
            m.boruSeg(pA0[0], y0 + dh + 0.88, pA0[1], pA1[0], y0 + half * dh + 0.88, pA1[1], 0.02, cKork);
            const pB0 = rotPt(0.04, -d / 2 + colW * 0.9);
            const pB1 = rotPt(0.04, d / 2 - db2 * 0.5);
            m.boruSeg(pB0[0], y0 + half * dh + 0.88, pB0[1], pB1[0], y0 + H + 0.88, pB1[1], 0.02, cKork);
          } else if (T.ozel === 'merdiven_l') {
            const leg1 = Math.floor(n * 0.6);
            const leg2 = n - leg1;
            const bW = Math.min(w, d) * 0.46;
            const db1 = (d - bW) / leg1;
            for (let i = 0; i < leg1; i++) {
              const t = G.donder(-w / 2 + bW / 2, d / 2 - db1 * (i + 0.5), o.r || 0);
              const by = y0 + i * dh;
              m.kutuD(o.x + t[0], by, o.y + t[1], bW, db1 * 0.94, Math.max(0.04, dh - 0.035), o.r || 0, cRiht, 1, 0, i === 0 ? mobHit : undefined);
              m.kutuD(o.x + t[0], by + dh - 0.04, o.y + t[1], bW + 0.02, db1 + 0.02, 0.04, o.r || 0, cBas, 1, 2);
            }
            const ts = G.donder(-w / 2 + bW / 2, -d / 2 + bW / 2, o.r || 0);
            m.kutuD(o.x + ts[0], y0 + leg1 * dh, o.y + ts[1], bW, bW, dh, o.r || 0, cBas, 1, 2);
            const db2 = (w - bW) / Math.max(1, leg2);
            for (let i = 0; i < leg2; i++) {
              const t = G.donder(-w / 2 + bW + db2 * (i + 0.5), -d / 2 + bW / 2, o.r || 0);
              const by = y0 + (leg1 + i) * dh;
              m.kutuD(o.x + t[0], by, o.y + t[1], db2 * 0.94, bW, Math.max(0.04, dh - 0.035), o.r || 0, cRiht);
              m.kutuD(o.x + t[0], by + dh - 0.04, o.y + t[1], db2 + 0.02, bW + 0.02, 0.04, o.r || 0, cBas, 1, 2);
            }
          } else {
            // Döner merdiven + merkezi çelik omurga & küpeşte dikmeleri
            const rad = Math.min(w, d) / 2;
            m.silindir(o.x, y0, o.y, 0.1, 0.1, H + 0.9, 12, cKork);
            let prevH: [number, number, number] | null = null;
            for (let i = 0; i < n; i++) {
              const ang = (i / n) * 280;
              const t = G.donder(rad * 0.52, 0, ang + (o.r || 0));
              m.kutuD(o.x + t[0], y0 + i * dh, o.y + t[1], rad * 0.85, 0.30, 0.055, ang + (o.r || 0), cBas, 1, 2, i === 0 ? mobHit : undefined);
              const outer = G.donder(rad * 0.92, 0, ang + (o.r || 0));
              const ox = o.x + outer[0], oz = o.y + outer[1], oy = y0 + i * dh + 0.055;
              m.boruSeg(ox, oy, oz, ox, oy + 0.88, oz, 0.015, cKork);
              if (prevH) m.boruSeg(prevH[0], prevH[1], prevH[2], ox, oy + 0.88, oz, 0.02, cKork);
              prevH = [ox, oy + 0.88, oz];
            }
          }
          continue;
        }
        mobilya3DEkle(m, o, y0, mobHit);
      }

      // İç mekan donanımları (aydınlatma, klima, petek, kombi) + nokta ışıklar her zaman görünür
      for (const t of (p.tesisat || []).filter(t => t.kat === K.id)) {
        if ((t.tip === 'lamba' || t.tip === 'aplik') && this.pointLights.length < 24) {
          this.pointLights.push(t.x, Math.min(y1 - 0.25, y0 + (t.tip === 'lamba' ? K.h - 0.34 : 1.95)), t.y);
        }
        if (['lamba', 'aplik', 'kombi', 'petek', 'klima'].includes(t.tip) || S.d3Tesisat) {
          tesisat3DEkle(m, t, y0, K.h);
        }
        if (S.d3Tesisat && t.tip === 'saft') {
          m.boruSeg(t.x - 0.08, y0, t.y, t.x - 0.08, y1, t.y, 0.04, hexRenk(BORU_TIPLERI.pis_su.renk));
          m.boruSeg(t.x + 0.08, y0, t.y, t.x + 0.08, y1, t.y, 0.025, hexRenk(BORU_TIPLERI.temiz_su_soguk.renk));
        }
      }

      // Tesisat boru döşemeleri (S.d3Tesisat açıksa)
      if (S.d3Tesisat) {
        for (const b of (p.borular || []).filter(b => b.kat === K.id)) {
          const tip = BORU_TIPLERI[b.tur];
          if (!tip || b.pts.length < 2) continue;
          const bc = hexRenk(tip.renk);
          const r = Math.max(0.015, Math.min(0.065, b.cap / 1600));
          const yBas = y0 + (b.kot ?? tip.varsKot);
          let kumL = 0;
          for (let s = 0; s + 1 < b.pts.length; s++) {
            const p0 = b.pts[s], p1 = b.pts[s + 1];
            const segL = Math.hypot(p1[0] - p0[0], p1[1] - p0[1]);
            const dy0 = b.egim ? -(kumL * b.egim) / 100 : 0;
            const dy1 = b.egim ? -((kumL + segL) * b.egim) / 100 : 0;
            m.boruSeg(
              p0[0], yBas + dy0, p0[1],
              p1[0], yBas + dy1, p1[1],
              r,
              bc,
              s === 0 ? { tur: 'boru', id: b.id, ad: tip.ad, detay: `Ø${b.cap} mm · Kot: ${fmt(b.kot ?? tip.varsKot)} m` } : undefined,
            );
            kumL += segL;
          }
        }
        // 3D MEP çakışma uyarı işaretçileri
        const cakismalar = boruCakismaBul(K.id);
        cakismalar.forEach((ck, ci) => {
          const cy = y0 + ck.kot;
          m.kutu(
            ck.x - 0.14,
            cy - 0.14,
            ck.y - 0.14,
            ck.x + 0.14,
            cy + 0.14,
            ck.y + 0.14,
            [0.95, 0.22, 0.2],
            0.88,
            0,
            { tur: 'cikti', id: `${K.id}_ck_${ci}`, ad: '⚠ Boru Çakışması', detay: ck.mesaj },
          );
        });
      }

      // 3D Akslar (opsiyonel)
      if (S.d3Aks && idx === 0) {
        const b = p.duvarlar.length
          ? G.bbox(p.duvarlar.flatMap(w => [[w.x1, w.y1], [w.x2, w.y2]] as Pt[]))
          : { x1: -2, y1: -2, x2: 12, y2: 10 };
        for (const a of p.akslar || []) {
          if (a.yon === 'd') m.duvarSeg(a.k, b.y1 - 1.5, a.k, b.y2 + 1.5, 0.03, y0 + 0.04, y0 + 0.06, [0.75, 0.22, 0.17], [0.75, 0.22, 0.17]);
          else m.duvarSeg(b.x1 - 1.5, a.k, b.x2 + 1.5, a.k, 0.03, y0 + 0.04, y0 + 0.06, [0.75, 0.22, 0.17], [0.75, 0.22, 0.17]);
        }
      }
    });

    // Çatı (en üst katın üstü)
    const son = p.katlar[p.katlar.length - 1];
    const oturSon = katOturum(son.id);
    if (son && oturSon && this.kesit === 'tumu') {
      const yT = bKot + katTaban(p.katlar.length - 1) + son.h;
      const sac = p.cati.sacak || 0;
      const e = Math.tan(p.cati.egim * RAD);
      const tavan = dikdortgenlere(oturSon) ? alanDikdortgen(oturSon) : [];
      for (const r of tavan) m.kutu(r.x0 - 0.12, yT, r.y0 - 0.12, r.x1 + 0.12, yT + 0.15, r.y1 + 0.12, cBeton);
      if (p.cati.tip === 'duz') {
        for (const r of tavan) {
          const x0 = r.x0 - 0.15, x1 = r.x1 + 0.15, z0 = r.y0 - 0.15, z1 = r.y1 + 0.15;
          m.kutu(x0, yT + 0.15, z0, x1, yT + 0.7, z0 + 0.18, cDuvar, 1, mtDis);
          m.kutu(x0, yT + 0.15, z1 - 0.18, x1, yT + 0.7, z1, cDuvar, 1, mtDis);
          m.kutu(x0, yT + 0.15, z0, x0 + 0.18, yT + 0.7, z1, cDuvar, 1, mtDis);
          m.kutu(x1 - 0.18, yT + 0.15, z0, x1, yT + 0.7, z1, cDuvar, 1, mtDis);
        }
      } else if (tavan.length >= 1 && tavan.length <= 4 && tavan.every(r => r.x1 - r.x0 > 0.8 && r.y1 - r.y0 > 0.8)) {
        for (const r of tavan) {
          const x0 = r.x0 - sac - 0.1, x1 = r.x1 + sac + 0.1, z0 = r.y0 - sac - 0.1, z1 = r.y1 + sac + 0.1;
          const h = ((p.cati.tip === 'tek' ? z1 - z0 : Math.min(x1 - x0, z1 - z0) / 2) * e) || 0.8;
          m.catiUcgen(x0, z0, x1, z1, yT + 0.15, h, p.cati.tip, cCati);
          if (p.cati.oluk) {
            const cOl: [number, number, number] = [0.22, 0.25, 0.29];
            m.duvarSeg(x0, z0, x1, z0, 0.08, yT + 0.08, yT + 0.16, cOl, cOl);
            m.duvarSeg(x0, z1, x1, z1, 0.08, yT + 0.08, yT + 0.16, cOl, cOl);
          }
        }
      } else {
        // Dikdörtgen olmayan / L / çokgen çatı fallback
        const genis = G.cekmePoligon(oturSon, oturSon.map(() => -(sac + 0.1))) || oturSon;
        const b = G.bbox(genis);
        const h = (Math.min(b.w, b.h) / 2) * e || 1.2;
        m.poligonCati(genis, yT + 0.15, h, cCati);
      }

      // Baca
      if (p.cati.baca && oturSon.length) {
        const mc = G.merkez(oturSon);
        const hMax = 2.4;
        m.kutu(mc[0] + 0.6, yT + 0.15, mc[1] - 0.3, mc[0] + 1.05, yT + hMax, mc[1] + 0.15, [0.68, 0.36, 0.3], 1, 6);
        m.kutu(mc[0] + 0.56, yT + hMax, mc[1] - 0.34, mc[0] + 1.09, yT + hMax + 0.08, mc[1] + 0.19, cBeton);
      }
    }

    // Yalnız kat modu: kesit düzlemi alt sınırı göster
    if (this.kesit === 'kat') {
      const i = p.katlar.findIndex(k => k.id === S.katId);
      const yKes = bKot + katTaban(Math.max(0, i)) + kat().h - 0.15;
      void yKes;
    }

    const gl = this.gl;
    if (!gl) return;
    gl.bindBuffer(gl.ARRAY_BUFFER, this.bo);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(m.o), gl.STATIC_DRAW);
    this.no = m.o.length / 11;
    gl.bindBuffer(gl.ARRAY_BUFFER, this.bs);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(m.s), gl.STATIC_DRAW);
    this.ns = m.s.length / 11;
    this.lastMesh = m;
    S.d3Kirli = false;
  },

  lastMesh: null as Mesh | null,

  odakla() {
    const pts: Pt[] = [];
    P().duvarlar.forEach(w => pts.push([w.x1, w.y1], [w.x2, w.y2]));
    const b = pts.length ? G.bbox(pts) : { x1: 0, y1: 0, x2: 10, y2: 8, w: 10, h: 8 };
    const h = P().katlar.reduce((s, k) => s + k.h, 0);
    this.kam.t = [b.x1 + b.w / 2, h * 0.4, b.y1 + b.h / 2];
    this.kam.dist = Math.max(8, Math.hypot(b.w, b.h) * 1.35);
    this.gez.p = [b.x1 + b.w / 2, 1.65, b.y2 + 4];
    this.gez.yaw = 0;
    this.gez.pitch = 0;
  },

  kameraAyar(yon: 'izo' | 'on' | 'arka' | 'sol' | 'sag' | 'ust') {
    this.mod = 'orbit';
    this.odakla();
    if (yon === 'izo') {
      this.orto = false;
      this.kam.yaw = 0.72;
      this.kam.pitch = 0.48;
    } else if (yon === 'on') {
      this.orto = true;
      this.kam.yaw = 0;
      this.kam.pitch = 0.05;
    } else if (yon === 'arka') {
      this.orto = true;
      this.kam.yaw = Math.PI;
      this.kam.pitch = 0.05;
    } else if (yon === 'sol') {
      this.orto = true;
      this.kam.yaw = -Math.PI / 2;
      this.kam.pitch = 0.05;
    } else if (yon === 'sag') {
      this.orto = true;
      this.kam.yaw = Math.PI / 2;
      this.kam.pitch = 0.05;
    } else if (yon === 'ust') {
      this.orto = true;
      this.kam.yaw = 0;
      this.kam.pitch = 1.5;
    }
    this.ortoBoy = Math.max(12, this.kam.dist * 0.8);
    this.ortoKay = [0, 0, 0];
    this.ciz();
  },

  matrisler() {
    let view: Float32Array;
    let cam: [number, number, number];
    let proj: Float32Array;
    const asp = this.w / (this.h || 1);
    if (this.mod === 'gez') {
      const g = this.gez;
      cam = g.p;
      const d = [
        Math.sin(g.yaw) * Math.cos(g.pitch),
        Math.sin(g.pitch),
        -Math.cos(g.yaw) * Math.cos(g.pitch),
      ];
      view = M4.bak(cam, [cam[0] + d[0], cam[1] + d[1], cam[2] + d[2]], [0, 1, 0]);
      proj = M4.persp(55 * RAD, asp, 0.1, 250);
    } else {
      const k = this.kam;
      cam = [
        k.t[0] + k.dist * Math.cos(k.pitch) * Math.sin(k.yaw),
        k.t[1] + k.dist * Math.sin(k.pitch),
        k.t[2] + k.dist * Math.cos(k.pitch) * Math.cos(k.yaw),
      ];
      const u: [number, number, number] = Math.abs(Math.sin(k.pitch)) > 0.98 ? [-Math.sin(k.yaw), 0, -Math.cos(k.yaw)] : [0, 1, 0];
      view = M4.bak(cam, k.t, u);
      if (this.orto) {
        const hh = this.ortoBoy / 2;
        const hw = hh * asp;
        proj = M4.ortog(-hw + this.ortoKay[0], hw + this.ortoKay[0], -hh + this.ortoKay[1], hh + this.ortoKay[1], -120, 220);
      } else {
        proj = M4.persp(45 * RAD, asp, 0.2, 250);
      }
    }
    this.lastProj = proj;
    this.lastView = view;
    this.sonVP = M4.mult(proj, view);
    return { VP: this.sonVP, cam };
  },

  ciz() {
    if (!this.gl || !S.p) return;
    if (S.d3Kirli) this.sahneKur();
    const gl = this.gl;
    const { VP, cam } = this.matrisler();

    const g = gunesKonum();
    const gunduz = sinir(g.el / (12 * RAD), 0.12, 1);
    const L = [g.yon[0], Math.max(0.08, g.yon[1]), g.yon[2]];
    const ll = Math.hypot(L[0], L[1], L[2]);
    L[0] /= ll; L[1] /= ll; L[2] /= ll;
    const sky = [0.46 * gunduz + 0.08, 0.65 * gunduz + 0.1, 0.84 * gunduz + 0.14];
    const sunC = [1, 0.84 + 0.14 * gunduz, 0.66 + 0.28 * gunduz];

    let kes: [number, number, number, number] = [0, 1, 0, 999];
    const p = P();
    const bKot = ARAZI.var() ? ARAZI.binaKot() - (p.cephe.subasman || 0) : 0;
    if (this.kesit === 'kat') {
      const i = p.katlar.findIndex(k => k.id === S.katId);
      kes = [0, 1, 0, -(bKot + katTaban(Math.max(0, i)) + kat().h - 0.1)];
    } else if (this.kesit.startsWith('k:')) {
      const ks = (p.kesitler || []).find(x => x.id === this.kesit.slice(2));
      if (ks) {
        const kd = kesitDuzlemHesap(ks);
        kes = [kd.kes[0], kd.kes[1], kd.kes[2], kd.kes[3]];
      }
    }

    const ls = M4.mult(
      M4.ortog(-22, 22, -22, 22, -40, 80),
      M4.bak([this.kam.t[0] + L[0] * 30, this.kam.t[1] + L[1] * 30, this.kam.t[2] + L[2] * 30], this.kam.t, [0, 1, 0]),
    );

    const bagla = (buf: WebGLBuffer | null, pr: WebGLProgram) => {
      gl.bindBuffer(gl.ARRAY_BUFFER, buf);
      const S4 = 44;
      const A = (n: string, k: number, o: number) => {
        const l = gl.getAttribLocation(pr, n);
        if (l >= 0) {
          gl.enableVertexAttribArray(l);
          gl.vertexAttribPointer(l, k, gl.FLOAT, false, S4, o);
        }
      };
      A('aPos', 3, 0);
      A('aNor', 3, 12);
      A('aCol', 3, 24);
      A('aAlp', 1, 36);
      A('aMat', 1, 40);
    };

    const golge = p.ayar.golge !== false && g.el > 0.04;
    if (golge) {
      gl.bindFramebuffer(gl.FRAMEBUFFER, this.sfb);
      gl.viewport(0, 0, 2048, 2048);
      gl.clear(gl.DEPTH_BUFFER_BIT);
      gl.useProgram(this.spr);
      gl.uniformMatrix4fv(gl.getUniformLocation(this.spr!, 'uLS'), false, ls);
      bagla(this.bo, this.spr!);
      gl.drawArrays(gl.TRIANGLES, 0, this.no);
      gl.bindFramebuffer(gl.FRAMEBUFFER, null);
    }

    gl.viewport(0, 0, this.w, this.h);
    gl.clearColor(sky[0], sky[1], sky[2], 1);
    gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
    gl.useProgram(this.pr);
    const pr = this.pr!;
    gl.uniformMatrix4fv(gl.getUniformLocation(pr, 'uVP'), false, VP);
    gl.uniformMatrix4fv(gl.getUniformLocation(pr, 'uLS'), false, ls);
    gl.uniform3fv(gl.getUniformLocation(pr, 'uSun'), L);
    gl.uniform3fv(gl.getUniformLocation(pr, 'uCam'), cam);
    gl.uniform3fv(gl.getUniformLocation(pr, 'uSky'), sky);
    gl.uniform3fv(gl.getUniformLocation(pr, 'uSunC'), sunC);
    gl.uniform4fv(gl.getUniformLocation(pr, 'uKes'), kes);
    gl.uniform1f(gl.getUniformLocation(pr, 'uKesOfset'), this.kesit === 'tumu' ? 0 : this.kesitOfset);
    gl.uniform1f(gl.getUniformLocation(pr, 'uGunduz'), gunduz);
    gl.uniform1i(gl.getUniformLocation(pr, 'uGolge'), golge ? 1 : 0);

    const ptsArr = new Float32Array(24);
    for (let i = 0; i < Math.min(24, this.pointLights.length); i++) ptsArr[i] = this.pointLights[i];
    gl.uniform3fv(gl.getUniformLocation(pr, 'uPointPos[0]'), ptsArr);
    gl.uniform1i(gl.getUniformLocation(pr, 'uPointCount'), Math.min(8, Math.floor(this.pointLights.length / 3)));

    gl.activeTexture(gl.TEXTURE0);
    gl.bindTexture(gl.TEXTURE_2D, this.stex);
    gl.uniform1i(gl.getUniformLocation(pr, 'uSMap'), 0);

    bagla(this.bo, pr);
    gl.drawArrays(gl.TRIANGLES, 0, this.no);
    if (this.ns) {
      gl.depthMask(false);
      bagla(this.bs, pr);
      gl.drawArrays(gl.TRIANGLES, 0, this.ns);
      gl.depthMask(true);
    }
  },

  foto(w: number, h: number, ayarFn: () => void, tip: 'image/jpeg' | 'image/png' = 'image/jpeg'): string {
    const c = document.querySelector('#c3d') as HTMLCanvasElement | null;
    if (!c) return '';
    if (!this.gl) this.baslat(c);
    const prev = {
      w: this.w,
      h: this.h,
      cw: c.width,
      ch: c.height,
      mod: this.mod,
      orto: this.orto,
      kesit: this.kesit,
      kesitC: this.kesitC,
      kesitOfset: this.kesitOfset,
      ortoKay: [...this.ortoKay] as [number, number, number],
      ortoBoy: this.ortoBoy,
      kam: { ...this.kam, t: [...this.kam.t] as [number, number, number] },
      _cepheGiz: this._cepheGiz,
      _kesitKur: this._kesitKur,
    };
    try {
      c.width = w;
      c.height = h;
      this.w = w;
      this.h = h;
      ayarFn();
      this.ciz();
      return c.toDataURL(tip, 0.92);
    } finally {
      this.w = prev.w;
      this.h = prev.h;
      c.width = prev.cw;
      c.height = prev.ch;
      this.mod = prev.mod;
      this.orto = prev.orto;
      this.kesit = prev.kesit;
      this.kesitC = prev.kesitC;
      this.kesitOfset = prev.kesitOfset;
      this.ortoKay = prev.ortoKay;
      this.ortoBoy = prev.ortoBoy;
      this.kam = prev.kam;
      this._cepheGiz = prev._cepheGiz;
      this._kesitKur = prev._kesitKur;
      if (this.gl) {
        this.gl.viewport(0, 0, prev.w, prev.h);
        if (this._kesitKur || S.d3Kirli) this.sahneKur();
        this.ciz();
      }
    }
  },

  kesitFoto(k: Kesit, w: number, h: number): string {
    const D = kesitDuzlemHesap(k);
    const pts: Pt[] = [];
    P().duvarlar.forEach(dw => pts.push([dw.x1, dw.y1], [dw.x2, dw.y2]));
    const b = pts.length ? G.bbox(pts) : { x1: 0, y1: 0, x2: 10, y2: 8, w: 10, h: 8 };
    const H = P().katlar.reduce((s, kk) => s + kk.h + kk.d, 0);
    return this.foto(w, h, () => {
      this.mod = 'orbit';
      this.orto = true;
      this.kesit = 'k:' + k.id;
      this.kesitOfset = 0;
      this.ortoBoy = Math.max(8, Math.max(b.w, b.h, H) * 1.45);
      this.ortoKay = [0, 0, 0];
      this.kam.t = [b.x1 + b.w / 2, H * 0.45, b.y1 + b.h / 2];
      this.kam.dist = 35;
      this.kam.yaw = Math.atan2(-D.v[0], -D.v[1]);
      this.kam.pitch = 0.02;
    });
  },

  rayIsabet(sx: number, sy: number, rect: DOMRect): { hit?: D3HitBox; nokta?: [number, number, number] } {
    if (!this.lastProj || !this.lastView) return {};
    const nx = ((sx - rect.left) / rect.width) * 2 - 1;
    const ny = 1 - ((sy - rect.top) / rect.height) * 2;
    const k = this.kam;
    const cam: [number, number, number] =
      this.mod === 'gez'
        ? this.gez.p
        : [
            k.t[0] + k.dist * Math.cos(k.pitch) * Math.sin(k.yaw),
            k.t[1] + k.dist * Math.sin(k.pitch),
            k.t[2] + k.dist * Math.cos(k.pitch) * Math.cos(k.yaw),
          ];
    let dir: [number, number, number];
    if (this.mod === 'gez') {
      const f = [Math.sin(this.gez.yaw) * Math.cos(this.gez.pitch), Math.sin(this.gez.pitch), -Math.cos(this.gez.yaw) * Math.cos(this.gez.pitch)];
      const r = [Math.cos(this.gez.yaw), 0, Math.sin(this.gez.yaw)];
      const u = [r[1] * f[2] - r[2] * f[1], r[2] * f[0] - r[0] * f[2], r[0] * f[1] - r[1] * f[0]];
      const th = Math.tan((55 * RAD) / 2);
      const asp = this.w / (this.h || 1);
      dir = [
        f[0] + r[0] * nx * th * asp + u[0] * ny * th,
        f[1] + r[1] * nx * th * asp + u[1] * ny * th,
        f[2] + r[2] * nx * th * asp + u[2] * ny * th,
      ];
    } else {
      const f = [k.t[0] - cam[0], k.t[1] - cam[1], k.t[2] - cam[2]];
      const fl = Math.hypot(f[0], f[1], f[2]) || 1;
      f[0] /= fl; f[1] /= fl; f[2] /= fl;
      let rx = -f[2], rz = f[0];
      const rl = Math.hypot(rx, rz) || 1;
      rx /= rl; rz /= rl;
      const ux = f[1] * rz - f[2] * 0;
      const uy = f[2] * rx - f[0] * rz;
      const uz = f[0] * 0 - f[1] * rx;
      if (this.orto) {
        const hh = this.ortoBoy / 2;
        const hw = hh * (this.w / (this.h || 1));
        cam[0] += rx * (nx * hw + this.ortoKay[0]) + ux * (ny * hh + this.ortoKay[1]);
        cam[1] += uy * (ny * hh + this.ortoKay[1]);
        cam[2] += rz * (nx * hw + this.ortoKay[0]) + uz * (ny * hh + this.ortoKay[1]);
        dir = [f[0], f[1], f[2]];
      } else {
        const th = Math.tan((45 * RAD) / 2);
        const asp = this.w / (this.h || 1);
        dir = [
          f[0] + rx * nx * th * asp + ux * ny * th,
          f[1] + uy * ny * th,
          f[2] + rz * nx * th * asp + uz * ny * th,
        ];
      }
    }
    const dl = Math.hypot(dir[0], dir[1], dir[2]) || 1;
    dir = [dir[0] / dl, dir[1] / dl, dir[2] / dl];

    let bestT = Infinity;
    let bestHit: D3HitBox | undefined;
    for (const h of this.hits) {
      let tmin = -Infinity;
      let tmax = Infinity;
      for (let i = 0; i < 3; i++) {
        const o = cam[i], d = dir[i] || 1e-9;
        let t1 = (h.min[i] - o) / d;
        let t2 = (h.max[i] - o) / d;
        if (t1 > t2) [t1, t2] = [t2, t1];
        tmin = Math.max(tmin, t1);
        tmax = Math.min(tmax, t2);
      }
      if (tmax >= Math.max(0.05, tmin) && tmin < bestT) {
        bestT = tmin;
        bestHit = h;
      }
    }
    if (bestHit && bestT < Infinity) {
      return {
        hit: bestHit,
        nokta: [cam[0] + dir[0] * bestT, cam[1] + dir[1] * bestT, cam[2] + dir[2] * bestT],
      };
    }
    // Zemin düzlemine (y=0) kesişim fallback
    if (Math.abs(dir[1]) > 1e-4) {
      const tg = -cam[1] / dir[1];
      if (tg > 0.1 && tg < 120) {
        return { nokta: [cam[0] + dir[0] * tg, 0, cam[2] + dir[2] * tg] };
      }
    }
    return {};
  },

  objUret(): string {
    if (!this.lastMesh) this.sahneKur();
    const m = this.lastMesh;
    if (!m) return '';
    const satir: string[] = ['# NexDrive Mimar 3D Mesh (.obj)', 'o NexDriveModel'];
    const dump = (arr: number[], basIdx: number) => {
      let idx = basIdx;
      const cnt = Math.floor(arr.length / 11 / 3);
      for (let t = 0; t < cnt; t++) {
        const i = t * 33;
        satir.push(
          `v ${arr[i].toFixed(4)} ${arr[i + 1].toFixed(4)} ${arr[i + 2].toFixed(4)}`,
          `v ${arr[i + 11].toFixed(4)} ${arr[i + 12].toFixed(4)} ${arr[i + 13].toFixed(4)}`,
          `v ${arr[i + 22].toFixed(4)} ${arr[i + 23].toFixed(4)} ${arr[i + 24].toFixed(4)}`,
          `vn ${arr[i + 3].toFixed(3)} ${arr[i + 4].toFixed(3)} ${arr[i + 5].toFixed(3)}`,
          `f ${idx}//${t + 1} ${idx + 1}//${t + 1} ${idx + 2}//${t + 1}`,
        );
        idx += 3;
      }
      return idx;
    };
    const nextIdx = dump(m.o, 1);
    dump(m.s, nextIdx);
    return satir.join('\n');
  },
};

export function bagla3DOlay(
  c3: HTMLCanvasElement,
  onSelect: (res: { hit?: D3HitBox; olcMesafe?: number }) => void,
) {
  let d3s: { b: number; x: number; y: number; downX: number; downY: number } | null = null;
  c3.addEventListener('pointerdown', e => {
    c3.setPointerCapture(e.pointerId);
    d3s = { b: e.button, x: e.clientX, y: e.clientY, downX: e.clientX, downY: e.clientY };
  });
  c3.addEventListener('pointermove', e => {
    if (!d3s) return;
    const dx = e.clientX - d3s.x;
    const dy = e.clientY - d3s.y;
    d3s.x = e.clientX;
    d3s.y = e.clientY;
    if (D3.mod === 'gez') {
      D3.gez.yaw += dx * 0.005;
      D3.gez.pitch = sinir(D3.gez.pitch - dy * 0.005, -1.2, 1.2);
    } else if (d3s.b === 2 || e.shiftKey) {
      const k = D3.kam;
      const sc = k.dist * 0.0015;
      const rx = Math.cos(k.yaw), rz = -Math.sin(k.yaw);
      k.t[0] -= dx * sc * rx;
      k.t[2] -= dx * sc * rz;
      k.t[1] += dy * sc;
    } else {
      D3.kam.yaw -= dx * 0.007;
      D3.kam.pitch = sinir(D3.kam.pitch + dy * 0.007, 0.05, 1.5);
    }
    D3.ciz();
  });
  c3.addEventListener('pointerup', e => {
    if (d3s && Math.hypot(e.clientX - d3s.downX, e.clientY - d3s.downY) < 4 && d3s.b === 0) {
      const r = c3.getBoundingClientRect();
      const res = D3.rayIsabet(e.clientX, e.clientY, r);
      if (S.d3OlcMod && res.nokta) {
        S.d3OlcNoktalar.push(res.nokta);
        if (S.d3OlcNoktalar.length >= 2) {
          const [a, b] = S.d3OlcNoktalar.slice(-2);
          const mes = Math.hypot(b[0] - a[0], b[1] - a[1], b[2] - a[2]);
          S.d3OlcNoktalar = [];
          onSelect({ olcMesafe: mes });
        } else {
          onSelect({ hit: { tur: 'olc', id: '1', ad: '1. Nokta seçildi', detay: 'Hedef 2. noktaya tıkla', min: res.nokta, max: res.nokta } });
        }
      } else {
        onSelect({ hit: res.hit });
      }
    }
    d3s = null;
  });
  c3.addEventListener('contextmenu', e => e.preventDefault());
  c3.addEventListener(
    'wheel',
    e => {
      e.preventDefault();
      if (D3.orto) D3.ortoBoy = sinir(D3.ortoBoy * (e.deltaY > 0 ? 1.12 : 0.89), 4, 120);
      else D3.kam.dist = sinir(D3.kam.dist * (e.deltaY > 0 ? 1.1 : 0.9), 3, 120);
      D3.ciz();
    },
    { passive: false },
  );

  // Yürüyüş modu döngüsü
  let gezZaman = 0;
  function gezDongu(ts: number) {
    requestAnimationFrame(gezDongu);
    if (S.gorunum !== '3d' || D3.mod !== 'gez' || !D3.tuslar.size) {
      gezZaman = ts;
      return;
    }
    const dt = Math.min(0.05, (ts - gezZaman) / 1000 || 0.016);
    gezZaman = ts;
    const h = 3.6 * dt;
    const g = D3.gez;
    const fx = Math.sin(g.yaw), fz = -Math.cos(g.yaw);
    const rx = Math.cos(g.yaw), rz = Math.sin(g.yaw);
    if (D3.tuslar.has('w') || D3.tuslar.has('arrowup')) { g.p[0] += fx * h; g.p[2] += fz * h; }
    if (D3.tuslar.has('s') || D3.tuslar.has('arrowdown')) { g.p[0] -= fx * h; g.p[2] -= fz * h; }
    if (D3.tuslar.has('d') || D3.tuslar.has('arrowright')) { g.p[0] += rx * h; g.p[2] += rz * h; }
    if (D3.tuslar.has('a') || D3.tuslar.has('arrowleft')) { g.p[0] -= rx * h; g.p[2] -= rz * h; }
    if (D3.tuslar.has('q')) g.p[1] = sinir(g.p[1] - h * 0.7, 0.5, 18);
    if (D3.tuslar.has('e')) g.p[1] = sinir(g.p[1] + h * 0.7, 0.5, 18);
    D3.ciz();
  }
  requestAnimationFrame(gezDongu);
}

export function katKutuMerkez(katIdxVal: number): number {
  const bKot = ARAZI.var() ? ARAZI.binaKot() - (P().cephe.subasman || 0) : 0;
  return bKot + katTaban(katIdxVal);
}
