export type GorunumTipi = 'plan' | '3d' | 'metraj' | 'pafta';
export type DuvarTuru = 'dis' | 'ic';
export type AciklikTuru = 'kapi' | 'pencere' | 'balkon' | 'surme' | 'cift_kapi' | 'cati_pencere';
export type ParaBirimi = 'TRY' | 'USD' | 'EUR';
export type KagitBoyutu = 'A4' | 'A3' | 'A2' | 'A1';

export type BoruTuru =
  | 'temiz_su_soguk'
  | 'temiz_su_sicak'
  | 'pis_su'
  | 'kalorifer'
  | 'elektrik_kablo'
  | 'dogalgaz';

export interface Kat {
  id: string;
  ad: string;
  h: number;
  d: number;
  sira?: number; // negatif: bodrum kat (-1, -2), 0+: zemin ve üst katlar
}

export interface Duvar {
  id: string;
  kat: string;
  x1: number;
  y1: number;
  x2: number;
  y2: number;
  k: number;
  tur: DuvarTuru;
  egri?: number; // kavis yüksekliği (m, orta noktadan dik çıkıntı; 0 veya undefined = düz)
}

export interface Aciklik {
  id: string;
  duvar: string;
  t: number; // 0..1 duvar boyunca oran
  g: number; // genişlik (m)
  h: number; // yükseklik (m)
  p: number; // parapet (m)
  tur: AciklikTuru;
  yon: number; // 1 veya -1
  mentese: 'sol' | 'sag';
  renk?: string; // doğrama rengi hex
  panjur?: boolean;
}

export interface Oda {
  id: string;
  kat: string;
  ad: string;
  zemin: string;
  pts: [number, number][];
  duvarKaplama?: string;
  tavanKaplama?: string;
}

export interface Mobilya {
  id: string;
  kat: string;
  tip: string;
  x: number;
  y: number;
  r: number;
  w?: number;
  d?: number;
  basamak?: number; // merdiven özel basamak sayısı
}

export interface Kiris {
  id: string;
  kat: string;
  x1: number;
  y1: number;
  x2: number;
  y2: number;
  w: number; // kiriş genişliği (m)
  h: number; // kiriş yüksekliği (m)
}

export interface TesisatNokta {
  id: string;
  kat: string;
  tip: string;
  x: number;
  y: number;
  r: number;
  kot?: number; // montaj kotu (m)
}

export interface BoruHatti {
  id: string;
  kat: string;
  tur: BoruTuru;
  pts: [number, number][];
  cap: number; // mm (16, 20, 25, 32, 50, 75, 110)
  egim?: number; // % (pis su için örn. 1.5)
  kot?: number; // döşeme kotuna göre yükseklik (m; -0.05 döşeme altı, 0.2 duvar içi, 2.5 tavan)
  oto?: boolean; // otomatik üretilmiş mi
}

export interface DisOge {
  id: string;
  tip: string;
  x?: number;
  y?: number;
  x1?: number;
  y1?: number;
  x2?: number;
  y2?: number;
  w?: number;
  d?: number;
  r?: number;
  cap?: number;
  h?: number;
  kot?: number;
}

export interface Olcu {
  id: string;
  kat: string;
  x1: number;
  y1: number;
  x2: number;
  y2: number;
}

export interface Yazi {
  id: string;
  kat: string;
  x: number;
  y: number;
  metin: string;
  boy?: number;
}

export interface Aks {
  id: string;
  yon: 'd' | 'y';
  k: number;
}

export interface Kesit {
  id: string;
  ad: string;
  x1: number;
  y1: number;
  x2: number;
  y2: number;
  yon: number;
}

export interface Altlik {
  src: string;
  x: number;
  y: number;
  olcek: number;
  opak: number;
  aci?: number; // derece
}

export interface OzelKalem {
  id: string;
  grup: string;
  ad: string;
  miktar: number;
  birim: string;
  fiyat: number;
  iscilik?: number;
  not?: string;
}

export interface FiyatKalem {
  ad: string;
  b: string;
  f: number; // malzeme / birim fiyat
  isc?: number; // işçilik birim fiyatı
}

export interface ProjeAyar {
  temelDerinlik: number;
  maxTaks: number;
  maxKaks: number;
  kabarma: number;
  kamyon: number;
  binaKot: number | null;
  kuzey: number;
  enlem: number;
  boylam: number;
  tarih: string;
  saat: number;
  golge: boolean;
  cekmeOn: number;
  cekmeYan: number;
  cekmeArka: number;
  onCepheKenar?: number; // arsa poligon kenar indeksi (0..n-1)
  kdvOran: number; // %
  muteahhitOran: number; // %
  paraBirimi: ParaBirimi;
  kurUsd: number;
  kurEur: number;
  gizliKalemler: string[];
  ozelKalemler: OzelKalem[];
}

export interface Proje {
  id: string;
  ad: string;
  surum: number;
  olusturma: number;
  guncelleme: number;
  cizen: string;
  firma: string;
  adres: string;
  ada?: string;
  parsel?: string;
  paftaNo?: string;
  revizyon?: string;
  katlar: Kat[];
  duvarlar: Duvar[];
  aciklar: Aciklik[];
  odalar: Oda[];
  mobilya: Mobilya[];
  kirisler: Kiris[];
  olculer: Olcu[];
  yazilar: Yazi[];
  dis: DisOge[];
  akslar: Aks[];
  kesitler: Kesit[];
  tesisat: TesisatNokta[];
  borular: BoruHatti[];
  arsa: { pts: [number, number][] } | null;
  altlik: Altlik | null;
  cati: {
    tip: string;
    egim: number;
    sacak: number;
    renk: string;
    baca?: boolean;
    oluk?: boolean;
    catiPencere?: boolean;
  };
  cephe: {
    renk: string;
    dogramaRenk: string;
    malzeme: string;
    icMalzeme: string;
    mantolama: boolean;
    subasman: number;
    kaplama: string;
  };
  ayar: ProjeAyar;
  fiyat: Record<string, FiyatKalem>;
  ozet?: Record<string, unknown>;
}

export interface Secim {
  tur:
    | 'duvar'
    | 'acik'
    | 'oda'
    | 'mobilya'
    | 'kiris'
    | 'dis'
    | 'olcu'
    | 'yazi'
    | 'aks'
    | 'kesit'
    | 'tesisat'
    | 'boru'
    | 'arsa'
    | 'uc';
  id: string;
  u?: 1 | 2;
}

export type DisiplinModu = 'tumu' | 'mimari' | 'statik' | 'sihhi' | 'elektrik';

export interface KatmanAyar {
  duvarlar: boolean;
  mobilya: boolean;
  akslar: boolean;
  sihhiBoru: boolean;
  elektrikHatti: boolean;
  dogalgazHatti: boolean;
  olculer: boolean;
  arazi: boolean;
}

export interface DurumS {
  p: Proje | null;
  katId: string | null;
  arac: string;
  secili: Secim | null;
  cokluSecili: Secim[];
  pano: { tip: string; data: unknown }[];
  gorunum: GorunumTipi;
  disiplin: DisiplinModu;
  katmanlar: KatmanAyar;
  zoningGoster: boolean;
  duvarK: number;
  duvarTur: DuvarTuru;
  duvarEgri: number;
  grid: number;
  orto: boolean;
  olcuGoster: boolean;
  mobTip: string;
  mobRot: number;
  disTip: string;
  kapiTip: AciklikTuru;
  pencere: { g: number; h: number; p: number };
  kapi: { g: number; h: number };
  aksYon: 'd' | 'y';
  tesTip: string;
  tesisatGoster: boolean;
  boruGoster: boolean;
  boruTur: BoruTuru;
  boruCap: number;
  boruKot: number;
  kolonBoyut: number;
  d3Kirli: boolean;
  d3Tesisat: boolean;
  d3Aks: boolean;
  d3Xray: boolean;
  d3OlcMod: boolean;
  d3OlcNoktalar: [number, number, number][];
}
