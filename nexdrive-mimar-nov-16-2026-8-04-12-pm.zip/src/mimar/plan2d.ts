import { BORU_TIPLERI, DIS, MOB, TES, ZEMIN, mobOlcu, odaZemini } from './catalog';
import {
  ARAZI,
  GECMIS,
  P,
  S,
  aksAdlari,
  cekmePoligonHesap,
  degistir,
  duvar,
  duvarBoy,
  duvarParcalari,
  duvarEkle,
  katDuvar,
  katIdx,
  katOturum,
  kaydetGecikmeli,
  kirisListesi,
  merdivenler,
  odaBul,
  odaTuru,
  odalariGuncelle,
  tumAciklariDogrula,
  uctaBagli,
} from './core';
import { G, Pt } from './geometry';
import { boruCiz, boruUzunluk, duvaraYasla, tesisatCiz, tesisatSembol } from './mep';
import type { Aciklik, BoruHatti, Duvar, Kesit, Kiris, Mobilya, Oda, Secim, TesisatNokta } from './types';
import { RAD, bildir, fmt, kopya, r3, sinir, uid, yuv } from './utils';

export const RENK = {
  ekran: {
    dis: '#1c2d44',
    ic: '#5a6680',
    yazi: '#1c2d44',
    olcu: '#2a6f9e',
    mob: '#4a5568',
    mobDolgu: '#ffffff',
    sec: '#16b3b9',
    kapi: '#1c2d44',
  },
  baski: {
    dis: '#111111',
    ic: '#555555',
    yazi: '#111111',
    olcu: '#111111',
    mob: '#333333',
    mobDolgu: '#ffffff',
    sec: '#111',
    kapi: '#111',
  },
};

export interface AracTanim {
  g: string;
  id: string;
  ad: string;
  k: string;
  i: string;
}

export const ARACLAR: AracTanim[] = [
  { g: 'Genel', id: 'sec', ad: 'Seç', k: 'V', i: '<path d="M5 3l14 8-6 2-3 6z"/>' },
  { g: 'Genel', id: 'kaydir', ad: 'Kaydır', k: 'H', i: '<path d="M12 3v18M3 12h18M12 3l-3 3M12 3l3 3M12 21l-3-3M12 21l3-3M3 12l3-3M3 12l3 3M21 12l-3-3M21 12l-3 3"/>' },
  { g: 'Yapı', id: 'duvar', ad: 'Duvar', k: 'W', i: '<path d="M3 17h18M3 7h18M3 7v10M21 7v10M9 7v5M15 12v5M3 12h18"/>' },
  { g: 'Yapı', id: 'odarect', ad: 'Hızlı oda', k: 'Q', i: '<rect x="4" y="5" width="16" height="14"/><path d="M4 5l4 4M20 5l-4 4"/>' },
  { g: 'Yapı', id: 'odabul', ad: 'Oda bul', k: 'O', i: '<rect x="3" y="4" width="18" height="16"/><path d="M8 12l3 3 5-6"/>' },
  { g: 'Yapı', id: 'kapi', ad: 'Kapı', k: 'D', i: '<path d="M4 20h16M7 20V5h8M7 5a12 12 0 0 1 10 12"/>' },
  { g: 'Yapı', id: 'pencere', ad: 'Pencere', k: 'P', i: '<rect x="3" y="9" width="18" height="6"/><path d="M3 12h18"/>' },
  { g: 'Yapı', id: 'aks', ad: 'Aks / kolon', k: 'X', i: '<path d="M7 2v20M2 8h20" stroke-dasharray="4 2 1 2"/><rect x="5" y="6" width="4" height="4" fill="currentColor"/>' },
  { g: 'Yapı', id: 'kiris', ad: 'Kiriş', k: 'J', i: '<path d="M3 8h18M3 16h18" stroke-dasharray="3 2"/><circle cx="5" cy="12" r="2" fill="currentColor"/><circle cx="19" cy="12" r="2" fill="currentColor"/>' },
  { g: 'Düzen', id: 'ofset', ad: 'Ofset', k: 'F', i: '<path d="M4 16L16 4M8 20L20 8" /><path d="M10 10l4 4" stroke-dasharray="2 2"/>' },
  { g: 'Düzen', id: 'buda', ad: 'Buda', k: 'C', i: '<path d="M4 18L18 4"/><path d="M5 6l13 13" stroke-dasharray="3 2"/><circle cx="11" cy="11" r="2"/>' },
  { g: 'Düzen', id: 'uzat', ad: 'Uzat', k: 'U', i: '<path d="M4 18l9-9"/><path d="M13 9l5-5" stroke-dasharray="2 2"/><path d="M19 3v12"/>' },
  { g: 'Düzen', id: 'pah', ad: 'Birleştir', k: 'G', i: '<path d="M4 18V7h11"/><circle cx="4" cy="7" r="2" fill="currentColor"/>' },
  { g: 'İç & MEP', id: 'mobilya', ad: 'Mobilya', k: 'M', i: '<path d="M4 18v-6h16v6M6 12V8h12v4M4 18v2M20 18v2"/>' },
  { g: 'İç & MEP', id: 'tesisat', ad: 'Tesisat', k: 'E', i: '<path d="M13 2L5 13h6l-1 9 8-11h-6z"/>' },
  { g: 'İç & MEP', id: 'boru', ad: 'Boru döşe', k: 'B', i: '<path d="M4 7h10v10h6"/><circle cx="4" cy="7" r="2" fill="currentColor"/><circle cx="20" cy="17" r="2" fill="currentColor"/>' },
  { g: 'Dış', id: 'arsa', ad: 'Arsa', k: 'A', i: '<path d="M3 18l3-12 9-2 6 8-4 8z" stroke-dasharray="3 2"/>' },
  { g: 'Dış', id: 'dis', ad: 'Peyzaj', k: 'L', i: '<circle cx="12" cy="9" r="6"/><path d="M12 15v6M8 21h8"/>' },
  { g: 'Dış', id: 'kot', ad: 'Arazi kotu', k: 'K', i: '<path d="M2 20l6-8 4 4 4-7 6 11z"/><path d="M14 4l3 3M17 4l-3 3"/>' },
  { g: 'Not', id: 'kesit', ad: 'Kesit', k: 'S', i: '<path d="M4 12h16" stroke-dasharray="5 2 1 2"/><path d="M4 12v-6M20 12v-6M4 6l-2 3M4 6l2 3M20 6l-2 3M20 6l2 3"/>' },
  { g: 'Not', id: 'olcu', ad: 'Ölçü', k: 'Ö', i: '<path d="M3 15h18M3 11v8M21 11v8"/><text x="12" y="10" font-size="7" text-anchor="middle" stroke="none" fill="currentColor">2,4</text>' },
  { g: 'Not', id: 'alanolc', ad: 'Alan ölç', k: 'N', i: '<polygon points="4,17 6,6 18,5 20,18" stroke-dasharray="3 2"/><text x="12" y="14" font-size="6.5" text-anchor="middle" stroke="none" fill="currentColor">m²</text>' },
  { g: 'Not', id: 'yazi', ad: 'Yazı', k: 'T', i: '<path d="M5 6V4h14v2M12 4v16M9 20h6"/>' },
  { g: 'Not', id: 'kalibre', ad: 'Altlık ölçek', k: '', i: '<rect x="3" y="4" width="18" height="16" rx="1"/><path d="M6 16l4-5 3 3 2-2 3 4M6 8h3"/>' },
];

export const IPUCU: Record<string, string> = {
  sec: 'Tıkla: seç · Shift+tıkla/sürükle: çoklu seç · sürükle: taşı · sağ tık: menü · R: döndür · Del: sil',
  kaydir: 'Sürükle: planı kaydır · tekerlek: yakınlaştır',
  duvar: 'Tıkla-tıkla duvar çiz · uzunluk yazıp Enter · kavis ayarı üstten · başlangıca tıkla: kapat · Esc/çift tık: bitir',
  odarect: 'Sürükle: oda çiz YA DA başlangıç tıklayıp 4x5 yaz+Enter ile tam ölçüde oda kur',
  odabul: 'Duvarlarla kapalı alanın içine tıkla: oda oluşur',
  kapi: 'Bir duvarın üzerine tıkla (üstten tek/çift/sürme/balkon seç) · imlecin olduğu tarafa açılır',
  pencere: 'Bir duvarın üzerine tıkla (standart veya çatı penceresi)',
  aks: 'Tıkla: aks çiz (Shift ile yön çevir) · kesişimlere kolon için “Kolonları yerleştir”',
  kiris: 'İki nokta arası manuel taşıyıcı kiriş çiz (uzunluk yazıp Enter destekli)',
  ofset: 'Bir duvara, boruya veya odaya tıkla: seçtiğin taraftan paralel kopya oluşturur',
  buda: 'Kesişen duvarın kesmek istediğin parçasına tıkla (Trim)',
  uzat: 'Uzatmak istediğin duvarın ucuna yakın tıkla — en yakın hedef duvara uzar (Extend)',
  pah: 'Köşesini birleştirmek istediğin iki duvara sırayla tıkla (Fillet / Köşe birleştir)',
  mobilya: 'Sağdan mobilya seç, plana tıkla · R: 90° döndür',
  tesisat: 'Sağdan sembol seç, plana tıkla · otomatik yerleştir veya boru döşemeyi başlat',
  boru: 'Üstten hat türü/çap seç · tıkla-tıkla boru/kablo döşe (Shift: serbest açı) · çift tık / Enter: bitir',
  arsa: 'Arsa köşelerine sırayla tıkla (uzunluk yazıp Enter) · ilk noktaya tıkla veya çift tık: kapat',
  dis: 'Sağdan peyzaj öğesi seç · alanlar için sürükle, ağaç/araba için tıkla, çit için tıkla-tıkla',
  kot: 'Arazide kotunu bildiğin noktaya tıkla, kotu gir',
  kesit: 'İki noktaya tıkla: kesit çizgisi (A-A, B-B …)',
  olcu: 'İki noktaya tıkla: ölçü çizgisi (uzunluk yazıp Enter)',
  alanolc: 'Çokgen alan ölçümü: köşelere tıkla · çift tık / Enter / ilk noktaya tıkla: m² ve çevre hesapla',
  yazi: 'Plana tıkla, yazıyı gir',
  kalibre: 'Altlık resminde uzunluğunu bildiğin iki noktaya tıkla',
};

export function aksSinir() {
  const pts: Pt[] = [];
  P().duvarlar.forEach(w => pts.push([w.x1, w.y1], [w.x2, w.y2]));
  (P().akslar || []).forEach(a => (a.yon === 'd' ? pts.push([a.k, 0]) : pts.push([0, a.k])));
  if (!pts.length) return { x1: -5, y1: -5, x2: 15, y2: 12 };
  const b = G.bbox(pts);
  return { x1: b.x1 - 1.6, y1: b.y1 - 1.6, x2: b.x2 + 1.6, y2: b.y2 + 1.6 };
}

export function siradakiKesitAdi(): string {
  const var_ = new Set((P().kesitler || []).map(k => k.ad));
  return 'ABCDEFGH'.split('').find(c => !var_.has(c)) || 'K';
}

const imgOnbellek: { src?: string; img?: HTMLImageElement } = {};
function altlikResmi(): HTMLImageElement | null {
  const a = P().altlik;
  if (!a || !a.src) return null;
  if (imgOnbellek.src !== a.src) {
    imgOnbellek.src = a.src;
    imgOnbellek.img = new Image();
    imgOnbellek.img.onload = () => PLAN.ciz();
    imgOnbellek.img.src = a.src;
  }
  return imgOnbellek.img?.complete ? imgOnbellek.img : null;
}

const _egriCache = { anahtar: '', cizgiler: [] as { h: number; seg: [Pt, Pt][]; ana: boolean }[] };
function esYukseltiler() {
  const N = ARAZI.noktalar();
  if (!N.length) return [];
  const p = P();
  const pts: Pt[] = N.map(n => [n.x ?? 0, n.y ?? 0]);
  if (p.arsa) pts.push(...p.arsa.pts);
  p.duvarlar.forEach(w => pts.push([w.x1, w.y1]));
  const b = G.bbox(pts);
  const anahtar = JSON.stringify([N.map(n => [n.x, n.y, n.kot]), b]);
  if (anahtar === _egriCache.anahtar) return _egriCache.cizgiler;
  const x0 = b.x1 - 4;
  const y0 = b.y1 - 4;
  const W = b.w + 8;
  const H = b.h + 8;
  const n = 70;
  const sx = W / n;
  const sy = H / n;
  const Z: number[][] = [];
  let mn = Infinity;
  let mx = -Infinity;
  for (let i = 0; i <= n; i++) {
    Z.push([]);
    for (let j = 0; j <= n; j++) {
      const z = ARAZI.z(x0 + i * sx, y0 + j * sy);
      Z[i].push(z);
      mn = Math.min(mn, z);
      mx = Math.max(mx, z);
    }
  }
  const ar = mx - mn;
  const adim = ar <= 0 ? 1 : [0.1, 0.25, 0.5, 1, 2, 5, 10].find(s => ar / s <= 14) || 20;
  const cizgiler: { h: number; seg: [Pt, Pt][]; ana: boolean }[] = [];
  for (let h = Math.ceil(mn / adim) * adim; h <= mx; h += adim) {
    const seg: [Pt, Pt][] = [];
    for (let i = 0; i < n; i++) {
      for (let j = 0; j < n; j++) {
        const v = [Z[i][j], Z[i + 1][j], Z[i + 1][j + 1], Z[i][j + 1]];
        const c = [
          [i, j],
          [i + 1, j],
          [i + 1, j + 1],
          [i, j + 1],
        ];
        const k: Pt[] = [];
        for (let e = 0; e < 4; e++) {
          const a = v[e];
          const bb = v[(e + 1) % 4];
          if (a < h !== bb < h) {
            const t = (h - a) / (bb - a);
            const p1 = c[e];
            const p2 = c[(e + 1) % 4];
            k.push([x0 + (p1[0] + (p2[0] - p1[0]) * t) * sx, y0 + (p1[1] + (p2[1] - p1[1]) * t) * sy]);
          }
        }
        if (k.length >= 2) seg.push([k[0], k[1]]);
        if (k.length === 4) seg.push([k[2], k[3]]);
      }
    }
    cizgiler.push({ h: Math.round(h * 100) / 100, seg, ana: Math.abs(h / (adim * 5) - Math.round(h / (adim * 5))) < 1e-6 });
  }
  _egriCache.anahtar = anahtar;
  _egriCache.cizgiler = cizgiler;
  return cizgiler;
}

export function araziCiz(ctx: CanvasRenderingContext2D, X: (x: number) => number, Y: (y: number) => number, _z: number, o: { baski?: boolean }, fs: number) {
  const N = ARAZI.noktalar();
  if (!N.length) return;
  ctx.save();
  for (const c of esYukseltiler()) {
    ctx.strokeStyle = o.baski ? (c.ana ? '#555' : '#999') : c.ana ? 'rgba(140,90,40,.75)' : 'rgba(140,90,40,.4)';
    ctx.lineWidth = c.ana ? 1.2 : 0.7;
    ctx.beginPath();
    c.seg.forEach(s => {
      ctx.moveTo(X(s[0][0]), Y(s[0][1]));
      ctx.lineTo(X(s[1][0]), Y(s[1][1]));
    });
    ctx.stroke();
    if (c.seg.length > 6) {
      const s = c.seg[Math.floor(c.seg.length / 2)];
      ctx.font = `600 ${9 * fs}px system-ui`;
      ctx.fillStyle = o.baski ? '#444' : 'rgba(120,70,30,.9)';
      ctx.textAlign = 'center';
      ctx.fillText(fmt(c.h), X(s[0][0]), Y(s[0][1]) - 2);
    }
  }
  N.forEach(n => {
    const x = X(n.x ?? 0);
    const y = Y(n.y ?? 0);
    ctx.strokeStyle = o.baski ? '#111' : '#8a4f1d';
    ctx.lineWidth = 1.4;
    ctx.beginPath();
    ctx.moveTo(x - 5, y - 5);
    ctx.lineTo(x + 5, y + 5);
    ctx.moveTo(x + 5, y - 5);
    ctx.lineTo(x - 5, y + 5);
    ctx.stroke();
    ctx.font = `700 ${10.5 * fs}px system-ui`;
    ctx.fillStyle = o.baski ? '#111' : '#8a4f1d';
    ctx.textAlign = 'left';
    ctx.textBaseline = 'middle';
    const kot = n.kot ?? 0;
    ctx.fillText((kot >= 0 ? '+' : '') + fmt(kot), x + 7, y - 7);
  });
  const iz = ARAZI.ayakIzi();
  if (iz) {
    const c = G.merkez(iz.pts);
    ctx.font = `700 ${10 * fs}px system-ui`;
    ctx.fillStyle = o.baski ? '#111' : '#a0461a';
    ctx.textAlign = 'center';
    ctx.fillText('±0.00 = ' + fmt(ARAZI.binaKot()), X(c[0]), Y(G.bbox(iz.pts).y1) - 14);
  }
  ctx.restore();
}

export function olcuCiz(
  ctx: CanvasRenderingContext2D,
  X: (x: number) => number,
  Y: (y: number) => number,
  x1: number,
  y1: number,
  x2: number,
  y2: number,
  t: string,
  px: number,
  renk: string,
  uzatY?: number | null,
  uzatX?: number | null,
) {
  const L = Math.hypot(x2 - x1, y2 - y1);
  if (!L) return;
  const ux = (x2 - x1) / L;
  const uy = (y2 - y1) / L;
  ctx.strokeStyle = renk;
  ctx.fillStyle = renk;
  ctx.lineWidth = 0.9;
  ctx.beginPath();
  ctx.moveTo(X(x1), Y(y1));
  ctx.lineTo(X(x2), Y(y2));
  for (const [x, y] of [
    [x1, y1],
    [x2, y2],
  ]) {
    ctx.moveTo(X(x) - 5, Y(y) + 5);
    ctx.lineTo(X(x) + 5, Y(y) - 5);
  }
  if (uzatY != null) {
    for (const x of [x1, x2]) {
      ctx.moveTo(X(x), Y(uzatY));
      ctx.lineTo(X(x), Y(y1) + 4);
    }
  }
  if (uzatX != null) {
    for (const y of [y1, y2]) {
      ctx.moveTo(X(uzatX), Y(y));
      ctx.lineTo(X(x1) + 4, Y(y));
    }
  }
  ctx.stroke();
  let ang = Math.atan2(uy, ux);
  if (ang > Math.PI / 2 + 1e-3 || ang < -Math.PI / 2 + 1e-3) ang += Math.PI;
  ctx.save();
  ctx.translate((X(x1) + X(x2)) / 2, (Y(y1) + Y(y2)) / 2);
  ctx.rotate(ang);
  ctx.font = `600 ${px}px system-ui,sans-serif`;
  ctx.textAlign = 'center';
  ctx.textBaseline = 'bottom';
  const tw = ctx.measureText(t).width;
  ctx.fillStyle = 'rgba(255,255,255,.85)';
  ctx.fillRect(-tw / 2 - 2, -px - 2, tw + 4, px + 1);
  ctx.fillStyle = renk;
  ctx.fillText(t, 0, -2);
  ctx.restore();
}

export function akslarCiz(ctx: CanvasRenderingContext2D, X: (x: number) => number, Y: (y: number) => number, z: number, o: { baski?: boolean }, fs: number) {
  const A = P().akslar || [];
  if (!A.length) return;
  const ad = aksAdlari();
  const b = aksSinir();
  const renk = o.baski ? '#222' : '#c0392b';
  const r = Math.max(9, 0.32 * z);
  ctx.save();
  ctx.strokeStyle = renk;
  ctx.lineWidth = 0.9;
  ctx.setLineDash([14, 4, 2, 4]);
  ctx.beginPath();
  A.forEach(a => {
    if (a.yon === 'd') {
      ctx.moveTo(X(a.k), Y(b.y1));
      ctx.lineTo(X(a.k), Y(b.y2));
    } else {
      ctx.moveTo(X(b.x1), Y(a.k));
      ctx.lineTo(X(b.x2), Y(a.k));
    }
  });
  ctx.stroke();
  ctx.setLineDash([]);
  ctx.font = `700 ${Math.round(r * 1.05)}px system-ui,sans-serif`;
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  const balon = (x: number, y: number, t: string) => {
    ctx.beginPath();
    ctx.arc(x, y, r, 0, 7);
    ctx.fillStyle = '#fff';
    ctx.fill();
    ctx.stroke();
    ctx.fillStyle = renk;
    ctx.fillText(t, x, y + 0.5);
  };
  A.forEach(a => {
    if (a.yon === 'd') {
      balon(X(a.k), Y(b.y1) - r, ad[a.id]);
      balon(X(a.k), Y(b.y2) + r, ad[a.id]);
    } else {
      balon(X(b.x1) - r, Y(a.k), ad[a.id]);
      balon(X(b.x2) + r, Y(a.k), ad[a.id]);
    }
  });
  const d = A.filter(a => a.yon === 'd').sort((u, v) => u.k - v.k);
  const y = A.filter(a => a.yon === 'y').sort((u, v) => u.k - v.k);
  for (let i = 0; i + 1 < d.length; i++) {
    olcuCiz(ctx, X, Y, d[i].k, b.y1 + 0.55, d[i + 1].k, b.y1 + 0.55, fmt(d[i + 1].k - d[i].k), 10 * fs, renk);
  }
  for (let i = 0; i + 1 < y.length; i++) {
    olcuCiz(ctx, X, Y, b.x1 + 0.55, y[i].k, b.x1 + 0.55, y[i + 1].k, fmt(y[i + 1].k - y[i].k), 10 * fs, renk);
  }
  ctx.restore();
}

export function kesitDuzlemHesap(k: Kesit) {
  const L = Math.hypot(k.x2 - k.x1, k.y2 - k.y1) || 1;
  const ux = (k.x2 - k.x1) / L;
  const uy = (k.y2 - k.y1) / L;
  const v: [number, number] = [-uy * (k.yon || 1), ux * (k.yon || 1)];
  return { v, u: [ux, uy] as [number, number], kes: [-v[0], 0, -v[1], -(k.x1 * v[0] + k.y1 * v[1])] as [number, number, number, number] };
}

export function kesitlerCiz(ctx: CanvasRenderingContext2D, X: (x: number) => number, Y: (y: number) => number, _z: number, o: { baski?: boolean }, fs: number) {
  for (const k of P().kesitler || []) {
    const D = kesitDuzlemHesap(k);
    const renk = o.baski ? '#111' : '#b03a2e';
    ctx.save();
    ctx.strokeStyle = renk;
    ctx.fillStyle = renk;
    ctx.lineWidth = 2;
    ctx.setLineDash([16, 4, 3, 4]);
    ctx.beginPath();
    ctx.moveTo(X(k.x1), Y(k.y1));
    ctx.lineTo(X(k.x2), Y(k.y2));
    ctx.stroke();
    ctx.setLineDash([]);
    for (const [x, y] of [
      [k.x1, k.y1],
      [k.x2, k.y2],
    ]) {
      const ex = X(x) + D.v[0] * 22;
      const ey = Y(y) + D.v[1] * 22;
      ctx.lineWidth = 2.5;
      ctx.beginPath();
      ctx.moveTo(X(x), Y(y));
      ctx.lineTo(ex, ey);
      ctx.stroke();
      ctx.beginPath();
      ctx.moveTo(ex + D.v[0] * 8, ey + D.v[1] * 8);
      ctx.lineTo(ex - D.v[1] * 6, ey + D.v[0] * 6);
      ctx.lineTo(ex + D.v[1] * 6, ey - D.v[0] * 6);
      ctx.closePath();
      ctx.fill();
      ctx.font = `800 ${14 * fs}px system-ui`;
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(k.ad, X(x) - D.u[0] * 14 * (x === k.x1 ? 1 : -1), Y(y) - D.u[1] * 14 * (x === k.x1 ? 1 : -1));
    }
    ctx.restore();
  }
}

export function bosluklarCiz(ctx: CanvasRenderingContext2D, X: (x: number) => number, Y: (y: number) => number, katId: string, o: { baski?: boolean }) {
  const p = P();
  const i = p.katlar.findIndex(k => k.id === katId);
  if (i < 1) return;
  merdivenler(p.katlar[i - 1].id).forEach(md => {
    const q = md.pts;
    ctx.save();
    ctx.strokeStyle = o.baski ? '#333' : '#5a6680';
    ctx.lineWidth = 1;
    ctx.setLineDash([6, 4]);
    ctx.fillStyle = o.baski ? '#fff' : '#f6f8fb';
    ctx.beginPath();
    q.forEach((v, j) => (j ? ctx.lineTo(X(v[0]), Y(v[1])) : ctx.moveTo(X(v[0]), Y(v[1]))));
    ctx.closePath();
    ctx.fill();
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(X(q[0][0]), Y(q[0][1]));
    ctx.lineTo(X(q[2][0]), Y(q[2][1]));
    ctx.moveTo(X(q[1][0]), Y(q[1][1]));
    ctx.lineTo(X(q[3][0]), Y(q[3][1]));
    ctx.stroke();
    const c = [(q[0][0] + q[2][0]) / 2, (q[0][1] + q[2][1]) / 2];
    ctx.setLineDash([]);
    ctx.font = '600 10px system-ui';
    ctx.fillStyle = o.baski ? '#333' : '#5a6680';
    ctx.textAlign = 'center';
    ctx.fillText('BOŞLUK', X(c[0]), Y(c[1]) - 8);
    ctx.restore();
  });
}

export function mobilyaCiz(
  ctx: CanvasRenderingContext2D,
  m: Pick<Mobilya, 'tip' | 'x' | 'y' | 'r' | 'w' | 'd' | 'basamak'>,
  X: (x: number) => number,
  Y: (y: number) => number,
  _z: number,
  R: typeof RENK.ekran,
  _o: { baski?: boolean },
  hayalet = false,
) {
  const T = MOB[m.tip];
  if (!T) return;
  const { w, d } = mobOlcu(m);
  const pt = (lx: number, ly: number): Pt => {
    const t = G.donder(lx, ly, m.r || 0);
    return [X(m.x + t[0]), Y(m.y + t[1])];
  };
  const linePt = (x0: number, y0: number, x1: number, y1: number) => {
    const a = pt(x0, y0);
    const b = pt(x1, y1);
    ctx.moveTo(a[0], a[1]);
    ctx.lineTo(b[0], b[1]);
  };
  const dikd = (x0: number, y0: number, x1: number, y1: number) => {
    ctx.beginPath();
    [
      [x0, y0],
      [x1, y0],
      [x1, y1],
      [x0, y1],
    ].forEach((q, i) => {
      const s = pt(q[0], q[1]);
      if (i) ctx.lineTo(s[0], s[1]);
      else ctx.moveTo(s[0], s[1]);
    });
    ctx.closePath();
  };
  const elips = (cx: number, cy: number, rx: number, ry: number) => {
    ctx.beginPath();
    for (let i = 0; i <= 24; i++) {
      const a = (i / 24) * Math.PI * 2;
      const s = pt(cx + Math.cos(a) * rx, cy + Math.sin(a) * ry);
      if (i) ctx.lineTo(s[0], s[1]);
      else ctx.moveTo(s[0], s[1]);
    }
    ctx.closePath();
  };

  ctx.save();
  if (hayalet) ctx.globalAlpha = 0.55;
  ctx.lineWidth = 1;
  ctx.strokeStyle = R.mob;
  ctx.fillStyle = R.mobDolgu;

  if (T.ozel === 'kolon') {
    dikd(-w / 2, -d / 2, w / 2, d / 2);
    ctx.fillStyle = R.dis;
    ctx.fill();
    ctx.restore();
    return;
  }
  if (T.ozel === 'merdiven') {
    dikd(-w / 2, -d / 2, w / 2, d / 2);
    ctx.fill();
    ctx.stroke();
    const n = m.basamak || Math.max(2, Math.round(d / 0.28));
    ctx.beginPath();
    for (let i = 1; i < n; i++) linePt(-w / 2, -d / 2 + (d * i) / n, w / 2, -d / 2 + (d * i) / n);
    linePt(0, d / 2 - 0.15, 0, -d / 2 + 0.2);
    linePt(0, -d / 2 + 0.2, -0.12, -d / 2 + 0.38);
    linePt(0, -d / 2 + 0.2, 0.12, -d / 2 + 0.38);
    ctx.stroke();
    ctx.restore();
    return;
  }
  if (T.ozel === 'merdiven_l') {
    const kolW = Math.min(w * 0.48, 1.05);
    dikd(-w / 2, -d / 2, w / 2, d / 2);
    ctx.fill();
    ctx.stroke();
    ctx.beginPath();
    const n1 = Math.max(3, Math.round((d - kolW) / 0.28));
    for (let i = 1; i <= n1; i++) {
      const yy = d / 2 - ((d - kolW) * i) / n1;
      linePt(-w / 2, yy, -w / 2 + kolW, yy);
    }
    const n2 = Math.max(3, Math.round((w - kolW) / 0.28));
    for (let i = 0; i < n2; i++) {
      const xx = -w / 2 + kolW + ((w - kolW) * i) / n2;
      linePt(xx, -d / 2, xx, -d / 2 + kolW);
    }
    // L ok
    linePt(-w / 2 + kolW / 2, d / 2 - 0.15, -w / 2 + kolW / 2, -d / 2 + kolW / 2);
    linePt(-w / 2 + kolW / 2, -d / 2 + kolW / 2, w / 2 - 0.18, -d / 2 + kolW / 2);
    linePt(w / 2 - 0.18, -d / 2 + kolW / 2, w / 2 - 0.32, -d / 2 + kolW / 2 - 0.1);
    linePt(w / 2 - 0.18, -d / 2 + kolW / 2, w / 2 - 0.32, -d / 2 + kolW / 2 + 0.1);
    ctx.stroke();
    ctx.restore();
    return;
  }
  if (T.ozel === 'merdiven_u') {
    const sahanD = Math.min(d * 0.36, 1.0);
    dikd(-w / 2, -d / 2, w / 2, d / 2);
    ctx.fill();
    ctx.stroke();
    ctx.beginPath();
    linePt(0, -d / 2 + sahanD, 0, d / 2);
    linePt(-w / 2, -d / 2 + sahanD, w / 2, -d / 2 + sahanD);
    const n = Math.max(3, Math.round((d - sahanD) / 0.28));
    for (let i = 1; i < n; i++) {
      const yy = d / 2 - ((d - sahanD) * i) / n;
      linePt(-w / 2, yy, 0, yy);
      linePt(0, yy, w / 2, yy);
    }
    // Çıkış oku (sol kol yukarı, sahanlık dön, sağ kol aşağı)
    linePt(-w / 4, d / 2 - 0.15, -w / 4, -d / 2 + sahanD / 2);
    linePt(-w / 4, -d / 2 + sahanD / 2, w / 4, -d / 2 + sahanD / 2);
    linePt(w / 4, -d / 2 + sahanD / 2, w / 4, d / 2 - 0.18);
    linePt(w / 4, d / 2 - 0.18, w / 4 - 0.1, d / 2 - 0.32);
    linePt(w / 4, d / 2 - 0.18, w / 4 + 0.1, d / 2 - 0.32);
    ctx.stroke();
    ctx.restore();
    return;
  }
  if (T.ozel === 'merdiven_doner') {
    const rx = w / 2;
    const ry = d / 2;
    elips(0, 0, rx, ry);
    ctx.fill();
    ctx.stroke();
    elips(0, 0, rx * 0.16, ry * 0.16);
    ctx.stroke();
    const n = m.basamak || 12;
    ctx.beginPath();
    for (let i = 0; i < n; i++) {
      const ang = (i / n) * Math.PI * 2;
      linePt(Math.cos(ang) * rx * 0.16, Math.sin(ang) * ry * 0.16, Math.cos(ang) * rx, Math.sin(ang) * ry);
    }
    ctx.stroke();
    ctx.restore();
    return;
  }

  const sx = w / T.w;
  const sy = d / T.d;
  const parca = (T.p ? T.p(T) : []).slice().sort((a, b) => a[5] - b[5]);
  parca.forEach(q => {
    dikd(q[0] * sx, q[1] * sy, q[2] * sx, q[3] * sy);
    if (q[6] === 'cam') {
      ctx.strokeStyle = '#6fb6d8';
      ctx.stroke();
      ctx.strokeStyle = R.mob;
    } else {
      ctx.fill();
      ctx.stroke();
    }
  });
  if (m.tip === 'wc') {
    elips(0, 0.1 * sy, 0.15 * sx, 0.19 * sy);
    ctx.stroke();
  }
  if (m.tip === 'lavabo') {
    elips(0, 0.02 * sy, 0.2 * sx, 0.13 * sy);
    ctx.stroke();
  }
  if (m.tip === 'evye') {
    dikd(-0.3 * sx, -0.2 * sy, 0.3 * sx, 0.2 * sy);
    ctx.stroke();
  }
  if (m.tip === 'kuvet') {
    elips(0, 0, 0.72 * sx, 0.28 * sy);
    ctx.stroke();
  }
  if (m.tip === 'ocak') {
    for (const [cx, cy] of [
      [-0.14, -0.14],
      [0.14, -0.14],
      [-0.14, 0.14],
      [0.14, 0.14],
    ]) {
      elips(cx * sx, cy * sy, 0.09, 0.09);
      ctx.stroke();
    }
  }
  if (m.tip === 'dus') {
    ctx.beginPath();
    linePt(-w / 2, -d / 2, w / 2, d / 2);
    linePt(w / 2, -d / 2, -w / 2, d / 2);
    ctx.stroke();
  }
  ctx.restore();
}

export interface PlanCizOpt {
  katId: string;
  baski?: boolean;
  grid?: boolean;
  w: number;
  h: number;
  altlik?: boolean;
  dis?: boolean;
  hayalet?: boolean;
  olcu?: boolean;
  disOlcu?: boolean;
  kuzey?: boolean;
  tesisat?: boolean;
  boru?: boolean;
  mobilya?: boolean;
  aks?: boolean;
  kesit?: boolean;
  fs?: number;
}

export function otomatikOlcule(katId: string): number {
  const p = P();
  const W = p.duvarlar.filter(w => w.kat === katId);
  if (!W.length) return 0;
  const b = G.bbox(W.flatMap(w => [[w.x1, w.y1], [w.x2, w.y2]] as Pt[]));
  const yeni: { x1: number; y1: number; x2: number; y2: number }[] = [];

  // Dış sınır ölçüsü (4 cephe boyunca 2. hat toplam ölçü)
  yeni.push({ x1: b.x1, y1: b.y1 - 1.15, x2: b.x2, y2: b.y1 - 1.15 });
  yeni.push({ x1: b.x1, y1: b.y2 + 1.15, x2: b.x2, y2: b.y2 + 1.15 });
  yeni.push({ x1: b.x1 - 1.15, y1: b.y1, x2: b.x1 - 1.15, y2: b.y2 });
  yeni.push({ x1: b.x2 + 1.15, y1: b.y1, x2: b.x2 + 1.15, y2: b.y2 });

  // Dış duvar segmentleri boyunca 1. hat duvar ve açıklık aksları (üst/alt yatay + sol/sağ dikey)
  const ekleSegmentHat = (yatay: boolean, kMin: boolean) => {
    const hedefCoord = yatay ? (kMin ? b.y1 : b.y2) : kMin ? b.x1 : b.x2;
    const hatOffset = kMin ? -0.65 : 0.65;
    const cuts = new Set<number>([yatay ? b.x1 : b.y1, yatay ? b.x2 : b.y2]);
    W.filter(w => {
      const m = yatay ? (w.y1 + w.y2) / 2 : (w.x1 + w.x2) / 2;
      const paralel = yatay ? Math.abs(w.y2 - w.y1) < 0.08 : Math.abs(w.x2 - w.x1) < 0.08;
      return paralel && Math.abs(m - hedefCoord) < 0.35;
    }).forEach(w => {
      const L = Math.hypot(w.x2 - w.x1, w.y2 - w.y1) || 1;
      cuts.add(r3(yatay ? w.x1 : w.y1));
      cuts.add(r3(yatay ? w.x2 : w.y2));
      p.aciklar
        .filter(a => a.duvar === w.id)
        .forEach(a => {
          const cx = w.x1 + (w.x2 - w.x1) * a.t;
          const cy = w.y1 + (w.y2 - w.y1) * a.t;
          const v = yatay ? cx : cy;
          const ux = Math.abs(yatay ? (w.x2 - w.x1) / L : (w.y2 - w.y1) / L);
          cuts.add(r3(v - (a.g / 2) * ux));
          cuts.add(r3(v + (a.g / 2) * ux));
        });
    });
    const sorted = [...cuts].sort((u, v) => u - v);
    for (let i = 0; i + 1 < sorted.length; i++) {
      if (sorted[i + 1] - sorted[i] < 0.25) continue;
      if (yatay) yeni.push({ x1: sorted[i], y1: r3(hedefCoord + hatOffset), x2: sorted[i + 1], y2: r3(hedefCoord + hatOffset) });
      else yeni.push({ x1: r3(hedefCoord + hatOffset), y1: sorted[i], x2: r3(hedefCoord + hatOffset), y2: sorted[i + 1] });
    }
  };
  ekleSegmentHat(true, true);
  ekleSegmentHat(true, false);
  ekleSegmentHat(false, true);
  ekleSegmentHat(false, false);

  let eklenen = 0;
  yeni.forEach(n => {
    const varMi = p.olculer.some(
      q => q.kat === katId && Math.hypot(q.x1 - n.x1, q.y1 - n.y1) < 0.08 && Math.hypot(q.x2 - n.x2, q.y2 - n.y2) < 0.08,
    );
    if (!varMi) {
      p.olculer.push({ id: uid(), kat: katId, x1: r3(n.x1), y1: r3(n.y1), x2: r3(n.x2), y2: r3(n.y2) });
      eklenen++;
    }
  });
  return eklenen;
}

const ZONE_RENK: Record<string, { bg: string; etiket: string }> = {
  salon: { bg: 'rgba(56, 189, 248, 0.26)', etiket: 'Yaşam' },
  yatak: { bg: 'rgba(168, 85, 247, 0.22)', etiket: 'Yatak' },
  mutfak: { bg: 'rgba(249, 115, 22, 0.25)', etiket: 'Mutfak' },
  banyo: { bg: 'rgba(20, 184, 166, 0.28)', etiket: 'Islak' },
  wc: { bg: 'rgba(20, 184, 166, 0.28)', etiket: 'Islak' },
  koridor: { bg: 'rgba(234, 179, 8, 0.22)', etiket: 'Sirkülasyon' },
  dis: { bg: 'rgba(74, 222, 128, 0.24)', etiket: 'Dış Mekan' },
  diger: { bg: 'rgba(148, 163, 184, 0.22)', etiket: 'Hizmet' },
};

export function planCiz(ctx: CanvasRenderingContext2D, v: { z: number; tx: number; ty: number }, o: PlanCizOpt) {
  const p = P();
  const R = o.baski ? RENK.baski : RENK.ekran;
  const z = v.z;
  const X = (x: number) => x * z + v.tx;
  const Y = (y: number) => y * z + v.ty;
  const katId = o.katId;
  const ki = p.katlar.findIndex(k => k.id === katId);
  const zemin = ki === 0;
  const disMod = o.baski ? 'tumu' : S.disiplin;
  const km = o.baski
    ? { duvarlar: true, mobilya: true, akslar: true, sihhiBoru: true, elektrikHatti: true, dogalgazHatti: true, olculer: true, arazi: true }
    : S.katmanlar;
  const yapiSoluk = !o.baski && (disMod === 'sihhi' || disMod === 'elektrik') ? 0.34 : 1;

  const yol = (pts: Pt[]) => {
    if (!pts.length) return;
    ctx.beginPath();
    pts.forEach((q, i) => (i ? ctx.lineTo(X(q[0]), Y(q[1])) : ctx.moveTo(X(q[0]), Y(q[1]))));
    ctx.closePath();
  };
  const dRect = (cx: number, cy: number, w: number, d: number, r = 0) => {
    const k = [
      [-w / 2, -d / 2],
      [w / 2, -d / 2],
      [w / 2, d / 2],
      [-w / 2, d / 2],
    ].map(q => {
      const t = G.donder(q[0], q[1], r);
      return [cx + t[0], cy + t[1]] as Pt;
    });
    yol(k);
    return k;
  };
  const metin = (t: string, x: number, y: number, px: number, renk: string, kalin = false, aci = 0) => {
    ctx.save();
    ctx.translate(x, y);
    if (aci) ctx.rotate(aci);
    ctx.font = `${kalin ? 700 : 500} ${px}px system-ui,sans-serif`;
    ctx.fillStyle = renk;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(t, 0, 0);
    ctx.restore();
  };
  const fs = o.baski ? o.fs || 1.8 : sinir(z / 40, 0.6, 1.6);

  // Izgara
  if (o.grid) {
    const W = o.w;
    const H = o.h;
    const adim = z * 0.1 >= 9 ? [0.1, 1] : z >= 9 ? [1, 5] : [5, 10];
    for (const [s, renk] of [
      [adim[0], 'rgba(28,45,68,.07)'],
      [adim[1], 'rgba(28,45,68,.16)'],
    ] as [number, string][]) {
      ctx.strokeStyle = renk;
      ctx.lineWidth = 1;
      ctx.beginPath();
      const x0 = Math.floor(-v.tx / z / s) * s;
      const y0 = Math.floor(-v.ty / z / s) * s;
      for (let x = x0; X(x) < W; x += s) {
        const sx = Math.round(X(x)) + 0.5;
        ctx.moveTo(sx, 0);
        ctx.lineTo(sx, H);
      }
      for (let y = y0; Y(y) < H; y += s) {
        const sy = Math.round(Y(y)) + 0.5;
        ctx.moveTo(0, sy);
        ctx.lineTo(W, sy);
      }
      ctx.stroke();
    }
    ctx.strokeStyle = 'rgba(22,179,185,.45)';
    ctx.beginPath();
    ctx.moveTo(X(0), 0);
    ctx.lineTo(X(0), H);
    ctx.moveTo(0, Y(0));
    ctx.lineTo(W, Y(0));
    ctx.stroke();
  }

  // Altlık (döndürme destekli)
  if (o.altlik && p.altlik) {
    const img = altlikResmi();
    if (img) {
      ctx.save();
      ctx.globalAlpha = p.altlik.opak ?? 0.5;
      ctx.translate(X(p.altlik.x), Y(p.altlik.y));
      if (p.altlik.aci) ctx.rotate(p.altlik.aci * RAD);
      ctx.drawImage(img, 0, 0, img.width * p.altlik.olcek * z, img.height * p.altlik.olcek * z);
      ctx.restore();
    }
  }

  // Arsa + imar çekme sınırı + dış mekân
  if (o.dis) {
    ctx.globalAlpha = zemin ? 1 : 0.35;
    if (p.arsa && p.arsa.pts.length >= 3) {
      yol(p.arsa.pts);
      ctx.fillStyle = o.baski ? '#f3f8ef' : '#e5f1dc';
      ctx.fill();
      ctx.setLineDash([10, 4, 2, 4]);
      ctx.strokeStyle = o.baski ? '#222' : '#4f8a3a';
      ctx.lineWidth = 1.4;
      ctx.stroke();
      ctx.setLineDash([]);

      // İmar çekme sınırı poligonu
      const cekmePts = cekmePoligonHesap();
      if (cekmePts) {
        ctx.save();
        yol(cekmePts);
        ctx.setLineDash([6, 4]);
        ctx.strokeStyle = o.baski ? '#666' : 'rgba(217, 119, 6, 0.8)';
        ctx.lineWidth = 1.2;
        ctx.stroke();
        ctx.setLineDash([]);
        // Ön cephe kenarını işaretle
        const pts = p.arsa.pts;
        const onIdx = sinir(p.ayar.onCepheKenar ?? Math.min(2, pts.length - 1), 0, pts.length - 1);
        const ea = pts[onIdx];
        const eb = pts[(onIdx + 1) % pts.length];
        ctx.strokeStyle = o.baski ? '#111' : '#d97706';
        ctx.lineWidth = 2.4;
        ctx.beginPath();
        ctx.moveTo(X(ea[0]), Y(ea[1]));
        ctx.lineTo(X(eb[0]), Y(eb[1]));
        ctx.stroke();
        if (z > 14 && !o.baski) {
          metin('ÖN CEPHE (YOL)', X((ea[0] + eb[0]) / 2), Y((ea[1] + eb[1]) / 2) + 12, 9.5 * fs, '#b45309', true);
        }
        ctx.restore();
      }

      if (o.olcu && p.arsa) {
        const arsaPts = p.arsa.pts;
        arsaPts.forEach((a, i) => {
          const b = arsaPts[(i + 1) % arsaPts.length];
          const L = Math.hypot(b[0] - a[0], b[1] - a[1]);
          if (L * z < 50) return;
          let ang = Math.atan2(b[1] - a[1], b[0] - a[0]);
          if (ang > Math.PI / 2 || ang < -Math.PI / 2) ang += Math.PI;
          metin(fmt(L) + ' m', X((a[0] + b[0]) / 2), Y((a[1] + b[1]) / 2) - 9, 10.5 * fs, o.baski ? '#222' : '#3d7a2c', false, ang);
        });
      }
    }

    const disSira: Record<string, number> = { cim: 0, yol: 1, otopark: 1, havuz: 2, cit: 3, araba: 4, cali: 5, agac: 6, kot: 7 };
    [...p.dis]
      .sort((a, b) => (disSira[a.tip] ?? 9) - (disSira[b.tip] ?? 9))
      .forEach(d => {
        const T = DIS[d.tip];
        if (!T || T.gizli) return;
        if (T.alan && d.x != null && d.y != null && d.w != null && d.d != null) {
          dRect(d.x, d.y, d.w, d.d, d.r || 0);
          ctx.fillStyle = o.baski ? (d.tip === 'havuz' ? '#e3f3fb' : '#f7f7f4') : T.renk || '#ddd';
          ctx.fill();
          ctx.strokeStyle = o.baski ? '#444' : 'rgba(0,0,0,.35)';
          ctx.lineWidth = 1;
          ctx.stroke();
          if (d.tip === 'havuz') {
            dRect(d.x, d.y, Math.max(0.1, d.w - 0.5), Math.max(0.1, d.d - 0.5), d.r || 0);
            ctx.strokeStyle = o.baski ? '#444' : '#2b86b5';
            ctx.stroke();
          }
          if (d.tip === 'otopark') {
            ctx.save();
            ctx.setLineDash([6, 5]);
            ctx.strokeStyle = o.baski ? '#666' : '#eef';
            dRect(d.x, d.y, d.w - 0.3, d.d - 0.3, d.r || 0);
            ctx.stroke();
            ctx.restore();
          }
          if (Math.min(d.w, d.d) * z > 40) {
            metin(T.ad.split(' ')[0] + ' · ' + fmt(d.w * d.d, 1) + ' m²', X(d.x), Y(d.y), 10.5 * fs, o.baski ? '#333' : 'rgba(20,40,30,.7)');
          }
        } else if (d.tip === 'cit' && d.x1 != null && d.y1 != null && d.x2 != null && d.y2 != null) {
          ctx.strokeStyle = o.baski ? '#333' : '#8a7c62';
          ctx.lineWidth = Math.max(2, 0.2 * z);
          ctx.lineCap = 'butt';
          ctx.beginPath();
          ctx.moveTo(X(d.x1), Y(d.y1));
          ctx.lineTo(X(d.x2), Y(d.y2));
          ctx.stroke();
        } else if ((d.tip === 'agac' || d.tip === 'cali') && d.x != null && d.y != null) {
          const r = ((d.cap || T.cap || 1) / 2) * z;
          ctx.beginPath();
          ctx.arc(X(d.x), Y(d.y), r, 0, 7);
          ctx.fillStyle = o.baski ? 'rgba(0,0,0,.04)' : d.tip === 'agac' ? 'rgba(70,140,60,.35)' : 'rgba(95,160,80,.45)';
          ctx.fill();
          ctx.strokeStyle = o.baski ? '#444' : '#3c7a33';
          ctx.lineWidth = 1;
          ctx.stroke();
          if (d.tip === 'agac') {
            ctx.beginPath();
            for (let i = 0; i < 8; i++) {
              const a = (i * Math.PI) / 4;
              ctx.moveTo(X(d.x), Y(d.y));
              ctx.lineTo(X(d.x) + Math.cos(a) * r * 0.75, Y(d.y) + Math.sin(a) * r * 0.75);
            }
            ctx.stroke();
            ctx.beginPath();
            ctx.arc(X(d.x), Y(d.y), Math.max(2, 0.15 * z), 0, 7);
            ctx.fillStyle = o.baski ? '#444' : '#6b4a2b';
            ctx.fill();
          }
        } else if (d.tip === 'araba' && d.x != null && d.y != null && d.w != null && d.d != null) {
          dRect(d.x, d.y, d.w, d.d, d.r || 0);
          ctx.fillStyle = o.baski ? '#fff' : '#dfe6ee';
          ctx.fill();
          ctx.strokeStyle = o.baski ? '#333' : '#44546a';
          ctx.lineWidth = 1;
          ctx.stroke();
          const t = G.donder(0, -d.d * 0.08, d.r || 0);
          dRect(d.x + t[0], d.y + t[1], d.w * 0.82, d.d * 0.42, d.r || 0);
          ctx.stroke();
        }
      });
    ctx.globalAlpha = 1;
    if (zemin && km.arazi) araziCiz(ctx, X, Y, z, o, fs);
  }

  // Alt kat hayaleti
  if (o.hayalet && ki > 0 && km.duvarlar) {
    const alt = p.katlar[ki - 1].id;
    ctx.globalAlpha = 0.18;
    ctx.fillStyle = R.ic;
    p.duvarlar
      .filter(w => w.kat === alt)
      .forEach(w => {
        const L = Math.hypot(w.x2 - w.x1, w.y2 - w.y1);
        if (!L) return;
        if (w.egri && Math.abs(w.egri) > 0.01) {
          ctx.strokeStyle = R.ic;
          ctx.lineWidth = Math.max(1.5, w.k * z);
          const pts = G.egriNoktalar(w.x1, w.y1, w.x2, w.y2, w.egri, 14);
          ctx.beginPath();
          pts.forEach((pt, idx) => (idx ? ctx.lineTo(X(pt[0]), Y(pt[1])) : ctx.moveTo(X(pt[0]), Y(pt[1]))));
          ctx.stroke();
          return;
        }
        const ux = (w.x2 - w.x1) / L;
        const uy = (w.y2 - w.y1) / L;
        const nx = (-uy * w.k) / 2;
        const ny = (ux * w.k) / 2;
        yol([
          [w.x1 + nx, w.y1 + ny],
          [w.x2 + nx, w.y2 + ny],
          [w.x2 - nx, w.y2 - ny],
          [w.x1 - nx, w.y1 - ny],
        ]);
        ctx.fill();
      });
    ctx.globalAlpha = 1;
  }

  // Odalar + Balkon/Teras korkuluğu + Mahal Bölgeleme (Zoning)
  const odalar = p.odalar.filter(r => r.kat === katId);
  const netKatAlan = odalar.reduce((s, r) => s + Math.abs(G.alan(r.pts)), 0) || 1;
  odalar.forEach(r => {
    yol(r.pts);
    if (!o.baski && S.zoningGoster) {
      const zr = ZONE_RENK[odaTuru(r.ad)] || ZONE_RENK.diger;
      ctx.fillStyle = zr.bg;
      ctx.globalAlpha = 1;
    } else {
      ctx.fillStyle = (ZEMIN[r.zemin] || ZEMIN.parke).renk;
      ctx.globalAlpha = o.baski ? 0.45 : 0.85 * yapiSoluk;
    }
    ctx.fill();
    ctx.globalAlpha = yapiSoluk;
    if (!o.baski && r.zemin === 'seramik') {
      ctx.save();
      ctx.clip();
      ctx.strokeStyle = 'rgba(80,110,130,.13)';
      ctx.lineWidth = 1;
      ctx.beginPath();
      const b = G.bbox(r.pts);
      for (let x = Math.floor(b.x1 / 0.6) * 0.6; x < b.x2; x += 0.6) {
        ctx.moveTo(X(x), Y(b.y1));
        ctx.lineTo(X(x), Y(b.y2));
      }
      for (let y = Math.floor(b.y1 / 0.6) * 0.6; y < b.y2; y += 0.6) {
        ctx.moveTo(X(b.x1), Y(y));
        ctx.lineTo(X(b.x2), Y(y));
      }
      ctx.stroke();
      ctx.restore();
    }
    if (/balkon|teras|veranda/i.test(r.ad)) {
      ctx.save();
      ctx.strokeStyle = o.baski ? '#333' : '#4a607a';
      ctx.lineWidth = 2;
      for (let i = 0; i < r.pts.length; i++) {
        const a = r.pts[i];
        const b = r.pts[(i + 1) % r.pts.length];
        const mx = (a[0] + b[0]) / 2;
        const my = (a[1] + b[1]) / 2;
        const duvarVar = p.duvarlar.some(w => w.kat === katId && G.segNokta(mx, my, w.x1, w.y1, w.x2, w.y2).d < w.k / 2 + 0.15);
        if (!duvarVar) {
          ctx.beginPath();
          ctx.moveTo(X(a[0]), Y(a[1]));
          ctx.lineTo(X(b[0]), Y(b[1]));
          ctx.stroke();
        }
      }
      ctx.restore();
    }
  });

  bosluklarCiz(ctx, X, Y, katId, o);

  // Kirişler (kesik çizgi gösterimi — statik modda vurgulu)
  const kirisler = km.akslar ? kirisListesi(katId) : [];
  if (kirisler.length && (disMod === 'tumu' || disMod === 'statik' || disMod === 'mimari')) {
    ctx.save();
    ctx.strokeStyle = o.baski ? '#666' : disMod === 'statik' ? '#b45309' : 'rgba(130, 82, 42, 0.55)';
    ctx.lineWidth = disMod === 'statik' ? 1.8 : 1.2;
    ctx.setLineDash([6, 4]);
    kirisler.forEach(k => {
      const L = Math.hypot(k.b.x - k.a.x, k.b.y - k.a.y) || 1;
      const nx = (-(k.b.y - k.a.y) / L) * (k.w / 2);
      const ny = ((k.b.x - k.a.x) / L) * (k.w / 2);
      ctx.beginPath();
      ctx.moveTo(X(k.a.x + nx), Y(k.a.y + ny));
      ctx.lineTo(X(k.b.x + nx), Y(k.b.y + ny));
      ctx.moveTo(X(k.a.x - nx), Y(k.a.y - ny));
      ctx.lineTo(X(k.b.x - nx), Y(k.b.y - ny));
      ctx.stroke();
      if (disMod === 'statik' && !o.baski && k.L * z > 38) {
        metin(`${Math.round(k.w * 100)}×${Math.round(k.h * 100)} (${fmt(k.L)}m)`, X((k.a.x + k.b.x) / 2), Y((k.a.y + k.b.y) / 2) - 8, 9 * fs, '#92400e', true);
      }
    });
    ctx.setLineDash([]);
    ctx.restore();
  }

  // Duvarlar
  const duvarlar = km.duvarlar ? p.duvarlar.filter(w => w.kat === katId) : [];
  ctx.save();
  ctx.globalAlpha = yapiSoluk;
  duvarlar.forEach(w => {
    if (w.egri && Math.abs(w.egri) > 0.01) {
      const pts = G.egriNoktalar(w.x1, w.y1, w.x2, w.y2, w.egri, 16);
      const sol: Pt[] = [];
      const sag: Pt[] = [];
      for (let i = 0; i < pts.length; i++) {
        const a = pts[Math.max(0, i - 1)];
        const b = pts[Math.min(pts.length - 1, i + 1)];
        const L = Math.hypot(b[0] - a[0], b[1] - a[1]) || 1;
        const nx = (-(b[1] - a[1]) / L) * (w.k / 2);
        const ny = ((b[0] - a[0]) / L) * (w.k / 2);
        sol.push([pts[i][0] + nx, pts[i][1] + ny]);
        sag.unshift([pts[i][0] - nx, pts[i][1] - ny]);
      }
      yol([...sol, ...sag]);
      ctx.fillStyle = w.tur === 'dis' ? R.dis : R.ic;
      ctx.fill();
      return;
    }

    const { L, tam } = duvarParcalari(w);
    if (L < 0.01) return;
    const ux = (w.x2 - w.x1) / L;
    const uy = (w.y2 - w.y1) / L;
    const nx = (-uy * w.k) / 2;
    const ny = (ux * w.k) / 2;
    const b1 = uctaBagli(w, w.x1, w.y1) ? w.k / 2 : 0;
    const b2 = uctaBagli(w, w.x2, w.y2) ? w.k / 2 : 0;
    ctx.fillStyle = w.tur === 'dis' ? R.dis : R.ic;
    tam.forEach(([s, e]) => {
      const s2 = s === 0 ? -b1 : s;
      const e2 = Math.abs(e - L) < 1e-6 ? L + b2 : e;
      const ax = w.x1 + ux * s2;
      const ay = w.y1 + uy * s2;
      const bx = w.x1 + ux * e2;
      const by = w.y1 + uy * e2;
      yol([
        [ax + nx, ay + ny],
        [bx + nx, by + ny],
        [bx - nx, by - ny],
        [ax - nx, ay - ny],
      ]);
      ctx.fill();
      if (o.baski && w.tur === 'dis') {
        ctx.save();
        ctx.clip();
        ctx.strokeStyle = '#fff';
        ctx.lineWidth = 0.6;
        ctx.beginPath();
        const bb = G.bbox([
          [ax + nx, ay + ny],
          [bx - nx, by - ny],
          [bx + nx, by + ny],
          [ax - nx, ay - ny],
        ]);
        for (let t = bb.x1 - bb.h; t < bb.x2 + bb.h; t += 0.12) {
          ctx.moveTo(X(t), Y(bb.y2));
          ctx.lineTo(X(t + bb.h + 0.01), Y(bb.y1));
        }
        ctx.stroke();
        ctx.restore();
      }
    });
  });

  // Açıklıklar (Kapı / Pencere / Sürme / Çift Kanat / Çatı Penceresi / Panjur)
  duvarlar.forEach(w => {
    const { L, acik } = duvarParcalari(w);
    if (!acik.length || L < 0.01) return;
    const ux = (w.x2 - w.x1) / L;
    const uy = (w.y2 - w.y1) / L;
    const nx = -uy;
    const ny = ux;
    const h = w.k / 2;

    acik.forEach(({ a, s, e }) => {
      const P0: Pt = [w.x1 + ux * s, w.y1 + uy * s];
      const P1: Pt = [w.x1 + ux * e, w.y1 + uy * e];
      const cerRenk = o.baski ? '#111' : a.renk || '#2a7fb0';
      ctx.lineWidth = 1;
      ctx.strokeStyle = R.kapi;
      ctx.beginPath();
      for (const q of [P0, P1]) {
        ctx.moveTo(X(q[0] + nx * h), Y(q[1] + ny * h));
        ctx.lineTo(X(q[0] - nx * h), Y(q[1] - ny * h));
      }
      ctx.stroke();

      if (a.tur === 'pencere' || a.tur === 'balkon' || a.tur === 'surme') {
        ctx.fillStyle = '#fff';
        yol([
          [P0[0] + nx * h, P0[1] + ny * h],
          [P1[0] + nx * h, P1[1] + ny * h],
          [P1[0] - nx * h, P1[1] - ny * h],
          [P0[0] - nx * h, P0[1] - ny * h],
        ]);
        ctx.fill();
        ctx.stroke();
        ctx.beginPath();
        for (const f of a.tur === 'balkon' ? [-h * 0.25, h * 0.25] : [-h * 0.33, 0, h * 0.33]) {
          ctx.moveTo(X(P0[0] + nx * f), Y(P0[1] + ny * f));
          ctx.lineTo(X(P1[0] + nx * f), Y(P1[1] + ny * f));
        }
        ctx.strokeStyle = cerRenk;
        ctx.stroke();

        // Sürme kapı kayar kanat çizgileri
        if (a.tur === 'surme') {
          const PM: Pt = [(P0[0] + P1[0]) / 2, (P0[1] + P1[1]) / 2];
          ctx.lineWidth = 2;
          ctx.strokeStyle = R.kapi;
          ctx.beginPath();
          ctx.moveTo(X(P0[0] + nx * h * 0.25), Y(P0[1] + ny * h * 0.25));
          ctx.lineTo(X(PM[0] + nx * h * 0.25), Y(PM[1] + ny * h * 0.25));
          ctx.moveTo(X(PM[0] - nx * h * 0.25), Y(PM[1] - ny * h * 0.25));
          ctx.lineTo(X(P1[0] - nx * h * 0.25), Y(P1[1] - ny * h * 0.25));
          ctx.stroke();
        }
        // Panjur çizgisi
        if (a.panjur) {
          ctx.save();
          ctx.strokeStyle = o.baski ? '#444' : '#526071';
          ctx.setLineDash([2, 2]);
          ctx.beginPath();
          const yon = a.yon || 1;
          ctx.moveTo(X(P0[0] + nx * (h + 0.06) * yon), Y(P0[1] + ny * (h + 0.06) * yon));
          ctx.lineTo(X(P1[0] + nx * (h + 0.06) * yon), Y(P1[1] + ny * (h + 0.06) * yon));
          ctx.stroke();
          ctx.restore();
        }
      }

      if (a.tur === 'cati_pencere') {
        ctx.save();
        ctx.setLineDash([4, 3]);
        ctx.strokeStyle = cerRenk;
        yol([
          [P0[0] + nx * h, P0[1] + ny * h],
          [P1[0] + nx * h, P1[1] + ny * h],
          [P1[0] - nx * h, P1[1] - ny * h],
          [P0[0] - nx * h, P0[1] - ny * h],
        ]);
        ctx.stroke();
        ctx.beginPath();
        ctx.moveTo(X(P0[0] + nx * h), Y(P0[1] + ny * h));
        ctx.lineTo(X(P1[0] - nx * h), Y(P1[1] - ny * h));
        ctx.moveTo(X(P1[0] + nx * h), Y(P1[1] + ny * h));
        ctx.lineTo(X(P0[0] - nx * h), Y(P0[1] - ny * h));
        ctx.stroke();
        ctx.restore();
      }

      if (a.tur === 'kapi' || a.tur === 'balkon' || a.tur === 'cift_kapi') {
        const yon = a.yon || 1;
        const cizKanat = (H: Pt, other: Pt, kanat: number) => {
          const Hx = H[0] + nx * yon * h;
          const Hy = H[1] + ny * yon * h;
          const A = Math.atan2(ny * yon, nx * yon);
          const Bv = [other[0] - H[0], other[1] - H[1]];
          const B = Math.atan2(Bv[1], Bv[0]);
          let dA = B - A;
          while (dA > Math.PI) dA -= 2 * Math.PI;
          while (dA < -Math.PI) dA += 2 * Math.PI;
          ctx.strokeStyle = R.kapi;
          ctx.lineWidth = o.baski ? 1 : 1.4;
          ctx.beginPath();
          ctx.moveTo(X(Hx), Y(Hy));
          ctx.lineTo(X(Hx + Math.cos(A) * kanat), Y(Hy + Math.sin(A) * kanat));
          ctx.stroke();
          ctx.lineWidth = 0.8;
          ctx.setLineDash([4, 3]);
          ctx.beginPath();
          for (let i = 0; i <= 16; i++) {
            const t = A + (dA * i) / 16;
            const x = X(Hx + Math.cos(t) * kanat);
            const y = Y(Hy + Math.sin(t) * kanat);
            if (i) ctx.lineTo(x, y);
            else ctx.moveTo(x, y);
          }
          ctx.stroke();
          ctx.setLineDash([]);
        };

        const g = Math.hypot(P1[0] - P0[0], P1[1] - P0[1]);
        if (a.tur === 'cift_kapi') {
          const PM: Pt = [(P0[0] + P1[0]) / 2, (P0[1] + P1[1]) / 2];
          cizKanat(P0, PM, g / 2);
          cizKanat(P1, PM, g / 2);
        } else {
          const menS = (a.mentese || 'sol') === 'sol';
          const H = menS ? P0 : P1;
          const other = menS ? P1 : P0;
          cizKanat(H, other, a.tur === 'balkon' ? g / 2 : g);
        }
      }
    });
  });

  ctx.restore();

  // Mobilyalar (disiplin ve katman filtreli)
  const mobKatman = km.mobilya && disMod !== 'statik' && disMod !== 'sihhi' && disMod !== 'elektrik';
  ctx.save();
  ctx.globalAlpha = disMod === 'sihhi' || disMod === 'elektrik' ? 0.22 : 1;
  if (o.mobilya !== false && mobKatman) {
    p.mobilya.filter(m => m.kat === katId).forEach(m => mobilyaCiz(ctx, m, X, Y, z, R, o));
  } else if (km.duvarlar) {
    p.mobilya.filter(m => m.kat === katId && MOB[m.tip]?.ozel).forEach(m => mobilyaCiz(ctx, m, X, Y, z, R, o));
  }
  ctx.restore();

  // Tesisat ve Boru Döşemeleri
  tesisatCiz(ctx, X, Y, z, { tesisat: o.tesisat, boru: o.boru ?? S.boruGoster, baski: o.baski, fs, katman: !o.baski }, katId);

  // Oda etiketleri
  odalar.forEach(r => {
    const c = G.merkez(r.pts);
    const a = Math.abs(G.alan(r.pts));
    if (Math.sqrt(a) * z < 38) return;
    metin(r.ad, X(c[0]), Y(c[1]) - 8 * fs, 12.5 * fs, R.yazi, true);
    const payTxt = !o.baski && S.zoningGoster ? ` · %${Math.round((a / netKatAlan) * 100)}` : '';
    metin(fmt(a) + ' m²' + payTxt, X(c[0]), Y(c[1]) + 8 * fs, 11 * fs, o.baski ? '#333' : '#4c5a70');
  });

  // Duvar ölçüleri
  const kb = duvarlar.length ? G.bbox(duvarlar.flatMap(w => [[w.x1, w.y1], [w.x2, w.y2]])) : null;
  if (o.olcu && km.olculer) {
    duvarlar.forEach(w => {
      const L = duvarBoy(w);
      if (L * z < 46 || (o.baski && w.tur !== 'dis')) return;
      const chord = Math.hypot(w.x2 - w.x1, w.y2 - w.y1) || 1;
      const ux = (w.x2 - w.x1) / chord;
      const uy = (w.y2 - w.y1) / chord;
      let ang = Math.atan2(uy, ux);
      let nx = -uy;
      let ny = ux;
      if (w.tur === 'dis' && kb && ((w.x1 + w.x2) / 2 - (kb.x1 + kb.w / 2)) * nx + ((w.y1 + w.y2) / 2 - (kb.y1 + kb.h / 2)) * ny < 0) {
        nx = -nx;
        ny = -ny;
      }
      if (ang > Math.PI / 2 + 1e-3 || ang < -Math.PI / 2 + 1e-3) ang += Math.PI;
      const off = (w.k / 2) * z + 8 * fs + (w.egri ? Math.abs(w.egri) * z : 0);
      metin(fmt(L), X((w.x1 + w.x2) / 2) + nx * off, Y((w.y1 + w.y2) / 2) + ny * off, 10 * fs, R.olcu, false, ang);
    });
  }

  // Genel dış ölçü zinciri
  if (o.disOlcu && duvarlar.length) {
    const pts: Pt[] = [];
    duvarlar.forEach(w =>
      pts.push(
        [w.x1 - w.k / 2, w.y1 - w.k / 2],
        [w.x2 + w.k / 2, w.y2 + w.k / 2],
        [w.x1 + w.k / 2, w.y1 + w.k / 2],
        [w.x2 - w.k / 2, w.y2 - w.k / 2],
      ),
    );
    const b = G.bbox(pts);
    ctx.strokeStyle = R.olcu;
    ctx.lineWidth = 0.8;
    olcuCiz(ctx, X, Y, b.x1, b.y2 + 1.0, b.x2, b.y2 + 1.0, fmt(b.w) + ' m', 11 * fs, R.olcu, b.y2 + 0.15);
    olcuCiz(ctx, X, Y, b.x2 + 1.0, b.y1, b.x2 + 1.0, b.y2, fmt(b.h) + ' m', 11 * fs, R.olcu, null, b.x2 + 0.15);
  }

  if (km.olculer) {
    p.olculer.filter(q => q.kat === katId).forEach(q => olcuCiz(ctx, X, Y, q.x1, q.y1, q.x2, q.y2, fmt(Math.hypot(q.x2 - q.x1, q.y2 - q.y1)) + ' m', 11 * fs, R.olcu));
  }
  p.yazilar.filter(q => q.kat === katId).forEach(q => metin(q.metin, X(q.x), Y(q.y), (q.boy || 12) * fs, R.yazi, true));
  if (o.aks !== false && km.akslar && disMod !== 'sihhi' && disMod !== 'elektrik') akslarCiz(ctx, X, Y, z, o, fs);
  if (o.kesit !== false) kesitlerCiz(ctx, X, Y, z, o, fs);

  if (o.kuzey) {
    const x = o.w - 46;
    const y = 50;
    const a = (p.ayar.kuzey || 0) * RAD;
    ctx.strokeStyle = R.yazi;
    ctx.fillStyle = R.yazi;
    ctx.lineWidth = 1.2;
    ctx.beginPath();
    ctx.arc(x, y, 18, 0, 7);
    ctx.stroke();
    ctx.save();
    ctx.translate(x, y);
    ctx.rotate(a);
    ctx.beginPath();
    ctx.moveTo(0, -16);
    ctx.lineTo(7, 10);
    ctx.lineTo(0, 5);
    ctx.lineTo(-7, 10);
    ctx.closePath();
    ctx.fill();
    metin('K', 0, -28, 12, R.yazi, true);
    ctx.restore();
  }
}

interface SnapResult {
  x: number;
  y: number;
  tip: 'uc' | 'orta' | 'kesisim' | 'dik' | 'aci' | 'cizgi' | 'izgara';
}

type DragState =
  | { tip: 'pinch'; d: number; m: Pt }
  | { tip: 'pan'; sx: number; sy: number; tx: number; ty: number }
  | { tip: 'kutuSec'; x0: number; y0: number; x1: number; y1: number; sx: number; sy: number }
  | { tip: 'rect'; x0: number; y0: number; x1: number; y1: number }
  | { tip: 'uc'; bag: { o: Duvar; u: 1 | 2 }[]; x0: number; y0: number; sx: number; sy: number; kayit: boolean }
  | { tip: 'tasi'; h: Secim; wx: number; wy: number; ilk: unknown; cokluIlk?: { s: Secim; data: unknown }[]; sx: number; sy: number; kayit: boolean };

interface Callbacks {
  onRefresh: () => void;
  onRefreshPanel: () => void;
  onSelectTool: (a: string) => void;
  onPrompt: (baslik: string, deger?: string, aciklama?: string) => Promise<string | null>;
  onAskRoomName: (oda: Oda) => void;
  onContextMenu: (cx: number, cy: number) => void;
}

let _cb: Callbacks = {
  onRefresh: () => {},
  onRefreshPanel: () => {},
  onSelectTool: () => {},
  onPrompt: async () => null,
  onAskRoomName: () => {},
  onContextMenu: () => {},
};

export function baglaPlanOlay(cb: Partial<Callbacks>) {
  _cb = { ..._cb, ...cb };
}

export const PLAN = {
  cv: null as HTMLCanvasElement | null,
  ctx: null as CanvasRenderingContext2D | null,
  W: 800,
  H: 600,
  v: { z: 42, tx: 140, ty: 90 },
  fare: null as { sx: number; sy: number } | null,
  zincir: null as { arac: string; pts: Pt[] } | null,
  pahIlk: null as string | null,
  surukle: null as DragState | null,
  uzunluk: '',
  isaretci: new Map<number, { x: number; y: number }>(),
  bosluk: false,
  shift: false,
  vurgu: null as Secim | null,
  _hk: '',
  sonTikDunya: null as Pt | null,

  init(cv: HTMLCanvasElement, wrap: HTMLElement) {
    this.cv = cv;
    this.ctx = cv.getContext('2d');
    new ResizeObserver(() => this.boyut()).observe(wrap);
    cv.addEventListener('pointerdown', e => this.asagi(e));
    cv.addEventListener('pointermove', e => this.hareket(e));
    cv.addEventListener('pointerup', e => this.yukari(e));
    cv.addEventListener('pointercancel', e => {
      this.isaretci.delete(e.pointerId);
      this.surukle = null;
    });
    cv.addEventListener('dblclick', e => this.cift(e));
    cv.addEventListener('contextmenu', e => {
      e.preventDefault();
      if (this.zincir) {
        this.zincirBitir();
        return;
      }
      const [wx, wy] = this.dunya(e.offsetX, e.offsetY);
      this.sonTikDunya = [wx, wy];
      const h = this.isabet(wx, wy);
      if (h && h.tur !== 'uc') {
        if (!S.cokluSecili.some(x => x.id === h.id && x.tur === h.tur)) {
          S.secili = h;
          S.cokluSecili = [];
          _cb.onRefreshPanel();
          this.ciz();
        }
      }
      _cb.onContextMenu(e.clientX, e.clientY);
    });
    cv.addEventListener(
      'wheel',
      e => {
        e.preventDefault();
        const f = Math.exp(-e.deltaY * 0.0015);
        this.zoom(f, e.offsetX, e.offsetY);
      },
      { passive: false },
    );
    cv.addEventListener('pointerleave', () => {
      this.fare = null;
      this.ciz();
    });
  },

  boyut() {
    if (!this.cv || !this.ctx) return;
    const parent = this.cv.parentElement?.parentElement || this.cv.parentElement;
    if (!parent) return;
    const r = parent.getBoundingClientRect();
    const dpr = window.devicePixelRatio || 1;
    if (!r.width) return;
    this.W = r.width;
    this.H = r.height;
    this.cv.width = r.width * dpr;
    this.cv.height = r.height * dpr;
    this.ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    this.ciz();
  },

  dunya(sx: number, sy: number): Pt {
    return [(sx - this.v.tx) / this.v.z, (sy - this.v.ty) / this.v.z];
  },

  zoom(f: number, sx: number, sy: number) {
    const z = sinir(this.v.z * f, 2, 600);
    f = z / this.v.z;
    this.v.tx = sx - (sx - this.v.tx) * f;
    this.v.ty = sy - (sy - this.v.ty) * f;
    this.v.z = z;
    this.ciz();
  },

  sigdir() {
    if (!S.p) return;
    const p = P();
    const pts: Pt[] = [];
    p.duvarlar.forEach(w => pts.push([w.x1, w.y1], [w.x2, w.y2]));
    if (p.arsa) pts.push(...p.arsa.pts);
    p.dis.forEach(d => {
      if (d.x1 != null && d.y1 != null && d.x2 != null && d.y2 != null) pts.push([d.x1, d.y1], [d.x2, d.y2]);
      else if (d.x != null && d.y != null) pts.push([d.x, d.y]);
    });
    if (!pts.length) {
      this.v = { z: 42, tx: (this.W || 800) / 2 - 5 * 42, ty: (this.H || 600) / 2 - 4 * 42 };
      this.ciz();
      return;
    }
    const b = G.bbox(pts);
    const W = this.W || 800;
    const H = this.H || 600;
    const z = sinir(Math.min((W - 80) / Math.max(b.w, 1), (H - 80) / Math.max(b.h, 1)), 3, 200);
    this.v = { z, tx: W / 2 - (b.x1 + b.w / 2) * z, ty: H / 2 - (b.y1 + b.h / 2) * z };
    this.ciz();
  },

  yakala(sx: number, sy: number, capa?: Pt | null, serbest = false): SnapResult {
    const [wx, wy] = this.dunya(sx, sy);
    const tol = 11 / this.v.z;
    const W = katDuvar();
    const uclar: Pt[] = [];
    W.forEach(w => uclar.push([w.x1, w.y1], [w.x2, w.y2]));
    (P().borular || []).filter(b => b.kat === S.katId).forEach(b => uclar.push(...b.pts));
    (P().tesisat || []).filter(t => t.kat === S.katId).forEach(t => uclar.push([t.x, t.y]));
    if (P().arsa) uclar.push(...P().arsa!.pts);
    if (this.zincir) uclar.push(...this.zincir.pts);
    P().dis.forEach(d => {
      if (d.x1 != null && d.y1 != null && d.x2 != null && d.y2 != null) uclar.push([d.x1, d.y1], [d.x2, d.y2]);
    });

    // 1) Uç nokta
    let enUc: Pt | null = null;
    let edUc = tol;
    for (const q of uclar) {
      const d = Math.hypot(q[0] - wx, q[1] - wy);
      if (d < edUc) {
        edUc = d;
        enUc = q;
      }
    }
    if (enUc) return { x: r3(enUc[0]), y: r3(enUc[1]), tip: 'uc' };

    // 2) Orta nokta (duvar orta noktası)
    for (const w of W) {
      const mx = (w.x1 + w.x2) / 2;
      const my = (w.y1 + w.y2) / 2;
      if (Math.hypot(mx - wx, my - wy) < tol * 0.85) return { x: r3(mx), y: r3(my), tip: 'orta' };
    }

    // 3) Kesişim noktası (duvar - aks kesişimleri)
    for (let i = 0; i < W.length; i++) {
      for (let j = i + 1; j < W.length; j++) {
        const k = G.dogruKesisim(W[i].x1, W[i].y1, W[i].x2, W[i].y2, W[j].x1, W[j].y1, W[j].x2, W[j].y2, true);
        if (k && Math.hypot(k.x - wx, k.y - wy) < tol * 0.85) return { x: k.x, y: k.y, tip: 'kesisim' };
      }
    }

    let x = wx;
    let y = wy;
    if (capa && !serbest && S.orto) {
      // Dik yakalama kontrolü
      for (const w of W) {
        const s = G.segNokta(capa[0], capa[1], w.x1, w.y1, w.x2, w.y2);
        if (s.t > 0.01 && s.t < 0.99 && Math.hypot(s.x - wx, s.y - wy) < tol * 0.9) {
          return { x: r3(s.x), y: r3(s.y), tip: 'dik' };
        }
      }
      const dx = x - capa[0];
      const dy = y - capa[1];
      const L = Math.hypot(dx, dy);
      const a = Math.round(Math.atan2(dy, dx) / (Math.PI / 4)) * (Math.PI / 4);
      const Ls = yuv(L, S.grid);
      x = capa[0] + Math.cos(a) * Ls;
      y = capa[1] + Math.sin(a) * Ls;
      return { x: r3(x), y: r3(y), tip: 'aci' };
    }

    for (const w of W) {
      const s = G.segNokta(wx, wy, w.x1, w.y1, w.x2, w.y2);
      if (s.d < tol * 0.8) return { x: r3(s.x), y: r3(s.y), tip: 'cizgi' };
    }
    return { x: r3(yuv(x, S.grid)), y: r3(yuv(y, S.grid)), tip: 'izgara' };
  },

  enYakinDuvar(wx: number, wy: number) {
    let en: { w: Duvar; s: ReturnType<typeof G.segNokta> } | null = null;
    let ed = Math.max(0.6, 16 / this.v.z);
    for (const w of katDuvar()) {
      const s = G.segNokta(wx, wy, w.x1, w.y1, w.x2, w.y2);
      if (s.d < ed) {
        ed = s.d;
        en = { w, s };
      }
    }
    return en;
  },

  isabet(wx: number, wy: number): Secim | null {
    const tol = 6 / this.v.z;
    const p = P();
    const ki = katIdx();
    if (S.secili && S.secili.tur === 'duvar') {
      const w = duvar(S.secili.id);
      if (w) {
        for (const u of [1, 2] as const) {
          const ux = u === 1 ? w.x1 : w.x2;
          const uy = u === 1 ? w.y1 : w.y2;
          if (Math.hypot(ux - wx, uy - wy) < 9 / this.v.z) return { tur: 'uc', id: w.id, u };
        }
      }
    }
    for (const a of p.aciklar) {
      const w = duvar(a.duvar);
      if (!w || w.kat !== S.katId) continue;
      const L = duvarBoy(w);
      const s = G.segNokta(wx, wy, w.x1, w.y1, w.x2, w.y2);
      if (s.d <= w.k / 2 + tol && Math.abs(s.t * L - a.t * L) <= a.g / 2) return { tur: 'acik', id: a.id };
    }
    const icRect = (x: number, y: number, cx: number, cy: number, w: number, d: number, r = 0) => {
      const t = G.donder(x - cx, y - cy, -r);
      return Math.abs(t[0]) <= w / 2 + tol && Math.abs(t[1]) <= d / 2 + tol;
    };
    if (S.tesisatGoster) {
      for (const t of [...(p.tesisat || [])].reverse()) {
        if (t.kat === S.katId && Math.hypot(t.x - wx, t.y - wy) < Math.max(0.2, 10 / this.v.z)) return { tur: 'tesisat', id: t.id };
      }
      if (S.boruGoster) {
        for (const b of [...(p.borular || [])].reverse()) {
          if (b.kat !== S.katId) continue;
          for (let i = 0; i + 1 < b.pts.length; i++) {
            if (G.segNokta(wx, wy, b.pts[i][0], b.pts[i][1], b.pts[i + 1][0], b.pts[i + 1][1]).d < Math.max(0.12, 8 / this.v.z)) {
              return { tur: 'boru', id: b.id };
            }
          }
        }
      }
    }
    if (ki === 0) {
      for (const d of p.dis) {
        if (d.tip === 'kot' && d.x != null && d.y != null && Math.hypot(d.x - wx, d.y - wy) < 9 / this.v.z) return { tur: 'dis', id: d.id };
      }
    }
    for (const k of p.kesitler || []) {
      if (G.segNokta(wx, wy, k.x1, k.y1, k.x2, k.y2).d < tol) return { tur: 'kesit', id: k.id };
    }
    for (const k of p.kirisler || []) {
      if (k.kat === S.katId && G.segNokta(wx, wy, k.x1, k.y1, k.x2, k.y2).d <= k.w / 2 + tol) return { tur: 'kiris', id: k.id };
    }
    for (const m of [...p.mobilya].reverse()) {
      if (m.kat !== S.katId) continue;
      const { w, d } = mobOlcu(m);
      if (icRect(wx, wy, m.x, m.y, w, d, m.r)) return { tur: 'mobilya', id: m.id };
    }
    for (const q of p.yazilar) {
      if (q.kat === S.katId && Math.hypot(q.x - wx, q.y - wy) < 14 / this.v.z) return { tur: 'yazi', id: q.id };
    }
    for (const q of p.olculer) {
      if (q.kat === S.katId && G.segNokta(wx, wy, q.x1, q.y1, q.x2, q.y2).d < tol) return { tur: 'olcu', id: q.id };
    }
    for (const w of katDuvar()) {
      if (G.segNokta(wx, wy, w.x1, w.y1, w.x2, w.y2).d <= w.k / 2 + tol) return { tur: 'duvar', id: w.id };
    }
    if (ki === 0) {
      const sira = ['agac', 'cali', 'araba', 'cit', 'havuz', 'yol', 'otopark', 'cim'];
      for (const t of sira) {
        for (const d of p.dis.filter(d => d.tip === t)) {
          if ((t === 'agac' || t === 'cali') && d.x != null && d.y != null) {
            if (Math.hypot(d.x - wx, d.y - wy) < ((d.cap || DIS[t].cap || 1) / 2) * (t === 'agac' ? 0.55 : 1)) {
              return { tur: 'dis', id: d.id };
            }
          }
          if (t === 'cit' && d.x1 != null && d.y1 != null && d.x2 != null && d.y2 != null) {
            if (G.segNokta(wx, wy, d.x1, d.y1, d.x2, d.y2).d < 0.15 + tol) return { tur: 'dis', id: d.id };
          }
          if (d.w != null && d.d != null && d.x != null && d.y != null && t !== 'agac' && t !== 'cali' && icRect(wx, wy, d.x, d.y, d.w, d.d, d.r || 0)) {
            if (p.odalar.some(o => o.kat === S.katId && G.icinde(wx, wy, o.pts))) break;
            return { tur: 'dis', id: d.id };
          }
        }
      }
    }
    const ab = aksSinir();
    for (const a of p.akslar || []) {
      const hitCoord = a.yon === 'd' ? wx : wy;
      const inRange = a.yon === 'd' ? wy > ab.y1 - 1 && wy < ab.y2 + 1 : wx > ab.x1 - 1 && wx < ab.x2 + 1;
      if (Math.abs(hitCoord - a.k) < tol && inRange) {
        const icOda = p.odalar.some(o => o.kat === S.katId && G.icinde(wx, wy, o.pts));
        if (!icOda || Math.abs(hitCoord - a.k) < tol * 0.6) return { tur: 'aks', id: a.id };
      }
    }
    for (const o of p.odalar) {
      if (o.kat === S.katId && G.icinde(wx, wy, o.pts)) return { tur: 'oda', id: o.id };
    }
    if (ki === 0 && p.arsa && G.icinde(wx, wy, p.arsa.pts)) return { tur: 'arsa', id: 'arsa' };
    return null;
  },

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  nesne(s: Secim | null): any {
    if (!s || !S.p) return null;
    const p = P();
    if (s.tur === 'arsa') return p.arsa;
    const map: Record<string, keyof typeof p> = {
      duvar: 'duvarlar',
      acik: 'aciklar',
      mobilya: 'mobilya',
      kiris: 'kirisler',
      oda: 'odalar',
      dis: 'dis',
      olcu: 'olculer',
      yazi: 'yazilar',
      aks: 'akslar',
      kesit: 'kesitler',
      tesisat: 'tesisat',
      boru: 'borular',
    };
    const key = map[s.tur];
    if (!key) return null;
    const arr = p[key] as { id: string }[];
    return arr ? arr.find(x => x.id === s.id) || null : null;
  },

  nesneMerkez(s: Secim): Pt | null {
    const o = this.nesne(s);
    if (!o) return null;
    if (o.pts) return G.merkez(o.pts);
    if (o.x1 != null) return [(o.x1 + o.x2) / 2, (o.y1 + o.y2) / 2];
    if (o.x != null) return [o.x, o.y];
    return null;
  },

  asagi(e: PointerEvent) {
    if (!this.cv || !S.p) return;
    this.cv.setPointerCapture(e.pointerId);
    this.isaretci.set(e.pointerId, { x: e.offsetX, y: e.offsetY });
    if (this.isaretci.size === 2) {
      const [a, b] = [...this.isaretci.values()];
      this.surukle = { tip: 'pinch', d: Math.hypot(a.x - b.x, a.y - b.y), m: [(a.x + b.x) / 2, (a.y + b.y) / 2] };
      return;
    }
    const sx = e.offsetX;
    const sy = e.offsetY;
    const [wx, wy] = this.dunya(sx, sy);
    this.sonTikDunya = [wx, wy];
    this.shift = e.shiftKey;
    if (e.button === 1 || e.button === 2 || this.bosluk || S.arac === 'kaydir') {
      if (e.button === 2) return;
      this.surukle = { tip: 'pan', sx, sy, tx: this.v.tx, ty: this.v.ty };
      return;
    }
    const A = S.arac;

    if (A === 'sec') {
      const h = this.isabet(wx, wy);
      if (h) {
        if (h.tur === 'uc') {
          const w = duvar(h.id)!;
          const x = h.u === 1 ? w.x1 : w.x2;
          const y = h.u === 1 ? w.y1 : w.y2;
          const bag = katDuvar().flatMap(o =>
            ([1, 2] as const)
              .filter(u => Math.hypot((u === 1 ? o.x1 : o.x2) - x, (u === 1 ? o.y1 : o.y2) - y) < 0.005)
              .map(u => ({ o, u })),
          );
          this.surukle = { tip: 'uc', bag, x0: x, y0: y, sx, sy, kayit: false };
        } else if (e.shiftKey) {
          // Shift+Tıkla ile çoklu seçim ekle/çıkar
          const idx = S.cokluSecili.findIndex(x => x.tur === h.tur && x.id === h.id);
          if (idx >= 0) S.cokluSecili.splice(idx, 1);
          else {
            if (S.secili && !S.cokluSecili.some(x => x.id === S.secili!.id && x.tur === S.secili!.tur)) {
              S.cokluSecili.push(S.secili);
            }
            S.cokluSecili.push(h);
          }
          S.secili = h;
          _cb.onRefreshPanel();
        } else {
          if (!S.cokluSecili.some(x => x.tur === h.tur && x.id === h.id)) S.cokluSecili = [];
          S.secili = h;
          const o = this.nesne(h);
          const cokluIlk = S.cokluSecili.length
            ? S.cokluSecili.map(item => ({ s: item, data: kopya(this.nesne(item)) })).filter(x => x.data)
            : undefined;
          this.surukle = { tip: 'tasi', h, wx, wy, ilk: kopya(o), cokluIlk, sx, sy, kayit: false };
          _cb.onRefreshPanel();
        }
      } else if (e.shiftKey) {
        // Shift+sürükle ile dikdörtgen çoklu seçim
        this.surukle = { tip: 'kutuSec', x0: wx, y0: wy, x1: wx, y1: wy, sx, sy };
      } else {
        S.secili = null;
        S.cokluSecili = [];
        _cb.onRefreshPanel();
        this.surukle = { tip: 'pan', sx, sy, tx: this.v.tx, ty: this.v.ty };
      }
      this.ciz();
      return;
    }

    if (A === 'ofset') {
      this.ofsetUygula(wx, wy);
      return;
    }
    if (A === 'buda') {
      this.budaUygula(wx, wy);
      return;
    }
    if (A === 'uzat') {
      this.uzatUygula(wx, wy);
      return;
    }
    if (A === 'pah') {
      this.pahUygula(wx, wy);
      return;
    }

    if (A === 'aks') {
      const q = this.yakala(sx, sy);
      const yon = e.shiftKey ? (S.aksYon === 'd' ? 'y' : 'd') : S.aksYon;
      const k = yon === 'd' ? q.x : q.y;
      if ((P().akslar || []).some(a => a.yon === yon && Math.abs(a.k - k) < 0.05)) {
        bildir('Burada zaten aks var');
        return;
      }
      degistir(() => P().akslar.push({ id: uid(), yon, k }));
      return;
    }

    if (A === 'kot') {
      const q = this.yakala(sx, sy);
      _cb
        .onPrompt('Arazi kotu (m)', fmt(ARAZI.z(q.x, q.y)), 'Bu noktanın kotu — harita/aplikasyon krokisinden ya da nivodan')
        .then(v => {
          if (v == null) return;
          const k = parseFloat(String(v).replace(',', '.'));
          if (!isNaN(k)) degistir(() => P().dis.push({ id: uid(), tip: 'kot', x: q.x, y: q.y, kot: k }));
        });
      return;
    }

    if (A === 'tesisat') {
      const q = this.yakala(sx, sy);
      const T = TES[S.tesTip];
      let x = q.x;
      let y = q.y;
      let r = S.mobRot;
      if (T?.duvar) {
        const yy = duvaraYasla(q.x, q.y, S.katId!, 0.8);
        if (yy) {
          x = yy.x;
          y = yy.y;
          r = yy.r;
        }
      }
      degistir(() => {
        const t: TesisatNokta = { id: uid(), kat: S.katId!, tip: S.tesTip, x, y, r, kot: T?.kot };
        P().tesisat.push(t);
        S.secili = { tur: 'tesisat', id: t.id };
      });
      return;
    }

    if (
      A === 'duvar' ||
      A === 'kiris' ||
      A === 'boru' ||
      (A === 'dis' && S.disTip === 'cit') ||
      A === 'arsa' ||
      A === 'olcu' ||
      A === 'alanolc' ||
      A === 'kalibre' ||
      A === 'kesit'
    ) {
      const capa = this.zincir && this.zincir.pts[this.zincir.pts.length - 1];
      const q = this.uzunlukNoktasi(capa, sx, sy) || this.yakala(sx, sy, capa, e.shiftKey);
      this.uzunluk = '';
      this.noktaEkle([q.x, q.y]);
      return;
    }

    if (A === 'odarect' || (A === 'dis' && DIS[S.disTip]?.alan)) {
      const q = this.yakala(sx, sy);
      this.uzunluk = '';
      this.surukle = { tip: 'rect', x0: q.x, y0: q.y, x1: q.x, y1: q.y };
      return;
    }

    if (A === 'odabul') {
      this.odaAlgila(wx, wy);
      return;
    }

    if (A === 'kapi' || A === 'pencere') {
      this.acikEkle(wx, wy);
      return;
    }

    if (A === 'mobilya') {
      const q = this.yakala(sx, sy);
      const T = MOB[S.mobTip];
      degistir(() => {
        const m: Mobilya = { id: uid(), kat: S.katId!, tip: S.mobTip, x: q.x, y: q.y, r: S.mobRot };
        P().mobilya.push(m);
        S.secili = { tur: 'mobilya', id: m.id };
      });
      bildir((T?.ad || 'Mobilya') + ' eklendi');
      return;
    }

    if (A === 'dis') {
      const q = this.yakala(sx, sy);
      const t = S.disTip;
      degistir(() => {
        const d: { id: string; tip: string; x: number; y: number; w?: number; d?: number; r?: number; cap?: number } = {
          id: uid(),
          tip: t,
          x: q.x,
          y: q.y,
        };
        if (t === 'araba') Object.assign(d, { w: DIS.araba.w, d: DIS.araba.d, r: S.mobRot });
        else d.cap = DIS[t]?.cap || 1;
        P().dis.push(d);
      });
      return;
    }

    if (A === 'yazi') {
      const q = this.yakala(sx, sy);
      _cb.onPrompt('Yazı', '', 'Plana eklenecek yazı').then(t => {
        if (t) degistir(() => P().yazilar.push({ id: uid(), kat: S.katId!, x: q.x, y: q.y, metin: t, boy: 12 }));
      });
    }
  },

  hareket(e: PointerEvent) {
    const sx = e.offsetX;
    const sy = e.offsetY;
    if (this.isaretci.has(e.pointerId)) this.isaretci.set(e.pointerId, { x: sx, y: sy });
    this.fare = { sx, sy };
    this.shift = e.shiftKey;
    const [wx, wy] = this.dunya(sx, sy);
    const dk = document.querySelector('#dKoord');
    if (dk) dk.innerHTML = `x: <b>${fmt(wx)}</b> y: <b>${fmt(wy)}</b> m`;
    const dOda = document.querySelector('#dOda');
    if (dOda && S.p) {
      const o = S.p.odalar.find(q => q.kat === S.katId && G.icinde(wx, wy, q.pts));
      const kz = ARAZI.var() ? ` · Kot: ${fmt(ARAZI.z(wx, wy), 2)} m` : '';
      dOda.textContent = (o ? `${o.ad} (${fmt(Math.abs(G.alan(o.pts)))} m²)` : '—') + kz;
    }

    const s = this.surukle;
    if (s) {
      if (s.tip === 'pinch' && this.isaretci.size === 2) {
        const [a, b] = [...this.isaretci.values()];
        const d = Math.hypot(a.x - b.x, a.y - b.y);
        const m: Pt = [(a.x + b.x) / 2, (a.y + b.y) / 2];
        this.v.tx += m[0] - s.m[0];
        this.v.ty += m[1] - s.m[1];
        this.zoom(d / s.d, m[0], m[1]);
        s.d = d;
        s.m = m;
        return;
      }
      if (s.tip === 'pan') {
        this.v.tx = s.tx + sx - s.sx;
        this.v.ty = s.ty + sy - s.sy;
        this.ciz();
        return;
      }
      if (s.tip === 'kutuSec') {
        s.x1 = wx;
        s.y1 = wy;
        this.ciz();
        return;
      }
      if (s.tip === 'rect') {
        const q = this.yakala(sx, sy);
        s.x1 = q.x;
        s.y1 = q.y;
        this.ciz();
        return;
      }
      if (s.tip !== 'uc' && s.tip !== 'tasi') return;
      if (Math.hypot(sx - s.sx, sy - s.sy) < 3 && !s.kayit) return;
      if (!s.kayit) {
        GECMIS.kaydet();
        s.kayit = true;
      }
      if (s.tip === 'uc') {
        const haric = new Set(s.bag.map(b => b.o.id));
        const q = this.yakalaHaric(sx, sy, haric);
        s.bag.forEach(b => {
          if (b.u === 1) {
            b.o.x1 = q.x;
            b.o.y1 = q.y;
          } else {
            b.o.x2 = q.x;
            b.o.y2 = q.y;
          }
        });
        tumAciklariDogrula(S.katId!);
        S.d3Kirli = true;
        this.ciz();
        return;
      }
      if (s.tip === 'tasi') this.tasi(s, wx, wy);
      return;
    }

    if (S.arac !== 'sec' && S.arac !== 'kaydir') {
      this.ciz();
    } else {
      const h = this.isabet(wx, wy);
      const k = JSON.stringify(h);
      if (k !== this._hk) {
        this._hk = k;
        this.vurgu = h;
        this.ciz();
      }
      if (this.cv) this.cv.style.cursor = h ? (h.tur === 'uc' ? 'crosshair' : 'move') : 'default';
    }
  },

  yakalaHaric(sx: number, sy: number, haric: Set<string>) {
    const [wx, wy] = this.dunya(sx, sy);
    const tol = 11 / this.v.z;
    for (const w of katDuvar()) {
      if (haric.has(w.id)) continue;
      for (const u of [1, 2] as const) {
        const x = u === 1 ? w.x1 : w.x2;
        const y = u === 1 ? w.y1 : w.y2;
        if (Math.hypot(x - wx, y - wy) < tol) return { x, y };
      }
    }
    return { x: r3(yuv(wx, S.grid)), y: r3(yuv(wy, S.grid)) };
  },

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  tekTasi(h: Secim, o: any, I: any, dx: number, dy: number, wx: number, wy: number) {
    if (!o || !I) return;
    if (h.tur === 'acik') {
      const w = duvar(o.duvar);
      if (!w) return;
      const L = duvarBoy(w);
      const t = G.segNokta(wx, wy, w.x1, w.y1, w.x2, w.y2).t;
      o.t = r3(sinir(yuv(t * L, S.grid), o.g / 2, L - o.g / 2) / L);
    } else if (h.tur === 'aks') {
      o.k = r3(I.k + (o.yon === 'd' ? dx : dy));
    } else if (h.tur === 'duvar' || h.tur === 'olcu' || h.tur === 'kesit' || h.tur === 'kiris' || (h.tur === 'dis' && I.x1 != null)) {
      o.x1 = r3(I.x1 + dx);
      o.y1 = r3(I.y1 + dy);
      o.x2 = r3(I.x2 + dx);
      o.y2 = r3(I.y2 + dy);
    } else if (h.tur === 'oda' || h.tur === 'arsa' || h.tur === 'boru') {
      o.pts = I.pts.map((q: Pt) => [r3(q[0] + dx), r3(q[1] + dy)]);
    } else {
      o.x = r3(I.x + dx);
      o.y = r3(I.y + dy);
      if (h.tur === 'tesisat' && TES[o.tip]?.duvar) {
        const y = duvaraYasla(o.x, o.y, o.kat, 0.5);
        if (y) {
          o.x = y.x;
          o.y = y.y;
          o.r = y.r;
        }
      }
    }
  },

  tasi(s: Extract<DragState, { tip: 'tasi' }>, wx: number, wy: number) {
    const dx = yuv(wx - s.wx, S.grid);
    const dy = yuv(wy - s.wy, S.grid);
    if (s.cokluIlk && s.cokluIlk.length > 1) {
      s.cokluIlk.forEach(item => {
        const o = this.nesne(item.s);
        this.tekTasi(item.s, o, item.data, dx, dy, wx, wy);
      });
    } else {
      const o = this.nesne(s.h);
      this.tekTasi(s.h, o, s.ilk, dx, dy, wx, wy);
    }
    S.d3Kirli = true;
    this.ciz();
  },

  yukari(e: PointerEvent) {
    this.isaretci.delete(e.pointerId);
    const s = this.surukle;
    this.surukle = null;
    if (!s) return;

    if (s.tip === 'kutuSec') {
      const x0 = Math.min(s.x0, s.x1);
      const x1 = Math.max(s.x0, s.x1);
      const y0 = Math.min(s.y0, s.y1);
      const y1 = Math.max(s.y0, s.y1);
      const p = P();
      const sel: Secim[] = [];
      const inBox = (x: number, y: number) => x >= x0 && x <= x1 && y >= y0 && y <= y1;
      katDuvar().forEach(w => {
        if (inBox((w.x1 + w.x2) / 2, (w.y1 + w.y2) / 2)) sel.push({ tur: 'duvar', id: w.id });
      });
      p.mobilya.filter(m => m.kat === S.katId).forEach(m => {
        if (inBox(m.x, m.y)) sel.push({ tur: 'mobilya', id: m.id });
      });
      (p.tesisat || []).filter(t => t.kat === S.katId).forEach(t => {
        if (inBox(t.x, t.y)) sel.push({ tur: 'tesisat', id: t.id });
      });
      (p.borular || []).filter(b => b.kat === S.katId).forEach(b => {
        if (b.pts.some(q => inBox(q[0], q[1]))) sel.push({ tur: 'boru', id: b.id });
      });
      S.cokluSecili = sel;
      S.secili = sel[0] || null;
      _cb.onRefreshPanel();
      this.ciz();
      return;
    }

    if (s.tip === 'rect') {
      const x0 = Math.min(s.x0, s.x1);
      const x1 = Math.max(s.x0, s.x1);
      const y0 = Math.min(s.y0, s.y1);
      const y1 = Math.max(s.y0, s.y1);
      if (x1 - x0 < 0.3 || y1 - y0 < 0.3) {
        this.ciz();
        return;
      }
      if (S.arac === 'odarect') {
        this.odaDikdortgenOlustur(x0, y0, x1, y1);
      } else {
        degistir(() => {
          const d = { id: uid(), tip: S.disTip, x: r3((x0 + x1) / 2), y: r3((y0 + y1) / 2), w: r3(x1 - x0), d: r3(y1 - y0), r: 0 };
          P().dis.push(d);
          S.secili = { tur: 'dis', id: d.id };
        });
      }
      return;
    }
    if ((s.tip === 'uc' || s.tip === 'tasi') && s.kayit) {
      if (s.tip === 'uc' || (s.tip === 'tasi' && s.h.tur === 'duvar')) odalariGuncelle(S.katId!);
      kaydetGecikmeli();
      _cb.onRefresh();
    }
  },

  odaDikdortgenOlustur(x0: number, y0: number, x1: number, y1: number) {
    let oda: Oda | null = null;
    degistir(() => {
      (
        [
          [x0, y0, x1, y0],
          [x1, y0, x1, y1],
          [x1, y1, x0, y1],
          [x0, y1, x0, y0],
        ] as [number, number, number, number][]
      ).forEach(q => duvarEkle(S.katId!, q[0], q[1], q[2], q[3], S.duvarK, S.duvarTur, S.duvarEgri));
      const r = odaBul(S.katId!, (x0 + x1) / 2, (y0 + y1) / 2);
      if (r && r.pts) {
        P().odalar = P().odalar.filter(o => !(o.kat === S.katId && G.icinde((x0 + x1) / 2, (y0 + y1) / 2, o.pts)));
        oda = { id: uid(), kat: S.katId!, ad: 'Oda', zemin: 'parke', pts: r.pts };
        P().odalar.push(oda);
        S.secili = { tur: 'oda', id: oda.id };
      }
      odalariGuncelle(S.katId!);
    });
    if (oda) _cb.onAskRoomName(oda);
  },

  cift(e: MouseEvent) {
    if (this.zincir) {
      this.zincirBitir();
    } else if (S.arac === 'sec') {
      const [wx, wy] = this.dunya(e.offsetX, e.offsetY);
      const h = this.isabet(wx, wy);
      if (h && h.tur === 'oda') _cb.onAskRoomName(this.nesne(h));
    }
  },

  uzunlukNoktasi(capa: Pt | null, sx: number, sy: number) {
    if (!capa || !this.uzunluk) return null;
    const L = parseFloat(this.uzunluk.replace(',', '.'));
    if (!(L > 0)) return null;
    const [wx, wy] = this.dunya(sx, sy);
    let a = Math.atan2(wy - capa[1], wx - capa[0]);
    if (S.orto && !this.shift) a = Math.round(a / (Math.PI / 4)) * (Math.PI / 4);
    return { x: r3(capa[0] + Math.cos(a) * L), y: r3(capa[1] + Math.sin(a) * L) };
  },

  noktaEkle(q: Pt) {
    const A = S.arac;
    if (!this.zincir) {
      this.zincir = { arac: A, pts: [q] };
      if (A === 'kalibre' && !P().altlik) {
        this.zincir = null;
        bildir('Önce sağ panelden bir altlık resmi yükle');
      }
      this.ciz();
      return;
    }
    const z = this.zincir;
    const son = z.pts[z.pts.length - 1];
    if (Math.hypot(q[0] - son[0], q[1] - son[1]) < 0.01) return;
    const kapandi = z.pts.length >= 2 && Math.hypot(q[0] - z.pts[0][0], q[1] - z.pts[0][1]) < 0.01;

    if (A === 'duvar') {
      degistir(() => duvarEkle(S.katId!, son[0], son[1], q[0], q[1], S.duvarK, S.duvarTur, S.duvarEgri), true);
      this.ciz();
      z.pts.push(q);
      if (kapandi) {
        this.zincirBitir(true);
        return;
      }
    } else if (A === 'kiris') {
      degistir(() => {
        const k: Kiris = { id: uid(), kat: S.katId!, x1: son[0], y1: son[1], x2: q[0], y2: q[1], w: 0.25, h: 0.5 };
        P().kirisler.push(k);
        S.secili = { tur: 'kiris', id: k.id };
      });
      this.zincir = null;
      bildir('Kiriş eklendi');
    } else if (A === 'boru') {
      z.pts.push(q);
      if (kapandi) this.zincirBitir();
    } else if (A === 'dis') {
      degistir(() => P().dis.push({ id: uid(), tip: 'cit', x1: son[0], y1: son[1], x2: q[0], y2: q[1], h: 1.6 }), true);
      z.pts.push(q);
      if (kapandi) this.zincirBitir();
    } else if (A === 'arsa' || A === 'alanolc') {
      if (kapandi) {
        this.zincirBitir();
        return;
      }
      z.pts.push(q);
    } else if (A === 'kesit') {
      degistir(() => P().kesitler.push({ id: uid(), ad: siradakiKesitAdi(), x1: son[0], y1: son[1], x2: q[0], y2: q[1], yon: 1 }));
      this.zincir = null;
      bildir('Kesit eklendi — 3D’de “Görünüş” listesinden ve paftada görebilirsin', 3500);
    } else if (A === 'olcu') {
      degistir(() => P().olculer.push({ id: uid(), kat: S.katId!, x1: son[0], y1: son[1], x2: q[0], y2: q[1] }));
      this.zincir = null;
    } else if (A === 'kalibre') {
      this.zincir = null;
      const olc = Math.hypot(q[0] - son[0], q[1] - son[1]);
      _cb.onPrompt('Gerçek uzunluk (m)', fmt(olc), 'Resimde işaretlediğin iki nokta arası gerçekte kaç metre?').then(v => {
        if (!v) return;
        const g = parseFloat(String(v).replace(',', '.'));
        if (!(g > 0)) return;
        degistir(() => {
          const a = P().altlik!;
          const f = g / olc;
          a.olcek *= f;
          a.x = r3(son[0] - (son[0] - a.x) * f);
          a.y = r3(son[1] - (son[1] - a.y) * f);
        });
        bildir('Altlık ölçeklendi');
      });
    }
    _cb.onRefreshPanel();
    this.ciz();
  },

  zincirBitir(kapali = false) {
    const z = this.zincir;
    this.zincir = null;
    this.uzunluk = '';
    if (!z) return;
    if (z.arac === 'alanolc' && z.pts.length >= 3) {
      const A = Math.abs(G.alan(z.pts));
      const C = G.cevre(z.pts);
      bildir(`Ölçülen Alan: ${fmt(A)} m² · Çevre: ${fmt(C)} m`, 5000);
      this.ciz();
      return;
    }
    if (z.arac === 'arsa' && z.pts.length >= 3) {
      degistir(() => {
        P().arsa = { pts: z.pts.map(q => [r3(q[0]), r3(q[1])] as Pt) };
        S.secili = { tur: 'arsa', id: 'arsa' };
      });
      bildir('Arsa: ' + fmt(Math.abs(G.alan(z.pts))) + ' m²');
    }
    if (z.arac === 'boru' && z.pts.length >= 2) {
      const tip = BORU_TIPLERI[S.boruTur];
      degistir(() => {
        const b: BoruHatti = {
          id: uid(),
          kat: S.katId!,
          tur: S.boruTur,
          pts: z.pts.map(q => [r3(q[0]), r3(q[1])] as Pt),
          cap: S.boruCap,
          egim: tip.varsEgim || 0,
          kot: S.boruKot,
          oto: false,
        };
        P().borular.push(b);
        S.secili = { tur: 'boru', id: b.id };
      });
      bildir(`${tip.kisa} hattı (Ø${S.boruCap}) döşendi · ${fmt(boruUzunluk({ pts: z.pts }))} m`);
    }
    if (z.arac === 'duvar') {
      odalariGuncelle(S.katId!);
      if (kapali && z.pts.length >= 4) {
        const c = G.merkez(z.pts);
        if (!P().odalar.some(o => o.kat === S.katId && G.icinde(c[0], c[1], o.pts))) {
          const r = odaBul(S.katId!, c[0], c[1]);
          if (r && r.pts) {
            const oda: Oda = { id: uid(), kat: S.katId!, ad: 'Oda', zemin: 'parke', pts: r.pts };
            P().odalar.push(oda);
            S.secili = { tur: 'oda', id: oda.id };
            kaydetGecikmeli();
            _cb.onRefresh();
            _cb.onAskRoomName(oda);
            return;
          }
        }
      }
      kaydetGecikmeli();
    }
    _cb.onRefresh();
  },

  odaAlgila(wx: number, wy: number) {
    const var_ = P().odalar.find(o => o.kat === S.katId && G.icinde(wx, wy, o.pts));
    const r = odaBul(S.katId!, wx, wy);
    if (!r) {
      bildir('Bu katta duvar yok');
      return;
    }
    if (r.duvar) {
      bildir('Duvarın üstüne tıkladın — odanın içine tıkla');
      return;
    }
    if (r.acik) {
      bildir('Kapalı alan bulunamadı — duvarlarda açık uç var, köşeleri birleştir', 4000);
      return;
    }
    if (!r.pts) return;
    let oda: Oda | undefined;
    degistir(() => {
      if (var_) {
        var_.pts = r.pts!;
        oda = var_;
      } else {
        oda = { id: uid(), kat: S.katId!, ad: 'Oda', zemin: 'parke', pts: r.pts! };
        P().odalar.push(oda);
      }
      S.secili = { tur: 'oda', id: oda!.id };
    });
    if (!var_ && oda) _cb.onAskRoomName(oda);
    else if (oda) bildir(oda.ad + ' güncellendi: ' + fmt(Math.abs(G.alan(oda.pts))) + ' m²');
  },

  acikEkle(wx: number, wy: number) {
    const y = this.enYakinDuvar(wx, wy);
    if (!y) {
      bildir('Bir duvarın üzerine tıkla');
      return;
    }
    const { w, s } = y;
    const L = duvarBoy(w);
    const pen = S.arac === 'pencere';
    const ol = pen
      ? { g: S.pencere.g, h: S.pencere.h, p: S.pencere.p, tur: 'pencere' as const }
      : { g: S.kapi.g, h: S.kapi.h, p: 0, tur: S.kapiTip };
    if (L < ol.g + 0.1) {
      bildir('Duvar bu açıklık için çok kısa (' + fmt(L) + ' m)');
      return;
    }
    const t = sinir(yuv(s.t * L, S.grid), ol.g / 2 + 0.05, L - ol.g / 2 - 0.05) / L;
    const cak = P().aciklar.find(a => a.duvar === w.id && Math.abs(a.t * L - t * L) < (a.g + ol.g) / 2);
    if (cak) {
      bildir('Burada zaten bir açıklık var');
      return;
    }
    const ux = (w.x2 - w.x1) / L;
    const uy = (w.y2 - w.y1) / L;
    const taraf = (wx - s.x) * -uy + (wy - s.y) * ux >= 0 ? 1 : -1;
    degistir(() => {
      const a: Aciklik = { id: uid(), duvar: w.id, t: r3(t), ...ol, yon: taraf, mentese: 'sol' };
      P().aciklar.push(a);
      S.secili = { tur: 'acik', id: a.id };
    });
  },

  /* ---- CAD Düzenleme Komutları: Ofset / Buda / Uzat / Pah ---- */
  ofsetUygula(wx: number, wy: number) {
    const h = this.isabet(wx, wy);
    if (!h || (h.tur !== 'duvar' && h.tur !== 'boru')) {
      bildir('Ofsetlemek için bir duvara veya boru hattına tıkla');
      return;
    }
    _cb.onPrompt('Paralel ofset mesafesi (m)', '1.50', 'Tıkladığın tarafa doğru kopyalanacak mesafe (örn. 1.5)').then(val => {
      if (!val) return;
      const dist = parseFloat(val.replace(',', '.'));
      if (!(dist > 0.05)) return;
      if (h.tur === 'duvar') {
        const w = duvar(h.id);
        if (!w) return;
        const L = duvarBoy(w) || 1;
        const nx = -(w.y2 - w.y1) / L;
        const ny = (w.x2 - w.x1) / L;
        const s = G.segNokta(wx, wy, w.x1, w.y1, w.x2, w.y2);
        const sg = (wx - s.x) * nx + (wy - s.y) * ny >= 0 ? 1 : -1;
        degistir(() => {
          duvarEkle(
            S.katId!,
            w.x1 + nx * dist * sg,
            w.y1 + ny * dist * sg,
            w.x2 + nx * dist * sg,
            w.y2 + ny * dist * sg,
            w.k,
            w.tur,
            w.egri || 0,
          );
          odalariGuncelle(S.katId!);
        });
        bildir(`Duvar ${fmt(dist)} m ofsetlendi`);
      } else if (h.tur === 'boru') {
        const b = P().borular.find(x => x.id === h.id);
        if (!b || b.pts.length < 2) return;
        const a = b.pts[0];
        const c = b.pts[1];
        const L = Math.hypot(c[0] - a[0], c[1] - a[1]) || 1;
        const nx = -(c[1] - a[1]) / L;
        const ny = (c[0] - a[0]) / L;
        const sg = (wx - a[0]) * nx + (wy - a[1]) * ny >= 0 ? 1 : -1;
        degistir(() => {
          P().borular.push({
            ...kopya(b),
            id: uid(),
            pts: b.pts.map(q => [r3(q[0] + nx * dist * sg), r3(q[1] + ny * dist * sg)] as Pt),
          });
        });
        bildir(`Boru hattı ${fmt(dist)} m paralel kopyalandı`);
      }
    });
  },

  budaUygula(wx: number, wy: number) {
    const h = this.isabet(wx, wy);
    if (!h || h.tur !== 'duvar') {
      bildir('Budamak için kesişen bir duvara tıkla');
      return;
    }
    const w = duvar(h.id);
    if (!w) return;
    const L = Math.hypot(w.x2 - w.x1, w.y2 - w.y1) || 1;
    const clickT = G.segNokta(wx, wy, w.x1, w.y1, w.x2, w.y2).t;
    const kesimler: number[] = [];
    for (const o of katDuvar()) {
      if (o.id === w.id) continue;
      const k = G.dogruKesisim(w.x1, w.y1, w.x2, w.y2, o.x1, o.y1, o.x2, o.y2, true);
      if (k && k.t > 0.02 && k.t < 0.98) kesimler.push(k.t);
    }
    if (!kesimler.length) {
      bildir('Bu duvarı kesen başka bir duvar bulunamadı');
      return;
    }
    kesimler.sort((a, b) => a - b);
    const tum = [0, ...kesimler, 1];
    let segIdx = 0;
    for (let i = 0; i + 1 < tum.length; i++) {
      if (clickT >= tum[i] && clickT <= tum[i + 1]) {
        segIdx = i;
        break;
      }
    }
    degistir(() => {
      P().duvarlar = P().duvarlar.filter(x => x.id !== w.id);
      P().aciklar = P().aciklar.filter(a => a.duvar !== w.id);
      for (let i = 0; i + 1 < tum.length; i++) {
        if (i === segIdx) continue;
        const t0 = tum[i];
        const t1 = tum[i + 1];
        if ((t1 - t0) * L < 0.05) continue;
        duvarEkle(S.katId!, w.x1 + (w.x2 - w.x1) * t0, w.y1 + (w.y2 - w.y1) * t0, w.x1 + (w.x2 - w.x1) * t1, w.y1 + (w.y2 - w.y1) * t1, w.k, w.tur);
      }
      odalariGuncelle(S.katId!);
    });
    bildir('Duvar parçası budandı');
  },

  uzatUygula(wx: number, wy: number) {
    const h = this.isabet(wx, wy);
    if (!h || h.tur !== 'duvar') {
      bildir('Uzatmak için bir duvara (ucuna yakın) tıkla');
      return;
    }
    const w = duvar(h.id);
    if (!w) return;
    const t = G.segNokta(wx, wy, w.x1, w.y1, w.x2, w.y2).t;
    const uc2 = t >= 0.5;
    const dirX = uc2 ? w.x2 - w.x1 : w.x1 - w.x2;
    const dirY = uc2 ? w.y2 - w.y1 : w.y1 - w.y2;
    const sx = uc2 ? w.x2 : w.x1;
    const sy = uc2 ? w.y2 : w.y1;
    let enU: { x: number; y: number; dist: number } | null = null;
    for (const o of katDuvar()) {
      if (o.id === w.id) continue;
      const k = G.dogruKesisim(sx, sy, sx + dirX, sy + dirY, o.x1, o.y1, o.x2, o.y2, false);
      if (!k) continue;
      if (k.t > 0.01 && k.u >= -0.02 && k.u <= 1.02) {
        const d = Math.hypot(k.x - sx, k.y - sy);
        if (d < 30 && (!enU || d < enU.dist)) enU = { x: k.x, y: k.y, dist: d };
      }
    }
    if (!enU) {
      bildir('Bu doğrultuda kesişecek hedef duvar bulunamadı');
      return;
    }
    degistir(() => {
      if (uc2) {
        w.x2 = r3(enU!.x);
        w.y2 = r3(enU!.y);
      } else {
        w.x1 = r3(enU!.x);
        w.y1 = r3(enU!.y);
      }
      odalariGuncelle(S.katId!);
    });
    bildir('Duvar hedef duvara uzatıldı');
  },

  pahUygula(wx: number, wy: number) {
    const h = this.isabet(wx, wy);
    if (!h || h.tur !== 'duvar') {
      bildir('Köşesini birleştirmek için 1. duvara tıkla');
      return;
    }
    if (!this.pahIlk || this.pahIlk === h.id) {
      this.pahIlk = h.id;
      bildir('Şimdi birleşecek 2. duvara tıkla');
      return;
    }
    const w1 = duvar(this.pahIlk);
    const w2 = duvar(h.id);
    this.pahIlk = null;
    if (!w1 || !w2) return;
    const k = G.dogruKesisim(w1.x1, w1.y1, w1.x2, w1.y2, w2.x1, w2.y1, w2.x2, w2.y2, false);
    if (!k) {
      bildir('Duvarlar paralel — kesişim yok');
      return;
    }
    degistir(() => {
      const enUcuBagla = (w: Duvar) => {
        const d1 = Math.hypot(w.x1 - k.x, w.y1 - k.y);
        const d2 = Math.hypot(w.x2 - k.x, w.y2 - k.y);
        if (d1 < d2) {
          w.x1 = k.x;
          w.y1 = k.y;
        } else {
          w.x2 = k.x;
          w.y2 = k.y;
        }
      };
      enUcuBagla(w1);
      enUcuBagla(w2);
      odalariGuncelle(S.katId!);
    });
    bildir('Duvar köşesi birleştirildi');
  },

  tus(e: KeyboardEvent): boolean {
    const sayiAraclar = ['duvar', 'arsa', 'olcu', 'alanolc', 'kesit', 'boru', 'kiris', 'dis'];
    if (this.zincir && /^[0-9.,]$/.test(e.key) && sayiAraclar.includes(S.arac)) {
      this.uzunluk += e.key;
      this.ciz();
      return true;
    }
    if ((S.arac === 'odarect' && (this.surukle?.tip === 'rect' || this.fare)) && /^[0-9.,xX*]$/.test(e.key)) {
      this.uzunluk += e.key;
      this.ciz();
      return true;
    }
    if ((this.zincir || this.uzunluk) && e.key === 'Backspace' && this.uzunluk) {
      this.uzunluk = this.uzunluk.slice(0, -1);
      this.ciz();
      return true;
    }
    if (S.arac === 'odarect' && e.key === 'Enter' && this.uzunluk) {
      const m = this.uzunluk.replace(/,/g, '.').match(/^(\d+(?:\.\d+)?)[xX*](\d+(?:\.\d+)?)$/);
      if (m) {
        const w = parseFloat(m[1]);
        const h = parseFloat(m[2]);
        if (w >= 0.5 && h >= 0.5) {
          const sx = this.surukle?.tip === 'rect' ? this.surukle.x0 : this.fare ? this.yakala(this.fare.sx, this.fare.sy).x : 0;
          const sy = this.surukle?.tip === 'rect' ? this.surukle.y0 : this.fare ? this.yakala(this.fare.sx, this.fare.sy).y : 0;
          this.surukle = null;
          this.uzunluk = '';
          this.odaDikdortgenOlustur(sx, sy, r3(sx + w), r3(sy + h));
          return true;
        }
      }
    }
    if (this.zincir && e.key === 'Enter') {
      if (this.uzunluk && this.fare) {
        const capa = this.zincir.pts[this.zincir.pts.length - 1];
        const q = this.uzunlukNoktasi(capa, this.fare.sx, this.fare.sy);
        this.uzunluk = '';
        if (q) this.noktaEkle([q.x, q.y]);
      } else {
        this.zincirBitir();
      }
      return true;
    }
    if (e.key === 'Escape') {
      if (this.zincir) this.zincirBitir();
      else if (this.surukle) this.surukle = null;
      else if (this.pahIlk) this.pahIlk = null;
      else {
        S.secili = null;
        S.cokluSecili = [];
        _cb.onRefreshPanel();
      }
      this.uzunluk = '';
      this.ciz();
      return true;
    }
    return false;
  },

  ciz() {
    if (!this.ctx || !S.p) return;
    const ctx = this.ctx;
    const W = this.W;
    const H = this.H;
    ctx.fillStyle = '#f6f8fb';
    ctx.fillRect(0, 0, W, H);
    planCiz(ctx, this.v, {
      katId: S.katId!,
      grid: true,
      w: W,
      h: H,
      altlik: true,
      dis: true,
      hayalet: true,
      olcu: S.olcuGoster,
      kuzey: true,
      tesisat: S.tesisatGoster,
      boru: S.boruGoster,
    });

    const X = (x: number) => x * this.v.z + this.v.tx;
    const Y = (y: number) => y * this.v.z + this.v.ty;

    const vurgula = (h: Secim | null, renk: string, kalin: number) => {
      if (!h) return;
      const o = this.nesne(h);
      if (!o) return;
      ctx.strokeStyle = renk;
      ctx.lineWidth = kalin;
      ctx.setLineDash(kalin > 2 ? [] : [5, 3]);
      ctx.beginPath();
      if (h.tur === 'duvar') {
        const L = duvarBoy(o) || 1;
        const nx = (-(o.y2 - o.y1) / L) * (o.k / 2);
        const ny = ((o.x2 - o.x1) / L) * (o.k / 2);
        [
          [o.x1 + nx, o.y1 + ny],
          [o.x2 + nx, o.y2 + ny],
          [o.x2 - nx, o.y2 - ny],
          [o.x1 - nx, o.y1 - ny],
        ].forEach((q, i) => (i ? ctx.lineTo(X(q[0]), Y(q[1])) : ctx.moveTo(X(q[0]), Y(q[1]))));
        ctx.closePath();
        ctx.stroke();
        if (kalin > 2) {
          ctx.fillStyle = renk;
          for (const u of [1, 2] as const) {
            ctx.beginPath();
            ctx.arc(X(u === 1 ? o.x1 : o.x2), Y(u === 1 ? o.y1 : o.y2), 5.5, 0, 7);
            ctx.fill();
          }
        }
      } else if (h.tur === 'oda' || h.tur === 'arsa') {
        o.pts.forEach((q: Pt, i: number) => (i ? ctx.lineTo(X(q[0]), Y(q[1])) : ctx.moveTo(X(q[0]), Y(q[1]))));
        ctx.closePath();
        ctx.stroke();
      } else if (h.tur === 'boru') {
        o.pts.forEach((q: Pt, i: number) => (i ? ctx.lineTo(X(q[0]), Y(q[1])) : ctx.moveTo(X(q[0]), Y(q[1]))));
        ctx.stroke();
      } else if (h.tur === 'acik') {
        const w = duvar(o.duvar);
        if (w) {
          const L = duvarBoy(w);
          const ux = (w.x2 - w.x1) / L;
          const uy = (w.y2 - w.y1) / L;
          const c = [w.x1 + ux * o.t * L, w.y1 + uy * o.t * L];
          ctx.rect(X(c[0]) - (o.g / 2) * this.v.z - 3, Y(c[1]) - (o.g / 2) * this.v.z - 3, o.g * this.v.z + 6, o.g * this.v.z + 6);
          ctx.stroke();
        }
      } else if (o.x1 != null) {
        ctx.moveTo(X(o.x1), Y(o.y1));
        ctx.lineTo(X(o.x2), Y(o.y2));
        ctx.stroke();
      } else if (o.w != null || h.tur === 'mobilya') {
        const { w, d } = h.tur === 'mobilya' ? mobOlcu(o) : o;
        [
          [-w / 2, -d / 2],
          [w / 2, -d / 2],
          [w / 2, d / 2],
          [-w / 2, d / 2],
        ].forEach((q, i) => {
          const t = G.donder(q[0], q[1], o.r || 0);
          if (i) ctx.lineTo(X(o.x + t[0]), Y(o.y + t[1]));
          else ctx.moveTo(X(o.x + t[0]), Y(o.y + t[1]));
        });
        ctx.closePath();
        ctx.stroke();
      } else if (o.cap != null) {
        ctx.arc(X(o.x), Y(o.y), (o.cap / 2) * this.v.z + 3, 0, 7);
        ctx.stroke();
      } else if (o.metin != null) {
        ctx.rect(X(o.x) - 40, Y(o.y) - 12, 80, 24);
        ctx.stroke();
      } else if (o.x != null) {
        ctx.arc(X(o.x), Y(o.y), 11, 0, 7);
        ctx.stroke();
      }
      ctx.setLineDash([]);
    };

    if (S.arac === 'sec' && this.vurgu && JSON.stringify(this.vurgu) !== JSON.stringify(S.secili)) {
      vurgula(this.vurgu, 'rgba(22,179,185,.7)', 1.5);
    }
    S.cokluSecili.forEach(s => vurgula(s, '#e8b04a', 2.2));
    vurgula(S.secili, '#16b3b9', 2.5);

    if (this.surukle && this.surukle.tip === 'kutuSec') {
      const s = this.surukle;
      ctx.save();
      ctx.fillStyle = 'rgba(63, 193, 198, 0.14)';
      ctx.strokeStyle = '#16b3b9';
      ctx.lineWidth = 1.5;
      ctx.setLineDash([4, 3]);
      const rx = X(Math.min(s.x0, s.x1));
      const ry = Y(Math.min(s.y0, s.y1));
      const rw = Math.abs(s.x1 - s.x0) * this.v.z;
      const rh = Math.abs(s.y1 - s.y0) * this.v.z;
      ctx.fillRect(rx, ry, rw, rh);
      ctx.strokeRect(rx, ry, rw, rh);
      ctx.restore();
    }

    const f = this.fare;
    if (!f) return;
    const A = S.arac;

    const nokta = (q: { x: number; y: number; tip?: SnapResult['tip'] }) => {
      const sx = X(q.x);
      const sy = Y(q.y);
      ctx.save();
      if (q.tip === 'uc') {
        ctx.fillStyle = '#e8b04a';
        ctx.beginPath();
        ctx.arc(sx, sy, 5, 0, 7);
        ctx.fill();
      } else if (q.tip === 'orta') {
        ctx.strokeStyle = '#22c55e';
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.moveTo(sx, sy - 6);
        ctx.lineTo(sx + 5, sy + 4);
        ctx.lineTo(sx - 5, sy + 4);
        ctx.closePath();
        ctx.stroke();
      } else if (q.tip === 'kesisim') {
        ctx.strokeStyle = '#a855f7';
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.moveTo(sx - 5, sy - 5);
        ctx.lineTo(sx + 5, sy + 5);
        ctx.moveTo(sx + 5, sy - 5);
        ctx.lineTo(sx - 5, sy + 5);
        ctx.stroke();
      } else if (q.tip === 'dik') {
        ctx.strokeStyle = '#16b3b9';
        ctx.lineWidth = 2;
        ctx.strokeRect(sx - 4, sy - 4, 8, 8);
      } else {
        ctx.fillStyle = '#16b3b9';
        ctx.beginPath();
        ctx.arc(sx, sy, 3.8, 0, 7);
        ctx.fill();
      }
      ctx.restore();
    };

    if (this.zincir) {
      const z = this.zincir;
      const capa = z.pts[z.pts.length - 1];
      const q = this.uzunlukNoktasi(capa, f.sx, f.sy) || this.yakala(f.sx, f.sy, capa, this.shift);
      if (A === 'alanolc') {
        const poly = [...z.pts, [q.x, q.y] as Pt];
        ctx.save();
        ctx.beginPath();
        poly.forEach((c, i) => (i ? ctx.lineTo(X(c[0]), Y(c[1])) : ctx.moveTo(X(c[0]), Y(c[1]))));
        if (poly.length >= 3) {
          ctx.closePath();
          ctx.fillStyle = 'rgba(22, 179, 185, 0.18)';
          ctx.fill();
        }
        ctx.strokeStyle = '#16b3b9';
        ctx.lineWidth = 2;
        ctx.setLineDash([5, 4]);
        ctx.stroke();
        ctx.setLineDash([]);
        const alan = poly.length >= 3 ? Math.abs(G.alan(poly)) : 0;
        const cevre = G.cevre(poly);
        const lbl = poly.length >= 3 ? `Alan: ${fmt(alan)} m² · Çevre: ${fmt(cevre)} m` : `Kenar: ${fmt(Math.hypot(q.x - capa[0], q.y - capa[1]))} m`;
        ctx.font = '700 12px system-ui';
        const tw = ctx.measureText(lbl).width;
        ctx.fillStyle = 'rgba(13,29,43,.9)';
        ctx.fillRect(f.sx + 14, f.sy + 10, tw + 14, 22);
        ctx.fillStyle = '#fff';
        ctx.fillText(lbl, f.sx + 21, f.sy + 25);
        ctx.restore();
        nokta(q);
        return;
      }
      if (A === 'boru') {
        const B = BORU_TIPLERI[S.boruTur];
        ctx.strokeStyle = B.renk;
        ctx.lineWidth = Math.max(2, (S.boruCap / 35) * (this.v.z / 40));
        if (B.cizgi.length) ctx.setLineDash(B.cizgi);
      } else {
        ctx.strokeStyle = '#16b3b9';
        ctx.lineWidth = A === 'duvar' ? Math.max(2, S.duvarK * this.v.z) : 2;
      }
      ctx.globalAlpha = A === 'duvar' ? 0.45 : 0.9;
      ctx.beginPath();
      if (A === 'arsa' || A === 'boru') {
        z.pts.forEach((c, i) => (i ? ctx.lineTo(X(c[0]), Y(c[1])) : ctx.moveTo(X(c[0]), Y(c[1]))));
      } else {
        ctx.moveTo(X(capa[0]), Y(capa[1]));
      }
      if (A === 'duvar' && Math.abs(S.duvarEgri) > 0.01) {
        G.egriNoktalar(capa[0], capa[1], q.x, q.y, S.duvarEgri, 14).forEach((pt, i) =>
          i ? ctx.lineTo(X(pt[0]), Y(pt[1])) : ctx.moveTo(X(pt[0]), Y(pt[1])),
        );
      } else {
        ctx.lineTo(X(q.x), Y(q.y));
      }
      ctx.stroke();
      ctx.setLineDash([]);
      ctx.globalAlpha = 1;
      const L = Math.hypot(q.x - capa[0], q.y - capa[1]);
      const deg = Math.round(((Math.atan2(q.y - capa[1], q.x - capa[0]) / RAD) + 360) % 360);
      ctx.font = '600 12px system-ui';
      const t = (this.uzunluk ? '⌨ ' + this.uzunluk : fmt(L)) + ` m · ${deg}°`;
      ctx.fillStyle = 'rgba(13,29,43,.88)';
      const tw = ctx.measureText(t).width;
      ctx.fillRect(f.sx + 14, f.sy + 10, tw + 12, 20);
      ctx.fillStyle = '#fff';
      ctx.fillText(t, f.sx + 20, f.sy + 24);
      nokta(q);
      return;
    }

    if (this.surukle && this.surukle.tip === 'rect') {
      const s = this.surukle;
      ctx.strokeStyle = '#16b3b9';
      ctx.lineWidth = 2;
      ctx.setLineDash([6, 4]);
      ctx.strokeRect(X(Math.min(s.x0, s.x1)), Y(Math.min(s.y0, s.y1)), Math.abs(s.x1 - s.x0) * this.v.z, Math.abs(s.y1 - s.y0) * this.v.z);
      ctx.setLineDash([]);
      ctx.font = '600 12px system-ui';
      ctx.fillStyle = '#0d1d2b';
      const etiket = this.uzunluk
        ? `⌨ ${this.uzunluk} (Enter: oluştur)`
        : `${fmt(Math.abs(s.x1 - s.x0))} × ${fmt(Math.abs(s.y1 - s.y0))} m = ${fmt(Math.abs((s.x1 - s.x0) * (s.y1 - s.y0)))} m²`;
      ctx.fillText(etiket, f.sx + 14, f.sy + 24);
      return;
    }

    if (A === 'odarect' && this.uzunluk) {
      ctx.font = '600 12px system-ui';
      const t = `⌨ Oda: ${this.uzunluk} m (Enter)`;
      const tw = ctx.measureText(t).width;
      ctx.fillStyle = 'rgba(13,29,43,.88)';
      ctx.fillRect(f.sx + 14, f.sy + 10, tw + 12, 20);
      ctx.fillStyle = '#fff';
      ctx.fillText(t, f.sx + 20, f.sy + 24);
    }

    if (A === 'aks') {
      const q = this.yakala(f.sx, f.sy);
      const yon = this.shift ? (S.aksYon === 'd' ? 'y' : 'd') : S.aksYon;
      ctx.strokeStyle = '#c0392b';
      ctx.setLineDash([14, 4, 2, 4]);
      ctx.beginPath();
      if (yon === 'd') {
        ctx.moveTo(X(q.x), 0);
        ctx.lineTo(X(q.x), this.H);
      } else {
        ctx.moveTo(0, Y(q.y));
        ctx.lineTo(this.W, Y(q.y));
      }
      ctx.stroke();
      ctx.setLineDash([]);
    }

    if (A === 'tesisat') {
      const q = this.yakala(f.sx, f.sy);
      const T = TES[S.tesTip];
      let t = { tip: S.tesTip, x: q.x, y: q.y, r: S.mobRot };
      if (T?.duvar) {
        const yy = duvaraYasla(q.x, q.y, S.katId!, 0.8);
        if (yy) t = { ...t, x: yy.x, y: yy.y, r: yy.r };
      }
      tesisatSembol(ctx, t, X, Y, this.v.z, {}, true);
    }

    if (
      ['duvar', 'odarect', 'arsa', 'olcu', 'alanolc', 'kalibre', 'yazi', 'kot', 'kesit', 'boru', 'kiris'].includes(A) ||
      (A === 'dis' && (DIS[S.disTip]?.alan || S.disTip === 'cit'))
    ) {
      nokta(this.yakala(f.sx, f.sy));
    }

    if (A === 'kapi' || A === 'pencere') {
      const [wx, wy] = this.dunya(f.sx, f.sy);
      const y = this.enYakinDuvar(wx, wy);
      if (y) {
        const g = A === 'pencere' ? S.pencere.g : S.kapi.g;
        const L = duvarBoy(y.w);
        const ux = (y.w.x2 - y.w.x1) / L;
        const uy = (y.w.y2 - y.w.y1) / L;
        const m = sinir(y.s.t * L, g / 2, L - g / 2);
        ctx.strokeStyle = '#16b3b9';
        ctx.lineWidth = Math.max(3, y.w.k * this.v.z);
        ctx.globalAlpha = 0.6;
        ctx.beginPath();
        ctx.moveTo(X(y.w.x1 + ux * (m - g / 2)), Y(y.w.y1 + uy * (m - g / 2)));
        ctx.lineTo(X(y.w.x1 + ux * (m + g / 2)), Y(y.w.y1 + uy * (m + g / 2)));
        ctx.stroke();
        ctx.globalAlpha = 1;
      }
    }

    if (A === 'mobilya') {
      const q = this.yakala(f.sx, f.sy);
      mobilyaCiz(ctx, { tip: S.mobTip, x: q.x, y: q.y, r: S.mobRot }, X, Y, this.v.z, RENK.ekran, {}, true);
    }

    if (A === 'dis' && (S.disTip === 'agac' || S.disTip === 'cali' || S.disTip === 'araba')) {
      const q = this.yakala(f.sx, f.sy);
      ctx.strokeStyle = '#16b3b9';
      ctx.beginPath();
      ctx.arc(X(q.x), Y(q.y), (S.disTip === 'araba' ? 2 : (DIS[S.disTip].cap || 1) / 2) * this.v.z, 0, 7);
      ctx.stroke();
    }
  },
};
