import { BORU_TIPLERI, DIS, MOB, TES, mobOlcu } from './catalog';
import {
  ARAZI,
  P,
  S,
  aksAdlari,
  cekmePoligonHesap,
  degistir,
  duvarBoy,
  duvarEkle,
  duvarParcalari,
  kirisListesi,
  odalariGuncelle,
} from './core';
import { G, Pt } from './geometry';
import { aksSinir } from './plan2d';
import type { BoruTuru } from './types';
import { RAD, asc, fmt, r3 } from './utils';

const BORU_LAYER: Record<BoruTuru, { lay: string; aci: number; lt: string }> = {
  temiz_su_soguk: { lay: 'BORU_SU', aci: 5, lt: 'CONTINUOUS' },
  temiz_su_sicak: { lay: 'BORU_SU_SICAK', aci: 1, lt: 'DASHED' },
  pis_su: { lay: 'BORU_PISSU', aci: 32, lt: 'CONTINUOUS' },
  kalorifer: { lay: 'BORU_ISITMA', aci: 30, lt: 'DASHDOT' },
  elektrik_kablo: { lay: 'BORU_ELEKTRIK', aci: 1, lt: 'DASHED' },
  dogalgaz: { lay: 'BORU_GAZ', aci: 2, lt: 'DASHDOT' },
};

export function dxfUret(unicode = false): string {
  const s: string[] = [];
  const p = P();
  const yz = (m: unknown) => (unicode ? String(m) : asc(String(m)));
  const e = (...a: (string | number)[]) => a.forEach(x => s.push(String(x)));
  const L = (x1: number, y1: number, x2: number, y2: number, l: string, lt = 'CONTINUOUS') =>
    e(0, 'LINE', 8, l, 6, lt, 10, x1.toFixed(4), 20, (-y1).toFixed(4), 30, 0, 11, x2.toFixed(4), 21, (-y2).toFixed(4), 31, 0);
  const PL = (pts: Pt[], c: boolean, l: string, lt = 'CONTINUOUS') => {
    e(0, 'LWPOLYLINE', 8, l, 6, lt, 90, pts.length, 70, c ? 1 : 0);
    pts.forEach(q => e(10, q[0].toFixed(4), 20, (-q[1]).toFixed(4)));
  };
  const TX = (x: number, y: number, m: string, h: number, l: string) =>
    e(0, 'TEXT', 8, l, 10, x.toFixed(4), 20, (-y).toFixed(4), 30, 0, 40, h.toFixed(3), 1, yz(m));
  const CR = (x: number, y: number, r: number, l: string) =>
    e(0, 'CIRCLE', 8, l, 10, x.toFixed(4), 20, (-y).toFixed(4), 30, 0, 40, r.toFixed(4));

  e(0, 'SECTION', 2, 'HEADER');
  e(9, '$ACADVER', 1, 'AC1015');
  e(9, '$INSUNITS', 70, 6); // 6 = metre
  e(0, 'ENDSEC');

  e(0, 'SECTION', 2, 'TABLES');
  e(0, 'TABLE', 2, 'LTYPE', 70, 3);
  e(0, 'LTYPE', 2, 'CONTINUOUS', 70, 0, 3, 'Solid line', 72, 65, 73, 0, 40, 0.0);
  e(0, 'LTYPE', 2, 'DASHED', 70, 0, 3, 'Dashed', 72, 65, 73, 2, 40, 0.4, 49, 0.25, 49, -0.15);
  e(0, 'LTYPE', 2, 'DASHDOT', 70, 0, 3, 'Dash dot', 72, 65, 73, 4, 40, 0.5, 49, 0.25, 49, -0.1, 49, 0.05, 49, -0.1);
  e(0, 'ENDTAB');

  const katmanlar: [string, number, string][] = [
    ['DUVAR', 7, 'CONTINUOUS'],
    ['KAPI', 30, 'CONTINUOUS'],
    ['PENCERE', 4, 'CONTINUOUS'],
    ['ODA', 252, 'CONTINUOUS'],
    ['MOBILYA', 8, 'CONTINUOUS'],
    ['AKSLAR', 1, 'DASHDOT'],
    ['KIRIS', 6, 'DASHED'],
    ['KESIT', 1, 'DASHDOT'],
    ['OLCU', 5, 'CONTINUOUS'],
    ['YAZI', 7, 'CONTINUOUS'],
    ['TESISAT', 6, 'CONTINUOUS'],
    ['BORU_SU', 5, 'CONTINUOUS'],
    ['BORU_SU_SICAK', 1, 'DASHED'],
    ['BORU_PISSU', 32, 'CONTINUOUS'],
    ['BORU_ISITMA', 30, 'DASHDOT'],
    ['BORU_ELEKTRIK', 1, 'DASHED'],
    ['BORU_GAZ', 2, 'DASHDOT'],
    ['ARSA', 2, 'DASHED'],
    ['CEKME', 4, 'DASHED'],
    ['PEYZAJ', 3, 'CONTINUOUS'],
    ['ARAZI', 9, 'CONTINUOUS'],
  ];
  e(0, 'TABLE', 2, 'LAYER', 70, katmanlar.length);
  katmanlar.forEach(([ad, aci, lt]) => {
    e(0, 'LAYER', 2, ad, 70, 0, 62, aci, 6, lt);
  });
  e(0, 'ENDTAB');
  e(0, 'ENDSEC');

  e(0, 'SECTION', 2, 'ENTITIES');
  let of = 0;
  const pts: Pt[] = [];
  p.duvarlar.forEach(w => pts.push([w.x1, w.y1], [w.x2, w.y2]));
  const gen = pts.length ? G.bbox(pts).w + 14 : 24;

  p.katlar.forEach((K, ki) => {
    const ox = ki * gen;
    of = Math.max(of, ox);
    TX(ox, -2.5, K.ad, 0.5, 'YAZI');
    p.duvarlar
      .filter(w => w.kat === K.id)
      .forEach(w => {
        if (w.egri && Math.abs(w.egri) > 0.01) {
          const ep = G.egriNoktalar(w.x1, w.y1, w.x2, w.y2, w.egri, 14);
          for (let off = -w.k / 2; off <= w.k / 2; off += w.k) {
            const pOff = ep.map((pt, idx) => {
              const prev = ep[Math.max(0, idx - 1)];
              const next = ep[Math.min(ep.length - 1, idx + 1)];
              const dx = next[0] - prev[0];
              const dy = next[1] - prev[1];
              const l = Math.hypot(dx, dy) || 1;
              return [ox + pt[0] + (-dy / l) * off, pt[1] + (dx / l) * off] as Pt;
            });
            PL(pOff, false, 'DUVAR');
          }
          return;
        }
        const pr = duvarParcalari(w);
        const ux = (w.x2 - w.x1) / (pr.L || 1);
        const uy = (w.y2 - w.y1) / (pr.L || 1);
        const nx = (-uy * w.k) / 2;
        const ny = (ux * w.k) / 2;
        for (const [a, b] of pr.tam) {
          const ax = ox + w.x1 + ux * a;
          const ay = w.y1 + uy * a;
          const bx = ox + w.x1 + ux * b;
          const by = w.y1 + uy * b;
          L(ax + nx, ay + ny, bx + nx, by + ny, 'DUVAR');
          L(ax - nx, ay - ny, bx - nx, by - ny, 'DUVAR');
          L(ax + nx, ay + ny, ax - nx, ay - ny, 'DUVAR');
          L(bx + nx, by + ny, bx - nx, by - ny, 'DUVAR');
        }
        for (const { a, s: ss, e: ee } of pr.acik) {
          const ax = ox + w.x1 + ux * ss;
          const ay = w.y1 + uy * ss;
          const bx = ox + w.x1 + ux * ee;
          const by = w.y1 + uy * ee;
          const lay = a.tur === 'pencere' || a.tur === 'cati_pencere' ? 'PENCERE' : 'KAPI';
          L(ax, ay, bx, by, lay);
        }
      });

    p.odalar
      .filter(o => o.kat === K.id)
      .forEach(o => {
        PL(
          o.pts.map(q => [ox + q[0], q[1]] as Pt),
          true,
          'ODA',
        );
        const c = G.merkez(o.pts);
        TX(ox + c[0], c[1], o.ad + ' ' + fmt(Math.abs(G.alan(o.pts))) + 'm2', 0.25, 'YAZI');
      });

    p.mobilya
      .filter(o => o.kat === K.id)
      .forEach(o => {
        const { w, d } = mobOlcu(o);
        PL(
          (
            [
              [-w / 2, -d / 2],
              [w / 2, -d / 2],
              [w / 2, d / 2],
              [-w / 2, d / 2],
            ] as Pt[]
          ).map(q => {
            const t = G.donder(q[0], q[1], o.r || 0);
            return [ox + o.x + t[0], o.y + t[1]] as Pt;
          }),
          true,
          'MOBILYA',
        );
      });

    // Kirişler
    kirisListesi(K.id).forEach(k => {
      L(ox + k.a.x, k.a.y, ox + k.b.x, k.b.y, 'KIRIS', 'DASHED');
    });

    // Tesisat noktaları
    (p.tesisat || [])
      .filter(t => t.kat === K.id)
      .forEach(t => {
        CR(ox + t.x, t.y, 0.14, 'TESISAT');
        TX(ox + t.x + 0.18, t.y, TES[t.tip]?.ad || t.tip, 0.16, 'TESISAT');
      });

    // Boru döşeme hatları
    (p.borular || [])
      .filter(b => b.kat === K.id)
      .forEach(b => {
        const bl = BORU_LAYER[b.tur] || { lay: 'TESISAT', lt: 'CONTINUOUS' };
        PL(
          b.pts.map(pt => [ox + pt[0], pt[1]] as Pt),
          false,
          bl.lay,
          bl.lt,
        );
        if (b.pts.length >= 2) {
          const mx = ox + (b.pts[0][0] + b.pts[1][0]) / 2;
          const my = (b.pts[0][1] + b.pts[1][1]) / 2;
          TX(mx, my - 0.15, `${BORU_TIPLERI[b.tur]?.kisa || b.tur} O${b.cap}`, 0.15, bl.lay);
        }
      });

    p.olculer
      .filter(o => o.kat === K.id)
      .forEach(o => {
        L(ox + o.x1, o.y1, ox + o.x2, o.y2, 'OLCU');
        TX(ox + (o.x1 + o.x2) / 2, (o.y1 + o.y2) / 2, fmt(Math.hypot(o.x2 - o.x1, o.y2 - o.y1)) + 'm', 0.2, 'OLCU');
      });

    p.yazilar
      .filter(y => y.kat === K.id)
      .forEach(y => TX(ox + y.x, y.y, y.metin, y.boy || 0.25, 'YAZI'));

    if (ki === 0) {
      const b = aksSinir();
      const ad = aksAdlari();
      (p.akslar || []).forEach(a => {
        if (a.yon === 'd') {
          L(ox + a.k, b.y1, ox + a.k, b.y2, 'AKSLAR', 'DASHDOT');
          TX(ox + a.k, b.y1 - 0.35, ad[a.id] || '', 0.3, 'AKSLAR');
        } else {
          L(ox + b.x1, a.k, ox + b.x2, a.k, 'AKSLAR', 'DASHDOT');
          TX(ox + b.x1 - 0.5, a.k, ad[a.id] || '', 0.3, 'AKSLAR');
        }
      });
      (p.kesitler || []).forEach(k => {
        L(ox + k.x1, k.y1, ox + k.x2, k.y2, 'KESIT', 'DASHDOT');
        TX(ox + k.x1, k.y1 - 0.3, `${k.ad}-${k.ad}`, 0.32, 'KESIT');
      });
    }
  });

  if (p.arsa) PL(p.arsa.pts, true, 'ARSA', 'DASHED');
  const cek = cekmePoligonHesap();
  if (cek) PL(cek, true, 'CEKME', 'DASHED');

  ARAZI.noktalar().forEach(n => {
    CR(n.x ?? 0, n.y ?? 0, 0.15, 'ARAZI');
    TX((n.x ?? 0) + 0.25, n.y ?? 0, fmt(n.kot ?? 0) + 'm', 0.2, 'ARAZI');
  });

  (p.dis || []).forEach(d => {
    if (d.tip === 'agac' || d.tip === 'cali') CR(d.x!, d.y!, (d.cap || 1) / 2, 'PEYZAJ');
    else if (d.tip === 'cit') L(d.x1!, d.y1!, d.x2!, d.y2!, 'PEYZAJ');
    else if (DIS[d.tip]?.alan) {
      PL(
        [
          [d.x1!, d.y1!],
          [d.x2!, d.y1!],
          [d.x2!, d.y2!],
          [d.x1!, d.y2!],
        ],
        true,
        'PEYZAJ',
      );
    }
  });

  // Referans
  void of;
  void MOB;
  void duvarBoy;
  void RAD;

  e(0, 'ENDSEC', 0, 'EOF');
  return s.join('\n');
}

/* Basit & Güvenilir ASCII DXF İçeri Aktarıcı (LINE ve LWPOLYLINE) */
export function dxfIceAktar(raw: string): { duvarSay: number; arsaVar: boolean } {
  const lines = raw.replace(/\r/g, '').split('\n');
  const segs: { x1: number; y1: number; x2: number; y2: number; layer: string }[] = [];
  const polys: { pts: Pt[]; closed: boolean; layer: string }[] = [];

  let i = 0;
  const nextPair = (): [number, string] | null => {
    if (i + 1 >= lines.length) return null;
    const code = parseInt(lines[i].trim(), 10);
    const val = lines[i + 1].trim();
    i += 2;
    return [Number.isNaN(code) ? -1 : code, val];
  };

  let curEnt = '';
  let layer = '0';
  let x1 = 0, y1 = 0, x2 = 0, y2 = 0;
  let polyPts: Pt[] = [];
  let polyX: number | null = null;
  let polyClosed = false;

  const flushEnt = () => {
    if (curEnt === 'LINE') {
      if (Math.hypot(x2 - x1, y2 - y1) > 0.05) segs.push({ x1, y1: -y1, x2, y2: -y2, layer });
    } else if (curEnt === 'LWPOLYLINE' && polyPts.length >= 2) {
      polys.push({ pts: polyPts.map(q => [q[0], -q[1]] as Pt), closed: polyClosed, layer });
    }
    curEnt = '';
    layer = '0';
    polyPts = [];
    polyX = null;
    polyClosed = false;
  };

  while (i + 1 < lines.length) {
    const p = nextPair();
    if (!p) break;
    const [code, val] = p;
    if (code === 0) {
      flushEnt();
      if (val === 'LINE' || val === 'LWPOLYLINE') curEnt = val;
      continue;
    }
    if (!curEnt) continue;
    if (code === 8) layer = val.toUpperCase();
    if (curEnt === 'LINE') {
      if (code === 10) x1 = parseFloat(val) || 0;
      else if (code === 20) y1 = parseFloat(val) || 0;
      else if (code === 11) x2 = parseFloat(val) || 0;
      else if (code === 21) y2 = parseFloat(val) || 0;
    } else if (curEnt === 'LWPOLYLINE') {
      if (code === 70) polyClosed = (parseInt(val, 10) & 1) === 1;
      else if (code === 10) polyX = parseFloat(val) || 0;
      else if (code === 20 && polyX != null) {
        polyPts.push([polyX, parseFloat(val) || 0]);
        polyX = null;
      }
    }
  }
  flushEnt();

  const allPts: Pt[] = [];
  segs.forEach(sg => allPts.push([sg.x1, sg.y1], [sg.x2, sg.y2]));
  polys.forEach(pl => pl.pts.forEach(q => allPts.push(q)));
  if (!allPts.length) return { duvarSay: 0, arsaVar: false };

  const b = G.bbox(allPts);
  // Milimetre/santimetre çizimler (> 500 birim) otomatik metreye ölçeklenir
  const maxDim = Math.max(b.w, b.h);
  const scale = maxDim > 1000 ? 0.001 : maxDim > 120 ? 0.01 : 1;
  const ox = b.x1 * scale;
  const oy = b.y1 * scale;

  let duvarSay = 0;
  let arsaVar = false;
  degistir(() => {
    segs.forEach(sg => {
      duvarEkle(
        S.katId!,
        r3(sg.x1 * scale - ox),
        r3(sg.y1 * scale - oy),
        r3(sg.x2 * scale - ox),
        r3(sg.y2 * scale - oy),
        sg.layer.includes('IC') ? 0.12 : 0.25,
        sg.layer.includes('IC') ? 'ic' : 'dis',
      );
      duvarSay++;
    });
    polys.forEach(pl => {
      const scaled = pl.pts.map(q => [r3(q[0] * scale - ox), r3(q[1] * scale - oy)] as Pt);
      if (pl.layer.includes('ARSA') || pl.layer.includes('PARSEL')) {
        P().arsa = { pts: scaled };
        arsaVar = true;
      } else {
        for (let k = 0; k + 1 < scaled.length; k++) {
          duvarEkle(S.katId!, scaled[k][0], scaled[k][1], scaled[k + 1][0], scaled[k + 1][1], 0.25, 'dis');
          duvarSay++;
        }
        if (pl.closed && scaled.length >= 3) {
          const son = scaled[scaled.length - 1];
          duvarEkle(S.katId!, son[0], son[1], scaled[0][0], scaled[0][1], 0.25, 'dis');
          duvarSay++;
        }
      }
    });
    odalariGuncelle(S.katId!);
  });

  return { duvarSay, arsaVar };
}
