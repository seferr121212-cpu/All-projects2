import {
  BLOK,
  BORU_TIPLERI,
  CATI,
  DIS,
  DOGRAMA_RENK,
  MOB,
  MOB_KAT,
  ODA_ADLARI,
  TES,
  ZEMIN,
  mobOlcu,
} from './catalog';
import {
  ARAZI,
  GECMIS,
  P,
  S,
  acikDogrula,
  baglaYenile,
  cekmePoligonHesap,
  degistir,
  duvar,
  duvarBoy,
  gunesAnalizi,
  gunesKonum,
  kat,
  katIdx,
  katOturum,
  katTaban,
  kaydetGecikmeli,
  kirisListesi,
  odaBul,
  odalariGuncelle,
  paraYaz,
  planKontrol,
  yeniProje,
} from './core';
import { dxfIceAktar, dxfUret } from './dxf';
import { G, Pt } from './geometry';
import { LOGO } from './logo';
import { boruUzunluk, mepMuhendislikHesap, otomatikBoruDose, otomatikTesisat } from './mep';
import { ARACLAR, IPUCU, PLAN, baglaPlanOlay, mobilyaCiz, otomatikOlcule } from './plan2d';
import { SABLONLAR, ornekProje, planUret, yaziyiAnla } from './planGen';
import { PAFTA, paftaSayfa } from './sheets';
import { DEPO } from './storage';
import { metrajHesap, metrajSayfa } from './takeoff';
import type { AciklikTuru, BoruTuru, DisiplinModu, KatmanAyar, Proje } from './types';
import { RAD, asc, bildir, esc, fmt, indir, kopya, r3, saatYaz, sinir, tarihTR, uid } from './utils';
import { D3, D3HitBox, KAPLAMA, bagla3DOlay } from './webgl3d';

const $ = (s: string, r: ParentNode = document) => r.querySelector(s) as HTMLElement | null;
const $$ = (s: string, r: ParentNode = document) => [...r.querySelectorAll(s)] as HTMLElement[];

export function diy(baslik: string, icHtml: string, dugmeler: { t: string; ana?: boolean; f: () => void }[]) {
  const perde = $('#perde')!;
  perde.innerHTML = `<div class="diyalog"><header><span>${baslik}</span><button class="ubtn" id="dKap">✕</button></header><div class="ic">${icHtml}</div><footer></footer></div>`;
  const ft = $('footer', perde)!;
  dugmeler.forEach(d => {
    const b = document.createElement('button');
    b.className = 'ubtn' + (d.ana ? ' ana' : '');
    b.textContent = d.t;
    b.onclick = d.f;
    ft.appendChild(b);
  });
  $('#dKap', perde)!.onclick = kapatDiy;
  perde.classList.add('acik');
}

export function kapatDiy() {
  $('#perde')?.classList.remove('acik');
}

export function mesajDiy(baslik: string, metin: string) {
  diy(baslik, `<p style="line-height:1.6">${esc(metin)}</p>`, [{ t: 'Tamam', ana: true, f: kapatDiy }]);
}

function onayDiy(baslik: string, metin: string, evet: () => void) {
  diy(baslik, `<p>${esc(metin)}</p>`, [
    { t: 'Vazgeç', f: kapatDiy },
    {
      t: 'Evet',
      ana: true,
      f: () => {
        kapatDiy();
        evet();
      },
    },
  ]);
}

function girdiDiy(baslik: string, etiket: string, varsayilan: string, tip: 'text' | 'number', evet: (v: string) => void) {
  diy(baslik, `<label class="alan"><span>${esc(etiket)}</span><input id="dGirdi" type="${tip}" value="${esc(varsayilan)}"></label>`, [
    { t: 'İptal', f: kapatDiy },
    {
      t: 'Tamam',
      ana: true,
      f: () => {
        const v = ($('#dGirdi') as HTMLInputElement).value;
        kapatDiy();
        evet(v);
      },
    },
  ]);
  setTimeout(() => {
    const inp = $('#dGirdi') as HTMLInputElement | null;
    if (inp) {
      inp.focus();
      inp.select();
      inp.onkeydown = e => {
        if (e.key === 'Enter') ($('#perde footer .ana') as HTMLButtonElement | null)?.click();
      };
    }
  }, 20);
}

/* Durum & Seçenek Çubuğu */
export function aracSec(id: string) {
  PLAN.zincir = null;
  PLAN.uzunluk = '';
  PLAN.pahIlk = null;
  S.arac = id;
  $$('.arac').forEach(b => b.classList.toggle('aktif', b.dataset.id === id));
  const ar = ARACLAR.find(x => x.id === id);
  const dArac = $('#dArac');
  if (dArac) dArac.textContent = ar ? ar.ad : '';
  const c2d = $('#c2d');
  if (c2d) c2d.style.cursor = id === 'kaydir' ? 'grab' : id === 'sec' ? 'default' : 'crosshair';
  secenekKur();
  panelKur();
  PLAN.ciz();
}

export function secenekKur() {
  const B = $('#secenek');
  if (!B) return;
  const A = S.arac;
  let h = '';
  if (A === 'duvar') {
    h = `<label>Tür <select id="sTur"><option value="dis"${S.duvarTur === 'dis' ? ' selected' : ''}>Dış (25 cm)</option><option value="ic"${S.duvarTur === 'ic' ? ' selected' : ''}>İç (12 cm)</option></select></label>
         <label>Kalınlık (cm) <input type="number" id="sKal" min="5" max="60" value="${Math.round(S.duvarK * 100)}"></label>
         <label>Kavis (cm) <input type="number" id="sEgri" min="-400" max="400" step="10" value="${Math.round(S.duvarEgri * 100)}" title="0 = düz duvar, ±cm = eğrisel kavis yüksekliği"></label>`;
  } else if (A === 'kapi') {
    h = `<label>Tip <select id="sKTip">
          <option value="kapi"${S.kapiTip === 'kapi' ? ' selected' : ''}>Tek kanatlı kapı</option>
          <option value="cift_kapi"${S.kapiTip === 'cift_kapi' ? ' selected' : ''}>Çift kanatlı kapı</option>
          <option value="surme"${S.kapiTip === 'surme' ? ' selected' : ''}>Sürme cam kapı</option>
          <option value="balkon"${S.kapiTip === 'balkon' ? ' selected' : ''}>Balkon kapısı</option>
         </select></label>
         <label>Genişlik (cm) <input type="number" id="sKG" min="60" max="420" step="10" value="${Math.round(S.kapi.g * 100)}"></label>
         <label>Yükseklik (cm) <input type="number" id="sKH" min="180" max="260" step="10" value="${Math.round(S.kapi.h * 100)}"></label>`;
  } else if (A === 'pencere') {
    h = `<label>Tür <select id="sPTip"><option value="pencere"${S.kapiTip !== 'cati_pencere' ? ' selected' : ''}>Cephe penceresi</option><option value="cati_pencere"${S.kapiTip === 'cati_pencere' ? ' selected' : ''}>Çatı penceresi</option></select></label>
         <label>Genişlik (cm) <input type="number" id="sPG" min="40" max="400" step="10" value="${Math.round(S.pencere.g * 100)}"></label>
         <label>Yükseklik (cm) <input type="number" id="sPH" min="40" max="240" step="10" value="${Math.round(S.pencere.h * 100)}"></label>
         <label>Parapet (cm) <input type="number" id="sPP" min="0" max="180" step="10" value="${Math.round(S.pencere.p * 100)}"></label>`;
  } else if (A === 'aks') {
    h = `<label>Yön <select id="sAY"><option value="d"${S.aksYon === 'd' ? ' selected' : ''}>Dikey (1, 2…)</option><option value="y"${S.aksYon === 'y' ? ' selected' : ''}>Yatay (A, B…)</option></select></label>
         <label>Kolon (cm) <input type="number" id="sAK" min="20" max="100" step="5" value="${Math.round(S.kolonBoyut * 100)}"></label>
         <button class="ubtn" id="sAKol">Kolonları yerleştir</button><button class="ubtn" id="sAOto">Otomatik akslar</button>`;
  } else if (A === 'boru') {
    h = `<label>Sistem <select id="sBTur">${(Object.keys(BORU_TIPLERI) as BoruTuru[]).map(k => `<option value="${k}"${S.boruTur === k ? ' selected' : ''}>${BORU_TIPLERI[k].kisa}</option>`).join('')}</select></label>
         <label>Çap (mm) <select id="sBCap">${BORU_TIPLERI[S.boruTur].caplar.map(c => `<option value="${c}"${S.boruCap === c ? ' selected' : ''}>Ø${c}</option>`).join('')}</select></label>
         <label>Kot (cm) <input type="number" id="sBKot" min="-100" max="320" step="5" value="${Math.round(S.boruKot * 100)}"></label>
         <button class="ubtn ana" id="sBOto">Otomatik boru döşe</button>
         <button class="ubtn" id="sBTmz" title="Otomatik boruları temizle">Oto temizle</button>`;
  } else if (A === 'tesisat') {
    h = `<label><input type="checkbox" id="sTG" ${S.tesisatGoster ? 'checked' : ''}> Semboller</label>
         <label><input type="checkbox" id="sBG" ${S.boruGoster ? 'checked' : ''}> Borular</label>
         <button class="ubtn" id="sTOto">Otomatik tesisat + boru</button>
         <button class="ubtn" id="sTTmz">Temizle</button>`;
  }

  h += `<span class="ayrac" style="width:1px;height:20px;background:var(--cizgi);flex-shrink:0"></span>
    <label>Disiplin <select id="sDisiplin" title="Çizim görünüm disiplini">
      <option value="tumu"${S.disiplin === 'tumu' ? ' selected' : ''}>Tümü</option>
      <option value="mimari"${S.disiplin === 'mimari' ? ' selected' : ''}>Mimari</option>
      <option value="statik"${S.disiplin === 'statik' ? ' selected' : ''}>Statik</option>
      <option value="sihhi"${S.disiplin === 'sihhi' ? ' selected' : ''}>Sıhhi</option>
      <option value="elektrik"${S.disiplin === 'elektrik' ? ' selected' : ''}>Elektrik</option>
    </select></label>
    <label>Izgara <select id="sGrid"><option value="0.01"${S.grid === 0.01 ? ' selected' : ''}>1 cm</option><option value="0.05"${S.grid === 0.05 ? ' selected' : ''}>5 cm</option><option value="0.1"${S.grid === 0.1 ? ' selected' : ''}>10 cm</option><option value="0.25"${S.grid === 0.25 ? ' selected' : ''}>25 cm</option><option value="0.5"${S.grid === 0.5 ? ' selected' : ''}>50 cm</option></select></label>
    <label><input type="checkbox" id="sOrto" ${S.orto ? 'checked' : ''}> Dik</label>
    <label><input type="checkbox" id="sOlc" ${S.olcuGoster ? 'checked' : ''}> Ölçüler</label>
    <label title="Islak / Yaşam / Servis / Dış alan renkli bölgeleme"><input type="checkbox" id="sZoning" ${S.zoningGoster ? 'checked' : ''}> Bölgeleme</label>
    <label><input type="checkbox" id="sBoru" ${S.boruGoster ? 'checked' : ''}> Borular</label>
    <button class="ubtn" id="sOtoOlcu" title="Aktif kat dış cephelerine otomatik 2 kademeli ölçü zinciri ekle">Oto ölçüle</button>
    <button class="ubtn" id="sKatmanBtn" title="Katman görünürlük ayarları">Katmanlar</button>
    <span class="ipucu">${IPUCU[A] || ''}</span>`;
  B.innerHTML = h;

  const sTur = $('#sTur', B) as HTMLSelectElement | null;
  if (sTur) {
    sTur.onchange = () => {
      S.duvarTur = sTur.value as 'dis' | 'ic';
      S.duvarK = S.duvarTur === 'dis' ? 0.25 : 0.12;
      ($('#sKal', B) as HTMLInputElement).value = String(Math.round(S.duvarK * 100));
    };
  }
  const sKal = $('#sKal', B) as HTMLInputElement | null;
  if (sKal) sKal.oninput = () => (S.duvarK = Math.max(0.05, +sKal.value / 100));
  const sEgri = $('#sEgri', B) as HTMLInputElement | null;
  if (sEgri) sEgri.oninput = () => (S.duvarEgri = (+sEgri.value || 0) / 100);

  const sKTip = $('#sKTip', B) as HTMLSelectElement | null;
  if (sKTip) {
    sKTip.onchange = () => {
      S.kapiTip = sKTip.value as AciklikTuru;
      if (S.kapiTip === 'cift_kapi' && S.kapi.g < 1.3) S.kapi.g = 1.6;
      else if (S.kapiTip === 'surme' && S.kapi.g < 1.5) S.kapi.g = 2.0;
      else if (S.kapiTip === 'kapi' && S.kapi.g > 1.3) S.kapi.g = 0.9;
      ($('#sKG', B) as HTMLInputElement).value = String(Math.round(S.kapi.g * 100));
    };
  }
  const sKG = $('#sKG', B) as HTMLInputElement | null;
  if (sKG) sKG.oninput = () => (S.kapi.g = Math.max(0.5, +sKG.value / 100));
  const sKH = $('#sKH', B) as HTMLInputElement | null;
  if (sKH) sKH.oninput = () => (S.kapi.h = Math.max(1.7, +sKH.value / 100));

  const sPTip = $('#sPTip', B) as HTMLSelectElement | null;
  if (sPTip) sPTip.onchange = () => (S.kapiTip = sPTip.value as AciklikTuru);
  const sPG = $('#sPG', B) as HTMLInputElement | null;
  if (sPG) sPG.oninput = () => (S.pencere.g = Math.max(0.3, +sPG.value / 100));
  const sPH = $('#sPH', B) as HTMLInputElement | null;
  if (sPH) sPH.oninput = () => (S.pencere.h = Math.max(0.3, +sPH.value / 100));
  const sPP = $('#sPP', B) as HTMLInputElement | null;
  if (sPP) sPP.oninput = () => (S.pencere.p = Math.max(0, +sPP.value / 100));

  const sAY = $('#sAY', B) as HTMLSelectElement | null;
  if (sAY) sAY.onchange = () => (S.aksYon = sAY.value as 'd' | 'y');
  const sAK = $('#sAK', B) as HTMLInputElement | null;
  if (sAK) sAK.oninput = () => (S.kolonBoyut = Math.max(0.2, +sAK.value / 100));
  const sAKol = $('#sAKol', B);
  if (sAKol) sAKol.onclick = aksKolonKoy;
  const sAOto = $('#sAOto', B);
  if (sAOto) sAOto.onclick = akslariOto;

  const sBTur = $('#sBTur', B) as HTMLSelectElement | null;
  if (sBTur) {
    sBTur.onchange = () => {
      S.boruTur = sBTur.value as BoruTuru;
      const bt = BORU_TIPLERI[S.boruTur];
      S.boruCap = bt.varsCap;
      S.boruKot = bt.varsKot;
      secenekKur();
    };
  }
  const sBCap = $('#sBCap', B) as HTMLSelectElement | null;
  if (sBCap) sBCap.onchange = () => (S.boruCap = +sBCap.value);
  const sBKot = $('#sBKot', B) as HTMLInputElement | null;
  if (sBKot) sBKot.oninput = () => (S.boruKot = (+sBKot.value || 0) / 100);
  const sBOto = $('#sBOto', B);
  if (sBOto) sBOto.onclick = autoBoruUygula;
  const sBTmz = $('#sBTmz', B);
  if (sBTmz) {
    sBTmz.onclick = () => {
      degistir(() => {
        P().borular = (P().borular || []).filter(b => !(b.kat === S.katId && b.oto));
      });
      bildir('Otomatik boru hatları temizlendi');
    };
  }

  const sTG = $('#sTG', B) as HTMLInputElement | null;
  if (sTG) {
    sTG.onchange = () => {
      S.tesisatGoster = sTG.checked;
      PLAN.ciz();
    };
  }
  const sBG = $('#sBG', B) as HTMLInputElement | null;
  if (sBG) {
    sBG.onchange = () => {
      S.boruGoster = sBG.checked;
      PLAN.ciz();
    };
  }
  const sTOto = $('#sTOto', B);
  if (sTOto) {
    sTOto.onclick = () => {
      if (!P().odalar.filter(o => o.kat === S.katId).length) {
        bildir('Önce bu katta odalar tanımlı olmalı');
        return;
      }
      degistir(() => {
        P().tesisat = (P().tesisat || []).filter(t => t.kat !== S.katId).concat(otomatikTesisat(S.katId!));
        P().borular = (P().borular || []).filter(b => b.kat !== S.katId).concat(otomatikBoruDose(S.katId!));
      });
      bildir('Tesisat noktaları ve boru güzergâhları döşendi');
    };
  }
  const sTTmz = $('#sTTmz', B);
  if (sTTmz) {
    sTTmz.onclick = () => {
      degistir(() => {
        P().tesisat = (P().tesisat || []).filter(t => t.kat !== S.katId);
        P().borular = (P().borular || []).filter(b => b.kat !== S.katId);
      });
    };
  }

  const sDisiplin = $('#sDisiplin', B) as HTMLSelectElement;
  sDisiplin.onchange = () => {
    S.disiplin = sDisiplin.value as DisiplinModu;
    if (S.disiplin === 'sihhi' || S.disiplin === 'elektrik') {
      S.tesisatGoster = true;
      S.boruGoster = true;
    }
    PLAN.ciz();
    secenekKur();
  };
  const sGrid = $('#sGrid', B) as HTMLSelectElement;
  sGrid.onchange = () => {
    S.grid = +sGrid.value;
    PLAN.ciz();
  };
  const sOrto = $('#sOrto', B) as HTMLInputElement;
  sOrto.onchange = () => (S.orto = sOrto.checked);
  const sOlc = $('#sOlc', B) as HTMLInputElement;
  sOlc.onchange = () => {
    S.olcuGoster = sOlc.checked;
    PLAN.ciz();
  };
  const sZoning = $('#sZoning', B) as HTMLInputElement;
  sZoning.onchange = () => {
    S.zoningGoster = sZoning.checked;
    PLAN.ciz();
  };
  const sBoru = $('#sBoru', B) as HTMLInputElement;
  sBoru.onchange = () => {
    S.boruGoster = sBoru.checked;
    PLAN.ciz();
  };
  $('#sOtoOlcu', B)!.onclick = () => {
    let adet = 0;
    degistir(() => {
      adet = otomatikOlcule(S.katId!);
    });
    bildir(adet ? `${adet} otomatik dış cephe ölçü çizgisi eklendi` : 'Ölçülendirilecek yeterli duvar bulunamadı');
  };
  $('#sKatmanBtn', B)!.onclick = katmanlarDiy;
}

function autoBoruUygula() {
  if (!(P().tesisat || []).some(t => t.kat === S.katId)) {
    bildir('Önce tesisat noktası yerleştirin veya “Tesisat” aracından otomatik tesisat çalıştırın');
    return;
  }
  degistir(() => {
    P().borular = (P().borular || []).filter(b => !(b.kat === S.katId && b.oto)).concat(otomatikBoruDose(S.katId!));
  });
  bildir('Kat boru/kablo döşemeleri otomatik oluşturuldu');
}

export function durumaAlanYaz() {
  if (!S.p) return;
  const odalar = P().odalar.filter(o => o.kat === S.katId);
  const net = odalar.reduce((s, o) => s + Math.abs(G.alan(o.pts)), 0);
  const ot = katOturum(S.katId!);
  const brut = ot ? Math.abs(G.alan(ot)) : 0;
  const k = kat();
  const dAlan = $('#dAlan');
  if (dAlan) dAlan.textContent = `Net: ${fmt(net)} m² · Brüt: ${fmt(brut)} m²`;
  const dKat = $('#dKat');
  if (dKat) dKat.textContent = `${k.ad} · ${P().borular?.filter(b => b.kat === k.id).length || 0} boru hattı`;

  // Üst çubuktaki hızlı kat seçiciyi güncelle
  const katSec = $('#katSec') as HTMLSelectElement | null;
  if (katSec) {
    katSec.innerHTML = P().katlar.map(kk => `<option value="${kk.id}"${kk.id === S.katId ? ' selected' : ''}>${esc(kk.ad)}</option>`).join('');
  }
}

/* Akslar & Kopyala / Yapıştır / Aynala */
function akslariOto() {
  const W = P().duvarlar.filter(w => w.kat === S.katId && !w.egri);
  if (!W.length) {
    bildir('Önce bu katta duvarlar olmalı');
    return;
  }
  const ku = (v: number[]) => {
    const s = [...v].sort((a, b) => a - b);
    const g: number[][] = [];
    for (const x of s) {
      const l = g[g.length - 1];
      if (l && x - l[l.length - 1] < 0.35) l.push(x);
      else g.push([x]);
    }
    return g.map(c => r3(c.reduce((a, b) => a + b, 0) / c.length));
  };
  const xs: number[] = [];
  const ys: number[] = [];
  W.forEach(w => {
    if (Math.abs(w.x2 - w.x1) < 0.08) xs.push((w.x1 + w.x2) / 2);
    if (Math.abs(w.y2 - w.y1) < 0.08) ys.push((w.y1 + w.y2) / 2);
  });
  degistir(() => {
    P().akslar = [];
    ku(xs).forEach(k => P().akslar.push({ id: uid(), yon: 'd', k }));
    ku(ys).forEach(k => P().akslar.push({ id: uid(), yon: 'y', k }));
  });
  bildir('Akslar duvar merkezlerinden oluşturuldu');
}

function aksKolonKoy() {
  const A = P().akslar || [];
  const d = A.filter(a => a.yon === 'd');
  const y = A.filter(a => a.yon === 'y');
  if (!d.length || !y.length) {
    bildir('Önce en az bir dikey ve bir yatay aks gerekli');
    return;
  }
  const ot = katOturum(S.katId!);
  const var_ = P().mobilya.filter(o => o.kat === S.katId && o.tip === 'kolon');
  const ks = S.kolonBoyut || 0.3;
  let say = 0;
  degistir(() => {
    for (const a of d) {
      for (const b of y) {
        if (ot && !G.icinde(a.k, b.k, ot) && G.segNokta(a.k, b.k, ot[0][0], ot[0][1], ot[1][0], ot[1][1]).d > 0.35) {
          // kenar yakın kontrolü
          const kenaraYakin = ot.some((q, idx) => G.segNokta(a.k, b.k, q[0], q[1], ot[(idx + 1) % ot.length][0], ot[(idx + 1) % ot.length][1]).d < 0.35);
          if (!kenaraYakin) continue;
        }
        if (var_.some(o => Math.hypot(o.x - a.k, o.y - b.k) < 0.25)) continue;
        P().mobilya.push({ id: uid(), kat: S.katId!, tip: 'kolon', x: r3(a.k), y: r3(b.k), r: 0, w: ks, d: ks });
        say++;
      }
    }
  });
  bildir(say + ' kolon yerleştirildi');
}

function panoyaKopyala() {
  const hedef = S.cokluSecili.length ? S.cokluSecili : S.secili ? [S.secili] : [];
  if (!hedef.length) return;
  const items: { tip: string; data: unknown }[] = [];
  for (const h of hedef) {
    const o = PLAN.nesne(h);
    if (o && ['duvar', 'mobilya', 'tesisat', 'boru', 'olcu', 'yazi', 'kiris'].includes(h.tur)) {
      items.push({ tip: h.tur, data: kopya(o) });
    }
  }
  if (!items.length) {
    bildir('Kopyalanacak öğe seçilmedi');
    return;
  }
  S.pano = items;
  bildir(`${items.length} öğe panoya kopyalandı (Ctrl+V ile yapıştır)`);
}

function panodanYapistir(offset = 0.6) {
  if (!S.pano.length) return;
  degistir(() => {
    const yeniSecim: typeof S.cokluSecili = [];
    for (const it of S.pano) {
      const obj = kopya(it.data) as Record<string, unknown>;
      obj.id = uid();
      if ('kat' in obj) obj.kat = S.katId;
      if (typeof obj.x === 'number') {
        obj.x = r3(obj.x + offset);
        obj.y = r3((obj.y as number) + offset);
      }
      if (typeof obj.x1 === 'number') {
        obj.x1 = r3(obj.x1 + offset);
        obj.y1 = r3((obj.y1 as number) + offset);
        obj.x2 = r3((obj.x2 as number) + offset);
        obj.y2 = r3((obj.y2 as number) + offset);
      }
      if (Array.isArray(obj.pts)) {
        obj.pts = (obj.pts as Pt[]).map(q => [r3(q[0] + offset), r3(q[1] + offset)]);
      }
      if (it.tip === 'duvar') P().duvarlar.push(obj as never);
      else if (it.tip === 'mobilya') P().mobilya.push(obj as never);
      else if (it.tip === 'tesisat') P().tesisat.push(obj as never);
      else if (it.tip === 'boru') P().borular.push(obj as never);
      else if (it.tip === 'olcu') P().olculer.push(obj as never);
      else if (it.tip === 'yazi') P().yazilar.push(obj as never);
      else if (it.tip === 'kiris') P().kirisler.push(obj as never);
      yeniSecim.push({ tur: it.tip as never, id: String(obj.id) });
    }
    S.cokluSecili = yeniSecim;
    S.secili = yeniSecim[0] || null;
  });
  bildir(`${S.pano.length} öğe yapıştırıldı`);
}

function seciliAynala(eksen: 'x' | 'y') {
  const hedef = S.cokluSecili.length ? S.cokluSecili : S.secili ? [S.secili] : [];
  if (!hedef.length) return;
  const pts: Pt[] = [];
  for (const h of hedef) {
    const o = PLAN.nesne(h);
    if (!o) continue;
    if (o.x != null) pts.push([o.x, o.y]);
    if (o.x1 != null) pts.push([o.x1, o.y1], [o.x2, o.y2]);
    if (Array.isArray(o.pts)) (o.pts as Pt[]).forEach(q => pts.push(q));
  }
  if (!pts.length) return;
  const b = G.bbox(pts);
  const cx = b.x1 + b.w / 2;
  const cy = b.y1 + b.h / 2;
  const ax = (x: number) => (eksen === 'x' ? r3(2 * cx - x) : x);
  const ay = (y: number) => (eksen === 'y' ? r3(2 * cy - y) : y);
  degistir(() => {
    for (const h of hedef) {
      const o = PLAN.nesne(h);
      if (!o) continue;
      if (o.x != null) {
        o.x = ax(o.x);
        o.y = ay(o.y);
        if (o.r != null) o.r = eksen === 'x' ? -o.r : 180 - o.r;
      }
      if (o.x1 != null) {
        o.x1 = ax(o.x1);
        o.y1 = ay(o.y1);
        o.x2 = ax(o.x2);
        o.y2 = ay(o.y2);
      }
      if (Array.isArray(o.pts)) {
        o.pts = (o.pts as Pt[]).map(q => [ax(q[0]), ay(q[1])]);
      }
    }
    odalariGuncelle(S.katId!);
  });
  bildir(eksen === 'x' ? 'Yatay aynalandı' : 'Dikey aynalandı');
}

function duvariOrtadanBol(wId: string, wx?: number, wy?: number) {
  const w = duvar(wId);
  if (!w) return;
  const t = wx != null && wy != null ? sinir(G.segNokta(wx, wy, w.x1, w.y1, w.x2, w.y2).t, 0.12, 0.88) : 0.5;
  const mx = r3(w.x1 + (w.x2 - w.x1) * t);
  const my = r3(w.y1 + (w.y2 - w.y1) * t);
  degistir(() => {
    const p = P();
    const yeniId = uid();
    const aciklar = p.aciklar.filter(a => a.duvar === w.id);
    const oldX2 = w.x2;
    const oldY2 = w.y2;
    w.x2 = mx;
    w.y2 = my;
    p.duvarlar.push({ id: yeniId, kat: w.kat, x1: mx, y1: my, x2: oldX2, y2: oldY2, k: w.k, tur: w.tur });
    aciklar.forEach(a => {
      if (a.t > t) {
        a.duvar = yeniId;
        a.t = r3((a.t - t) / (1 - t));
      } else {
        a.t = r3(a.t / t);
      }
    });
    acikDogrula(w.id);
    acikDogrula(yeniId);
  });
  bildir('Duvar iki parçaya bölündü');
}

function seciliSil() {
  const silList = S.cokluSecili.length ? S.cokluSecili : S.secili ? [S.secili] : [];
  if (!silList.length) return;
  const p = P();
  degistir(() => {
    for (const h of silList) {
      if (h.tur === 'duvar') {
        p.duvarlar = p.duvarlar.filter(w => w.id !== h.id);
        p.aciklar = p.aciklar.filter(a => a.duvar !== h.id);
      } else if (h.tur === 'acik') p.aciklar = p.aciklar.filter(a => a.id !== h.id);
      else if (h.tur === 'oda') p.odalar = p.odalar.filter(o => o.id !== h.id);
      else if (h.tur === 'mobilya') p.mobilya = p.mobilya.filter(o => o.id !== h.id);
      else if (h.tur === 'kiris') p.kirisler = (p.kirisler || []).filter(o => o.id !== h.id);
      else if (h.tur === 'dis') p.dis = p.dis.filter(o => o.id !== h.id);
      else if (h.tur === 'olcu') p.olculer = p.olculer.filter(o => o.id !== h.id);
      else if (h.tur === 'yazi') p.yazilar = p.yazilar.filter(o => o.id !== h.id);
      else if (h.tur === 'aks') p.akslar = (p.akslar || []).filter(o => o.id !== h.id);
      else if (h.tur === 'kesit') p.kesitler = (p.kesitler || []).filter(o => o.id !== h.id);
      else if (h.tur === 'tesisat') p.tesisat = (p.tesisat || []).filter(o => o.id !== h.id);
      else if (h.tur === 'boru') p.borular = (p.borular || []).filter(o => o.id !== h.id);
      else if (h.tur === 'arsa') p.arsa = null;
    }
    S.secili = null;
    S.cokluSecili = [];
    odalariGuncelle(S.katId!);
  });
}

function seciliDondur(aci = 90) {
  const h = S.secili;
  if (!h) {
    S.mobRot = (S.mobRot + aci) % 360;
    PLAN.ciz();
    return;
  }
  const o = PLAN.nesne(h);
  if (!o) return;
  if (h.tur === 'mobilya' || h.tur === 'tesisat' || (h.tur === 'dis' && o.r != null)) {
    degistir(() => (o.r = ((o.r || 0) + aci) % 360));
  } else if (h.tur === 'acik') {
    degistir(() => (o.yon *= -1));
  } else if (h.tur === 'kesit') {
    degistir(() => (o.yon *= -1));
  }
}

/* Sağ Panel */
export function panelKur() {
  const Pnl = $('#panel');
  if (!Pnl || !S.p) return;
  const p = P();
  Pnl.innerHTML = '';

  const kart = (baslik: string, ic: string, dugme?: { t: string; f: () => void }) => {
    const d = document.createElement('div');
    d.className = 'kart';
    d.innerHTML = `<h4><span>${baslik}</span></h4><div>${ic}</div>`;
    if (dugme) {
      const b = document.createElement('button');
      b.className = 'ubtn';
      b.textContent = dugme.t;
      b.onclick = dugme.f;
      $('h4', d)!.appendChild(b);
    }
    Pnl.appendChild(d);
    return d;
  };

  // Seçili nesne özellikleri
  if (S.cokluSecili.length > 1) {
    const c = kart(
      `Çoklu seçim (${S.cokluSecili.length} öğe)`,
      `<div class="satir" style="margin-bottom:8px">
        <button class="ubtn" id="csKop">Kopyala (Ctrl+C)</button>
        <button class="ubtn" id="csAynX">Yatay aynala</button>
        <button class="ubtn" id="csAynY">Dikey aynala</button>
        <button class="ubtn" id="csSil" style="color:var(--kirmizi)">Tümünü sil</button>
      </div>`,
    );
    $('#csKop', c)!.onclick = panoyaKopyala;
    $('#csAynX', c)!.onclick = () => seciliAynala('x');
    $('#csAynY', c)!.onclick = () => seciliAynala('y');
    $('#csSil', c)!.onclick = seciliSil;
  } else if (S.secili) {
    const s = S.secili;
    const o = PLAN.nesne(s);
    if (o) {
      const dug: { t: string; f: () => void } = { t: 'Sil', f: seciliSil };
      if (s.tur === 'duvar') {
        const L = Math.hypot(o.x2 - o.x1, o.y2 - o.y1);
        const c = kart(
          'Seçili duvar',
          `<label class="alan"><span>Uzunluk (m)</span><input type="number" step="0.05" min="0.2" id="eBoy" value="${L.toFixed(2)}"></label>
           <label class="alan"><span>Kalınlık (cm)</span><input type="number" min="5" max="60" id="eKal" value="${Math.round(o.k * 100)}"></label>
           <label class="alan"><span>Kavis (cm)</span><input type="number" min="-400" max="400" step="10" id="eEgri" value="${Math.round((o.egri || 0) * 100)}"></label>
           <label class="alan"><span>Tür</span><select id="eDTur"><option value="dis"${o.tur === 'dis' ? ' selected' : ''}>Dış duvar</option><option value="ic"${o.tur === 'ic' ? ' selected' : ''}>İç duvar</option></select></label>
           <div class="satir"><button class="ubtn" id="eBol">Ortadan böl</button><button class="ubtn" id="eKop">Kopyala</button></div>`,
          dug,
        );
        ($('#eBoy', c) as HTMLInputElement).onchange = e => {
          const v = Math.max(0.2, +(e.target as HTMLInputElement).value);
          const L2 = Math.hypot(o.x2 - o.x1, o.y2 - o.y1) || 1;
          degistir(() => {
            o.x2 = r3(o.x1 + ((o.x2 - o.x1) / L2) * v);
            o.y2 = r3(o.y1 + ((o.y2 - o.y1) / L2) * v);
            acikDogrula(o.id);
            odalariGuncelle(S.katId!);
          });
        };
        ($('#eKal', c) as HTMLInputElement).onchange = e => degistir(() => (o.k = Math.max(0.05, +(e.target as HTMLInputElement).value / 100)));
        ($('#eEgri', c) as HTMLInputElement).onchange = e => degistir(() => (o.egri = (+(e.target as HTMLInputElement).value || 0) / 100));
        ($('#eDTur', c) as HTMLSelectElement).onchange = e => degistir(() => (o.tur = (e.target as HTMLSelectElement).value));
        $('#eBol', c)!.onclick = () => duvariOrtadanBol(o.id);
        $('#eKop', c)!.onclick = panoyaKopyala;
      } else if (s.tur === 'acik') {
        const w = duvar(o.duvar);
        const Lw = w ? Math.hypot(w.x2 - w.x1, w.y2 - w.y1) : 1;
        const basMes = Math.max(0, o.t * Lw - o.g / 2);
        const bitMes = Math.max(0, (1 - o.t) * Lw - o.g / 2);
        const renkSec = Object.entries(DOGRAMA_RENK)
          .map(([_, r]) => `<option value="${r.hex}"${(o.renk || p.cephe.dogramaRenk) === r.hex ? ' selected' : ''}>${r.ad}</option>`)
          .join('');
        const c = kart(
          'Seçili açıklık',
          `<label class="alan"><span>Tip</span><select id="eATip">
            <option value="kapi"${o.tur === 'kapi' ? ' selected' : ''}>Kapı</option>
            <option value="cift_kapi"${o.tur === 'cift_kapi' ? ' selected' : ''}>Çift kapı</option>
            <option value="surme"${o.tur === 'surme' ? ' selected' : ''}>Sürme kapı</option>
            <option value="balkon"${o.tur === 'balkon' ? ' selected' : ''}>Balkon kapısı</option>
            <option value="pencere"${o.tur === 'pencere' ? ' selected' : ''}>Pencere</option>
            <option value="cati_pencere"${o.tur === 'cati_pencere' ? ' selected' : ''}>Çatı penceresi</option>
          </select></label>
          <label class="alan"><span>Genişlik (cm)</span><input type="number" min="40" max="420" step="5" id="eAG" value="${Math.round(o.g * 100)}"></label>
          <label class="alan"><span>Yükseklik (cm)</span><input type="number" min="40" max="260" step="5" id="eAH" value="${Math.round(o.h * 100)}"></label>
          <label class="alan"><span>Parapet (cm)</span><input type="number" min="0" max="180" step="5" id="eAP" value="${Math.round(o.p * 100)}"></label>
          <label class="alan"><span>Köşe 1 (cm)</span><input type="number" min="0" step="5" id="eKB" value="${Math.round(basMes * 100)}" title="Duvar başlangıç ucuna mesafe"></label>
          <label class="alan"><span>Köşe 2 (cm)</span><input type="number" min="0" step="5" id="eKS" value="${Math.round(bitMes * 100)}" title="Duvar bitiş ucuna mesafe"></label>
          <label class="alan"><span>Doğrama renk</span><select id="eARenk">${renkSec}</select></label>
          <label class="alan"><span>Panjur</span><input type="checkbox" id="eAPanjur" ${o.panjur ? 'checked' : ''} style="width:auto"></label>
          <div class="satir"><button class="ubtn" id="eAYon">Açılış yönü</button><button class="ubtn" id="eAMen">Menteşe sol/sağ</button></div>`,
          dug,
        );
        ($('#eATip', c) as HTMLSelectElement).onchange = e => degistir(() => (o.tur = (e.target as HTMLSelectElement).value));
        ($('#eAG', c) as HTMLInputElement).onchange = e =>
          degistir(() => {
            o.g = Math.max(0.4, +(e.target as HTMLInputElement).value / 100);
            acikDogrula(o.duvar);
          });
        ($('#eAH', c) as HTMLInputElement).onchange = e => degistir(() => (o.h = Math.max(0.4, +(e.target as HTMLInputElement).value / 100)));
        ($('#eAP', c) as HTMLInputElement).onchange = e => degistir(() => (o.p = Math.max(0, +(e.target as HTMLInputElement).value / 100)));
        ($('#eKB', c) as HTMLInputElement).onchange = e => {
          const d = Math.max(0.02, +(e.target as HTMLInputElement).value / 100);
          degistir(() => {
            o.t = r3((d + o.g / 2) / (Lw || 1));
            acikDogrula(o.duvar);
          });
        };
        ($('#eKS', c) as HTMLInputElement).onchange = e => {
          const d = Math.max(0.02, +(e.target as HTMLInputElement).value / 100);
          degistir(() => {
            o.t = r3(1 - (d + o.g / 2) / (Lw || 1));
            acikDogrula(o.duvar);
          });
        };
        ($('#eARenk', c) as HTMLSelectElement).onchange = e => degistir(() => (o.renk = (e.target as HTMLSelectElement).value));
        ($('#eAPanjur', c) as HTMLInputElement).onchange = e => degistir(() => (o.panjur = (e.target as HTMLInputElement).checked));
        $('#eAYon', c)!.onclick = () => degistir(() => (o.yon *= -1));
        $('#eAMen', c)!.onclick = () => degistir(() => (o.mentese = o.mentese === 'sol' ? 'sag' : 'sol'));
      } else if (s.tur === 'oda') {
        const zSec = Object.entries(ZEMIN)
          .map(([k, v]) => `<option value="${k}"${o.zemin === k ? ' selected' : ''}>${v.ad}</option>`)
          .join('');
        const c = kart(
          'Seçili oda',
          `<label class="alan"><span>Oda adı</span><input type="text" id="eOAd" list="odaList" value="${esc(o.ad)}"><datalist id="odaList">${ODA_ADLARI.map(x => `<option value="${x}">`).join('')}</datalist></label>
           <label class="alan"><span>Zemin</span><select id="eOZ">${zSec}</select></label>
           <label class="alan"><span>Duvar kaplama</span><input type="text" id="eODuv" placeholder="Alçı sıva + boya" value="${esc(o.duvarKaplama || '')}"></label>
           <label class="alan"><span>Tavan kaplama</span><input type="text" id="eOTav" placeholder="Tavan boyası" value="${esc(o.tavanKaplama || '')}"></label>
           <div class="bilgi">Alan: <b>${fmt(Math.abs(G.alan(o.pts)))} m²</b> · Çevre: <b>${fmt(G.cevre(o.pts))} m</b></div>`,
          dug,
        );
        ($('#eOAd', c) as HTMLInputElement).onchange = e => degistir(() => (o.ad = (e.target as HTMLInputElement).value || 'Oda'));
        ($('#eOZ', c) as HTMLSelectElement).onchange = e => degistir(() => (o.zemin = (e.target as HTMLSelectElement).value));
        ($('#eODuv', c) as HTMLInputElement).onchange = e => degistir(() => (o.duvarKaplama = (e.target as HTMLInputElement).value));
        ($('#eOTav', c) as HTMLInputElement).onchange = e => degistir(() => (o.tavanKaplama = (e.target as HTMLInputElement).value));
      } else if (s.tur === 'mobilya') {
        const T = MOB[o.tip];
        const { w, d } = mobOlcu(o);
        const isMerd = T?.ozel?.startsWith('merdiven');
        const c = kart(
          'Seçili · ' + (T?.ad || o.tip),
          `<label class="alan"><span>Genişlik (cm)</span><input type="number" min="20" step="5" id="eMW" value="${Math.round(w * 100)}"></label>
           <label class="alan"><span>Derinlik (cm)</span><input type="number" min="20" step="5" id="eMD" value="${Math.round(d * 100)}"></label>
           <label class="alan"><span>Açı (°)</span><input type="number" step="15" id="eMR" value="${o.r || 0}"></label>
           ${isMerd ? `<label class="alan"><span>Basamak sayısı</span><input type="number" min="2" max="36" id="eMBas" value="${o.basamak || Math.max(8, Math.round((kat().h + 0.15) / 0.175))}"></label>` : ''}
           <div class="satir"><button class="ubtn" id="eM90">90° döndür</button><button class="ubtn" id="eMKop">Kopyala</button></div>`,
          dug,
        );
        ($('#eMW', c) as HTMLInputElement).onchange = e => degistir(() => (o.w = Math.max(0.2, +(e.target as HTMLInputElement).value / 100)));
        ($('#eMD', c) as HTMLInputElement).onchange = e => degistir(() => (o.d = Math.max(0.2, +(e.target as HTMLInputElement).value / 100)));
        ($('#eMR', c) as HTMLInputElement).onchange = e => degistir(() => (o.r = +(e.target as HTMLInputElement).value % 360));
        const basEl = $('#eMBas', c) as HTMLInputElement | null;
        if (basEl) basEl.onchange = e => degistir(() => (o.basamak = Math.max(2, +(e.target as HTMLInputElement).value || 16)));
        $('#eM90', c)!.onclick = () => seciliDondur(90);
        $('#eMKop', c)!.onclick = panoyaKopyala;
      } else if (s.tur === 'boru') {
        const bt = BORU_TIPLERI[o.tur as BoruTuru];
        const c = kart(
          'Seçili boru hattı',
          `<label class="alan"><span>Sistem</span><select id="eBTur">${(Object.keys(BORU_TIPLERI) as BoruTuru[]).map(k => `<option value="${k}"${o.tur === k ? ' selected' : ''}>${BORU_TIPLERI[k].ad}</option>`).join('')}</select></label>
           <label class="alan"><span>Çap (mm)</span><select id="eBCap">${(bt?.caplar || [16, 20, 25, 32, 50, 75, 110]).map(v => `<option value="${v}"${o.cap === v ? ' selected' : ''}>Ø${v} mm</option>`).join('')}</select></label>
           <label class="alan"><span>Kot (cm)</span><input type="number" min="-150" max="320" step="5" id="eBKot" value="${Math.round((o.kot ?? bt?.varsKot ?? 0) * 100)}"></label>
           <label class="alan"><span>Eğim (%)</span><input type="number" min="0" max="10" step="0.5" id="eBEgim" value="${o.egim || 0}"></label>
           <div class="bilgi">Hat boyu: <b>${fmt(boruUzunluk(o))} m</b></div>`,
          dug,
        );
        ($('#eBTur', c) as HTMLSelectElement).onchange = e => degistir(() => (o.tur = (e.target as HTMLSelectElement).value));
        ($('#eBCap', c) as HTMLSelectElement).onchange = e => degistir(() => (o.cap = +((e.target as HTMLSelectElement).value) || 20));
        ($('#eBKot', c) as HTMLInputElement).onchange = e => degistir(() => (o.kot = (+(e.target as HTMLInputElement).value || 0) / 100));
        ($('#eBEgim', c) as HTMLInputElement).onchange = e => degistir(() => (o.egim = Math.max(0, +(e.target as HTMLInputElement).value || 0)));
      } else if (s.tur === 'kiris') {
        const c = kart(
          'Seçili taşıyıcı kiriş',
          `<label class="alan"><span>Genişlik (cm)</span><input type="number" min="15" max="80" step="5" id="eKW" value="${Math.round((o.w || 0.25) * 100)}"></label>
           <label class="alan"><span>Yükseklik (cm)</span><input type="number" min="25" max="120" step="5" id="eKH" value="${Math.round((o.h || 0.5) * 100)}"></label>
           <div class="bilgi">Açıklık: <b>${fmt(Math.hypot(o.x2 - o.x1, o.y2 - o.y1))} m</b></div>`,
          dug,
        );
        ($('#eKW', c) as HTMLInputElement).onchange = e => degistir(() => (o.w = Math.max(0.15, +(e.target as HTMLInputElement).value / 100)));
        ($('#eKH', c) as HTMLInputElement).onchange = e => degistir(() => (o.h = Math.max(0.25, +(e.target as HTMLInputElement).value / 100)));
      } else if (s.tur === 'tesisat') {
        const c = kart(
          'Seçili · ' + (TES[o.tip]?.ad || o.tip),
          `<label class="alan"><span>Açı (°)</span><input type="number" step="15" id="eTR" value="${o.r || 0}"></label>
           <label class="alan"><span>Kot (cm)</span><input type="number" step="5" id="eTKot" value="${Math.round((o.kot ?? TES[o.tip]?.kot ?? 0) * 100)}"></label>
           <button class="ubtn" id="eT90">90° döndür</button>`,
          dug,
        );
        ($('#eTR', c) as HTMLInputElement).onchange = e => degistir(() => (o.r = +(e.target as HTMLInputElement).value % 360));
        ($('#eTKot', c) as HTMLInputElement).onchange = e => degistir(() => (o.kot = (+(e.target as HTMLInputElement).value || 0) / 100));
        $('#eT90', c)!.onclick = () => seciliDondur(90);
      } else if (s.tur === 'arsa') {
        const nKenar = o.pts.length;
        const c = kart(
          'Arsa & Çekme Mesafeleri',
          `<label class="alan"><span>Ön çekme (m)</span><input type="number" min="0" max="20" step="0.5" id="eCekOn" value="${p.ayar.cekmeOn ?? 5}"></label>
           <label class="alan"><span>Yan çekme (m)</span><input type="number" min="0" max="20" step="0.5" id="eCekYan" value="${p.ayar.cekmeYan ?? 3}"></label>
           <label class="alan"><span>Arka çekme (m)</span><input type="number" min="0" max="20" step="0.5" id="eCekArka" value="${p.ayar.cekmeArka ?? 3}"></label>
           <label class="alan"><span>Ön cephe kenarı</span><select id="eOnKenar">${Array.from({ length: nKenar }, (_, i) => `<option value="${i}"${(p.ayar.onCepheKenar ?? Math.min(2, nKenar - 1)) === i ? ' selected' : ''}>Kenar ${i + 1}</option>`).join('')}</select></label>
           <div class="bilgi">Arsa Alanı: <b>${fmt(Math.abs(G.alan(o.pts)))} m²</b></div>`,
          dug,
        );
        ($('#eCekOn', c) as HTMLInputElement).onchange = e => degistir(() => (p.ayar.cekmeOn = Math.max(0, +(e.target as HTMLInputElement).value || 0)));
        ($('#eCekYan', c) as HTMLInputElement).onchange = e => degistir(() => (p.ayar.cekmeYan = Math.max(0, +(e.target as HTMLInputElement).value || 0)));
        ($('#eCekArka', c) as HTMLInputElement).onchange = e => degistir(() => (p.ayar.cekmeArka = Math.max(0, +(e.target as HTMLInputElement).value || 0)));
        ($('#eOnKenar', c) as HTMLSelectElement).onchange = e => degistir(() => (p.ayar.onCepheKenar = +((e.target as HTMLSelectElement).value) || 0));
      } else if (s.tur === 'kesit') {
        const c = kart(
          `Seçili · Kesit ${o.ad}-${o.ad}`,
          `<button class="ubtn" id="eKY">Bakış yönünü çevir</button> <button class="ubtn" id="eK3">3D kesitte gör</button>`,
          dug,
        );
        $('#eKY', c)!.onclick = () => degistir(() => (o.yon *= -1));
        $('#eK3', c)!.onclick = () => {
          D3.kesit = 'k:' + o.id;
          gorunum('3d');
        };
      } else {
        kart('Seçili · ' + s.tur, `<div class="bilgi">Taşımak için sürükle, silmek için Del.</div>`, dug);
      }
    }
  }

  // Kütüphane araçları (Mobilya, Tesisat, Peyzaj)
  if (S.arac === 'mobilya') {
    const c = kart('Mobilya & Merdiven', '<input type="text" id="mobAra" class="arama-kutusu" placeholder="Mobilya ara…"><div id="mobKutu"></div>');
    const mk = $('#mobKutu', c)!;
    for (const k of MOB_KAT) {
      const h = document.createElement('div');
      h.dataset.grup = k;
      h.innerHTML = `<div class="bilgi" style="margin:6px 0 4px"><b>${k}</b></div><div class="kutuphane"></div>`;
      const g = $('.kutuphane', h)!;
      for (const [id, m] of Object.entries(MOB).filter(([_, x]) => x.k === k)) {
        const b = document.createElement('button');
        b.dataset.ad = `${m.ad} ${k}`.toLocaleLowerCase('tr');
        if (S.mobTip === id) b.className = 'aktif';
        b.innerHTML = `<canvas width="46" height="34"></canvas><span>${m.ad}</span>`;
        const ctx = ($('canvas', b) as HTMLCanvasElement).getContext('2d')!;
        const sc = Math.min(34 / Math.max(0.4, m.w), 24 / Math.max(0.4, m.d));
        ctx.translate(23, 17);
        mobilyaCiz(ctx, { tip: id, x: 0, y: 0, r: 0 }, x => x * sc, y => y * sc, sc, { dis: '#8fa7ba', ic: '#8fa7ba', yazi: '#8fa7ba', olcu: '#8fa7ba', mob: '#cfdce6', mobDolgu: '#1a3550', sec: '#3fc1c6', kapi: '#cfdce6' }, {});
        b.onclick = () => {
          S.mobTip = id;
          $$('button', mk).forEach(x => x.classList.remove('aktif'));
          b.classList.add('aktif');
        };
        g.appendChild(b);
      }
      mk.appendChild(h);
    }
    ($('#mobAra', c) as HTMLInputElement).oninput = e => {
      const q = (e.target as HTMLInputElement).value.trim().toLocaleLowerCase('tr');
      $$('[data-grup]', mk).forEach(gr => {
        let vis = 0;
        $$('button', gr).forEach(btn => {
          const ok = !q || (btn.dataset.ad || '').includes(q);
          btn.style.display = ok ? 'flex' : 'none';
          if (ok) vis++;
        });
        gr.style.display = vis ? 'block' : 'none';
      });
    };
  }

  if (S.arac === 'tesisat') {
    const c = kart(
      'Tesisat sembolleri',
      `<div class="satir" style="margin-bottom:8px">
         <button class="ubtn" id="pTOto">Otomatik yerleştir</button>
         <button class="ubtn ana" id="pBoruGec">Boru döşemeye geç</button>
       </div>
       <input type="text" id="tesAra" class="arama-kutusu" placeholder="Tesisat sembolü ara…">
       <div id="tesKutu"></div>`,
    );
    $('#pTOto', c)!.onclick = () => {
      if (!P().odalar.filter(o => o.kat === S.katId).length) {
        bildir('Önce odalar tanımlı olmalı');
        return;
      }
      degistir(() => {
        P().tesisat = (P().tesisat || []).filter(t => t.kat !== S.katId).concat(otomatikTesisat(S.katId!));
        P().borular = (P().borular || []).filter(b => b.kat !== S.katId).concat(otomatikBoruDose(S.katId!));
      });
      bildir('Tesisat ve boru hatları oluşturuldu');
    };
    $('#pBoruGec', c)!.onclick = () => aracSec('boru');
    const tk = $('#tesKutu', c)!;
    for (const grp of ['Elektrik', 'Sıhhi & ısıtma', 'Altyapı & şaft']) {
      const d = document.createElement('div');
      d.dataset.grup = grp;
      d.innerHTML = `<div class="bilgi" style="margin:6px 0 4px"><b>${grp}</b></div><div class="kutuphane"></div>`;
      const g = $('.kutuphane', d)!;
      for (const [id, t] of Object.entries(TES).filter(([_, x]) => x.g === grp)) {
        const b = document.createElement('button');
        b.dataset.ad = `${t.ad} ${grp}`.toLocaleLowerCase('tr');
        if (S.tesTip === id) b.className = 'aktif';
        b.innerHTML = `<b style="color:${t.renk};font-size:13px">${t.ad[0]}</b><span>${t.ad}</span>`;
        b.onclick = () => {
          S.tesTip = id;
          $$('button', tk).forEach(x => x.classList.remove('aktif'));
          b.classList.add('aktif');
        };
        g.appendChild(b);
      }
      tk.appendChild(d);
    }
    ($('#tesAra', c) as HTMLInputElement).oninput = e => {
      const q = (e.target as HTMLInputElement).value.trim().toLocaleLowerCase('tr');
      $$('[data-grup]', tk).forEach(gr => {
        let vis = 0;
        $$('button', gr).forEach(btn => {
          const ok = !q || (btn.dataset.ad || '').includes(q);
          btn.style.display = ok ? 'flex' : 'none';
          if (ok) vis++;
        });
        gr.style.display = vis ? 'block' : 'none';
      });
    };
  }

  if (S.arac === 'boru') {
    const hatlar = (p.borular || []).filter(b => b.kat === S.katId);
    const özet = (Object.keys(BORU_TIPLERI) as BoruTuru[])
      .map(t => {
        const bt = BORU_TIPLERI[t];
        const m = hatlar.filter(b => b.tur === t).reduce((s, b) => s + boruUzunluk(b), 0);
        return `<div style="display:flex;align-items:center;justify-content:space-between;padding:3px 0;border-bottom:1px solid rgba(37,68,95,.4)">
          <span style="display:inline-flex;align-items:center;gap:6px"><i style="display:inline-block;width:12px;height:3px;background:${bt.renk}"></i>${bt.kisa}</span>
          <b>${fmt(m, 1)} m</b>
        </div>`;
      })
      .join('');
    const c = kart(
      'Boru Döşeme Özeti',
      `<div style="margin-bottom:8px">${özet}</div>
       <div class="satir">
         <button class="ubtn ana" id="pBoruOto">Otomatik boru döşe</button>
         <button class="ubtn" id="pBoruTes">Tesisat sembolleri</button>
       </div>`,
    );
    $('#pBoruOto', c)!.onclick = autoBoruUygula;
    $('#pBoruTes', c)!.onclick = () => aracSec('tesisat');
  }

  if (S.arac === 'dis') {
    const c = kart('Peyzaj & çevre', '<div class="kutuphane"></div>');
    const g = $('.kutuphane', c)!;
    for (const [id, d] of Object.entries(DIS).filter(([_, x]) => !x.gizli)) {
      const b = document.createElement('button');
      if (S.disTip === id) b.className = 'aktif';
      b.innerHTML = `<span style="width:16px;height:16px;border-radius:50%;background:${d.renk || '#6ea24d'};display:inline-block"></span><span>${d.ad}</span>`;
      b.onclick = () => {
        S.disTip = id;
        $$('button', g).forEach(x => x.classList.remove('aktif'));
        b.classList.add('aktif');
      };
      g.appendChild(b);
    }
  }

  // Katlar (bodrum kat destekli + kopya + sil temizlikli)
  const kHtml = p.katlar
    .map(
      (k, i) => `<div class="kat${k.id === S.katId ? ' aktif' : ''}" data-k="${k.id}">
        <span><b>${esc(k.ad)}</b></span><small>${fmt(k.h)} m · kot ${fmt(katTaban(i), 1)}</small>
      </div>`,
    )
    .join('');
  const kk = kart(
    'Katlar',
    `<div class="katlar">${kHtml}</div>
     <label class="alan"><span>Kat yüksekliği</span><input type="number" step="0.1" min="2.2" max="6" id="pKH" value="${kat().h}"></label>
     <div class="satir"><button class="ubtn" id="kBodrum">+ Bodrum</button><button class="ubtn" id="kKopya">Planı kopyala</button><button class="ubtn" id="kSil">Katı sil</button></div>`,
    { t: '+ Kat', f: katEkle },
  );
  $$('.kat', kk).forEach(el => {
    el.onclick = () => {
      S.katId = el.dataset.k!;
      S.secili = null;
      S.cokluSecili = [];
      S.d3Kirli = true;
      yenile();
    };
  });
  ($('#pKH', kk) as HTMLInputElement).onchange = e => degistir(() => (kat().h = Math.max(2.2, +(e.target as HTMLInputElement).value)));
  $('#kBodrum', kk)!.onclick = bodrumKatEkle;
  $('#kKopya', kk)!.onclick = katKopya;
  $('#kSil', kk)!.onclick = katSil;

  // Cephe ve çatı
  const blokSec = (sec: string) =>
    Object.entries(BLOK)
      .map(([k, v]) => `<option value="${k}"${sec === k ? ' selected' : ''}>${v.ad}</option>`)
      .join('');
  const catiSec = Object.entries(CATI)
    .map(([k, v]) => `<option value="${k}"${p.cati.tip === k ? ' selected' : ''}>${v}</option>`)
    .join('');
  const kapSec = Object.entries(KAPLAMA)
    .map(([k, v]) => `<option value="${k}"${p.cephe.kaplama === k ? ' selected' : ''}>${v}</option>`)
    .join('');
  const cc = kart(
    'Cephe ve çatı',
    `<label class="alan"><span>Çatı</span><select id="cTip">${catiSec}</select></label>
     <label class="alan"><span>Çatı eğimi (°)</span><input type="number" min="5" max="60" id="cEgim" value="${p.cati.egim}"></label>
     <label class="alan"><span>Saçak (cm)</span><input type="number" min="0" max="150" step="10" id="cSac" value="${Math.round(p.cati.sacak * 100)}"></label>
     <label class="alan"><span>Baca / oluk</span><span><input type="checkbox" id="cBaca" ${p.cati.baca !== false ? 'checked' : ''} style="width:auto"> Baca &nbsp;<input type="checkbox" id="cOluk" ${p.cati.oluk !== false ? 'checked' : ''} style="width:auto"> Oluk</span></label>
     <label class="alan"><span>Cephe kaplama</span><select id="cKap">${kapSec}</select></label>
     <label class="alan"><span>Cephe rengi</span><input type="color" id="cRenk" value="${p.cephe.renk}"></label>
     <label class="alan"><span>Çatı rengi</span><input type="color" id="cCRenk" value="${p.cati.renk}"></label>
     <label class="alan"><span>Dış duvar</span><select id="cMal">${blokSec(p.cephe.malzeme)}</select></label>
     <label class="alan"><span>İç duvar</span><select id="cIMal">${blokSec(p.cephe.icMalzeme)}</select></label>
     <label class="alan"><span>Subasman (cm)</span><input type="number" min="0" max="150" step="5" id="cSub" value="${Math.round(p.cephe.subasman * 100)}"></label>
     <label class="alan"><span>Mantolama</span><input type="checkbox" id="cMan" ${p.cephe.mantolama ? 'checked' : ''} style="width:auto"></label>`,
  );
  ($('#cTip', cc) as HTMLSelectElement).onchange = e => degistir(() => (p.cati.tip = (e.target as HTMLSelectElement).value));
  ($('#cEgim', cc) as HTMLInputElement).onchange = e => degistir(() => (p.cati.egim = Math.max(5, +(e.target as HTMLInputElement).value)));
  ($('#cSac', cc) as HTMLInputElement).onchange = e => degistir(() => (p.cati.sacak = Math.max(0, +(e.target as HTMLInputElement).value / 100)));
  ($('#cBaca', cc) as HTMLInputElement).onchange = e => degistir(() => (p.cati.baca = (e.target as HTMLInputElement).checked));
  ($('#cOluk', cc) as HTMLInputElement).onchange = e => degistir(() => (p.cati.oluk = (e.target as HTMLInputElement).checked));
  ($('#cKap', cc) as HTMLSelectElement).onchange = e => degistir(() => (p.cephe.kaplama = (e.target as HTMLSelectElement).value));
  ($('#cRenk', cc) as HTMLInputElement).onchange = e => degistir(() => (p.cephe.renk = (e.target as HTMLInputElement).value));
  ($('#cCRenk', cc) as HTMLInputElement).onchange = e => degistir(() => (p.cati.renk = (e.target as HTMLInputElement).value));
  ($('#cMal', cc) as HTMLSelectElement).onchange = e => degistir(() => (p.cephe.malzeme = (e.target as HTMLSelectElement).value));
  ($('#cIMal', cc) as HTMLSelectElement).onchange = e => degistir(() => (p.cephe.icMalzeme = (e.target as HTMLSelectElement).value));
  ($('#cSub', cc) as HTMLInputElement).onchange = e => degistir(() => (p.cephe.subasman = Math.max(0, +(e.target as HTMLInputElement).value / 100)));
  ($('#cMan', cc) as HTMLInputElement).onchange = e => degistir(() => (p.cephe.mantolama = (e.target as HTMLInputElement).checked));

  // Özet + TAKS/KAKS
  const M = metrajHesap();
  const oz = kart(
    'Bina & imar özeti',
    `<div class="mini">
      <div><small>Net alan</small><b>${fmt(M.toplamNet)} m²</b></div>
      <div><small>Brüt alan</small><b>${fmt(M.toplamBrut)} m²</b></div>
      <div><small>Arsa</small><b>${M.arsaA ? fmt(M.arsaA) + ' m²' : '—'}</b></div>
      <div><small>Tahmini maliyet</small><b>${paraYaz(M.toplam)}</b></div>
    </div>
    ${M.arsaA ? `<div class="bilgi" style="margin-top:8px">TAKS: <span class="rozet ${(M.taks || 0) <= p.ayar.maxTaks ? 'iyi' : 'kotu'}">${fmt(M.taks || 0)} / ${fmt(p.ayar.maxTaks)}</span> &nbsp; KAKS: <span class="rozet ${(M.kaks || 0) <= p.ayar.maxKaks ? 'iyi' : 'kotu'}">${fmt(M.kaks || 0)} / ${fmt(p.ayar.maxKaks)}</span></div>` : ''}
    ${p.arsa ? `<div class="satir" style="margin-top:8px"><label class="bilgi">Ön çekme <input type="number" id="iCOn" min="0" step="0.5" value="${p.ayar.cekmeOn ?? 5}" style="width:48px"></label><label class="bilgi">Yan/Arka <input type="number" id="iCYan" min="0" step="0.5" value="${p.ayar.cekmeYan ?? 3}" style="width:48px"></label></div>` : ''}`,
    {
      t: 'Proje / Tapu',
      f: () =>
        diy(
          'Proje ve Tapu / Antet Bilgileri',
          `<label class="alan"><span>Çizen</span><input type="text" id="prC" value="${esc(p.cizen || '')}"></label>
           <label class="alan"><span>Firma</span><input type="text" id="prF" value="${esc(p.firma || '')}"></label>
           <label class="alan"><span>Adres</span><input type="text" id="prA" value="${esc(p.adres || '')}"></label>
           <label class="alan"><span>Ada / Parsel</span><span class="satir"><input type="text" id="prAda" placeholder="Ada" value="${esc(p.ada || '')}" style="width:85px"><input type="text" id="prParsel" placeholder="Parsel" value="${esc(p.parsel || '')}" style="width:85px"></span></label>
           <label class="alan"><span>Pafta / Rev</span><span class="satir"><input type="text" id="prPaf" value="${esc(p.paftaNo || 'M-01')}" style="width:85px"><input type="text" id="prRev" value="${esc(p.revizyon || 'Rev.0')}" style="width:85px"></span></label>
           <label class="alan"><span>Enlem / Boylam</span><span class="satir"><input type="number" step="0.01" id="prEn" value="${p.ayar.enlem}" style="width:85px"><input type="number" step="0.01" id="prBo" value="${p.ayar.boylam}" style="width:85px"></span></label>
           <label class="alan"><span>Maks TAKS / KAKS</span><span class="satir"><input type="number" step="0.05" id="prT" value="${p.ayar.maxTaks}" style="width:85px"><input type="number" step="0.05" id="prK" value="${p.ayar.maxKaks}" style="width:85px"></span></label>`,
          [
            {
              t: 'Kaydet',
              ana: true,
              f: () => {
                degistir(() => {
                  p.cizen = ($('#prC') as HTMLInputElement).value;
                  p.firma = ($('#prF') as HTMLInputElement).value;
                  p.adres = ($('#prA') as HTMLInputElement).value;
                  p.ada = ($('#prAda') as HTMLInputElement).value;
                  p.parsel = ($('#prParsel') as HTMLInputElement).value;
                  p.paftaNo = ($('#prPaf') as HTMLInputElement).value;
                  p.revizyon = ($('#prRev') as HTMLInputElement).value;
                  p.ayar.enlem = +($('#prEn') as HTMLInputElement).value;
                  p.ayar.boylam = +($('#prBo') as HTMLInputElement).value;
                  p.ayar.maxTaks = +($('#prT') as HTMLInputElement).value;
                  p.ayar.maxKaks = +($('#prK') as HTMLInputElement).value;
                });
                kapatDiy();
              },
            },
          ],
        ),
    },
  );
  const iCOn = $('#iCOn', oz) as HTMLInputElement | null;
  if (iCOn) iCOn.onchange = () => degistir(() => (p.ayar.cekmeOn = Math.max(0, +iCOn.value || 0)));
  const iCYan = $('#iCYan', oz) as HTMLInputElement | null;
  if (iCYan) iCYan.onchange = () => degistir(() => (p.ayar.cekmeYan = Math.max(0, +iCYan.value || 0)));

  // Yön & Güneş
  const gk = gunesKonum();
  const ga = gunesAnalizi();
  const gKart = kart(
    'Yön ve güneş ışığı',
    `<label class="alan"><span>Kuzey açısı (°)</span><input type="number" step="15" id="gKuz" value="${p.ayar.kuzey || 0}"></label>
     <label class="alan"><span>Tarih</span><select id="gTar"><option value="06-21"${p.ayar.tarih === '06-21' ? ' selected' : ''}>21 Haziran</option><option value="03-21"${p.ayar.tarih === '03-21' ? ' selected' : ''}>21 Mart</option><option value="12-21"${p.ayar.tarih === '12-21' ? ' selected' : ''}>21 Aralık</option></select></label>
     <div class="bilgi" style="margin:6px 0">Saat ${saatYaz(p.ayar.saat)} · Güneş ${gk.el > 0 ? Math.round(gk.el / RAD) + '° yukarıda' : 'batmış'}</div>
     ${ga.map(x => `<div style="display:flex;justify-content:space-between;font-size:12px;margin:2px 0"><span>${esc(x.oda)}</span><b>${x.saat ? fmt(x.saat, 1) + ' sa' : '—'}</b></div>`).join('')}`,
    {
      t: '3D güneşte gör',
      f: () => {
        D3.kesit = 'tumu';
        gorunum('3d');
      },
    },
  );
  ($('#gKuz', gKart) as HTMLInputElement).onchange = e => degistir(() => (p.ayar.kuzey = +(e.target as HTMLInputElement).value % 360));
  ($('#gTar', gKart) as HTMLSelectElement).onchange = e => degistir(() => (p.ayar.tarih = (e.target as HTMLSelectElement).value));

  // Plan kontrolü
  const kon = planKontrol(M.taks ?? undefined, M.kaks ?? undefined, M.arsaA);
  const kh = kon.length
    ? kon
        .map(
          (x, i) =>
            `<div data-ki="${i}" style="display:flex;gap:6px;align-items:flex-start;padding:5px 6px;border-radius:6px;cursor:pointer;font-size:12px;background:${x.sev === 'hata' ? 'rgba(229,83,75,.14)' : x.sev === 'uyari' ? 'rgba(232,176,74,.14)' : 'rgba(63,193,198,.1)'};margin-bottom:4px">
               <span>${x.sev === 'hata' ? '⛔' : x.sev === 'uyari' ? '⚠' : 'ℹ'}</span><span>${esc(x.mesaj)}</span>
             </div>`,
        )
        .join('')
    : '<div class="bilgi"><span class="rozet iyi">Sorun bulunamadı</span></div>';
  const kKart = kart(`Plan kontrolü (${kon.length})`, kh);
  $$('[data-ki]', kKart).forEach(el => {
    el.onclick = () => {
      const k = kon[+el.dataset.ki!];
      if (k.kat && k.kat !== S.katId) {
        S.katId = k.kat;
        yenile();
      }
      if (k.nokta) {
        PLAN.v.tx = PLAN.W / 2 - k.nokta[0] * PLAN.v.z;
        PLAN.v.ty = PLAN.H / 2 - k.nokta[1] * PLAN.v.z;
      }
      if (k.sec) S.secili = k.sec as typeof S.secili;
      PLAN.ciz();
    };
  });

  // Altlık resim
  if (p.altlik) {
    const c = kart(
      'Altlık resim',
      `<label class="alan"><span>Saydamlık</span><input type="range" min="0.1" max="1" step="0.05" id="aOp" value="${p.altlik.opak}"></label>
       <label class="alan"><span>Ölçek</span><input type="number" step="0.002" min="0.002" id="aOl" value="${p.altlik.olcek.toFixed(4)}"></label>
       <label class="alan"><span>Döndür (°)</span><input type="number" step="1" min="-180" max="180" id="aAc" value="${p.altlik.aci || 0}"></label>
       <button class="ubtn" id="aKal">İki noktayla ölçekle</button>`,
      { t: 'Kaldır', f: () => degistir(() => (p.altlik = null)) },
    );
    ($('#aOp', c) as HTMLInputElement).oninput = e => {
      p.altlik!.opak = +(e.target as HTMLInputElement).value;
      PLAN.ciz();
      kaydetGecikmeli();
    };
    ($('#aOl', c) as HTMLInputElement).onchange = e => degistir(() => (p.altlik!.olcek = Math.max(0.001, +(e.target as HTMLInputElement).value)));
    ($('#aAc', c) as HTMLInputElement).onchange = e => degistir(() => (p.altlik!.aci = +(e.target as HTMLInputElement).value || 0));
    $('#aKal', c)!.onclick = () => aracSec('kalibre');
  }
}

/* Kat yönetimi */
function katEkle() {
  const p = P();
  const sira = p.katlar.filter(k => (k.sira ?? 0) >= 0).length;
  const id = uid();
  degistir(() => {
    p.katlar.push({ id, ad: sira + '. Kat', h: 2.8, d: 0.15, sira });
    S.katId = id;
  });
}

function bodrumKatEkle() {
  const p = P();
  const minSira = Math.min(0, ...p.katlar.map(k => k.sira ?? 0));
  const yeniSira = minSira - 1;
  const id = uid();
  degistir(() => {
    p.katlar.unshift({ id, ad: `${Math.abs(yeniSira)}. Bodrum Kat`, h: 2.7, d: 0.15, sira: yeniSira });
    S.katId = id;
  });
  bildir('Bodrum kat eklendi');
}

function katKopya() {
  const p = P();
  const sira = p.katlar.filter(k => (k.sira ?? 0) >= 0).length;
  const id = uid();
  const kaynak = S.katId!;
  degistir(() => {
    p.katlar.push({ id, ad: sira + '. Kat', h: kat().h, d: kat().d, sira });
    const es: Record<string, string> = {};
    for (const w of p.duvarlar.filter(x => x.kat === kaynak)) {
      const nw = kopya(w);
      nw.id = uid();
      nw.kat = id;
      es[w.id] = nw.id;
      p.duvarlar.push(nw);
    }
    for (const a of p.aciklar.filter(a => es[a.duvar])) {
      const na = kopya(a);
      na.id = uid();
      na.duvar = es[a.duvar];
      p.aciklar.push(na);
    }
    for (const o of p.odalar.filter(o => o.kat === kaynak)) {
      const no = kopya(o);
      no.id = uid();
      no.kat = id;
      p.odalar.push(no);
    }
    for (const m of p.mobilya.filter(m => m.kat === kaynak && m.tip === 'kolon')) {
      const nm = kopya(m);
      nm.id = uid();
      nm.kat = id;
      p.mobilya.push(nm);
    }
    for (const kr of (p.kirisler || []).filter(x => x.kat === kaynak)) {
      const nk = kopya(kr);
      nk.id = uid();
      nk.kat = id;
      p.kirisler.push(nk);
    }
    S.katId = id;
  });
  bildir('Kat duvarları, kolonları ve kirişleri kopyalandı');
}

function katSil() {
  const p = P();
  if (p.katlar.length < 2) {
    bildir('Son kalan kat silinemez');
    return;
  }
  const id = S.katId!;
  onayDiy('Katı sil', `“${kat().ad}” ve içindeki tüm elemanlar silinsin mi?`, () => {
    degistir(() => {
      const d = new Set(p.duvarlar.filter(w => w.kat === id).map(w => w.id));
      p.katlar = p.katlar.filter(k => k.id !== id);
      p.duvarlar = p.duvarlar.filter(w => w.kat !== id);
      p.aciklar = p.aciklar.filter(a => !d.has(a.duvar));
      p.odalar = p.odalar.filter(o => o.kat !== id);
      p.mobilya = p.mobilya.filter(m => m.kat !== id);
      p.kirisler = (p.kirisler || []).filter(m => m.kat !== id);
      p.olculer = p.olculer.filter(o => o.kat !== id);
      p.yazilar = p.yazilar.filter(y => y.kat !== id);
      p.tesisat = (p.tesisat || []).filter(t => t.kat !== id);
      p.borular = (p.borular || []).filter(b => b.kat !== id);
      S.katId = p.katlar[0].id;
    });
  });
}

/* Diyaloglar: Yazıdan Plan, Şablon, Projeler, Yardım */
function yaziPlanDiy() {
  diy(
    'Yazıdan plan oluştur',
    `<p class="bilgi" style="margin:0 0 8px">Oda adlarını ve boyutlarını yaz: <code>3+1 120m2</code>, <code>2 yatak odası 12 ve 16 m2, salon 30 m2, mutfak 12 m2, banyo, wc, balkon</code>.</p>
     <textarea id="yGirdi" rows="4" style="width:100%">3+1 130 m², ebeveyn banyolu, mutfak ayrı, balkon</textarea>
     <div style="margin-top:8px"><label class="alan"><span>Kat sayısı</span><select id="yKat"><option value="1">Tek kat</option><option value="2">2 kat (dubleks)</option></select></label></div>
     <div id="yOn" class="bilgi" style="margin-top:8px"></div>`,
    [
      {
        t: 'Planı oluştur',
        ana: true,
        f: () => {
          const { sp } = yaziyiAnla(($('#yGirdi') as HTMLTextAreaElement).value);
          if (+($('#yKat') as HTMLSelectElement).value > 1) sp.dubleks = true;
          projeYukle(planUret(sp));
          kapatDiy();
          bildir('Plan, tesisat ve boru hatları oluşturuldu');
        },
      },
    ],
  );
  const gunc = () => {
    const { sp, anla } = yaziyiAnla(($('#yGirdi') as HTMLTextAreaElement).value);
    const katSay = +($('#yKat') as HTMLSelectElement).value || (sp.dubleks ? 2 : 1);
    const yOn = $('#yOn');
    if (yOn) {
      yOn.innerHTML = `Anlaşılan (${katSay} kat): <b>${anla.map(esc).join(' · ') || `${sp.yatak}+1 · ${sp.alan} m²`}</b>`;
    }
  };
  setTimeout(() => {
    const yg = $('#yGirdi');
    const yk = $('#yKat');
    if (yg) yg.oninput = gunc;
    if (yk) yk.onchange = gunc;
    gunc();
  }, 20);
}

function sablonDiy() {
  const h = SABLONLAR.map(
    (s, i) => `<div style="display:flex;justify-content:space-between;align-items:center;gap:8px"><span><b>${esc(s.ad)}</b><small>${s.s.yatak}+1 · ${s.s.alan} m²${s.s.dubleks ? ' · dubleks' : ''}</small></span><button class="ubtn ana" data-si="${i}">Aç</button></div>`,
  ).join('');
  diy('Hazır plan şablonları', `<div class="plist">${h}</div>`, []);
  $$('#perde [data-si]').forEach(b => {
    b.onclick = () => {
      projeYukle(planUret(SABLONLAR[+b.dataset.si!].s));
      kapatDiy();
    };
  });
}

function projelerDiy() {
  const d = DEPO.oku();
  const l = Object.values(d.projeler).sort((a, b) => b.guncelleme - a.guncelleme);
  const h = l
    .map(
      x => `<div class="${x.id === P().id ? 'aktif' : ''}">
        <span data-ac="${x.id}"><b>${esc(x.ad)}</b><small>${x.katlar.length} kat · ${tarihTR(x.guncelleme)}</small></span>
        <button class="ubtn" data-sil="${x.id}">Sil</button>
      </div>`,
    )
    .join('');
  diy(
    'Projelerim',
    `<div class="plist">${h}</div><hr style="border-color:var(--cizgi)"><div class="satir"><button class="ubtn ana" id="yeniP">+ Yeni boş proje</button><button class="ubtn" id="icJson">.json içe aktar</button><button class="ubtn" id="icDxf">.dxf içe aktar</button></div>`,
    [],
  );
  $$('#perde [data-ac]').forEach(s => {
    s.onclick = () => {
      projeYukle(d.projeler[s.dataset.ac!]);
      kapatDiy();
    };
  });
  $$('#perde [data-sil]').forEach(b => {
    b.onclick = () => {
      const id = b.dataset.sil!;
      if (Object.keys(d.projeler).length < 2) {
        bildir('Son proje silinemez');
        return;
      }
      delete d.projeler[id];
      DEPO.yaz(d);
      if (id === P().id) projeYukle(Object.values(d.projeler)[0]);
      projelerDiy();
    };
  });
  $('#yeniP')!.onclick = () => {
    projeYukle(yeniProje('Yeni proje'));
    kapatDiy();
  };
  $('#icJson')!.onclick = () => ($('#dosyaJson') as HTMLInputElement).click();
  $('#icDxf')!.onclick = () => ($('#dosyaDxf') as HTMLInputElement).click();
}

function katmanlarDiy() {
  const etiket: [keyof KatmanAyar, string][] = [
    ['duvarlar', 'Duvar, Kapı & Odalar'],
    ['mobilya', 'Mobilyalar'],
    ['akslar', 'Akslar, Kolon & Kirişler'],
    ['sihhiBoru', 'Sıhhi Su, Kalorifer & Şaft'],
    ['elektrikHatti', 'Elektrik Sembol & Kablolar'],
    ['dogalgazHatti', 'Doğalgaz Hatları'],
    ['olculer', 'Ölçüler & Notlar'],
    ['arazi', 'Arsa, Kot & Peyzaj'],
  ];
  diy(
    'Katman Görünürlüğü (Layers)',
    `<div class="katman-grid">${etiket
      .map(([k, ad]) => `<label><input type="checkbox" data-katman="${k}" ${S.katmanlar[k] ? 'checked' : ''}><span>${ad}</span></label>`)
      .join('')}</div>`,
    [
      {
        t: 'Tümünü Aç',
        f: () => {
          (Object.keys(S.katmanlar) as (keyof KatmanAyar)[]).forEach(k => (S.katmanlar[k] = true));
          PLAN.ciz();
          katmanlarDiy();
        },
      },
      { t: 'Kapat', ana: true, f: kapatDiy },
    ],
  );
  $$('#perde [data-katman]').forEach(el => {
    el.onchange = () => {
      const inp = el as HTMLInputElement;
      S.katmanlar[inp.dataset.katman as keyof KatmanAyar] = inp.checked;
      PLAN.ciz();
    };
  });
}

function mepRaporDiy() {
  const mep = mepMuhendislikHesap();
  const linyeRows = mep.linyeListesi
    .map(
      l =>
        `<tr><td><b>${esc(l.kod)}</b></td><td>${esc(l.ad)}</td><td class="s">${l.adet}</td><td class="s">${fmt(l.gucW, 0)} W</td><td class="s">${l.sigortaA} A</td><td>${esc(l.kesit)}</td></tr>`,
    )
    .join('');
  const isiRows = mep.odaIsitma
    .map(
      o =>
        `<tr><td>${esc(o.katAd)}</td><td><b>${esc(o.odaAd)}</b></td><td class="s">${fmt(o.hacim, 1)} m³</td><td class="s">${fmt(o.gerekKcal, 0)} kcal/h</td><td class="s">${o.oneriMetre} m</td><td><span class="rozet ${o.yeterli ? 'iyi' : 'kotu'}">${o.yeterli ? 'Uygun' : 'Petek Eksik'}</span></td></tr>`,
    )
    .join('');
  const cakRows = mep.cakismalar.length
    ? mep.cakismalar
        .map(
          (c, idx) =>
            `<div data-ck="${idx}" style="display:flex;align-items:center;justify-content:space-between;gap:8px;padding:7px 9px;border:1px solid rgba(229,83,75,.45);border-radius:7px;background:rgba(229,83,75,.12);cursor:pointer;margin-bottom:5px">
               <span>⛔ ${esc(c.mesaj)}</span>
               <span class="ubtn" style="padding:2px 7px;font-size:11px">Planda göster</span>
             </div>`,
        )
        .join('')
    : '<div class="bilgi"><span class="rozet iyi">Farklı sistem boruları arasında kot çakışması yok</span></div>';

  diy(
    'MEP Mühendislik Hesap & Çakışma Analizi',
    `<div class="mini" style="grid-template-columns:repeat(4,1fr);margin-bottom:12px">
       <div><small>Kurulu / Talep Güç</small><b>${fmt(mep.toplamKuruluW / 1000, 1)} / ${fmt(mep.talepGucW / 1000, 1)} kW</b></div>
       <div><small>${esc(mep.faz)}</small><b>${mep.anaSigortaA} A (${mep.akimA} A)</b></div>
       <div><small>Toplam Isı Yükü</small><b>${fmt(mep.toplamIsiKcal, 0)} kcal/h</b></div>
       <div><small>Fiting / Pis Düşüm</small><b>${mep.fiting.dirsek90 + mep.fiting.dirsek45} Dirsek · ${mep.pisSuMaxDusumCm} cm</b></div>
     </div>
     <h4 style="margin:6px 0;color:var(--tur);font-size:12px;text-transform:uppercase">Elektrik Linye & Sigorta Dağılımı</h4>
     <table class="tbl" style="margin-bottom:12px">
       <thead><tr><th>Kod</th><th>Hat / Amaç</th><th class="s">Nokta</th><th class="s">Güç</th><th class="s">Sigorta</th><th>Kablo</th></tr></thead>
       <tbody>${linyeRows || '<tr><td colspan="6" class="bilgi">Elektrik noktası bulunamadı.</td></tr>'}</tbody>
     </table>
     <h4 style="margin:6px 0;color:var(--tur);font-size:12px;text-transform:uppercase">Mahal Isı İhtiyacı & Radyatör Yeterliliği</h4>
     <table class="tbl" style="margin-bottom:12px">
       <thead><tr><th>Kat</th><th>Mahal</th><th class="s">Hacim</th><th class="s">Isı Yükü</th><th class="s">Öneri Petek</th><th>Durum</th></tr></thead>
       <tbody>${isiRows || '<tr><td colspan="6" class="bilgi">Tanımlı oda bulunamadı.</td></tr>'}</tbody>
     </table>
     <h4 style="margin:6px 0;color:var(--tur);font-size:12px;text-transform:uppercase">Boru Çakışma Kontrolü (${mep.cakismalar.length})</h4>
     <div>${cakRows}</div>`,
    [{ t: 'Kapat', ana: true, f: kapatDiy }],
  );

  $$('#perde [data-ck]').forEach(el => {
    el.onclick = () => {
      const ck = mep.cakismalar[+el.dataset.ck!];
      kapatDiy();
      if (ck.katId !== S.katId) {
        S.katId = ck.katId;
        yenile();
      }
      S.disiplin = 'sihhi';
      S.boruGoster = true;
      gorunum('plan');
      PLAN.v.tx = PLAN.W / 2 - ck.x * PLAN.v.z;
      PLAN.v.ty = PLAN.H / 2 - ck.y * PLAN.v.z;
      PLAN.ciz();
    };
  });
}

function yardimDiy() {
  diy(
    'Klavye Kısayolları ve İpuçları',
    `<table class="tbl"><tbody>
      <tr><td><b>V</b> / <b>H</b></td><td>Seç aracı / Planı kaydır</td></tr>
      <tr><td><b>W</b> / <b>Q</b> / <b>O</b></td><td>Duvar çiz / Hızlı oda (veya 4x5 yaz) / Oda bul</td></tr>
      <tr><td><b>D</b> / <b>P</b> / <b>X</b> / <b>J</b></td><td>Kapı / Pencere / Aks / Taşıyıcı kiriş</td></tr>
      <tr><td><b>F</b> / <b>C</b> / <b>U</b> / <b>G</b></td><td>Ofset / Buda (Trim) / Uzat (Extend) / Birleştir (Fillet)</td></tr>
      <tr><td><b>M</b> / <b>E</b> / <b>B</b></td><td>Mobilya / Tesisat sembolü / Boru döşe</td></tr>
      <tr><td><b>Ö</b> / <b>N</b> / <b>T</b></td><td>Mesafe ölç / Çokgen Alan ölç / Yazı ekle</td></tr>
      <tr><td><b>Ctrl+C / V / D</b></td><td>Kopyala / Yapıştır / Çoğalt</td></tr>
      <tr><td><b>R</b> / <b>Del</b> / <b>Ctrl+Z</b></td><td>90° Döndür / Sil / Geri al</td></tr>
      <tr><td><b>Shift + Sürükle</b></td><td>Çoklu seçim kutusu veya serbest açılı çizim</td></tr>
      <tr><td><b>Sağ tık (Plan)</b></td><td>Bağlam menüsü (Sil, Böl, Aynala, Boru döşe…)</td></tr>
    </tbody></table>`,
    [{ t: 'Kapat', ana: true, f: kapatDiy }],
  );
}

/* Bağlam (Sağ Tık) Menüsü */
function baglamMenuAc(sx: number, sy: number, wx: number, wy: number) {
  const m = $('#baglamMenu')!;
  const h = PLAN.isabet(wx, wy);
  if (h && !S.cokluSecili.some(x => x.id === h.id)) {
    S.secili = h;
    panelKur();
    PLAN.ciz();
  }
  const items: { t: string; k?: string; f: () => void }[] = [];
  if (h) {
    items.push({ t: 'Sil', k: 'Del', f: seciliSil });
    if (['mobilya', 'tesisat', 'acik', 'kesit'].includes(h.tur)) {
      items.push({ t: '90° Döndür', k: 'R', f: () => seciliDondur(90) });
    }
    if (['duvar', 'mobilya', 'tesisat', 'boru', 'olcu', 'yazi', 'kiris'].includes(h.tur)) {
      items.push({ t: 'Kopyala', k: 'Ctrl+C', f: panoyaKopyala });
    }
    if (h.tur === 'duvar') {
      items.push({ t: 'Tıklanan yerden böl', f: () => duvariOrtadanBol(h.id, wx, wy) });
    }
    if (h.tur === 'mobilya' && MOB[PLAN.nesne(h)?.tip]?.ozel === 'kolon') {
      items.push({
        t: 'Kolonu tüm katlara kopyala',
        f: () => {
          const src = PLAN.nesne(h);
          degistir(() => {
            P().katlar.forEach(K => {
              if (K.id === S.katId) return;
              if (!P().mobilya.some(x => x.kat === K.id && x.tip === 'kolon' && Math.hypot(x.x - src.x, x.y - src.y) < 0.25)) {
                P().mobilya.push({ ...kopya(src), id: uid(), kat: K.id });
              }
            });
          });
          bildir('Kolon tüm katlara yerleştirildi');
        },
      });
    }
    items.push({ t: 'Yatay aynala', f: () => seciliAynala('x') });
  } else {
    if (S.pano.length) items.push({ t: 'Yapıştır', k: 'Ctrl+V', f: () => panodanYapistir(0.4) });
    items.push({ t: 'Oda bul (Alan)', k: 'O', f: () => {
      const r = odaBul(S.katId!, wx, wy);
      if (r && r.pts) {
        degistir(() => P().odalar.push({ id: uid(), kat: S.katId!, ad: 'Yeni Oda', zemin: 'parke', pts: r.pts! }));
      } else bildir('Bu noktada kapalı duvar çevresi yok');
    }});
    items.push({ t: 'Otomatik boru döşe', f: autoBoruUygula });
    items.push({ t: 'Plana sığdır', f: () => PLAN.sigdir() });
  }

  m.innerHTML = '';
  items.forEach(it => {
    const b = document.createElement('button');
    b.innerHTML = `<span>${esc(it.t)}</span>${it.k ? `<small class="bilgi">${esc(it.k)}</small>` : ''}`;
    b.onclick = () => {
      m.style.display = 'none';
      it.f();
    };
    m.appendChild(b);
  });
  m.style.left = Math.min(window.innerWidth - 200, sx) + 'px';
  m.style.top = Math.min(window.innerHeight - 220, sy) + 'px';
  m.style.display = 'block';
}

/* Görünüm Değiştirici */
export function gorunum(v: 'plan' | '3d' | 'metraj' | 'pafta') {
  S.gorunum = v;
  $$('.sekmeler button').forEach(b => b.classList.toggle('aktif', b.dataset.v === v));
  $$('.gorunum').forEach(g => g.classList.remove('aktif'));
  const targetId = v === 'plan' ? '#gPlan' : v === '3d' ? '#g3d' : v === 'metraj' ? '#gMetraj' : '#gPafta';
  $(targetId)?.classList.add('aktif');

  if (v === '3d') {
    const c3 = $('#c3d') as HTMLCanvasElement;
    if (!D3.gl) D3.baslat(c3);
    D3.boyut(c3);
    D3.sahneKur();
    D3.odakla();
    if (D3.mod === 'kesit') D3.mod = 'orbit';
    const k3 = $('#k3d') as HTMLSelectElement;
    k3.innerHTML =
      `<option value="tumu">Tüm bina</option><option value="kat">Sadece ${esc(kat().ad)}</option>` +
      (P().kesitler || []).map(k => `<option value="k:${k.id}">Kesit ${k.ad}–${k.ad}</option>`).join('');
    k3.value = D3.kesit;
    D3.ciz();
    ($('#tar3d') as HTMLSelectElement).value = P().ayar.tarih;
    ($('#saat3d') as HTMLInputElement).value = String(P().ayar.saat);
    $('#saatYaz3d')!.textContent = saatYaz(P().ayar.saat);
    ($('#golge3d') as HTMLInputElement).checked = P().ayar.golge !== false;
    ($('#tes3d') as HTMLInputElement).checked = S.d3Tesisat;
    ($('#xray3d') as HTMLInputElement).checked = S.d3Xray;
    ($('#aks3d') as HTMLInputElement).checked = S.d3Aks;
    ($('#kesitOfset3d') as HTMLInputElement).value = String(D3.kesitOfset);
  }
  if (v === 'metraj') metrajSayfa(() => gorunum('pafta'), mepRaporDiy);
  if (v === 'pafta') paftaSayfa();
  if (v === 'plan') {
    PLAN.boyut();
    PLAN.ciz();
  }
}

export function projeYukle(p: Proje) {
  S.p = kopya(p);
  if (!S.p.kirisler) S.p.kirisler = [];
  if (!S.p.borular) S.p.borular = [];
  if (!S.p.tesisat) S.p.tesisat = [];
  S.katId = S.p.katlar[0].id;
  S.secili = null;
  S.cokluSecili = [];
  S.d3Kirli = true;
  GECMIS.sifirla();
  ($('#projeAd') as HTMLInputElement).value = S.p.ad;
  const d = DEPO.oku();
  d.projeler[S.p.id] = S.p;
  d.son = S.p.id;
  DEPO.yaz(d);
  yenile();
  PLAN.sigdir();
  if (S.gorunum !== 'plan') gorunum(S.gorunum);
}

export function yenile() {
  durumaAlanYaz();
  panelKur();
  PLAN.ciz();
  if (S.gorunum === '3d') {
    D3.sahneKur();
    D3.ciz();
  }
  if (S.gorunum === 'metraj') metrajSayfa(() => gorunum('pafta'), mepRaporDiy);
}

/* Ana Başlatıcı */
let _baslatildi = false;
export function basla() {
  if (_baslatildi) return;
  _baslatildi = true;

  baglaYenile(yenile);

  const logoEl = $('#ust .marka');
  if (logoEl) {
    logoEl.innerHTML = LOGO(true, 22) + '<span>NexDrive <b>Mimar</b></span>';
  }

  const sol = $('#araclar')!;
  let grp = '';
  for (const a of ARACLAR) {
    if (a.g !== grp) {
      grp = a.g;
      const h = document.createElement('h6');
      h.textContent = grp;
      sol.appendChild(h);
    }
    const b = document.createElement('button');
    b.className = 'arac';
    b.dataset.id = a.id;
    b.title = `${a.ad}${a.k ? ' (' + a.k + ')' : ''}`;
    b.innerHTML = `<svg viewBox="0 0 24 24">${a.i}</svg><span>${a.ad}</span>${a.k ? `<kbd>${a.k}</kbd>` : ''}`;
    b.onclick = () => aracSec(a.id);
    sol.appendChild(b);
  }

  PLAN.init($('#c2d') as HTMLCanvasElement, $('#orta')!);
  baglaPlanOlay({
    onRefresh: () => yenile(),
    onRefreshPanel: () => panelKur(),
    onSelectTool: (id: string) => aracSec(id),
    onContextMenu: (sx: number, sy: number) => {
      const pt = PLAN.sonTikDunya || [0, 0];
      baglamMenuAc(sx, sy, pt[0], pt[1]);
    },
    onPrompt: (baslik: string, deger?: string, aciklama?: string) =>
      new Promise(res => {
        girdiDiy(baslik, aciklama || baslik, deger || '', 'text', v => res(v));
      }),
    onAskRoomName: oda => {
      girdiDiy('Oda Adı', 'Bu odanın adını girin', oda.ad, 'text', ad => {
        if (ad) {
          degistir(() => {
            oda.ad = ad;
          });
        }
      });
    },
  });

  // 3D olayları ve seçim/ölçüm kartı
  const d3Kart = $('#d3SecimKart')!;
  bagla3DOlay($('#c3d') as HTMLCanvasElement, res => {
    if (res.olcMesafe != null) {
      d3Kart.innerHTML = `<b>3D Mesafe Ölçümü</b><div style="font-size:15px;color:var(--tur);margin:4px 0">${fmt(res.olcMesafe, 2)} m</div><button class="ubtn" id="d3Kapat">Kapat</button>`;
      d3Kart.style.display = 'block';
      $('#d3Kapat', d3Kart)!.onclick = () => (d3Kart.style.display = 'none');
      return;
    }
    if (res.hit) {
      const h: D3HitBox = res.hit;
      d3Kart.innerHTML = `<b>${esc(h.ad)}</b>${h.detay ? `<div class="bilgi" style="margin:3px 0 6px">${esc(h.detay)}</div>` : ''}
        <div class="satir">
          ${['duvar', 'acik', 'oda', 'mobilya', 'boru', 'tesisat'].includes(h.tur) ? '<button class="ubtn" id="d3PlandaSec">Planda seç</button>' : ''}
          <button class="ubtn" id="d3Kapat">Kapat</button>
        </div>`;
      d3Kart.style.display = 'block';
      const pBtn = $('#d3PlandaSec', d3Kart);
      if (pBtn) {
        pBtn.onclick = () => {
          S.secili = { tur: h.tur as never, id: h.id };
          gorunum('plan');
          panelKur();
        };
      }
      $('#d3Kapat', d3Kart)!.onclick = () => (d3Kart.style.display = 'none');
    } else {
      d3Kart.style.display = 'none';
    }
  });

  // Bağlam menüsünü dış tıklamada kapat
  window.addEventListener('pointerdown', e => {
    const bm = $('#baglamMenu');
    if (bm && bm.style.display === 'block' && !bm.contains(e.target as Node)) bm.style.display = 'none';
  });

  window.addEventListener('resize', () => {
    PLAN.boyut();
    PLAN.ciz();
    if (D3.gl && S.gorunum === '3d') {
      D3.boyut($('#c3d') as HTMLCanvasElement);
      D3.ciz();
    }
  });

  // Klavye kısayolları
  window.addEventListener('keydown', e => {
    if (S.gorunum === '3d' && D3.mod === 'gez') {
      D3.tuslar.add(e.key.toLowerCase());
      return;
    }
    if (e.target instanceof Element && e.target.closest('input,select,textarea')) return;
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'z') {
      e.preventDefault();
      GECMIS.geri();
      return;
    }
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'y') {
      e.preventDefault();
      GECMIS.ileri();
      return;
    }
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'c') {
      e.preventDefault();
      panoyaKopyala();
      return;
    }
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'v') {
      e.preventDefault();
      panodanYapistir();
      return;
    }
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'd') {
      e.preventDefault();
      panoyaKopyala();
      panodanYapistir(0.45);
      return;
    }
    if (e.key === '?' || e.key === 'F1') {
      e.preventDefault();
      yardimDiy();
      return;
    }
    if (S.gorunum === 'plan' && PLAN.tus(e)) {
      e.preventDefault();
      return;
    }
    if (e.key === 'Delete' || e.key === 'Backspace') {
      seciliSil();
      return;
    }
    if (e.key.toLowerCase() === 'r') {
      e.preventDefault();
      seciliDondur(90);
      return;
    }
    const harita: Record<string, string> = {
      v: 'sec',
      h: 'kaydir',
      w: 'duvar',
      q: 'odarect',
      o: 'odabul',
      d: 'kapi',
      p: 'pencere',
      x: 'aks',
      j: 'kiris',
      f: 'ofset',
      c: 'buda',
      u: 'uzat',
      g: 'pah',
      m: 'mobilya',
      e: 'tesisat',
      b: 'boru',
      a: 'arsa',
      l: 'dis',
      k: 'kot',
      s: 'kesit',
      ö: 'olcu',
      n: 'alanolc',
      t: 'yazi',
    };
    const arac = harita[e.key.toLowerCase()];
    if (arac) aracSec(arac);
  });
  window.addEventListener('keyup', e => D3.tuslar.delete(e.key.toLowerCase()));

  // Üst çubuk olayları
  $$('.sekmeler button').forEach(b => (b.onclick = () => gorunum(b.dataset.v as never)));
  ($('#projeAd') as HTMLInputElement).onchange = e => degistir(() => (P().ad = (e.target as HTMLInputElement).value || 'Adsız proje'));
  ($('#katSec') as HTMLSelectElement).onchange = e => {
    S.katId = (e.target as HTMLSelectElement).value;
    S.secili = null;
    S.cokluSecili = [];
    S.d3Kirli = true;
    yenile();
  };
  $('#bGeri')!.onclick = () => GECMIS.geri();
  $('#bIleri')!.onclick = () => GECMIS.ileri();
  $('#bYazi')!.onclick = yaziPlanDiy;
  $('#bSablon')!.onclick = sablonDiy;
  $('#bProjeler')!.onclick = projelerDiy;
  $('#bAltlik')!.onclick = () => ($('#dosyaResim') as HTMLInputElement).click();
  $('#bMepRapor')!.onclick = mepRaporDiy;
  $('#bYardim')!.onclick = yardimDiy;

  const disaAktarDiy = () => {
    const p = P();
    diy(
      'Dışa aktar',
      `<div class="plist">
        <div><span><b>Proje dosyası (.json)</b><small>Tüm projeyi bilgisayara kaydet</small></span><button class="ubtn ana" id="exJ">İndir</button></div>
        <div><span><b>AutoCAD çizimi (.dxf)</b><small>Katmanlı DXF: duvarlar, borular, akslar, kesitler</small></span><button class="ubtn" id="exD">İndir</button></div>
        <div><span><b>AutoCAD içe aktar (.dxf)</b><small>Düz ASCII DXF dosyasından duvar ve arsa ekle</small></span><button class="ubtn" id="inD">Dosya seç</button></div>
        <div><span><b>Vektör PDF Paftası (.pdf)</b><small>Çok sayfalı teknik PDF (duvarlar + borular + antet)</small></span><button class="ubtn ana" id="exPdf">PDF indir</button></div>
        <div><span><b>3D Mesh (.obj)</b><small>Blender / SketchUp uyumlu Wavefront 3D dosya</small></span><button class="ubtn" id="exObj">.obj indir</button></div>
        <div><span><b>2D Plan görseli (.png)</b><small>Aktif kat planını yüksek çözünürlükte indir</small></span><button class="ubtn" id="exP">İndir</button></div>
        <div><span><b>Yazdır / Çıktı Paftaları</b><small>Mimari pafta sayfasında önizle</small></span><button class="ubtn" id="exPf">Paftaya git</button></div>
      </div>`,
      [],
    );
    $('#exJ')!.onclick = () => indir(asc(p.ad) + '.json', new Blob([JSON.stringify(p, null, 2)], { type: 'application/json' }));
    $('#exD')!.onclick = () => indir(asc(p.ad) + '.dxf', new Blob([dxfUret()], { type: 'application/dxf' }));
    $('#inD')!.onclick = () => {
      kapatDiy();
      ($('#dosyaDxf') as HTMLInputElement).click();
    };
    $('#exPdf')!.onclick = async () => {
      kapatDiy();
      const { pdfUret } = await import('./sheets');
      indir(asc(p.ad) + `_pafta_${PAFTA.kagit}.pdf`, pdfUret());
      bildir('Vektör PDF oluşturuldu');
    };
    $('#exObj')!.onclick = () => {
      const obj = D3.objUret();
      indir(asc(p.ad) + '.obj', new Blob([obj], { type: 'text/plain;charset=utf-8' }));
    };
    $('#exP')!.onclick = async () => {
      const { planResmi } = await import('./sheets');
      const r = planResmi({ katId: S.katId!, mobilya: true, olcu: true, kuzey: true, tesisat: S.tesisatGoster, boru: S.boruGoster }, 2400, 1700);
      const a = document.createElement('a');
      a.href = r.img;
      a.download = asc(p.ad) + '.png';
      a.click();
    };
    $('#exPf')!.onclick = () => {
      kapatDiy();
      gorunum('pafta');
    };
  };
  $('#bDisa')!.onclick = disaAktarDiy;

  // Mobil menü (<900px)
  $('#bMobilMenu')!.onclick = () => {
    diy(
      'Araçlar & İşlemler',
      `<div class="plist">
        <div><span><b>Projelerim</b><small>Yeni proje, kayıtlar veya JSON/DXF</small></span><button class="ubtn" id="mPrj">Aç</button></div>
        <div><span><b>Hazır Şablonlar</b><small>Daire, dubleks, villa planları</small></span><button class="ubtn" id="mSab">Seç</button></div>
        <div><span><b>Yazıdan Plan Oluştur</b><small>Oda metni yazarak anında plan kur</small></span><button class="ubtn" id="mYaz">Aç</button></div>
        <div><span><b>Altlık Resim Yükle</b><small>Kroki veya PDF görüntüsü</small></span><button class="ubtn" id="mAlt">Yükle</button></div>
        <div><span><b>MEP Mühendislik Analizi</b><small>Elektrik linye, ısıtma & boru çakışma kontrolü</small></span><button class="ubtn" id="mMep">Aç</button></div>
        <div><span><b>Dışa Aktar / İçe Aktar</b><small>PDF, DXF, OBJ, JSON, PNG</small></span><button class="ubtn ana" id="mDis">Aç</button></div>
      </div>`,
      [],
    );
    $('#mPrj')!.onclick = projelerDiy;
    $('#mSab')!.onclick = sablonDiy;
    $('#mYaz')!.onclick = yaziPlanDiy;
    $('#mMep')!.onclick = mepRaporDiy;
    $('#mAlt')!.onclick = () => {
      kapatDiy();
      ($('#dosyaResim') as HTMLInputElement).click();
    };
    $('#mDis')!.onclick = disaAktarDiy;
  };

  // Dosya okuma girişleri
  ($('#dosyaResim') as HTMLInputElement).onchange = e => {
    const f = (e.target as HTMLInputElement).files?.[0];
    if (!f) return;
    const rd = new FileReader();
    rd.onload = () => {
      const im = new Image();
      im.onload = () => {
        degistir(() => (P().altlik = { src: String(rd.result), x: 0, y: 0, olcek: 15 / im.width, opak: 0.45, aci: 0 }));
        bildir('Altlık eklendi — ölçeği uydurmak için “Altlık ölçek” kullanabilirsin');
      };
      im.src = String(rd.result);
    };
    rd.readAsDataURL(f);
    (e.target as HTMLInputElement).value = '';
  };

  ($('#dosyaJson') as HTMLInputElement).onchange = e => {
    const f = (e.target as HTMLInputElement).files?.[0];
    if (!f) return;
    const rd = new FileReader();
    rd.onload = () => {
      try {
        const j = JSON.parse(String(rd.result)) as Proje;
        if (!j.katlar) throw new Error('Geçersiz dosya');
        projeYukle(j);
        kapatDiy();
        bildir('Proje yüklendi');
      } catch {
        mesajDiy('Hata', 'Dosya okunamadı');
      }
    };
    rd.readAsText(f);
    (e.target as HTMLInputElement).value = '';
  };

  ($('#dosyaDxf') as HTMLInputElement).onchange = e => {
    const f = (e.target as HTMLInputElement).files?.[0];
    if (!f) return;
    const rd = new FileReader();
    rd.onload = () => {
      const res = dxfIceAktar(String(rd.result || ''));
      kapatDiy();
      if (!res.duvarSay && !res.arsaVar) bildir('DXF içinde desteklenen LINE/LWPOLYLINE bulunamadı');
      else {
        PLAN.sigdir();
        bildir(`DXF içe aktarıldı: ${res.duvarSay} duvar${res.arsaVar ? ' + arsa sınırı' : ''}`);
      }
    };
    rd.readAsText(f);
    (e.target as HTMLInputElement).value = '';
  };

  // 3D araç çubuğu olayları
  $$('#gec3d button').forEach(b => {
    b.onclick = () => {
      $$('#gec3d button').forEach(x => x.classList.remove('aktif'));
      b.classList.add('aktif');
      D3.mod = b.dataset.m as 'orbit' | 'gez';
      $('#gezIpucu')!.style.display = D3.mod === 'gez' ? 'block' : 'none';
      D3.ciz();
    };
  });
  ($('#k3d') as HTMLSelectElement).onchange = e => {
    D3.kesit = (e.target as HTMLSelectElement).value;
    D3.ciz();
  };
  ($('#kesitOfset3d') as HTMLInputElement).oninput = e => {
    D3.kesitOfset = +(e.target as HTMLInputElement).value;
    D3.ciz();
  };
  $('#o3d')!.onclick = e => {
    D3.orto = !D3.orto;
    (e.target as HTMLElement).classList.toggle('aktif', D3.orto);
    D3.ciz();
  };
  ($('#kam3d') as HTMLSelectElement).onchange = e => {
    const yon = (e.target as HTMLSelectElement).value as 'izo' | 'on' | 'arka' | 'sol' | 'sag' | 'ust';
    D3.kameraAyar(yon);
    $$('#gec3d button').forEach(x => x.classList.toggle('aktif', x.dataset.m === 'orbit'));
    $('#gezIpucu')!.style.display = 'none';
    $('#o3d')!.classList.toggle('aktif', D3.orto);
  };
  ($('#tes3d') as HTMLInputElement).onchange = e => {
    S.d3Tesisat = (e.target as HTMLInputElement).checked;
    D3.sahneKur();
    D3.ciz();
  };
  ($('#xray3d') as HTMLInputElement).onchange = e => {
    S.d3Xray = (e.target as HTMLInputElement).checked;
    D3.sahneKur();
    D3.ciz();
  };
  ($('#aks3d') as HTMLInputElement).onchange = e => {
    S.d3Aks = (e.target as HTMLInputElement).checked;
    D3.sahneKur();
    D3.ciz();
  };
  $('#olc3d')!.onclick = e => {
    S.d3OlcMod = !S.d3OlcMod;
    S.d3OlcNoktalar = [];
    (e.target as HTMLElement).classList.toggle('aktif', S.d3OlcMod);
    bildir(S.d3OlcMod ? '3D Ölçüm açık: iki noktaya tıkla' : '3D Ölçüm kapalı');
  };
  ($('#tar3d') as HTMLSelectElement).onchange = e => degistir(() => (P().ayar.tarih = (e.target as HTMLSelectElement).value));
  ($('#saat3d') as HTMLInputElement).oninput = e => {
    P().ayar.saat = +(e.target as HTMLInputElement).value;
    $('#saatYaz3d')!.textContent = saatYaz(P().ayar.saat);
    D3.ciz();
    kaydetGecikmeli();
  };
  ($('#golge3d') as HTMLInputElement).onchange = e => degistir(() => (P().ayar.golge = (e.target as HTMLInputElement).checked));
  $('#objIndir')!.onclick = () => {
    const obj = D3.objUret();
    indir(asc(P().ad) + '.obj', new Blob([obj], { type: 'text/plain;charset=utf-8' }));
    bildir('3D Mesh (.obj) indirildi');
  };
  $('#foto3d')!.onclick = () => {
    const a = document.createElement('a');
    a.href = D3.foto(1920, 1200, () => {}, 'image/png');
    a.download = asc(P().ad) + '_3d.png';
    a.click();
  };

  let oynat = 0;
  $('#oynat3d')!.onclick = () => {
    if (oynat) {
      clearInterval(oynat);
      oynat = 0;
      $('#oynat3d')!.textContent = '▶';
      return;
    }
    $('#oynat3d')!.textContent = '⏸';
    oynat = window.setInterval(() => {
      if (S.gorunum !== '3d') return;
      const p = P();
      p.ayar.saat = +(p.ayar.saat + 0.15).toFixed(2);
      if (p.ayar.saat > 20) p.ayar.saat = 6;
      ($('#saat3d') as HTMLInputElement).value = String(p.ayar.saat);
      $('#saatYaz3d')!.textContent = saatYaz(p.ayar.saat);
      D3.ciz();
    }, 60);
  };

  // İlk proje yüklemesi
  const d = DEPO.oku();
  let bas = d.son && d.projeler[d.son] ? d.projeler[d.son] : Object.values(d.projeler)[0];
  if (!bas) bas = ornekProje();
  projeYukle(bas);
  aracSec('sec');
}
