import { BORU_TIPLERI, TES, mobOlcu } from './catalog';
import { P, S, duvar, duvarBoy, kat, katOturum } from './core';
import { G, Pt } from './geometry';
import type { BoruHatti, BoruTuru, DisiplinModu, KatmanAyar, TesisatNokta } from './types';
import { RAD, fmt, r3, uid } from './utils';

export function tesisatSembol(
  ctx: CanvasRenderingContext2D,
  t: Pick<TesisatNokta, 'tip' | 'x' | 'y' | 'r'>,
  X: (x: number) => number,
  Y: (y: number) => number,
  z: number,
  o: { baski?: boolean },
  hayalet = false,
) {
  const T = TES[t.tip];
  if (!T) return;
  const s = Math.max(5, 0.14 * z);
  const x = X(t.x);
  const y = Y(t.y);
  const r = (t.r || 0) * RAD;
  const renk = o.baski ? '#111' : T.renk;
  ctx.save();
  ctx.translate(x, y);
  ctx.rotate(r);
  if (hayalet) ctx.globalAlpha = 0.55;
  ctx.strokeStyle = renk;
  ctx.fillStyle = renk;
  ctx.lineWidth = 1.4;
  ctx.font = `700 ${Math.round(s * 1.05)}px system-ui`;
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  const yaz = (m: string, yy = 0) => ctx.fillText(m, 0, yy);

  switch (t.tip) {
    case 'priz':
    case 'etanj':
      ctx.beginPath();
      ctx.arc(0, 0, s, Math.PI, 0);
      ctx.stroke();
      ctx.beginPath();
      ctx.moveTo(-s, 0);
      ctx.lineTo(s, 0);
      ctx.moveTo(0, -s);
      ctx.lineTo(0, -s * 1.6);
      ctx.stroke();
      if (t.tip === 'etanj') yaz('E', -s * 0.45);
      break;
    case 'anahtar':
      ctx.beginPath();
      ctx.arc(0, -s * 0.4, s * 0.45, 0, 7);
      ctx.fill();
      ctx.beginPath();
      ctx.moveTo(0, -s * 0.4);
      ctx.lineTo(s * 1.1, -s * 1.5);
      ctx.lineTo(s * 1.5, -s * 1.1);
      ctx.stroke();
      break;
    case 'lamba':
      ctx.beginPath();
      ctx.arc(0, 0, s, 0, 7);
      ctx.stroke();
      ctx.beginPath();
      ctx.moveTo(-s * 0.7, -s * 0.7);
      ctx.lineTo(s * 0.7, s * 0.7);
      ctx.moveTo(s * 0.7, -s * 0.7);
      ctx.lineTo(-s * 0.7, s * 0.7);
      ctx.stroke();
      break;
    case 'aplik':
      ctx.beginPath();
      ctx.arc(0, -s * 0.6, s * 0.7, 0, 7);
      ctx.stroke();
      ctx.beginPath();
      ctx.moveTo(0, 0);
      ctx.lineTo(0, -s * 0.1);
      ctx.moveTo(-s * 0.5, -s * 1.1);
      ctx.lineTo(s * 0.5, -s * 0.1);
      ctx.stroke();
      break;
    case 'tv':
      ctx.strokeRect(-s, -s * 1.3, s * 2, s * 1.3);
      ctx.font = `700 ${Math.round(s * 0.8)}px system-ui`;
      yaz('TV', -s * 0.62);
      break;
    case 'klima':
      ctx.strokeRect(-s * 2.4, -s * 0.9, s * 4.8, s * 0.9);
      ctx.font = `700 ${Math.round(s * 0.72)}px system-ui`;
      yaz('KLİMA', -s * 0.45);
      break;
    case 'pano':
      ctx.fillRect(-s * 1.4, -s * 0.8, s * 2.8, s * 0.8);
      break;
    case 'kombi':
      ctx.strokeRect(-s * 1.2, -s * 2.2, s * 2.4, s * 2.2);
      yaz('K', -s * 1.1);
      break;
    case 'petek':
      ctx.strokeRect(-s * 2.6, -s * 0.7, s * 5.2, s * 0.7);
      ctx.beginPath();
      for (let i = -2; i <= 2; i++) {
        ctx.moveTo(i * s, -s * 0.7);
        ctx.lineTo(i * s, 0);
      }
      ctx.stroke();
      break;
    case 'sayac':
      ctx.strokeRect(-s, -s * 1.6, s * 2, s * 1.6);
      ctx.font = `700 ${Math.round(s * 0.7)}px system-ui`;
      yaz('SY', -s * 0.8);
      break;
    case 'dogalgaz_sayac':
      ctx.strokeRect(-s * 1.2, -s * 1.6, s * 2.4, s * 1.6);
      ctx.font = `700 ${Math.round(s * 0.65)}px system-ui`;
      yaz('DG', -s * 0.8);
      break;
    case 'kollektor':
      ctx.fillStyle = '#fff';
      ctx.fillRect(-s * 1.6, -s * 0.8, s * 3.2, s * 0.8);
      ctx.strokeRect(-s * 1.6, -s * 0.8, s * 3.2, s * 0.8);
      ctx.fillStyle = renk;
      ctx.font = `700 ${Math.round(s * 0.6)}px system-ui`;
      yaz('KOL', -s * 0.4);
      break;
    case 'hidrofor':
      ctx.beginPath();
      ctx.arc(0, 0, s * 1.3, 0, 7);
      ctx.fillStyle = '#fff';
      ctx.fill();
      ctx.stroke();
      ctx.fillStyle = renk;
      ctx.font = `700 ${Math.round(s * 0.75)}px system-ui`;
      yaz('HD', 0.5);
      break;
    case 'saft':
      ctx.fillStyle = '#e7f8f8';
      ctx.fillRect(-s * 1.5, -s * 1.5, s * 3, s * 3);
      ctx.strokeRect(-s * 1.5, -s * 1.5, s * 3, s * 3);
      ctx.beginPath();
      ctx.moveTo(-s * 1.5, -s * 1.5);
      ctx.lineTo(s * 1.5, s * 1.5);
      ctx.moveTo(s * 1.5, -s * 1.5);
      ctx.lineTo(-s * 1.5, s * 1.5);
      ctx.stroke();
      break;
    case 'logar':
      ctx.fillStyle = '#f3ece7';
      ctx.fillRect(-s * 1.6, -s * 1.6, s * 3.2, s * 3.2);
      ctx.strokeRect(-s * 1.6, -s * 1.6, s * 3.2, s * 3.2);
      ctx.fillStyle = renk;
      ctx.font = `700 ${Math.round(s * 0.65)}px system-ui`;
      yaz('RÖG', 0);
      break;
    case 'yer_suzgeci':
      ctx.strokeRect(-s * 0.9, -s * 0.9, s * 1.8, s * 1.8);
      ctx.beginPath();
      ctx.arc(0, 0, s * 0.45, 0, 7);
      ctx.stroke();
      break;
    case 'su':
    case 'gider':
      ctx.beginPath();
      ctx.arc(0, 0, s * 0.9, 0, 7);
      ctx.fillStyle = '#fff';
      ctx.fill();
      ctx.stroke();
      ctx.fillStyle = renk;
      yaz(t.tip === 'su' ? 'S' : 'G', 0.5);
      break;
  }
  ctx.restore();
}

export function boruUzunluk(b: Pick<BoruHatti, 'pts'>): number {
  let L = 0;
  for (let i = 0; i + 1 < b.pts.length; i++) {
    L += Math.hypot(b.pts[i + 1][0] - b.pts[i][0], b.pts[i + 1][1] - b.pts[i][1]);
  }
  return L;
}

export function boruCiz(
  ctx: CanvasRenderingContext2D,
  b: BoruHatti,
  X: (x: number) => number,
  Y: (y: number) => number,
  z: number,
  o: { baski?: boolean; fs?: number },
  hayalet = false,
) {
  if (b.pts.length < 2) return;
  const T = BORU_TIPLERI[b.tur];
  if (!T) return;
  const renk = o.baski ? '#222' : T.renk;
  const fs = o.fs || Math.min(1.4, Math.max(0.7, z / 42));
  ctx.save();
  if (hayalet) ctx.globalAlpha = 0.55;
  ctx.strokeStyle = renk;
  ctx.fillStyle = renk;
  ctx.lineWidth = Math.max(1.5, Math.min(4.2, (b.cap / 35) * (z / 40)));
  ctx.lineCap = 'round';
  ctx.lineJoin = 'round';
  if (T.cizgi.length) ctx.setLineDash(T.cizgi);
  ctx.beginPath();
  b.pts.forEach((pt, i) => (i ? ctx.lineTo(X(pt[0]), Y(pt[1])) : ctx.moveTo(X(pt[0]), Y(pt[1]))));
  ctx.stroke();
  ctx.setLineDash([]);

  // Köşe/dirsek noktaları ve akış yönü okları
  for (let i = 0; i < b.pts.length; i++) {
    const [px, py] = b.pts[i];
    if (i > 0 && i < b.pts.length - 1) {
      ctx.beginPath();
      ctx.arc(X(px), Y(py), Math.max(2, ctx.lineWidth * 0.8), 0, 7);
      ctx.fill();
    }
    if (i + 1 < b.pts.length) {
      const [nx, ny] = b.pts[i + 1];
      const segL = Math.hypot(nx - px, ny - py);
      if (segL * z > 34) {
        const mx = X((px + nx) / 2);
        const my = Y((py + ny) / 2);
        const ang = Math.atan2(ny - py, nx - px);
        ctx.save();
        ctx.translate(mx, my);
        ctx.rotate(ang);
        ctx.beginPath();
        ctx.moveTo(5, 0);
        ctx.lineTo(-4, -3.5);
        ctx.lineTo(-4, 3.5);
        ctx.closePath();
        ctx.fill();
        ctx.restore();
      }
    }
  }

  // En uzun segment ortasına çap & eğim etiketi
  let enL = 0;
  let enIdx = 0;
  for (let i = 0; i + 1 < b.pts.length; i++) {
    const L = Math.hypot(b.pts[i + 1][0] - b.pts[i][0], b.pts[i + 1][1] - b.pts[i][1]);
    if (L > enL) {
      enL = L;
      enIdx = i;
    }
  }
  if (enL * z > 48) {
    const a = b.pts[enIdx];
    const c = b.pts[enIdx + 1];
    const mx = X((a[0] + c[0]) / 2);
    const my = Y((a[1] + c[1]) / 2);
    let ang = Math.atan2(c[1] - a[1], c[0] - a[0]);
    if (ang > Math.PI / 2 || ang < -Math.PI / 2) ang += Math.PI;
    const lbl = `Ø${b.cap}${b.egim ? ` · %${b.egim}` : ''}`;
    ctx.save();
    ctx.translate(mx, my);
    ctx.rotate(ang);
    ctx.font = `700 ${9 * fs}px system-ui`;
    const tw = ctx.measureText(lbl).width;
    ctx.fillStyle = 'rgba(255,255,255,0.88)';
    ctx.fillRect(-tw / 2 - 2, -11 * fs, tw + 4, 10 * fs);
    ctx.fillStyle = renk;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'bottom';
    ctx.fillText(lbl, 0, -2);
    ctx.restore();
  }
  ctx.restore();
}

export function boruKatmanAcik(tur: BoruTuru, dis: DisiplinModu, km: KatmanAyar): boolean {
  if (dis === 'mimari' || dis === 'statik') return false;
  if (dis === 'elektrik') return tur === 'elektrik_kablo';
  if (dis === 'sihhi') return tur !== 'elektrik_kablo';
  if (tur === 'elektrik_kablo') return km.elektrikHatti;
  if (tur === 'dogalgaz') return km.dogalgazHatti;
  return km.sihhiBoru;
}

export function tesisatNoktaKatmanAcik(tip: string, dis: DisiplinModu, km: KatmanAyar): boolean {
  if (dis === 'mimari' || dis === 'statik') return false;
  const g = TES[tip]?.g;
  if (dis === 'elektrik') return g === 'Elektrik';
  if (dis === 'sihhi') return g !== 'Elektrik';
  if (tip === 'dogalgaz_sayac') return km.dogalgazHatti;
  if (g === 'Elektrik') return km.elektrikHatti;
  return km.sihhiBoru;
}

export function tesisatCiz(
  ctx: CanvasRenderingContext2D,
  X: (x: number) => number,
  Y: (y: number) => number,
  z: number,
  o: { tesisat?: boolean; boru?: boolean; baski?: boolean; fs?: number; katman?: boolean },
  katId: string,
) {
  const p = P();
  const useLayer = o.katman !== false && !o.baski;
  const dis = useLayer ? S.disiplin : 'tumu';
  const km = useLayer
    ? S.katmanlar
    : { duvarlar: true, mobilya: true, akslar: true, sihhiBoru: true, elektrikHatti: true, dogalgazHatti: true, olculer: true, arazi: true };

  if (o.boru !== false && o.tesisat) {
    (p.borular || [])
      .filter(b => b.kat === katId && boruKatmanAcik(b.tur, dis, km))
      .forEach(b => boruCiz(ctx, b, X, Y, z, o));
  }
  if (o.tesisat) {
    (p.tesisat || [])
      .filter(t => t.kat === katId && tesisatNoktaKatmanAcik(t.tip, dis, km))
      .forEach(t => tesisatSembol(ctx, t, X, Y, z, o));
  }

  // MEP Çakışma uyarı işaretleri (ekran modunda ve borular açıkken)
  if (!o.baski && o.boru !== false && o.tesisat && (dis === 'tumu' || dis === 'sihhi' || dis === 'elektrik')) {
    const cak = boruCakismaBul(katId);
    cak.forEach(c => {
      const cx = X(c.x);
      const cy = Y(c.y);
      ctx.save();
      ctx.strokeStyle = '#e5534b';
      ctx.fillStyle = 'rgba(229, 83, 75, 0.22)';
      ctx.lineWidth = 1.8;
      ctx.beginPath();
      ctx.arc(cx, cy, Math.max(8, 0.22 * z), 0, 7);
      ctx.fill();
      ctx.stroke();
      ctx.fillStyle = '#b91c1c';
      ctx.font = '800 10px system-ui';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText('⚡', cx, cy);
      ctx.restore();
    });
  }
}

export function duvaraYasla(x: number, y: number, katId: string, maks = 0.6) {
  let en: { w: ReturnType<typeof P>['duvarlar'][number]; s: ReturnType<typeof G.segNokta> } | null = null;
  let ed = maks;
  for (const w of P().duvarlar.filter(w => w.kat === katId)) {
    const s = G.segNokta(x, y, w.x1, w.y1, w.x2, w.y2);
    if (s.d < ed && s.d > 1e-6) {
      ed = s.d;
      en = { w, s };
    }
  }
  if (!en) return null;
  const { w, s } = en;
  const dx = (x - s.x) / s.d;
  const dy = (y - s.y) / s.d;
  const off = w.k / 2 + 0.06;
  return { x: r3(s.x + dx * off), y: r3(s.y + dy * off), r: Math.round(Math.atan2(dy, dx) / RAD + 90), w };
}

export function otomatikTesisat(katId: string): TesisatNokta[] {
  const p = P();
  const K = p.katlar.find(k => k.id === katId)!;
  const i = p.katlar.indexOf(K);
  const yeni: TesisatNokta[] = [];
  const ekle = (tip: string, x: number, y: number, r = 0) =>
    yeni.push({ id: uid(), kat: katId, tip, x: r3(x), y: r3(y), r, kot: TES[tip]?.kot });
  const odalar = p.odalar.filter(o => o.kat === katId);
  const otur = katOturum(katId);
  const kapilar: { a: (typeof p.aciklar)[number]; w: (typeof p.duvarlar)[number]; mx: number; my: number; ux: number; uy: number }[] = [];
  p.aciklar.forEach(a => {
    const w = duvar(a.duvar);
    if (!w || w.kat !== katId) return;
    const L = duvarBoy(w);
    const ux = (w.x2 - w.x1) / L;
    const uy = (w.y2 - w.y1) / L;
    kapilar.push({ a, w, mx: w.x1 + ux * a.t * L, my: w.y1 + uy * a.t * L, ux, uy });
  });

  const kenarNokta = (o: (typeof odalar)[number], adet: number): [number, number, number][] => {
    const per = G.cevre(o.pts);
    const sonuc: [number, number, number][] = [];
    for (let k = 0; k < adet * 6 && sonuc.length < adet; k++) {
      let s = ((k * 0.618034) % 1) * per;
      for (let e = 0; e < o.pts.length; e++) {
        const a = o.pts[e];
        const b = o.pts[(e + 1) % o.pts.length];
        const L = Math.hypot(b[0] - a[0], b[1] - a[1]);
        if (s > L) {
          s -= L;
          continue;
        }
        if (s < 0.35 || s > L - 0.35) break;
        const x = a[0] + ((b[0] - a[0]) * s) / L;
        const y = a[1] + ((b[1] - a[1]) * s) / L;
        if (kapilar.some(d => Math.hypot(d.mx - x, d.my - y) < d.a.g / 2 + 0.45)) break;
        if (sonuc.some(q => Math.hypot(q[0] - x, q[1] - y) < 1.2)) break;
        const c = G.merkez(o.pts);
        const yas = duvaraYasla(x + (c[0] - x) * 0.02, y + (c[1] - y) * 0.02, katId, 0.4);
        if (yas) sonuc.push([yas.x, yas.y, yas.r]);
        break;
      }
    }
    return sonuc;
  };

  odalar.forEach(o => {
    const a = Math.abs(G.alan(o.pts));
    const ad = o.ad.toLocaleLowerCase('tr');
    const c = G.merkez(o.pts);
    const islak = /banyo|wc|tuvalet|duş|çamaşır/i.test(o.ad);
    if (/balkon|teras/.test(ad)) {
      const n = kenarNokta(o, 1)[0];
      if (n) ekle('aplik', ...n);
      return;
    }
    ekle('lamba', c[0], c[1]);
    const prizSay = islak ? (/banyo/.test(ad) ? 1 : 0) : /mutfak/.test(ad) ? 4 : /koridor|hol|antre/.test(ad) ? 1 : Math.max(2, Math.round(a / 6));
    kenarNokta(o, prizSay).forEach(n => ekle(islak ? 'etanj' : 'priz', ...n));
    if (/salon|yatak|çalışma|oturma/.test(ad)) {
      const n = kenarNokta(o, prizSay + 1)[prizSay];
      if (n) ekle('tv', ...n);
    }
    if (/salon/.test(ad)) {
      const n = kenarNokta(o, prizSay + 2)[prizSay + 1];
      if (n) ekle('klima', n[0], n[1], n[2]);
    }
    let anSay = 0;
    const anMax = /koridor|hol|antre/.test(ad) ? 2 : 9;
    kapilar
      .filter(d => d.a.tur !== 'pencere' && d.a.tur !== 'cati_pencere')
      .forEach(d => {
        if (anSay >= anMax) return;
        const nx = -d.uy;
        const ny = d.ux;
        const off = d.w.k / 2 + 0.15;
        for (const sg of [1, -1]) {
          const ix = d.mx + nx * off * sg;
          const iy = d.my + ny * off * sg;
          if (!G.icinde(ix, iy, o.pts)) continue;
          const kil = (d.a.mentese || 'sol') === 'sol' ? 1 : -1;
          const x = ix + d.ux * (d.a.g / 2 + 0.2) * kil;
          const y = iy + d.uy * (d.a.g / 2 + 0.2) * kil;
          ekle('anahtar', x, y, Math.round(Math.atan2(ny * sg, nx * sg) / RAD + 90));
          anSay++;
          break;
        }
      });
    const pen = kapilar
      .filter(d => d.a.tur === 'pencere' && d.w.tur === 'dis')
      .map(d => {
        const nx = -d.uy;
        const ny = d.ux;
        const off = d.w.k / 2 + 0.12;
        for (const sg of [1, -1]) {
          const x = d.mx + nx * off * sg;
          const y = d.my + ny * off * sg;
          if (G.icinde(x, y, o.pts)) return { d, x, y, r: Math.round(Math.atan2(ny * sg, nx * sg) / RAD + 90) };
        }
        return null;
      })
      .filter((x): x is NonNullable<typeof x> => !!x)
      .sort((u, v) => v.d.a.g - u.d.a.g);
    if (pen[0] && !/koridor|hol|antre|kiler/.test(ad)) ekle('petek', pen[0].x, pen[0].y, pen[0].r);
  });

  // Islak hacim noktaları + yer süzgeci
  p.mobilya
    .filter(m => m.kat === katId && ['wc', 'lavabo', 'evye', 'dus', 'kuvet', 'camasir'].includes(m.tip))
    .forEach(m => {
      const { w, d } = mobOlcu(m);
      const arka = G.donder(0, -d / 2 + 0.08, m.r || 0);
      const yan = G.donder(w / 4, 0, m.r || 0);
      ekle('su', m.x + arka[0] - yan[0], m.y + arka[1] - yan[1]);
      if (m.tip !== 'dus') ekle('gider', m.x + arka[0] + yan[0], m.y + arka[1] + yan[1]);
      else ekle('gider', m.x, m.y);
    });

  // Banyo/WC odalarına yer süzgeci + en yakın ıslak odaya şaft
  const banyolar = odalar.filter(o => /banyo|wc/i.test(o.ad));
  banyolar.forEach((b, idx) => {
    const c = G.merkez(b.pts);
    ekle('yer_suzgeci', c[0] + 0.2, c[1] + 0.2);
    if (idx === 0) {
      const kose = b.pts[0];
      ekle('saft', kose[0] + (c[0] - kose[0]) * 0.18, kose[1] + (c[1] - kose[1]) * 0.18);
    }
  });

  // Pano + Sayaç + Doğalgaz sayacı + Kombi + Kollektör
  const giris = kapilar.find(d => (d.a.tur === 'kapi' || d.a.tur === 'cift_kapi') && d.w.tur === 'dis');
  if (giris) {
    const nx = -giris.uy;
    const ny = giris.ux;
    const off = giris.w.k / 2 + 0.1;
    for (const sg of [1, -1]) {
      const x = giris.mx + nx * off * sg + giris.ux * (giris.a.g / 2 + 0.55);
      const y = giris.my + ny * off * sg + giris.uy * (giris.a.g / 2 + 0.55);
      if (otur ? G.icinde(x, y, otur) : odalar.some(o => G.icinde(x, y, o.pts))) {
        const r = Math.round(Math.atan2(ny * sg, nx * sg) / RAD + 90);
        ekle('pano', x, y, r);
        if (i === 0) {
          ekle('sayac', x + giris.ux * 0.55, y + giris.uy * 0.55, r);
          ekle('dogalgaz_sayac', x - nx * (giris.w.k + 0.25) * sg, y - ny * (giris.w.k + 0.25) * sg, r);
        }
        break;
      }
    }
  }

  const mutfak = odalar.find(o => /mutfak/i.test(o.ad));
  if (mutfak && i === 0) {
    const n = kenarNokta(mutfak, 6)[5] || kenarNokta(mutfak, 1)[0];
    if (n) {
      ekle('kombi', ...n);
      ekle('kollektor', n[0] + 0.35, n[1], n[2]);
    }
  }
  const koridor = odalar.find(o => /koridor|hol|antre/i.test(o.ad));
  if (koridor && i > 0) {
    const n = kenarNokta(koridor, 1)[0];
    if (n) ekle('kollektor', ...n);
  }
  if (i === 0 && otur) {
    const b = G.bbox(otur);
    ekle('logar', b.x1 - 1.2, b.y2 + 1.0);
  }
  return yeni;
}

/** İki nokta arasında L (dik açılı) boru güzergâhı oluşturur; paralel ofset ile hatlar üst üste binmez */
function dikGuzergah(a: Pt, b: Pt, ofset = 0, yatayOnce = true): Pt[] {
  const dx = b[0] - a[0];
  const dy = b[1] - a[1];
  if (Math.hypot(dx, dy) < 0.05) return [a, b];
  const ox = Math.abs(dx) > 0.1 ? 0 : ofset;
  const oy = Math.abs(dy) > 0.1 ? 0 : ofset;
  if (Math.abs(dx) < 0.08 || Math.abs(dy) < 0.08) {
    return [
      [r3(a[0] + ox), r3(a[1] + oy)],
      [r3(b[0] + ox), r3(b[1] + oy)],
    ];
  }
  const mid: Pt = yatayOnce ? [r3(b[0] + ofset), r3(a[1] + ofset)] : [r3(a[0] + ofset), r3(b[1] + ofset)];
  return [[r3(a[0]), r3(a[1])], mid, [r3(b[0]), r3(b[1])]];
}

/** Verilen kattaki tesisat noktalarından otomatik boru döşemeleri (soğuk su, sıcak su, pis su, kalorifer, elektrik, doğalgaz) üretir */
export function otomatikBoruDose(katId: string): BoruHatti[] {
  const p = P();
  const T = (p.tesisat || []).filter(t => t.kat === katId);
  const yeni: BoruHatti[] = [];
  if (!T.length) return yeni;

  const ekleBoru = (tur: BoruTuru, pts: Pt[], cap?: number) => {
    if (pts.length < 2) return;
    const B = BORU_TIPLERI[tur];
    yeni.push({
      id: uid(),
      kat: katId,
      tur,
      pts,
      cap: cap ?? B.varsCap,
      egim: B.varsEgim || 0,
      kot: B.varsKot,
      oto: true,
    });
  };

  const enYakin = (hedef: Pt, adaylar: TesisatNokta[]): TesisatNokta | null => {
    if (!adaylar.length) return null;
    return adaylar.reduce((a, b) =>
      Math.hypot(a.x - hedef[0], a.y - hedef[1]) < Math.hypot(b.x - hedef[0], b.y - hedef[1]) ? a : b,
    );
  };

  const saft = T.find(t => t.tip === 'saft') || p.tesisat.find(t => t.tip === 'saft');
  const kollektor = T.find(t => t.tip === 'kollektor');
  const kombi = T.find(t => t.tip === 'kombi') || p.tesisat.find(t => t.tip === 'kombi');
  const sayac = T.find(t => t.tip === 'sayac') || p.tesisat.find(t => t.tip === 'sayac');
  const hidrofor = T.find(t => t.tip === 'hidrofor');
  const logar = T.find(t => t.tip === 'logar') || p.tesisat.find(t => t.tip === 'logar');
  const pano = T.find(t => t.tip === 'pano') || p.tesisat.find(t => t.tip === 'pano');
  const dgSayac = T.find(t => t.tip === 'dogalgaz_sayac') || p.tesisat.find(t => t.tip === 'dogalgaz_sayac');

  // 1) Soğuk su ana hat + kollektör -> su noktaları
  const suKaynak = hidrofor || sayac || saft;
  const suHub = kollektor || kombi || suKaynak;
  if (suKaynak && suHub && suKaynak !== suHub) {
    ekleBoru('temiz_su_soguk', dikGuzergah([suKaynak.x, suKaynak.y], [suHub.x, suHub.y], 0.05, true), 25);
  }
  if (suHub) {
    T.filter(t => t.tip === 'su').forEach((s, idx) => {
      ekleBoru('temiz_su_soguk', dikGuzergah([suHub.x, suHub.y], [s.x, s.y], 0.04, idx % 2 === 0), 20);
      // WC dışındaki ıslak çıkışlara sıcak su hattı da götür
      const komsuMob = p.mobilya.find(m => m.kat === katId && Math.hypot(m.x - s.x, m.y - s.y) < 0.75);
      if (!komsuMob || !['wc', 'camasir'].includes(komsuMob.tip)) {
        const sicakKaynak = kombi || kollektor || saft;
        if (sicakKaynak) {
          ekleBoru('temiz_su_sicak', dikGuzergah([sicakKaynak.x, sicakKaynak.y], [s.x, s.y], -0.05, idx % 2 === 0), 20);
        }
      }
    });
  }

  // 2) Kalorifer (Kombi -> Kollektör -> Petekler)
  const isiHub = kollektor || kombi || saft;
  if (kombi && kollektor && kombi !== kollektor) {
    ekleBoru('kalorifer', dikGuzergah([kombi.x, kombi.y], [kollektor.x, kollektor.y], -0.06, false), 25);
  }
  if (isiHub) {
    T.filter(t => t.tip === 'petek').forEach((ptk, idx) => {
      ekleBoru('kalorifer', dikGuzergah([isiHub.x, isiHub.y], [ptk.x, ptk.y], 0.08, idx % 2 === 0), 20);
    });
  }

  // 3) Pis su giderleri -> Şaft / Rögar (eğimli PVC Ø50 branşman + Ø110 ana kollektör)
  const giderHedef = saft || logar;
  if (saft && logar && saft.kat === katId) {
    ekleBoru('pis_su', dikGuzergah([saft.x, saft.y], [logar.x, logar.y], 0, true), 110);
  }
  if (giderHedef) {
    T.filter(t => t.tip === 'gider' || t.tip === 'yer_suzgeci').forEach((g, idx) => {
      const komsuWc = p.mobilya.some(m => m.kat === katId && m.tip === 'wc' && Math.hypot(m.x - g.x, m.y - g.y) < 0.7);
      ekleBoru('pis_su', dikGuzergah([g.x, g.y], [giderHedef.x, giderHedef.y], 0, idx % 2 === 1), komsuWc ? 110 : 50);
    });
  } else {
    // Şaft/logar yoksa dış duvara en kısa pis su hattı
    const disW = p.duvarlar.filter(w => w.kat === katId && w.tur === 'dis');
    T.filter(t => t.tip === 'gider' || t.tip === 'yer_suzgeci').forEach(g => {
      if (!disW.length) return;
      let en: Pt = [g.x, g.y + 1.5];
      let ed = Infinity;
      for (const w of disW) {
        const s = G.segNokta(g.x, g.y, w.x1, w.y1, w.x2, w.y2);
        if (s.d < ed) {
          ed = s.d;
          en = [r3(s.x), r3(s.y)];
        }
      }
      ekleBoru('pis_su', [[g.x, g.y], en], 110);
    });
  }

  // 4) Elektrik kablo/boru güzergâhları (Pano -> odalardaki lambalar -> anahtar & prizler)
  if (pano) {
    const lambalar = T.filter(t => t.tip === 'lamba');
    lambalar.forEach(l => {
      ekleBoru('elektrik_kablo', dikGuzergah([pano.x, pano.y], [l.x, l.y], 0.03, true), 20);
    });
    T.filter(t => ['priz', 'etanj', 'anahtar', 'aplik', 'tv', 'klima'].includes(t.tip)).forEach(el => {
      const yakinLamba = el.tip === 'anahtar' || el.tip === 'aplik' ? enYakin([el.x, el.y], lambalar) : null;
      const src = yakinLamba || pano;
      ekleBoru('elektrik_kablo', dikGuzergah([src.x, src.y], [el.x, el.y], -0.04, false), el.tip === 'klima' ? 25 : 16);
    });
  }

  // 5) Doğalgaz (Doğalgaz sayacı -> Kombi & Ocak)
  if (dgSayac) {
    if (kombi) ekleBoru('dogalgaz', dikGuzergah([dgSayac.x, dgSayac.y], [kombi.x, kombi.y], -0.1, true), 25);
    const ocak = p.mobilya.find(m => m.kat === katId && m.tip === 'ocak');
    if (ocak) ekleBoru('dogalgaz', dikGuzergah([dgSayac.x, dgSayac.y], [ocak.x, ocak.y], -0.12, false), 20);
  }

  return yeni;
}

export interface BoruCakisma {
  katId: string;
  katAd: string;
  x: number;
  y: number;
  kot: number;
  turA: BoruTuru;
  turB: BoruTuru;
  mesaj: string;
}

export interface FitingSayim {
  dirsek90: number;
  dirsek45: number;
  te: number;
  vana: number;
}

export function fitingSay(hatlar: BoruHatti[]): FitingSayim {
  let dirsek90 = 0;
  let dirsek45 = 0;
  let te = 0;
  let vana = 0;

  for (const h of hatlar) {
    for (let i = 1; i + 1 < h.pts.length; i++) {
      const a = h.pts[i - 1];
      const m = h.pts[i];
      const b = h.pts[i + 1];
      const v1x = m[0] - a[0];
      const v1y = m[1] - a[1];
      const v2x = b[0] - m[0];
      const v2y = b[1] - m[1];
      const L1 = Math.hypot(v1x, v1y);
      const L2 = Math.hypot(v2x, v2y);
      if (L1 < 0.04 || L2 < 0.04) continue;
      const dot = Math.max(-1, Math.min(1, (v1x * v2x + v1y * v2y) / (L1 * L2)));
      const aci = Math.acos(dot) / RAD;
      if (aci > 65) dirsek90++;
      else if (aci > 20) dirsek45++;
    }
    if (h.tur === 'temiz_su_soguk' || h.tur === 'temiz_su_sicak' || h.tur === 'dogalgaz' || h.tur === 'kalorifer') {
      if (boruUzunluk(h) > 0.8) vana++;
    }
  }

  // Aynı tür ve aynı kattaki boruların gövdesine bağlanan T-parçaları say
  for (let i = 0; i < hatlar.length; i++) {
    const a = hatlar[i];
    if (!a.pts.length) continue;
    const uclar = [a.pts[0], a.pts[a.pts.length - 1]];
    for (const uc of uclar) {
      let bagli = false;
      for (let j = i + 1; j < hatlar.length && !bagli; j++) {
        const b = hatlar[j];
        if (b.kat !== a.kat || b.tur !== a.tur) continue;
        for (let s = 0; s + 1 < b.pts.length; s++) {
          const d = G.segNokta(uc[0], uc[1], b.pts[s][0], b.pts[s][1], b.pts[s + 1][0], b.pts[s + 1][1]);
          if (d.d < 0.06 && d.t > 0.05 && d.t < 0.95) {
            te++;
            bagli = true;
            break;
          }
        }
      }
    }
  }

  return { dirsek90, dirsek45, te, vana };
}

export function boruCakismaBul(sadeceKatId?: string): BoruCakisma[] {
  const p = P();
  const out: BoruCakisma[] = [];
  const borular = p.borular || [];
  const katlar = sadeceKatId ? p.katlar.filter(k => k.id === sadeceKatId) : p.katlar;

  for (const K of katlar) {
    const kHat = borular.filter(b => b.kat === K.id && b.pts.length >= 2);
    const kNoktalar = (p.tesisat || []).filter(t => t.kat === K.id);
    const yakinHub = (x: number, y: number) =>
      kNoktalar.some(t => ['saft', 'kollektor', 'kombi', 'pano', 'sayac', 'hidrofor'].includes(t.tip) && Math.hypot(t.x - x, t.y - y) < 0.35);

    for (let i = 0; i < kHat.length; i++) {
      const A = kHat[i];
      const kotA = A.kot ?? BORU_TIPLERI[A.tur]?.varsKot ?? 0;
      for (let j = i + 1; j < kHat.length; j++) {
        const B = kHat[j];
        if (A.tur === B.tur) continue;
        const kotB = B.kot ?? BORU_TIPLERI[B.tur]?.varsKot ?? 0;
        const minClearance = (A.cap + B.cap) / 2000 + 0.025;
        if (Math.abs(kotA - kotB) > minClearance) continue;

        let bulundu = false;
        for (let sa = 0; sa + 1 < A.pts.length && !bulundu; sa++) {
          const [ax1, ay1] = A.pts[sa];
          const [ax2, ay2] = A.pts[sa + 1];
          for (let sb = 0; sb + 1 < B.pts.length && !bulundu; sb++) {
            const [bx1, by1] = B.pts[sb];
            const [bx2, by2] = B.pts[sb + 1];
            const hit = G.dogruKesisim(ax1, ay1, ax2, ay2, bx1, by1, bx2, by2, true);
            if (hit && hit.t > 0.04 && hit.t < 0.96 && hit.u > 0.04 && hit.u < 0.96) {
              if (yakinHub(hit.x, hit.y)) continue;
              if (out.some(c => c.katId === K.id && Math.hypot(c.x - hit.x, c.y - hit.y) < 0.3)) continue;
              out.push({
                katId: K.id,
                katAd: K.ad,
                x: r3(hit.x),
                y: r3(hit.y),
                kot: r3((kotA + kotB) / 2),
                turA: A.tur,
                turB: B.tur,
                mesaj: `${K.ad}: ${BORU_TIPLERI[A.tur].kisa} (kot ${Math.round(kotA * 100)} cm) ile ${BORU_TIPLERI[B.tur].kisa} (kot ${Math.round(kotB * 100)} cm) aynı kotta kesişiyor`,
              });
              bulundu = true;
            }
          }
        }
      }
    }
  }
  return out;
}

export interface LinyeItem {
  kod: string;
  ad: string;
  adet: number;
  gucW: number;
  sigortaA: number;
  kesit: string;
}

export interface OdaIsitmaItem {
  katAd: string;
  odaAd: string;
  alan: number;
  hacim: number;
  gerekKcal: number;
  gerekWatt: number;
  petekSay: number;
  oneriMetre: number;
  yeterli: boolean;
}

export interface MepMuhendislikRapor {
  toplamKuruluW: number;
  talepGucW: number;
  akimA: number;
  faz: 'Monofaze 230V' | 'Trifaze 400V';
  anaSigortaA: number;
  linyeListesi: LinyeItem[];
  odaIsitma: OdaIsitmaItem[];
  toplamIsiKcal: number;
  toplamIsiWatt: number;
  fiting: FitingSayim;
  pisSuMaxDusumCm: number;
  cakismalar: BoruCakisma[];
}

export function mepMuhendislikHesap(): MepMuhendislikRapor {
  const p = P();
  const T = p.tesisat || [];
  const B = p.borular || [];
  const say = (t: string) => T.filter(x => x.tip === t).length;

  const lambaAdet = say('lamba') + say('aplik');
  const prizAdet = say('priz') + say('etanj') + say('tv');
  const klimaAdet = say('klima');
  const mutfakGucAdet = p.mobilya.filter(m => m.tip === 'ocak' || m.tip === 'camasir').length + say('kombi');

  const aydGuc = lambaAdet * 60;
  const prizGuc = prizAdet * 300;
  const klimaGuc = klimaAdet * 2400;
  const mutfakGuc = mutfakGucAdet * 2200 + (say('hidrofor') * 1100);

  const linyeListesi: LinyeItem[] = [];
  if (lambaAdet) linyeListesi.push({ kod: 'L1', ad: 'Aydınlatma linyesi', adet: lambaAdet, gucW: aydGuc, sigortaA: 10, kesit: '3×1.5 mm² NYM' });
  if (prizAdet) linyeListesi.push({ kod: 'L2', ad: 'Normal priz & TV linyesi', adet: Math.max(0, say('priz') + say('tv')), gucW: (say('priz') + say('tv')) * 300, sigortaA: 16, kesit: '3×2.5 mm² NYM' });
  if (say('etanj')) linyeListesi.push({ kod: 'L3', ad: 'Islak hacim etanj priz (30mA KAKR)', adet: say('etanj'), gucW: say('etanj') * 450, sigortaA: 16, kesit: '3×2.5 mm² NYM' });
  if (mutfakGucAdet) linyeListesi.push({ kod: 'L4', ad: 'Fırın / Çamaşır / Kombi özel linye', adet: mutfakGucAdet, gucW: mutfakGuc, sigortaA: 20, kesit: '3×4 mm² NYM' });
  if (klimaAdet) linyeListesi.push({ kod: 'L5', ad: 'Split klima güç linyesi', adet: klimaAdet, gucW: klimaGuc, sigortaA: 25, kesit: '3×4 mm² NYM' });

  const toplamKuruluW = linyeListesi.reduce((s, x) => s + x.gucW, 0);
  const talepGucW = Math.round(toplamKuruluW * 0.65);
  const faz: 'Monofaze 230V' | 'Trifaze 400V' = talepGucW > 11000 ? 'Trifaze 400V' : 'Monofaze 230V';
  const akimA = faz === 'Trifaze 400V' ? talepGucW / (Math.sqrt(3) * 400 * 0.9) : talepGucW / (230 * 0.9);
  const sigSecenek = [16, 20, 25, 32, 40, 50, 63, 80, 100];
  const anaSigortaA = sigSecenek.find(s => s >= akimA * 1.15) || 100;

  // Isı kaybı ve radyatör hesabı
  const katsayi = p.cephe.mantolama ? 38 : 54; // kcal / m³·h
  const odaIsitma: OdaIsitmaItem[] = [];
  let toplamIsiKcal = 0;

  p.katlar.forEach(K => {
    const disW = p.duvarlar.filter(w => w.kat === K.id && w.tur === 'dis');
    const katPetek = T.filter(t => t.kat === K.id && t.tip === 'petek');
    p.odalar
      .filter(o => o.kat === K.id)
      .forEach(o => {
        if (/balkon|teras|garaj|depo|kiler/i.test(o.ad)) return;
        const alan = Math.abs(G.alan(o.pts));
        const hacim = alan * K.h;
        const c = G.merkez(o.pts);
        const disYakin = disW.some(w => G.segNokta(c[0], c[1], w.x1, w.y1, w.x2, w.y2).d < 4.5);
        const gerekKcal = Math.round(hacim * katsayi * (disYakin ? 1.12 : 0.95));
        const gerekWatt = Math.round(gerekKcal * 1.163);
        const petekSay = katPetek.filter(pt => G.icinde(pt.x, pt.y, o.pts)).length;
        const oneriMetre = Math.max(0.6, Math.round((gerekKcal / 1650) * 10) / 10);
        const yeterli = /koridor|hol|antre|wc/i.test(o.ad) || petekSay > 0;
        toplamIsiKcal += gerekKcal;
        odaIsitma.push({ katAd: K.ad, odaAd: o.ad, alan, hacim, gerekKcal, gerekWatt, petekSay, oneriMetre, yeterli });
      });
  });

  const fiting = fitingSay(B);
  const pisSuMaxDusumCm = B.filter(b => b.tur === 'pis_su').reduce(
    (mx, b) => Math.max(mx, Math.round(boruUzunluk(b) * (b.egim || 1.5))),
    0,
  );
  const cakismalar = boruCakismaBul();

  return {
    toplamKuruluW,
    talepGucW,
    akimA: Math.round(akimA * 10) / 10,
    faz,
    anaSigortaA,
    linyeListesi,
    odaIsitma,
    toplamIsiKcal,
    toplamIsiWatt: Math.round(toplamIsiKcal * 1.163),
    fiting,
    pisSuMaxDusumCm,
    cakismalar,
  };
}

export function tesisatMetraj(ekle: (grup: string, ad: string, miktar: number, birim: string, fk: string | null, not?: string) => void) {
  const p = P();
  const T = p.tesisat || [];
  const B = p.borular || [];
  if (!T.length && !B.length) return;
  const say = (t: string) => T.filter(x => x.tip === t).length;
  const G7 = 'Tesisat & boru döşeme';

  ekle(G7, 'Priz / anahtar / data noktası', say('priz') + say('etanj') + say('anahtar') + say('tv'), 'adet', 'tes_priz');
  ekle(G7, 'Aydınlatma noktası', say('lamba') + say('aplik'), 'adet', 'tes_lamba');
  ekle(G7, 'Sigorta panosu', say('pano'), 'adet', 'tes_pano');
  ekle(G7, 'Klima hattı', say('klima'), 'adet', 'tes_klima');
  ekle(G7, 'Kombi', say('kombi'), 'adet', 'tes_kombi');
  ekle(G7, 'Petek', say('petek'), 'adet', 'tes_petek');
  ekle(G7, 'Su / doğalgaz sayacı & kollektör', say('sayac') + say('dogalgaz_sayac') + say('kollektor'), 'adet', 'tes_sayac');
  ekle(G7, 'Tesisat şaftı / rögar / hidrofor', say('saft') + say('logar') + say('hidrofor'), 'adet', 'tes_saft_logar');

  // Boru hatları çizilmişse gerçek çizilen boru uzunluklarını (katlar arası şaft iniş/çıkış payı dahil) hesapla
  if (B.length) {
    const topByTur: Record<BoruTuru, { m: number; caplar: Record<number, number> }> = {
      temiz_su_soguk: { m: 0, caplar: {} },
      temiz_su_sicak: { m: 0, caplar: {} },
      pis_su: { m: 0, caplar: {} },
      kalorifer: { m: 0, caplar: {} },
      elektrik_kablo: { m: 0, caplar: {} },
      dogalgaz: { m: 0, caplar: {} },
    };
    for (const h of B) {
      const L = boruUzunluk(h);
      const bucket = topByTur[h.tur];
      if (!bucket) continue;
      bucket.m += L * 1.05; // %5 ek/dirsek payı
      bucket.caplar[h.cap] = (bucket.caplar[h.cap] || 0) + L * 1.05;
    }
    const katYukToplam = p.katlar.length > 1 ? p.katlar.slice(0, -1).reduce((s, k) => s + k.h + 0.15, 0) : 0;
    const saftSay = Math.max(1, p.katlar.filter(k => T.some(t => t.kat === k.id && t.tip === 'saft')).length > 0 ? 1 : 0);
    if (katYukToplam > 0 && saftSay > 0) {
      topByTur.temiz_su_soguk.m += katYukToplam;
      topByTur.pis_su.m += katYukToplam;
      topByTur.elektrik_kablo.m += katYukToplam;
    }
    for (const [tur, data] of Object.entries(topByTur) as [BoruTuru, { m: number; caplar: Record<number, number> }][]) {
      if (data.m < 0.05) continue;
      const tip = BORU_TIPLERI[tur];
      const detay = Object.entries(data.caplar)
        .map(([c, l]) => `Ø${c}: ${fmt(l, 1)} m`)
        .join(', ');
      ekle(G7, tip.ad, data.m, 'm', tip.fk, detay + ' (%5 ek/dirsek payı)');
    }
    const fit = fitingSay(B);
    const ekParca = fit.dirsek90 + fit.dirsek45 + fit.te;
    if (ekParca > 0) {
      ekle(G7, 'Boru ek parçası (Dirsek / Te)', ekParca, 'adet', 'tes_dirsek', `${fit.dirsek90}×90°, ${fit.dirsek45}×45°, ${fit.te}×Te`);
    }
    if (fit.vana > 0) {
      ekle(G7, 'Kesme / küresel vana grubu', fit.vana, 'adet', 'tes_vana');
    }
  } else {
    let kablo = 0;
    let su = 0;
    let gider = 0;
    p.katlar.forEach((K, i) => {
      const t = T.filter(x => x.kat === K.id);
      const pano = t.find(x => x.tip === 'pano') || T.find(x => x.tip === 'pano');
      const merk = katOturum(K.id) ? G.merkez(katOturum(K.id)!) : [0, 0];
      const hub = pano || { x: merk[0], y: merk[1] };
      const katFark = pano && pano.kat !== K.id ? Math.abs(i - p.katlar.findIndex(k => k.id === pano.kat)) * K.h : 0;
      t.filter(x => TES[x.tip]?.g === 'Elektrik' && x.tip !== 'pano').forEach(
        x => (kablo += (Math.abs(x.x - hub.x) + Math.abs(x.y - hub.y)) * 1.15 + 2.2 + katFark),
      );
      const kaynak = t.filter(x => x.tip === 'kombi' || x.tip === 'sayac');
      const W = p.duvarlar.filter(w => w.kat === K.id && w.tur === 'dis');
      t.filter(x => x.tip === 'su').forEach(x => {
        const k = kaynak.length
          ? kaynak.reduce((a, b) => (Math.hypot(a.x - x.x, a.y - x.y) < Math.hypot(b.x - x.x, b.y - x.y) ? a : b))
          : hub;
        su += 2 * ((Math.abs(x.x - k.x) + Math.abs(x.y - k.y)) * 1.1 + 1);
      });
      t.filter(x => x.tip === 'gider').forEach(x => {
        const d = W.length ? Math.min(...W.map(w => G.segNokta(x.x, x.y, w.x1, w.y1, w.x2, w.y2).d)) : 3;
        gider += d * 1.2 + 1 + (i > 0 ? K.h : 0);
      });
    });
    ekle(G7, 'Elektrik kablosu (tahmini)', kablo, 'm', 'tes_kablo', 'panoya dik açılı güzergâh + iniş payı');
    ekle(G7, 'Temiz su borusu (sıcak + soğuk)', su, 'm', 'tes_su', 'kombi/sayaca güzergâh × 2');
    ekle(G7, 'Pis su borusu', gider, 'm', 'tes_gider', 'en yakın dış duvara');
  }
}
