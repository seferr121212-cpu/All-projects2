import { DIS, odaZemini } from './catalog';
import { S, duvarBoy, duvarEkle, odaBul, yeniProje } from './core';
import { G, Pt } from './geometry';
import { otomatikBoruDose, otomatikTesisat } from './mep';
import type { AciklikTuru, Proje } from './types';
import { r3, sinir, uid } from './utils';

export interface PlanParam {
  ad?: string;
  yatak: number;
  alan: number;
  dubleks?: boolean;
  ebeveynBanyo?: boolean;
  acikMutfak?: boolean;
  calisma?: boolean;
  kiler?: boolean;
  garaj?: boolean;
  teras?: boolean;
  havuz?: boolean;
  yon?: 'guney' | 'kuzey' | 'dogu' | 'bati';
  cati?: string;
}

export const SABLONLAR: { ad: string; s: PlanParam }[] = [
  { ad: '1+1 · ≈60 m²', s: { yatak: 1, alan: 60 } },
  { ad: '2+1 · ≈90 m²', s: { yatak: 2, alan: 90 } },
  { ad: '3+1 · ≈120 m²', s: { yatak: 3, alan: 120, ebeveynBanyo: true } },
  { ad: '4+1 · ≈160 m²', s: { yatak: 4, alan: 160, ebeveynBanyo: true } },
  { ad: 'Dubleks 3+1 · ≈170 m²', s: { yatak: 3, alan: 170, dubleks: true, ebeveynBanyo: true } },
  {
    ad: 'Villa 4+1 · garaj + havuz (L plan)',
    s: { yatak: 4, alan: 190, ebeveynBanyo: true, garaj: true, havuz: true, teras: true, calisma: true },
  },
];

interface PlanRect {
  t: string;
  a?: number;
  min?: number;
  ad?: string;
  banyo?: boolean;
  acik?: boolean;
  kiler?: boolean;
  x0: number;
  x1: number;
  y0: number;
  y1: number;
  ust?: boolean;
  alt?: PlanRect;
  kapiKenar?: 'n' | 's' | 'e' | 'w';
  kapiX?: number;
}

interface BantOge {
  t: string;
  a: number;
  min: number;
  ad?: string;
  banyo?: boolean;
  acik?: boolean;
  kiler?: boolean;
}

export function planUret(spIn: Partial<PlanParam>): Proje {
  const sp: PlanParam = Object.assign(
    {
      yatak: 3,
      alan: 120,
      dubleks: false,
      ebeveynBanyo: false,
      acikMutfak: false,
      calisma: false,
      kiler: false,
      garaj: false,
      teras: false,
      havuz: false,
      yon: 'guney' as const,
    },
    spIn,
  );
  const N = sinir(Math.round(sp.yatak), 1, 6);
  const buyuk = sp.alan > 150;
  const Db = sp.dubleks ? 4.6 : buyuk ? 4.2 : 3.8;
  const Dc = 1.3;
  const Df = buyuk ? 5.4 : 4.8;
  const D = Db + Dc + Df;
  const ad = sp.ad || `${sp.dubleks ? 'Dubleks ' : ''}${N}+1 · ${Math.round(sp.alan)} m²`;
  const eski = S.p;
  const p = yeniProje(ad);
  S.p = p;

  const H = (t: string, a: number, min: number, ek: Partial<BantOge> = {}): BantOge => ({ t, a, min, ...ek });
  const katlar: { arka: BantOge[]; on: BantOge[]; kor: string; K?: Proje['katlar'][number]; rect?: PlanRect[] }[] = [];
  if (!sp.dubleks) {
    const arka: BantOge[] = [];
    const on: BantOge[] = [];
    for (let i = 1; i < N; i++) arka.push(H('yatak', N > 2 && i === 1 ? 12 : 11, 3.0, { ad: N === 2 ? 'Yatak Odası' : 'Çocuk Odası ' + i }));
    arka.push(H('banyo', 6, 2.1));
    if (sp.calisma) arka.push(H('calisma', 9, 2.6));
    on.push(
      H('ebeveyn', sp.ebeveynBanyo ? 17 : 14, sp.ebeveynBanyo ? 4.4 : 3.4, {
        ad: N === 1 ? 'Yatak Odası' : 'Ebeveyn Yatak Odası',
        banyo: sp.ebeveynBanyo,
      }),
    );
    on.push(H('salon', sinir(sp.alan * 0.25, 18, 48), 4.0));
    on.push(H('mutfak', sinir(sp.alan * 0.09, 8, 16), 2.7, { acik: sp.acikMutfak }));
    if (N >= 3 || sp.alan >= 110 || sp.kiler) on.push(H('wckol', 1.6 * Df, 1.6, { kiler: true }));
    katlar.push({ arka, on, kor: 'Koridor' });
  } else {
    const a0 = [
      H('merdiven', 1.4 * Db, 1.4),
      H('calisma', 10, 2.8, { ad: sp.calisma ? 'Çalışma Odası' : 'Misafir Odası' }),
      H('wc', 3.5, 1.6),
    ];
    const o0 = [H('salon', sinir(sp.alan * 0.2, 24, 50), 4.5), H('mutfak', sinir(sp.alan * 0.08, 10, 18), 3.0, { acik: sp.acikMutfak })];
    if (sp.kiler) a0.push(H('kiler', 4, 1.6));
    const a1 = [H('bosluk', 1.4 * Db, 1.4)];
    const o1: BantOge[] = [];
    for (let i = 1; i < N; i++) (i % 2 ? a1 : o1).push(H('yatak', 12, 3.0, { ad: N === 2 ? 'Yatak Odası' : 'Çocuk Odası ' + i }));
    a1.push(H('banyo', 6.5, 2.2));
    o1.unshift(H('ebeveyn', sp.ebeveynBanyo ? 18 : 15, sp.ebeveynBanyo ? 4.4 : 3.6, { ad: 'Ebeveyn Yatak Odası', banyo: sp.ebeveynBanyo }));
    katlar.push({ arka: a0, on: o0, kor: 'Hol' }, { arka: a1, on: o1, kor: 'Hol' });
  }

  const gen = (b: BantOge[], d: number) => b.map(x => Math.max(x.min, x.a / d));
  const tops = (b: number[]) => b.reduce((s, x) => s + x, 0);
  if (!sp.dubleks) {
    const k = katlar[0];
    if (tops(gen(k.on, Df)) - tops(gen(k.arka, Db)) > 4) {
      const i = k.on.findIndex(x => x.t === 'mutfak');
      if (i >= 0) k.arka.push(...k.on.splice(i, 1));
    }
  }
  const hedefW = (sp.dubleks ? sp.alan / 2 : sp.alan) / D;
  let W = Math.max(hedefW, ...katlar.flatMap(k => [tops(gen(k.arka, Db)), tops(gen(k.on, Df))]));
  W = Math.round(W * 10) / 10;
  const dagit = (b: BantOge[], d: number) => {
    const g = gen(b, d);
    const fark = W - tops(g);
    const esnek0 = b.map(x => (['salon', 'yatak', 'ebeveyn', 'mutfak', 'calisma'].includes(x.t) ? x.a : 0));
    const esnek = tops(esnek0) ? esnek0 : b.map(x => x.a);
    const te = tops(esnek) || 1;
    return g.map((v, i) => Math.round((v + (fark * esnek[i]) / te) * 100) / 100);
  };

  katlar.forEach((k, ki) => {
    const K =
      ki === 0
        ? p.katlar[0]
        : (() => {
            const n = { id: uid(), ad: '1. Kat', h: 2.8, d: 0.15, sira: 1 };
            p.katlar.push(n);
            return n;
          })();
    k.K = K;
    k.rect = [];
    const yerles = (b: BantOge[], y0: number, y1: number, ust: boolean) => {
      let x = 0;
      dagit(b, y1 - y0).forEach((w, i) => {
        const it = b[i];
        const x1 = i === b.length - 1 ? W : x + w;
        k.rect!.push({ ...it, x0: r3(x), x1: r3(x1), y0, y1, ust });
        x = x1;
      });
    };
    yerles(k.arka, 0, Db, true);
    yerles(k.on, Db + Dc, D, false);
    k.rect.push({ t: 'koridor', ad: k.kor, x0: 0, x1: W, y0: Db, y1: Db + Dc });
  });
  if (sp.garaj) katlar[0].rect!.push({ t: 'garaj', ad: 'Garaj', x0: W, x1: r3(W + 3.6), y0: Db, y1: D });

  const kapiKoy = (
    katId: string,
    x: number,
    y: number,
    g: number,
    tur: AciklikTuru,
    ic: Pt,
    ek: { h?: number; p?: number; mentese?: 'sol' | 'sag' } = {},
  ) => {
    let en: { w: Proje['duvarlar'][number]; s: ReturnType<typeof G.segNokta> } | null = null;
    let ed = 0.03;
    for (const w of p.duvarlar.filter(w => w.kat === katId)) {
      const s = G.segNokta(x, y, w.x1, w.y1, w.x2, w.y2);
      if (s.d < ed) {
        ed = s.d;
        en = { w, s };
      }
    }
    if (!en) return;
    const { w, s } = en;
    const L = duvarBoy(w);
    if (L < g + 0.1) return;
    const t = sinir(s.t * L, g / 2 + 0.05, L - g / 2 - 0.05) / L;
    const ux = (w.x2 - w.x1) / L;
    const uy = (w.y2 - w.y1) / L;
    const yon = (ic[0] - s.x) * -uy + (ic[1] - s.y) * ux >= 0 ? 1 : -1;
    if (p.aciklar.some(a => a.duvar === w.id && Math.abs(a.t - t) * L < (a.g + g) / 2)) return;
    p.aciklar.push({
      id: uid(),
      duvar: w.id,
      t: r3(t),
      g,
      h: tur === 'pencere' ? ek.h || 1.4 : ek.h || 2.1,
      p: tur === 'pencere' ? ek.p ?? 0.9 : 0,
      tur,
      yon,
      mentese: ek.mentese || 'sol',
    });
  };

  katlar.forEach((k, ki) => {
    const KI = k.K!.id;
    const R = k.rect!;
    const ekR: PlanRect[] = [];
    R.forEach(r => {
      if (r.t === 'ebeveyn' && r.banyo) {
        const bw = 2.1;
        const bd = 2.3;
        r.alt = {
          t: 'ebanyo',
          ad: 'Ebeveyn Banyosu',
          x0: r.x0,
          x1: r3(r.x0 + bw),
          y0: r.ust ? r3(r.y1 - bd) : r.y0,
          y1: r.ust ? r.y1 : r3(r.y0 + bd),
        };
        ekR.push(r.alt);
      }
      if (r.t === 'wckol') {
        r.t = 'kiler';
        r.ad = 'Kiler / çamaşır';
        const wc: PlanRect = {
          t: 'wc',
          ad: 'WC',
          x0: r.x0,
          x1: r.x1,
          y0: r.ust ? r3(r.y1 - 2.0) : r.y0,
          y1: r.ust ? r.y1 : r3(r.y0 + 2.0),
        };
        if (r.ust) r.y1 = wc.y0;
        else r.y0 = wc.y1;
        ekR.push(wc);
      }
    });
    R.push(...ekR);
    const icinde = (x: number, y: number) => R.some(r => x > r.x0 + 1e-6 && x < r.x1 - 1e-6 && y > r.y0 + 1e-6 && y < r.y1 - 1e-6);

    const acik: [number, number, number, number][] = [];
    R.forEach(r => {
      if (r.t === 'merdiven' || r.t === 'bosluk') acik.push([r.x0 + 0.02, r.y1, r.x1 - 0.02, r.y1]);
      if (r.t === 'mutfak' && r.acik) {
        const s = R.find(q => q.t === 'salon' && Math.abs(q.y0 - r.y0) < 0.01);
        if (s) {
          const x = Math.abs(s.x1 - r.x0) < 0.01 ? r.x0 : Math.abs(s.x0 - r.x1) < 0.01 ? r.x1 : null;
          if (x != null) acik.push([x, r.y0 + 0.02, x, r.y1 - 0.02]);
        }
      }
    });
    const cikar = (x1: number, y1: number, x2: number, y2: number): [number, number, number, number][] => {
      const L = Math.hypot(x2 - x1, y2 - y1);
      const ux = (x2 - x1) / L;
      const uy = (y2 - y1) / L;
      let ar: [number, number][] = [[0, L]];
      for (const [a1, b1, a2, b2] of acik) {
        if (Math.abs((a1 - x1) * uy - (b1 - y1) * ux) > 0.01 || Math.abs((a2 - x1) * uy - (b2 - y1) * ux) > 0.01) continue;
        let a = (a1 - x1) * ux + (b1 - y1) * uy;
        let b = (a2 - x1) * ux + (b2 - y1) * uy;
        if (a > b) [a, b] = [b, a];
        ar = ar.flatMap(([s, e]) => {
          if (b <= s || a >= e) return [[s, e] as [number, number]];
          const o: [number, number][] = [];
          if (a > s + 0.05) o.push([s, a]);
          if (b < e - 0.05) o.push([b, e]);
          return o;
        });
      }
      return ar.map(([s, e]) => [x1 + ux * s, y1 + uy * s, x1 + ux * e, y1 + uy * e]);
    };
    R.forEach(r =>
      (
        [
          [r.x0, r.y0, r.x1, r.y0],
          [r.x1, r.y0, r.x1, r.y1],
          [r.x1, r.y1, r.x0, r.y1],
          [r.x0, r.y1, r.x0, r.y0],
        ] as [number, number, number, number][]
      ).forEach(e => cikar(...e).forEach(q => duvarEkle(KI, q[0], q[1], q[2], q[3], 0.1, 'ic'))),
    );

    const kose: Pt[] = [];
    R.forEach(r => kose.push([r.x0, r.y0], [r.x1, r.y0], [r.x0, r.y1], [r.x1, r.y1]));
    for (const w of p.duvarlar.filter(w => w.kat === KI).slice()) {
      const L = duvarBoy(w);
      const ux = (w.x2 - w.x1) / L;
      const uy = (w.y2 - w.y1) / L;
      const ts = kose
        .map(q => {
          const s = G.segNokta(q[0], q[1], w.x1, w.y1, w.x2, w.y2);
          return s.d < 0.005 ? s.t * L : null;
        })
        .filter((t): t is number => t != null && t > 0.05 && t < L - 0.05)
        .sort((a, b) => a - b);
      const t2 = [...new Set(ts.map(t => Math.round(t * 1000) / 1000))];
      if (!t2.length) continue;
      const pts = [0, ...t2, L];
      const x1 = w.x1;
      const y1 = w.y1;
      w.x2 = r3(x1 + ux * pts[1]);
      w.y2 = r3(y1 + uy * pts[1]);
      for (let i = 1; i + 1 < pts.length; i++) {
        p.duvarlar.push({
          ...w,
          id: uid(),
          x1: r3(x1 + ux * pts[i]),
          y1: r3(y1 + uy * pts[i]),
          x2: r3(x1 + ux * pts[i + 1]),
          y2: r3(y1 + uy * pts[i + 1]),
        });
      }
    }
    p.duvarlar
      .filter(w => w.kat === KI)
      .forEach(w => {
        const L = duvarBoy(w);
        const mx = (w.x1 + w.x2) / 2;
        const my = (w.y1 + w.y2) / 2;
        const nx = (-(w.y2 - w.y1) / L) * 0.2;
        const ny = ((w.x2 - w.x1) / L) * 0.2;
        if (icinde(mx + nx, my + ny) !== icinde(mx - nx, my - ny)) {
          w.tur = 'dis';
          w.k = 0.25;
        }
      });

    const kor = R.find(r => r.t === 'koridor')!;
    const korY = kor.y0 + Dc / 2;
    R.forEach(r => {
      const cx = (r.x0 + r.x1) / 2;
      if (['yatak', 'ebeveyn', 'banyo', 'calisma', 'mutfak', 'salon', 'wc'].includes(r.t) && !(r.t === 'mutfak' && r.acik)) {
        const y = r.ust ? r.y1 : r.y0;
        const alt = r.alt;
        let x = r.x1 - 0.65 - (r.t === 'salon' ? 0.1 : 0);
        if (alt && x < alt.x1 + 0.6) x = alt.x1 + 0.6;
        if (r.t === 'wc') x = cx;
        const g = r.t === 'salon' ? 1.2 : ['banyo', 'wc'].includes(r.t) ? 0.8 : 0.9;
        if ((r.y0 >= kor.y0 - 0.01 && r.y0 <= kor.y1 + 0.01) || (r.y1 >= kor.y0 - 0.01 && r.y1 <= kor.y1 + 0.01)) {
          kapiKoy(KI, x, y, g, 'kapi', [x, r.ust ? y - 0.5 : y + 0.5], { mentese: r.ust ? 'sag' : 'sol' });
        }
        r.kapiKenar = r.ust ? 's' : 'n';
        r.kapiX = x;
      }
      if (r.t === 'ebanyo') {
        const pr = R.find(q => q.alt === r)!;
        kapiKoy(KI, r.x1, (r.y0 + r.y1) / 2, 0.8, 'kapi', [r.x1 - 0.5, (r.y0 + r.y1) / 2]);
        r.kapiKenar = pr ? 'e' : 'e';
      }
      if (r.t === 'kiler') {
        const yk = (r.y0 + r.y1) / 2;
        const kom = R.find(q => q !== r && Math.abs(q.x1 - r.x0) < 0.01 && q.y0 <= yk && q.y1 >= yk);
        if (kom) kapiKoy(KI, r.x0, yk, 0.8, 'kapi', [r.x0 + 0.4, yk]);
        r.kapiKenar = 'w';
      }
      if (r.t === 'garaj') {
        kapiKoy(KI, r.x0, korY, 0.9, 'kapi', [r.x0 + 0.5, korY]);
        kapiKoy(KI, (r.x0 + r.x1) / 2, r.y1, 2.6, 'kapi', [(r.x0 + r.x1) / 2, r.y1 - 0.5], { h: 2.3 });
        r.kapiKenar = 's';
      }
    });
    if (ki === 0) kapiKoy(KI, 0, korY, 1.0, 'kapi', [0.5, korY], { h: 2.2, mentese: 'sag' });

    const disDuvar = p.duvarlar.filter(w => w.kat === KI && w.tur === 'dis');
    const PEN: Record<string, [number, number, number] | null> = {
      salon: [1.8, 1.5, 0.8],
      yatak: [1.4, 1.4, 0.9],
      ebeveyn: [1.6, 1.4, 0.9],
      mutfak: [1.2, 1.2, 1.0],
      banyo: [0.6, 0.6, 1.6],
      ebanyo: [0.6, 0.6, 1.6],
      wc: [0.5, 0.5, 1.6],
      calisma: [1.4, 1.4, 0.9],
      koridor: null,
      kiler: [0.5, 0.5, 1.6],
      garaj: [1.0, 0.6, 1.5],
    };
    R.forEach(r => {
      const pp = PEN[r.t];
      if (!pp) return;
      const ust = disDuvar
        .map(w => {
          const mx = (w.x1 + w.x2) / 2;
          const my = (w.y1 + w.y2) / 2;
          const kenarda =
            (Math.abs(w.y1 - w.y2) < 0.01 && (Math.abs(w.y1 - r.y0) < 0.01 || Math.abs(w.y1 - r.y1) < 0.01) && mx > r.x0 && mx < r.x1) ||
            (Math.abs(w.x1 - w.x2) < 0.01 && (Math.abs(w.x1 - r.x0) < 0.01 || Math.abs(w.x1 - r.x1) < 0.01) && my > r.y0 && my < r.y1);
          if (!kenarda) return null;
          const a = Math.max(Math.min(w.x1, w.x2), r.x0);
          const b = Math.min(Math.max(w.x1, w.x2), r.x1);
          const c = Math.max(Math.min(w.y1, w.y2), r.y0);
          const d = Math.min(Math.max(w.y1, w.y2), r.y1);
          return { w, L: Math.max(b - a, d - c), x: (a + b) / 2, y: (c + d) / 2, guney: Math.abs(w.y1 - D) < 0.01 ? 1 : 0 };
        })
        .filter((x): x is NonNullable<typeof x> => !!x)
        .filter(x => !r.alt || !(x.x > r.alt.x0 && x.x < r.alt.x1 && x.y > r.alt.y0 - 0.01 && x.y < r.alt.y1 + 0.01))
        .sort((a, b) => b.guney - a.guney || b.L - a.L);
      ust.slice(0, r.t === 'salon' ? 2 : 1).forEach((u, i) => {
        const oA = (r.x1 - r.x0) * (r.y1 - r.y0) - (r.alt ? (r.alt.x1 - r.alt.x0) * (r.alt.y1 - r.alt.y0) : 0);
        const adet = r.t === 'salon' ? Math.min(2, ust.length) : 1;
        const gerek = ['salon', 'yatak', 'ebeveyn', 'mutfak', 'calisma'].includes(r.t) ? oA / 8 / adet / pp[1] + 0.05 : 0;
        const g = Math.min(Math.max(pp[0], Math.ceil(gerek * 10) / 10), u.L - 0.7);
        if (g < 0.45) return;
        const ic: Pt = [
          u.x + (Math.abs(u.w.x1 - u.w.x2) < 0.01 ? (u.x < W / 2 ? 0.5 : -0.5) : 0),
          u.y + (Math.abs(u.w.y1 - u.w.y2) < 0.01 ? (u.y < D / 2 ? 0.5 : -0.5) : 0),
        ];
        if (r.t === 'salon' && sp.teras && i === 0 && u.guney && u.L > 3.8) {
          kapiKoy(KI, u.x + 1.1, u.y, 2.0, 'balkon', ic, { h: 2.2 });
          kapiKoy(KI, u.x - 1.5, u.y, Math.max(1.2, Math.min(2.2, u.L / 2 - 1.0)), 'pencere', ic, { h: pp[1], p: pp[2] });
          return;
        }
        kapiKoy(KI, u.x, u.y, g, 'pencere', ic, { h: pp[1], p: pp[2] });
      });
    });

    R.forEach(r => {
      if (r.t === 'merdiven' || r.t === 'bosluk') return;
      const nokta: Pt = r.alt ? [(r.alt.x1 + r.x1) / 2, (r.y0 + r.y1) / 2] : [(r.x0 + r.x1) / 2, (r.y0 + r.y1) / 2];
      const var_ = p.odalar.find(o => o.kat === KI && G.icinde(nokta[0], nokta[1], o.pts));
      if (var_) {
        if (r.t === 'mutfak') var_.ad = 'Salon + Mutfak';
        return;
      }
      const o = odaBul(KI, nokta[0], nokta[1]);
      if (!o || !o.pts) return;
      const odaAd =
        r.ad ||
        ({ salon: 'Salon', mutfak: 'Mutfak', banyo: 'Banyo', wc: 'WC', calisma: 'Çalışma Odası', koridor: 'Koridor', kiler: 'Kiler' }[r.t] || 'Oda');
      p.odalar.push({ id: uid(), kat: KI, ad: odaAd, zemin: odaZemini(odaAd), pts: o.pts });
    });

    R.forEach(r => mobilyaDoseme(p, KI, r));
  });

  if (sp.teras) {
    const s = katlar[0].rect!.find(r => r.t === 'salon');
    if (s) {
      p.odalar.push({
        id: uid(),
        kat: p.katlar[0].id,
        ad: 'Teras',
        zemin: 'deck',
        pts: [
          [s.x0, D + 0.13],
          [s.x1, D + 0.13],
          [s.x1, D + 2.6],
          [s.x0, D + 2.6],
        ],
      });
    }
  }

  const bw = W + (sp.garaj ? 3.6 : 0);
  const on = sp.havuz ? 13 : 7;
  const ax0 = -6;
  const ay0 = -4;
  const ax1 = bw + 5;
  const ay1 = D + on + 2;
  p.arsa = {
    pts: [
      [ax0, ay0],
      [ax1, ay0],
      [ax1, ay1],
      [ax0, ay1],
    ],
  };
  const d = (tip: string, o: Record<string, unknown>) => p.dis.push({ id: uid(), tip, ...o });
  d('cim', { x: r3((ax0 + ax1) / 2), y: r3((D + 3 + ay1) / 2), w: r3(ax1 - ax0 - 1), d: r3(ay1 - D - 3.5), r: 0 });
  d('yol', { x: r3(ax0 / 2 - 0.1), y: r3(Db + Dc / 2), w: r3(-ax0 - 0.2), d: 1.4, r: 0 });
  if (!sp.garaj) {
    d('otopark', { x: -3, y: r3(D + 4.5), w: 5.2, d: 6, r: 0 });
    d('araba', { x: -3, y: r3(D + 4.5), w: 1.85, d: 4.5, r: 0 });
  } else {
    const g = katlar[0].rect!.find(r => r.t === 'garaj')!;
    d('araba', { x: r3((g.x0 + g.x1) / 2), y: r3((g.y0 + g.y1) / 2 + 0.3), w: 1.85, d: 4.5, r: 0 });
    d('otopark', { x: r3((g.x0 + g.x1) / 2), y: r3((D + ay1) / 2 + 0.5), w: 3.4, d: r3(ay1 - D - 1), r: 0 });
  }
  if (sp.havuz) d('havuz', { x: r3(W * 0.45), y: r3(D + 7.5), w: Math.min(9, r3(W * 0.6)), d: 4, r: 0 });
  for (const [x, y, c] of [
    [ax0 + 2.5, ay0 + 2.5, 4],
    [ax1 - 2.5, ay0 + 2.5, 4],
    [ax1 - 3, ay1 - 3, 4.5],
    [ax0 + 3, ay1 - 3, 3.5],
  ]) {
    d('agac', { x: r3(x), y: r3(y), cap: c });
  }
  for (let i = 0; i < 4; i++) d('cali', { x: r3(1 + i * 1.6), y: r3(D + 1.2), cap: 1 });
  const cs = p.arsa.pts;
  for (let i = 0; i < 4; i++) {
    const a = cs[i];
    const b = cs[(i + 1) % 4];
    if (i === 3) {
      d('cit', { x1: a[0], y1: a[1], x2: ax0, y2: r3(Db + Dc / 2 + 1.5), h: 1.6 });
      d('cit', { x1: ax0, y1: r3(Db + Dc / 2 - 1.5), x2: b[0], y2: b[1], h: 1.6 });
    } else {
      d('cit', { x1: a[0], y1: a[1], x2: b[0], y2: b[1], h: 1.6 });
    }
  }
  p.cati.tip = sp.cati || 'kirma';
  yonDonustur(p, sp.yon);

  // Şablonda da otomatik tesisat & boru döşemeleri oluştur
  p.katlar.forEach(K => {
    p.tesisat.push(...otomatikTesisat(K.id));
    p.borular.push(...otomatikBoruDose(K.id));
  });

  p.ozet = sp as unknown as Record<string, unknown>;
  S.p = eski;
  return p;
}

function mobilyaDoseme(p: Proje, KI: string, r: PlanRect) {
  const m = (tip: string, u: number, v: number, rr = 0, ek: { w?: number; d?: number } = {}) => {
    const k = r.kapiKenar || 's';
    let x: number;
    let y: number;
    let rot: number;
    if (k === 's') {
      x = r.x0 + u;
      y = r.y0 + v;
      rot = 0;
    } else if (k === 'n') {
      x = r.x1 - u;
      y = r.y1 - v;
      rot = 180;
    } else if (k === 'e') {
      x = r.x0 + v;
      y = r.y1 - u;
      rot = 270;
    } else {
      x = r.x1 - v;
      y = r.y0 + u;
      rot = 90;
    }
    p.mobilya.push({ id: uid(), kat: KI, tip, x: r3(x), y: r3(y), r: (rot + rr) % 360, ...ek });
  };
  const k = r.kapiKenar || 's';
  const Wu = k === 'n' || k === 's' ? r.x1 - r.x0 : r.y1 - r.y0;
  const Dv = k === 'n' || k === 's' ? r.y1 - r.y0 : r.x1 - r.x0;
  const kapiU = r.kapiX != null ? (k === 's' ? r.kapiX - r.x0 : k === 'n' ? r.x1 - r.kapiX : null) : null;
  const altU = r.alt ? (k === 's' ? [r.alt.x0 - r.x0, r.alt.x1 - r.x0] : [r.x1 - r.alt.x1, r.x1 - r.alt.x0]) : null;
  switch (r.t) {
    case 'ebeveyn':
    case 'yatak': {
      const cift = r.t === 'ebeveyn' || (Wu >= 3.4 && Dv >= 3.4);
      if (cift) {
        const dx = altU && altU[0] < 1 ? 0.5 : 0;
        m('yatak2', Wu / 2 + dx, 1.05);
        m('komodin', Wu / 2 + dx - 1.08, 0.22);
        m('komodin', Wu / 2 + dx + 1.08, 0.22);
      } else {
        m('yatak1', 0.52, 1.02);
        m('calisma', Wu - 0.62, 0.32, 0, { w: 1.1 });
        m('sandalye', Wu - 0.62, 0.85, 180);
      }
      const gw = Math.min(1.8, Wu - 1.6);
      if (!r.alt && gw >= 1) {
        if (kapiU != null && kapiU > Wu / 2) m('gardirop', gw / 2 + 0.05, Dv - 0.32, 180, { w: gw });
        else m('gardirop', Wu - gw / 2 - 0.05, Dv - 0.32, 180, { w: gw });
      } else if (r.alt && altU && Wu - altU[1] > 2.4) {
        m('gardirop', Wu - 0.32, Dv - 1.3, 90, { w: 1.6 });
      }
      if (r.alt) {
        mobilyaDoseme(p, KI, { ...r.alt, kapiKenar: 'e', t: 'banyoK' });
      }
      break;
    }
    case 'salon': {
      if (Wu >= 5 && Dv >= 4) {
        m('kose', 1.5, 1.05);
        m('sehpa', 1.7, 2.35);
        m('tv', 1.6, Dv - 0.3, 180);
        if (Wu >= 6) m('koltuk', 3.9, 1.0);
      } else {
        m('kanepe', Wu / 2, 0.5);
        m('sehpa', Wu / 2, 1.6);
        m('tv', Wu / 2 - 0.4, Dv - 0.3, 180);
      }
      if (Wu >= 7.5) {
        m('masa', Wu - 1.4, Dv / 2 + 0.2, 90);
        m('sandalye', Wu - 2.0, Dv / 2 - 0.2, 90);
        m('sandalye', Wu - 2.0, Dv / 2 + 0.6, 90);
        m('sandalye', Wu - 0.8, Dv / 2 - 0.2, 270);
        m('sandalye', Wu - 0.8, Dv / 2 + 0.6, 270);
      }
      m('bitki', Wu - 0.35, 0.35);
      break;
    }
    case 'mutfak': {
      const L = Wu - 0.8;
      m('evye', 0.45, 0.3);
      if (L > 1.6) m('tezgah', 0.9 + (L - 1.5) / 2, 0.3, 0, { w: Math.max(0.3, L - 1.5) });
      m('ocak', L - 0.3, 0.3);
      m('buzdolabi', Wu - 0.38, 0.38);
      if (Dv >= 3.6 && Wu >= 2.6 && !r.acik) {
        m('masa', Wu / 2, Dv / 2 + 0.3, 0, { w: 1.2, d: 0.8 });
        m('sandalye', Wu / 2 - 0.3, Dv / 2 - 0.3, 180);
        m('sandalye', Wu / 2 + 0.3, Dv / 2 - 0.3, 180);
        m('sandalye', Wu / 2 - 0.3, Dv / 2 + 0.9);
        m('sandalye', Wu / 2 + 0.3, Dv / 2 + 0.9);
      }
      break;
    }
    case 'banyo':
    case 'banyoK':
    case 'ebanyo': {
      if (r.t === 'ebanyo') break;
      m('dus', 0.47, 0.47);
      if (Wu >= 1.8) m('lavabo', Wu >= 2.4 ? 1.3 : 1.25, 0.25);
      if (Wu >= 2.4) m('wc', Wu - 0.3, 0.35);
      else m('wc', Wu - 0.3, Dv - 1.2, 270);
      if (Dv >= 3.2 && r.t === 'banyo') m('camasir', 0.35, Dv - 0.35, 90);
      break;
    }
    case 'wc':
      m('wc', Wu / 2, 0.35);
      if (Wu >= 1.4) m('lavabo', Wu / 2, Dv - 0.6, 180, { w: 0.45 });
      break;
    case 'calisma':
      m('calisma', Wu / 2, 0.32, 0, { w: Math.min(1.4, Wu - 0.6) });
      m('sandalye', Wu / 2, 0.9, 180);
      if (Dv > 3) m('kitaplik', 0.2, Dv / 2, 270, { w: Math.min(1.6, Dv - 1.4) });
      break;
    case 'merdiven':
      p.mobilya.push({
        id: uid(),
        kat: KI,
        tip: 'merdiven',
        x: r3((r.x0 + r.x1) / 2),
        y: r3((r.y0 + r.y1) / 2),
        r: 180,
        w: Math.min(1.1, r.x1 - r.x0 - 0.25),
        d: Math.min(4.6, r.y1 - r.y0 - 0.3),
      });
      break;
  }
}

export function yonDonustur(p: Proje, yon?: 'guney' | 'kuzey' | 'dogu' | 'bati') {
  if (!yon || yon === 'guney') return;
  let f: (x: number, y: number) => Pt;
  let rd: (r: number) => number;
  let ayna = false;
  if (yon === 'kuzey') {
    f = (x, y) => [x, -y];
    rd = r => (180 - r + 360) % 360;
    ayna = true;
  } else if (yon === 'dogu') {
    f = (x, y) => G.donder(x, y, -90);
    rd = r => (r - 90 + 360) % 360;
  } else {
    f = (x, y) => G.donder(x, y, 90);
    rd = r => (r + 90) % 360;
  }
  const T = (q: Pt): Pt => {
    const t = f(q[0], q[1]);
    return [r3(t[0]), r3(t[1])];
  };
  p.duvarlar.forEach(w => {
    [w.x1, w.y1] = T([w.x1, w.y1]);
    [w.x2, w.y2] = T([w.x2, w.y2]);
  });
  if (ayna) p.aciklar.forEach(a => (a.yon = -(a.yon || 1)));
  p.odalar.forEach(o => (o.pts = o.pts.map(T)));
  p.mobilya.forEach(m => {
    [m.x, m.y] = T([m.x, m.y]);
    m.r = rd(m.r || 0);
  });
  p.tesisat.forEach(t => {
    [t.x, t.y] = T([t.x, t.y]);
    t.r = rd(t.r || 0);
  });
  p.borular.forEach(b => (b.pts = b.pts.map(T)));
  p.kirisler.forEach(k => {
    [k.x1, k.y1] = T([k.x1, k.y1]);
    [k.x2, k.y2] = T([k.x2, k.y2]);
  });
  p.dis.forEach(d => {
    if (d.x1 != null && d.y1 != null && d.x2 != null && d.y2 != null) {
      [d.x1, d.y1] = T([d.x1, d.y1]);
      [d.x2, d.y2] = T([d.x2, d.y2]);
      return;
    }
    if (d.x != null && d.y != null) {
      [d.x, d.y] = T([d.x, d.y]);
    }
    if (DIS[d.tip]?.alan) {
      if (!ayna && d.w != null && d.d != null) [d.w, d.d] = [d.d, d.w];
    } else if (d.r != null) {
      d.r = rd(d.r);
    }
  });
  if (p.arsa) p.arsa.pts = p.arsa.pts.map(T);
}

export function yaziyiAnla(metin: string): { sp: PlanParam; anla: string[] } {
  const t = ' ' + metin.toLocaleLowerCase('tr').replace(/[.,;!?()]/g, ' ') + ' ';
  const sp: Partial<PlanParam> = {};
  const anla: string[] = [];
  const oda = t.match(/(\d)\s*\+\s*(\d)/);
  if (oda) {
    sp.yatak = +oda[1];
    anla.push(`${oda[1]}+${oda[2]}`);
  } else {
    const y = t.match(/(\d|bir|iki|üç|dört|beş)\s*(yatak|oda)/);
    if (y) {
      const map: Record<string, number> = { bir: 1, iki: 2, üç: 3, dört: 4, beş: 5 };
      const n = map[y[1]] || +y[1];
      sp.yatak = y[2] === 'oda' ? Math.max(1, n - 1) : n;
      anla.push(sp.yatak + ' yatak odası');
    }
  }
  const a = t.match(/(\d{2,4})\s*(m2|m²|metrekare|metre kare|metre|mt|m)\b/);
  if (a) {
    sp.alan = +a[1];
    anla.push(a[1] + ' m²');
  }
  if (/dubleks|iki katlı|2 katlı|çift katlı|iki kat /.test(t)) {
    sp.dubleks = true;
    anla.push('dubleks (2 kat)');
  }
  if (/ebeveyn banyo|ebeveyn banyolu|ebeveyn odasında banyo|en suite/.test(t)) {
    sp.ebeveynBanyo = true;
    anla.push('ebeveyn banyolu');
  }
  if (/amerikan|açık mutfak|salona açık/.test(t)) {
    sp.acikMutfak = true;
    anla.push('açık (Amerikan) mutfak');
  }
  if (/çalışma/.test(t)) {
    sp.calisma = true;
    anla.push('çalışma odası');
  }
  if (/kiler|çamaşır odası/.test(t)) {
    sp.kiler = true;
    anla.push('kiler');
  }
  if (/garaj/.test(t)) {
    sp.garaj = true;
    anla.push('garaj (L plan)');
  }
  if (/teras|balkon|veranda/.test(t)) {
    sp.teras = true;
    anla.push('teras');
  }
  if (/havuz/.test(t)) {
    sp.havuz = true;
    anla.push('havuz');
  }
  if (/beşik çatı/.test(t)) {
    sp.cati = 'besik';
    anla.push('beşik çatı');
  } else if (/düz çatı|teras çatı/.test(t)) {
    sp.cati = 'duz';
    anla.push('düz çatı');
  }
  const yon = t.match(/(güney|kuzey|doğu|batı)/);
  if (yon) {
    const yonMap: Record<string, PlanParam['yon']> = { güney: 'guney', kuzey: 'kuzey', doğu: 'dogu', batı: 'bati' };
    const adMap: Record<string, string> = { güney: 'güneye', kuzey: 'kuzeye', doğu: 'doğuya', batı: 'batıya' };
    sp.yon = yonMap[yon[1]];
    anla.push('salon ' + adMap[yon[1]] + ' bakıyor');
  }
  if (!sp.yatak) {
    sp.yatak = sp.alan ? (sp.alan < 75 ? 1 : sp.alan < 100 ? 2 : sp.alan < 145 ? 3 : 4) : 3;
    anla.push(`${sp.yatak}+1 (alandan tahmin)`);
  }
  if (!sp.alan) {
    sp.alan = ([0, 60, 90, 120, 160, 200, 240][sp.yatak] || 140) * (sp.dubleks ? 1.35 : 1);
    anla.push(`≈${Math.round(sp.alan)} m² (oda sayısından tahmin)`);
  }
  if (sp.yatak >= 3 && sp.alan >= 120 && sp.ebeveynBanyo == null && !/ebeveyn banyosuz/.test(t)) {
    sp.ebeveynBanyo = true;
    anla.push('ebeveyn banyosu (3+1 için varsayılan)');
  }
  return { sp: sp as PlanParam, anla };
}

export function ornekProje(): Proje {
  const eski = S.p;
  const p = yeniProje('Örnek · 3+1 bahçeli ev');
  S.p = p;
  const k = p.katlar[0].id;
  const D = (x1: number, y1: number, x2: number, y2: number, t: 'dis' | 'ic' = 'ic') =>
    duvarEkle(k, x1, y1, x2, y2, t === 'dis' ? 0.25 : 0.1, t);
  D(0, 0, 12, 0, 'dis');
  D(12, 0, 12, 10, 'dis');
  D(12, 10, 0, 10, 'dis');
  D(0, 10, 0, 0, 'dis');
  D(0, 3.8, 12, 3.8);
  D(0, 5, 12, 5);
  D(4, 0, 4, 3.8);
  D(6.5, 0, 6.5, 3.8);
  D(7, 5, 7, 10);

  const W = (x1: number, y1: number, x2: number, y2: number) =>
    p.duvarlar.find(
      w =>
        Math.abs(w.x1 - x1) < 0.01 &&
        Math.abs(w.y1 - y1) < 0.01 &&
        Math.abs(w.x2 - x2) < 0.01 &&
        Math.abs(w.y2 - y2) < 0.01,
    )!;
  const A = (
    w: Proje['duvarlar'][number],
    pos: number,
    o: { tur: AciklikTuru; g: number; h: number; p?: number; yon?: number; mentese?: 'sol' | 'sag' },
  ) => {
    const t = Math.abs(w.x2 - w.x1) > 0.01 ? (pos - w.x1) / (w.x2 - w.x1) : (pos - w.y1) / (w.y2 - w.y1);
    p.aciklar.push({ id: uid(), duvar: w.id, t: r3(t), p: 0, yon: 1, mentese: 'sol', ...o });
  };
  const ust = W(0, 0, 12, 0);
  const sag = W(12, 0, 12, 10);
  const alt = W(12, 10, 0, 10);
  const sol = W(0, 10, 0, 0);
  const k1 = W(0, 3.8, 12, 3.8);
  const k2 = W(0, 5, 12, 5);
  const pen = (g: number, h = 1.4, pp = 0.9) => ({ tur: 'pencere' as const, g, h, p: pp });
  const kap = (g = 0.9, yon = 1) => ({ tur: 'kapi' as const, g, h: 2.1, yon });

  A(ust, 2, pen(1.4));
  A(ust, 5.25, pen(0.6, 0.6, 1.6));
  A(ust, 9.25, pen(1.6));
  A(alt, 2.4, pen(1.8, 1.5));
  A(alt, 5.2, { tur: 'balkon', g: 1.4, h: 2.2, p: 0, yon: -1 });
  A(alt, 9.5, pen(1.4));
  A(sag, 1.9, pen(1.2));
  A(sag, 7.5, pen(1.2));
  A(sol, 1.9, pen(1.2));
  A(sol, 7.5, pen(1.6));
  A(sol, 4.4, { tur: 'kapi', g: 1.0, h: 2.2, yon: 1, mentese: 'sag' });
  A(k1, 2, kap(0.9, -1));
  A(k1, 5.25, kap(0.8, -1));
  A(k1, 9, kap(0.9, -1));
  A(k2, 3, kap(1.0, 1));
  A(k2, 9.5, kap(0.9, 1));

  const oda = (x: number, y: number, ad: string) => {
    const r = odaBul(k, x, y);
    if (r && r.pts) p.odalar.push({ id: uid(), kat: k, ad, zemin: odaZemini(ad), pts: r.pts });
  };
  oda(2, 1.9, 'Yatak Odası');
  oda(5.25, 1.9, 'Banyo');
  oda(9.25, 1.9, 'Ebeveyn Yatak Odası');
  oda(6, 4.4, 'Koridor');
  oda(3.5, 7.5, 'Salon');
  oda(9.5, 7.5, 'Mutfak');

  const m = (tip: string, x: number, y: number, r = 0, ek: { w?: number; d?: number } = {}) =>
    p.mobilya.push({ id: uid(), kat: k, tip, x, y, r, ...ek });
  m('yatak1', 1.0, 1.4);
  m('gardirop', 3.0, 0.45, 0, { w: 1.6 });
  m('calisma', 2.9, 3.35, 180, { w: 1.0 });
  m('komodin', 2.0, 0.35);
  m('wc', 4.45, 0.5);
  m('lavabo', 5.3, 0.35);
  m('dus', 6.0, 0.6);
  m('yatak2', 9.0, 1.15);
  m('komodin', 7.8, 0.33);
  m('komodin', 10.2, 0.33);
  m('gardirop', 11.5, 1.9, 90, { w: 2.0 });
  m('kose', 2.0, 7.9, 0);
  m('sehpa', 2.7, 6.9);
  m('tv', 3.0, 5.4, 180);
  m('koltuk', 5.4, 7.9, 270);
  m('bitki', 0.5, 9.4);
  m('kitaplik', 6.6, 6.2, 90);
  m('tezgah', 11.55, 7.0, 90, { w: 3.0 });
  m('buzdolabi', 11.5, 5.55);
  m('ocak', 11.55, 8.8, 90);
  m('evye', 7.6, 9.55, 0);
  m('masa', 9.0, 7.6, 0, { w: 1.6 });
  m('sandalye', 8.6, 7.0, 180);
  m('sandalye', 9.4, 7.0, 180);
  m('sandalye', 8.6, 8.2);
  m('sandalye', 9.4, 8.2);

  p.arsa = {
    pts: [
      [-9, -6],
      [21, -6],
      [21, 22],
      [-9, 22],
    ],
  };
  const d = (tip: string, o: Record<string, unknown>) => p.dis.push({ id: uid(), tip, ...o });
  d('cim', { x: 6, y: 16, w: 26, d: 10, r: 0 });
  d('cim', { x: 17, y: 3, w: 7, d: 16, r: 0 });
  d('yol', { x: -4.5, y: 4.4, w: 9, d: 1.4, r: 0 });
  d('yol', { x: 5.2, y: 11.0, w: 2.4, d: 2.0, r: 0 });
  d('otopark', { x: -5, y: 13.5, w: 6, d: 7, r: 0 });
  d('araba', { x: -5, y: 13.5, w: 1.85, d: 4.5, r: 0 });
  d('havuz', { x: 9, y: 16, w: 8, d: 4, r: 0 });
  for (const [x, y, c] of [
    [-6.5, -3.5, 4],
    [18.5, -3.5, 4.5],
    [18.5, 19.5, 4],
    [1.5, 19.5, 3.5],
    [16, 9, 3],
  ]) {
    d('agac', { x, y, cap: c });
  }
  for (const [x, y] of [
    [-1, 11.2],
    [-1, 12.6],
    [13.5, 11],
    [13.5, 12.4],
    [3, 11.5],
  ]) {
    d('cali', { x, y, cap: 1 });
  }
  const cs = p.arsa.pts;
  for (let i = 0; i < 4; i++) {
    const a = cs[i];
    const b = cs[(i + 1) % 4];
    if (i === 3) {
      d('cit', { x1: a[0], y1: a[1], x2: -9, y2: 10, h: 1.6 });
      d('cit', { x1: -9, y1: 17.5, x2: b[0], y2: b[1], h: 1.6 });
    } else {
      d('cit', { x1: a[0], y1: a[1], x2: b[0], y2: b[1], h: 1.6 });
    }
  }

  // Otomatik tesisat + boru döşemesi
  p.tesisat.push(...otomatikTesisat(k));
  p.borular.push(...otomatikBoruDose(k));

  p.cizen = '';
  S.p = eski;
  return p;
}
