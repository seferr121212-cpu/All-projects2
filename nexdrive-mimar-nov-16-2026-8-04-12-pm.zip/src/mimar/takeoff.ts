import { ACIK_ALAN_ODA, BLOK, DIS, ISLAK, MOB, ZEMIN, mobOlcu, zeminFiyatKey } from './catalog';
import {
  ARAZI,
  P,
  blokAdetM2,
  degistir,
  duvarBoy,
  duvarParcalari,
  katOturum,
  kirisListesi,
  odaTuru,
  paraYaz,
  zeminKatIndeks,
} from './core';
import { G, Pt } from './geometry';
import { mepMuhendislikHesap, tesisatMetraj } from './mep';
import type { FiyatKalem, ParaBirimi } from './types';
import { VARSAYILAN_FIYAT } from './catalog';
import { asc, esc, fmt, indir, uid } from './utils';

export interface MetrajKalem {
  uid: string;
  grup: string;
  ad: string;
  miktar: number;
  birim: string;
  fk: string | null;
  not?: string;
  birimMal: number;
  birimIsc: number;
  toplamMal: number;
  toplamIsc: number;
  tutar: number;
  gizli: boolean;
  ozelId?: string;
}

export interface MetrajSonuc {
  kalemler: MetrajKalem[];
  katOzet: {
    id: string;
    ad: string;
    net: number;
    brut: number;
    cevre: number;
    duvar: number;
    oda: number;
  }[];
  toplamNet: number;
  toplamBrut: number;
  arsaA: number;
  taks: number | null;
  kaks: number | null;
  malzemeToplam: number;
  iscilikToplam: number;
  araToplam: number;
  karTutar: number;
  kdvTutar: number;
  toplam: number;
  hafriyat: ReturnType<typeof ARAZI.hafriyat>;
  binaKot: number;
}

export function birimFiyatAl(fk: string): FiyatKalem {
  const p = P();
  const ozel = p.fiyat?.[fk];
  const vars = VARSAYILAN_FIYAT[fk] || { ad: fk, b: 'adet', f: 0, isc: 0 };
  return {
    ad: ozel?.ad ?? vars.ad,
    b: ozel?.b ?? vars.b,
    f: ozel?.f ?? vars.f,
    isc: ozel?.isc ?? vars.isc ?? 0,
  };
}

export function metrajHesap(): MetrajSonuc {
  const p = P();
  const gizliSet = new Set(p.ayar.gizliKalemler || []);
  const kalemler: MetrajKalem[] = [];
  const grupluSayac: Record<string, number> = {};

  const ekle = (grup: string, ad: string, miktar: number, birim: string, fk: string | null, not?: string) => {
    if (!(miktar > 0.005)) return;
    const key = fk || `${grup}_${ad}`;
    grupluSayac[key] = (grupluSayac[key] || 0) + 1;
    const itemUid = `${key}#${grupluSayac[key]}`;
    const F = fk ? birimFiyatAl(fk) : { ad, b: birim, f: 0, isc: 0 };
    const birimMal = F.f || 0;
    const birimIsc = F.isc || 0;
    const toplamMal = miktar * birimMal;
    const toplamIsc = miktar * birimIsc;
    const tutar = toplamMal + toplamIsc;
    kalemler.push({
      uid: itemUid,
      grup,
      ad,
      miktar,
      birim,
      fk,
      not,
      birimMal,
      birimIsc,
      toplamMal,
      toplamIsc,
      tutar,
      gizli: gizliSet.has(itemUid),
    });
  };

  let topNet = 0;
  let topBrut = 0;
  const katOzet = p.katlar.map(K => {
    const net = p.odalar.filter(o => o.kat === K.id).reduce((s, o) => s + Math.abs(G.alan(o.pts)), 0);
    const otur = katOturum(K.id);
    const brut = otur ? Math.abs(G.alan(otur)) : net * 1.15;
    topNet += net;
    topBrut += brut;
    return {
      id: K.id,
      ad: K.ad,
      net,
      brut,
      cevre: otur ? G.cevre(otur) : 0,
      duvar: p.duvarlar.filter(w => w.kat === K.id).reduce((s, w) => s + duvarBoy(w), 0),
      oda: p.odalar.filter(o => o.kat === K.id).length,
    };
  });

  // 1) Hafriyat & Temel
  const haf = ARAZI.var() ? ARAZI.hafriyat() : null;
  const zIdx = zeminKatIndeks();
  const zeminKat = p.katlar[zIdx] || p.katlar[0];
  const oturZemin = katOturum(zeminKat.id);
  const bTum = p.duvarlar.length
    ? G.bbox(p.duvarlar.flatMap(w => [[w.x1, w.y1], [w.x2, w.y2]] as Pt[]))
    : { x1: 0, y1: 0, x2: 0, y2: 0, w: 0, h: 0 };
  const temelAlan = oturZemin ? Math.abs(G.alan(oturZemin)) + G.cevre(oturZemin) * 0.45 : bTum.w * bTum.h;

  if (haf) {
    ekle('Hafriyat & Temel', 'Kazı (yarma hacmi)', haf.yarma * (p.ayar.kabarma || 1.25), 'm³', 'hafriyat', `Kabarma ×${p.ayar.kabarma || 1.25}`);
    if (haf.dolgu > 0.1) ekle('Hafriyat & Temel', 'Şantiye içi / dışı dolgu', Math.max(0, haf.dolgu - haf.yarma), 'm³', 'dis_dolgu');
  } else if (temelAlan > 0) {
    ekle('Hafriyat & Temel', 'Temel kazısı', temelAlan * (p.ayar.temelDerinlik || 1.5) * (p.ayar.kabarma || 1.25), 'm³', 'hafriyat');
  }

  const radyeHacim = temelAlan * 0.45;
  const groBeton = temelAlan * 0.1;
  ekle('Hafriyat & Temel', 'Grobeton (10 cm)', groBeton, 'm³', 'beton');
  ekle('Hafriyat & Temel', 'Radye temel betonu (45 cm)', radyeHacim, 'm³', 'beton');
  ekle('Hafriyat & Temel', 'Temel donatı demiri', radyeHacim * 115, 'kg', 'demir');

  // 2) Kaba Yapı (Betonarme + Duvar Blokları)
  let topDosemeBeton = 0;
  let topKolonKirisBeton = 0;
  const blokSayilari: Record<string, number> = { gazbeton: 0, tugla: 0, bims: 0 };
  let disDuvarNetM2 = 0;
  let icDuvarNetM2 = 0;

  p.katlar.forEach((K, idx) => {
    const ko = katOzet[idx];
    if (idx > 0 && ko.brut > 0) topDosemeBeton += ko.brut * (K.d || 0.15);
    p.mobilya
      .filter(m => m.kat === K.id && m.tip === 'kolon')
      .forEach(m => {
        const { w, d } = mobOlcu(m);
        topKolonKirisBeton += w * d * K.h;
      });
    kirisListesi(K.id).forEach(kr => {
      topKolonKirisBeton += kr.L * (kr.w || 0.25) * (kr.h || 0.5);
    });

    p.duvarlar
      .filter(w => w.kat === K.id)
      .forEach(w => {
        const L = duvarBoy(w);
        const brutM2 = L * K.h;
        const acikM2 = p.aciklar.filter(a => a.duvar === w.id).reduce((s, a) => s + a.g * a.h, 0);
        const netM2 = Math.max(0, brutM2 - acikM2);
        const mal = w.tur === 'dis' ? p.cephe.malzeme : p.cephe.icMalzeme;
        if (w.tur === 'dis') disDuvarNetM2 += netM2;
        else icDuvarNetM2 += netM2;
        blokSayilari[mal] = (blokSayilari[mal] || 0) + netM2 * blokAdetM2(mal, w.k) * 1.05;
      });
  });
  // En üst kat tavan döşemesi
  if (katOzet.length) topDosemeBeton += katOzet[katOzet.length - 1].brut * 0.15;

  ekle('Kaba Yapı', 'Döşeme ve tavan betonu', topDosemeBeton, 'm³', 'beton');
  ekle('Kaba Yapı', 'Kolon ve kiriş betonu', topKolonKirisBeton, 'm³', 'kolon_kiris');
  ekle('Kaba Yapı', 'Üst yapı donatı demiri', (topDosemeBeton + topKolonKirisBeton) * 105, 'kg', 'demir');

  Object.entries(blokSayilari).forEach(([mal, adet]) => {
    if (adet > 1 && BLOK[mal]) {
      ekle('Kaba Yapı', BLOK[mal].ad + ' (%5 fire)', Math.ceil(adet), 'adet', BLOK[mal].fk);
    }
  });

  // 3) Cephe & Sıva & Mantolama & Boya
  ekle('Cephe & Sıva', 'Dış cephe kaba + ince sıva', disDuvarNetM2, 'm²', 'siva_dis');
  ekle('Cephe & Sıva', 'İç cephe alçı / kara sıva', icDuvarNetM2 * 2 + disDuvarNetM2, 'm²', 'siva_ic');
  if (p.cephe.mantolama) ekle('Cephe & Sıva', 'Dış cephe mantolama (EPS/Taşyünü)', disDuvarNetM2, 'm²', 'mantolama');
  ekle('Cephe & Sıva', 'Dış cephe boyası (2 kat)', disDuvarNetM2 * 0.35, 'lt', 'dis_boya');
  const icBoyaM2 = icDuvarNetM2 * 2 + disDuvarNetM2 + topNet; // tavan dahil
  ekle('Cephe & Sıva', 'İç cephe & tavan boyası', icBoyaM2 * 0.28, 'lt', 'boya');

  // 4) Zemin & Duvar Kaplamaları & Süpürgelik
  const zeminAlan: Record<string, number> = {};
  let duvarSeramikM2 = 0;
  let supurgelikM = 0;

  p.odalar.forEach(o => {
    const K = p.katlar.find(k => k.id === o.kat);
    const a = Math.abs(G.alan(o.pts));
    const per = G.cevre(o.pts);
    const z = o.zemin || 'parke';
    zeminAlan[z] = (zeminAlan[z] || 0) + a;
    if (ISLAK(o.ad)) {
      duvarSeramikM2 += per * (K?.h || 2.8) * 0.85;
    } else if (!ACIK_ALAN_ODA(o.ad)) {
      supurgelikM += Math.max(0, per - 1.0);
    }
  });

  Object.entries(zeminAlan).forEach(([z, a]) => {
    const Z = ZEMIN[z];
    ekle('Zemin & Kaplama', `${Z?.ad || z} (%7 fire)`, a * 1.07, 'm²', zeminFiyatKey(z));
  });
  if (duvarSeramikM2 > 0) ekle('Zemin & Kaplama', 'Islak hacim duvar seramiği', duvarSeramikM2 * 1.08, 'm²', 'duvar_seramik');
  if (supurgelikM > 0) ekle('Zemin & Kaplama', 'Süpürgelik', supurgelikM * 1.05, 'm', 'supurgelik');

  // 5) Doğrama (Kapılar, Pencereler, Panjurlar)
  let icKapi = 0;
  let disKapi = 0;
  let garajKapi = 0;
  let ciftKapi = 0;
  let penM2 = 0;
  let blkM2 = 0;
  let panjurM2 = 0;

  p.aciklar.forEach(a => {
    const w = p.duvarlar.find(dw => dw.id === a.duvar);
    if (!w) return;
    if (a.tur === 'cift_kapi') ciftKapi++;
    else if (a.tur === 'kapi') {
      if (a.g >= 2.2) garajKapi++;
      else if (w.tur === 'dis') disKapi++;
      else icKapi++;
    } else if (a.tur === 'balkon' || a.tur === 'surme') {
      blkM2 += a.g * a.h;
    } else {
      penM2 += a.g * a.h;
    }
    if (a.panjur) panjurM2 += a.g * a.h;
  });

  ekle('Kapı & Pencere', 'İç kapı (kanat + kasa)', icKapi, 'adet', 'kapi_ic');
  ekle('Kapı & Pencere', 'Çelik giriş kapısı', disKapi, 'adet', 'kapi_dis');
  ekle('Kapı & Pencere', 'Çift kanatlı kapı', ciftKapi, 'adet', 'kapi_cift');
  ekle('Kapı & Pencere', 'Garaj kapısı', garajKapi, 'adet', 'kapi_garaj');
  ekle('Kapı & Pencere', 'Pencere (çift cam + doğrama)', penM2, 'm²', 'pencere');
  ekle('Kapı & Pencere', 'Balkon / sürme kapısı', blkM2, 'm²', 'balkon');
  ekle('Kapı & Pencere', 'Panjur / kepenk sistemi', panjurM2, 'm²', 'panjur');

  // 6) Merdiven & Korkuluk & Çatı
  let merdBeton = 0;
  let merdBasamak = 0;
  let korkulukM = 0;
  p.katlar.forEach((K, idx) => {
    p.mobilya
      .filter(m => m.kat === K.id && MOB[m.tip]?.ozel?.startsWith('merdiven'))
      .forEach(m => {
        const { w, d } = mobOlcu(m);
        const H = K.h + (p.katlar[idx + 1]?.d || 0.15);
        const n = m.basamak || Math.max(8, Math.round(H / 0.175));
        merdBeton += w * d * 0.24;
        merdBasamak += n;
        korkulukM += d * 1.15;
      });
    // Açık balkon kenar korkulukları
    p.odalar
      .filter(o => o.kat === K.id && ACIK_ALAN_ODA(o.ad))
      .forEach(o => {
        const katDuv = p.duvarlar.filter(w => w.kat === K.id);
        for (let ei = 0; ei < o.pts.length; ei++) {
          const a = o.pts[ei], b = o.pts[(ei + 1) % o.pts.length];
          const mx = (a[0] + b[0]) / 2, my = (a[1] + b[1]) / 2;
          if (!katDuv.some(w => G.segNokta(mx, my, w.x1, w.y1, w.x2, w.y2).d < w.k / 2 + 0.25)) {
            korkulukM += Math.hypot(b[0] - a[0], b[1] - a[1]);
          }
        }
      });
  });
  ekle('Merdiven & Çatı', 'Merdiven betonu ve kalıbı', merdBeton, 'm³', 'merdiven_beton');
  ekle('Merdiven & Çatı', 'Merdiven basamak kaplaması', merdBasamak, 'adet', 'merdiven_kaplama');
  ekle('Merdiven & Çatı', 'Balkon & merdiven korkuluğu', korkulukM, 'm', 'korkuluk');

  const sonKat = p.katlar[p.katlar.length - 1];
  const sonOtur = sonKat ? katOturum(sonKat.id) : null;
  if (sonOtur) {
    const bA = Math.abs(G.alan(sonOtur));
    const bP = G.cevre(sonOtur);
    const sac = p.cati.sacak || 0;
    const izd = bA + bP * sac + 4 * sac * sac;
    if (p.cati.tip === 'duz') {
      ekle('Merdiven & Çatı', 'Teras çatı su + ısı yalıtımı', izd, 'm²', 'teras');
    } else {
      const e = Math.cos((p.cati.egim || 30) * (Math.PI / 180)) || 0.86;
      ekle('Merdiven & Çatı', `Eğimli çatı (${p.cati.egim}° kiremit + ahşap)`, izd / e, 'm²', 'cati');
      if (p.cati.oluk !== false) ekle('Merdiven & Çatı', 'Yağmur oluğu + iniş boruları', bP + p.katlar.length * 6, 'm', 'oluk');
    }
  }

  // 7) Tesisat & Boru Döşemeleri
  tesisatMetraj(ekle);

  // 8) Peyzaj & Çevre
  const alanSay = (t: string) => p.dis.filter(d => d.tip === t).reduce((s, d) => s + Math.abs((d.x2! - d.x1!) * (d.y2! - d.y1!)), 0);
  ekle('Peyzaj & Çevre', 'Çim ekimi / rulo çim', alanSay('cim'), 'm²', 'cim');
  ekle('Peyzaj & Çevre', 'Yol / kaldırım parke taşı', alanSay('yol'), 'm²', 'yol');
  ekle('Peyzaj & Çevre', 'Otopark asfalt / beton', alanSay('otopark'), 'm²', 'otopark');
  ekle('Peyzaj & Çevre', 'Yüzme havuzu', alanSay('havuz'), 'm²', 'havuz');
  ekle('Peyzaj & Çevre', 'Ağaç fidanı', p.dis.filter(d => d.tip === 'agac').length, 'adet', 'agac');
  ekle('Peyzaj & Çevre', 'Çalı / süs bitkisi', p.dis.filter(d => d.tip === 'cali').length, 'adet', 'cali');
  const citM = p.dis.filter(d => d.tip === 'cit').reduce((s, d) => s + Math.hypot(d.x2! - d.x1!, d.y2! - d.y1!), 0);
  ekle('Peyzaj & Çevre', 'Çevre duvarı / çit', citM, 'm', 'cit');

  // 9) Kullanıcının Özel Kalemleri
  (p.ayar.ozelKalemler || []).forEach(ok => {
    const mal = ok.miktar * (ok.fiyat || 0);
    const isc = ok.miktar * (ok.iscilik || 0);
    kalemler.push({
      uid: 'ozel:' + ok.id,
      grup: ok.grup || 'Özel Kalemler',
      ad: ok.ad,
      miktar: ok.miktar,
      birim: ok.birim || 'adet',
      fk: null,
      not: ok.not,
      birimMal: ok.fiyat || 0,
      birimIsc: ok.iscilik || 0,
      toplamMal: mal,
      toplamIsc: isc,
      tutar: mal + isc,
      gizli: false,
      ozelId: ok.id,
    });
  });

  const aktif = kalemler.filter(k => !k.gizli);
  const malzemeToplam = aktif.reduce((s, k) => s + k.toplamMal, 0);
  const iscilikToplam = aktif.reduce((s, k) => s + k.toplamIsc, 0);
  const araToplam = malzemeToplam + iscilikToplam;
  const karTutar = araToplam * ((p.ayar.muteahhitOran || 0) / 100);
  const kdvTutar = (araToplam + karTutar) * ((p.ayar.kdvOran ?? 20) / 100);
  const toplam = araToplam + karTutar + kdvTutar;

  const arsaA = p.arsa ? Math.abs(G.alan(p.arsa.pts)) : 0;
  const tabanA = katOzet[zIdx]?.brut || katOzet[0]?.brut || 0;
  return {
    kalemler,
    katOzet,
    toplamNet: topNet,
    toplamBrut: topBrut,
    arsaA,
    taks: arsaA ? tabanA / arsaA : null,
    kaks: arsaA ? topBrut / arsaA : null,
    malzemeToplam,
    iscilikToplam,
    araToplam,
    karTutar,
    kdvTutar,
    toplam,
    hafriyat: haf,
    binaKot: ARAZI.var() ? ARAZI.binaKot() : 0,
  };
}

export function metrajSayfa(baglaPaftaFn: () => void, onMepRapor?: () => void) {
  const m = metrajHesap();
  const mep = mepMuhendislikHesap();
  const p = P();
  const g = document.querySelector('#gMetraj')!;
  const pb = p.ayar.paraBirimi || 'TRY';
  const katlar = p.katlar
    .map((k, i) => {
      const o = m.katOzet[i];
      return `<tr><td><b>${esc(k.ad)}</b></td><td class="s">${fmt(o.net)} m²</td><td class="s">${fmt(o.brut)} m²</td><td class="s">${fmt(o.duvar)} m</td><td class="s">${o.oda}</td></tr>`;
    })
    .join('');

  const gruplar = [...new Set(m.kalemler.map(k => k.grup))];
  const GRUP_RENK = ['#3fc1c6', '#4cc38a', '#e8b04a', '#5b9bd5', '#d97757', '#9b7ed9', '#e5534b', '#8fa7ba', '#a8c66c'];
  const grupToplamlar = gruplar
    .map((gr, gi) => ({
      gr,
      tutar: m.kalemler.filter(x => x.grup === gr && !x.gizli).reduce((s, x) => s + x.tutar, 0),
      renk: GRUP_RENK[gi % GRUP_RENK.length],
    }))
    .filter(x => x.tutar > 0);
  const maliyetBarHtml = grupToplamlar.length
    ? `<div style="background:var(--lac2);border:1px solid var(--cizgi);border-radius:10px;padding:11px 14px;margin-bottom:16px">
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:7px">
          <small style="color:var(--soluk);text-transform:uppercase;letter-spacing:.6px;font-size:11px">Maliyet Dağılımı (Ara Toplam Bazlı)</small>
          <small class="bilgi">${paraYaz(m.araToplam)}</small>
        </div>
        <div class="maliyet-bar">${grupToplamlar
          .map(x => `<span style="width:${((x.tutar / (m.araToplam || 1)) * 100).toFixed(2)}%;background:${x.renk}" title="${esc(x.gr)}: ${paraYaz(x.tutar)}"></span>`)
          .join('')}</div>
        <div class="maliyet-lejant">${grupToplamlar
          .map(
            x =>
              `<span><i style="background:${x.renk}"></i>${esc(x.gr)}: <b>%${Math.round((x.tutar / (m.araToplam || 1)) * 100)}</b> <small>(${paraYaz(x.tutar)})</small></span>`,
          )
          .join('')}</div>
      </div>`
    : '';

  const mepKartHtml = `<div style="background:var(--lac2);border:1px solid var(--cizgi);border-radius:10px;padding:11px 14px;margin-bottom:16px;display:flex;flex-wrap:wrap;align-items:center;justify-content:space-between;gap:12px">
    <div style="display:flex;flex-wrap:wrap;gap:18px;align-items:center">
      <div><small class="bilgi" style="display:block">MEP Kurulu / Talep</small><b>${fmt(mep.toplamKuruluW / 1000, 1)} / ${fmt(mep.talepGucW / 1000, 1)} kW</b> <small class="bilgi">(${esc(mep.faz)} · ${mep.anaSigortaA}A)</small></div>
      <div><small class="bilgi" style="display:block">Isıtma Yükü</small><b>${fmt(mep.toplamIsiKcal, 0)} kcal/h</b> <small class="bilgi">(${fmt(mep.toplamIsiWatt / 1000, 1)} kW)</small></div>
      <div><small class="bilgi" style="display:block">Boru Fiting</small><b>${mep.fiting.dirsek90 + mep.fiting.dirsek45} Dirsek · ${mep.fiting.te} Te · ${mep.fiting.vana} Vana</b></div>
      <div><small class="bilgi" style="display:block">Boru Çakışması</small><span class="rozet ${mep.cakismalar.length ? 'kotu' : 'iyi'}">${mep.cakismalar.length ? mep.cakismalar.length + ' Çakışma' : 'Temiz'}</span></div>
    </div>
    ${onMepRapor ? '<button class="ubtn ana" id="mMepDetay">MEP Mühendislik Raporu</button>' : ''}
  </div>`;

  let satir = '';
  for (const gr of gruplar) {
    satir += `<tr class="grup"><td colspan="9">${esc(gr)}</td></tr>`;
    for (const k of m.kalemler.filter(x => x.grup === gr)) {
      const disabledStyle = k.gizli ? 'opacity:0.42;text-decoration:line-through' : '';
      const fkAttr = k.fk ? `data-fk="${esc(k.fk)}"` : k.ozelId ? `data-ozel="${esc(k.ozelId)}"` : '';
      satir += `<tr style="${disabledStyle}">
        <td style="width:24px"><input type="checkbox" data-gizli="${esc(k.uid)}" ${!k.gizli ? 'checked' : ''} title="Metraja dahil et"></td>
        <td>${esc(k.ad)}${k.not ? ` <small class="bilgi">(${esc(k.not)})</small>` : ''}</td>
        <td class="s">${fmt(k.miktar, 1)}</td>
        <td>${esc(k.birim)}</td>
        <td class="s">${k.fk || k.ozelId ? `<input type="number" step="5" min="0" ${fkAttr} data-tip="mal" value="${Math.round(k.birimMal)}" style="width:74px">` : '—'}</td>
        <td class="s">${k.fk || k.ozelId ? `<input type="number" step="5" min="0" ${fkAttr} data-tip="isc" value="${Math.round(k.birimIsc)}" style="width:74px">` : '—'}</td>
        <td class="s">${paraYaz(k.toplamMal)}</td>
        <td class="s">${paraYaz(k.toplamIsc)}</td>
        <td class="s"><b>${paraYaz(k.tutar)}</b> ${k.ozelId ? `<button class="ubtn" style="padding:1px 6px;margin-left:4px" data-sil-ozel="${esc(k.ozelId)}">×</button>` : ''}</td>
      </tr>`;
    }
  }

  g.innerHTML = `<div class="mbaslik">
    <h2>Metraj ve Maliyet</h2>
    <select id="mPara" title="Para birimi">
      <option value="TRY"${pb === 'TRY' ? ' selected' : ''}>TL (₺)</option>
      <option value="USD"${pb === 'USD' ? ' selected' : ''}>USD ($ · ${p.ayar.kurUsd})</option>
      <option value="EUR"${pb === 'EUR' ? ' selected' : ''}>EUR (€ · ${p.ayar.kurEur})</option>
    </select>
    <label class="bilgi">KDV % <input type="number" id="mKdv" min="0" max="30" value="${p.ayar.kdvOran ?? 20}" style="width:52px"></label>
    <label class="bilgi">Kâr % <input type="number" id="mKar" min="0" max="60" value="${p.ayar.muteahhitOran ?? 0}" style="width:52px"></label>
    <button class="ubtn" id="mOzelEkle">+ Özel kalem</button>
    <button class="ubtn" id="mSifirla">Fiyatları sıfırla</button>
    <button class="ubtn" id="mCsv">CSV indir</button>
    <button class="ubtn ana" id="mPafta">Paftada gör</button>
  </div>
  <div class="kpiler">
    <div class="kpi"><small>Toplam net alan</small><b>${fmt(m.toplamNet)}</b> <em>m²</em></div>
    <div class="kpi"><small>Toplam brüt alan</small><b>${fmt(m.toplamBrut)}</b> <em>m²</em></div>
    ${m.arsaA ? `<div class="kpi"><small>TAKS / KAKS</small><b>${fmt(m.taks || 0)}</b> / <b>${fmt(m.kaks || 0)}</b></div>` : ''}
    <div class="kpi"><small>Malzeme + İşçilik</small><b>${paraYaz(m.malzemeToplam)}</b><br><em>+ ${paraYaz(m.iscilikToplam)} işçilik</em></div>
    <div class="kpi"><small>Kâr + KDV (%${p.ayar.kdvOran ?? 20})</small><b>${paraYaz(m.karTutar + m.kdvTutar)}</b></div>
    <div class="kpi"><small>Genel toplam maliyet</small><b>${paraYaz(m.toplam)}</b></div>
    <div class="kpi"><small>Birim m² maliyeti</small><b>${m.toplamBrut ? paraYaz(m.toplam / m.toplamBrut) : '—'}</b></div>
  </div>
  ${maliyetBarHtml}
  ${mepKartHtml}
  <div class="iki" style="margin-bottom:14px">
    <div>
      <h3 class="bol">Kat Özeti</h3>
      <table class="tbl"><thead><tr><th>Kat</th><th class="s">Net</th><th class="s">Brüt</th><th class="s">Duvar</th><th class="s">Oda</th></tr></thead><tbody>${katlar}</tbody></table>
    </div>
    <div>
      <h3 class="bol">Odalar & Alan Dağılımı</h3>
      <table class="tbl"><thead><tr><th>Oda</th><th>Tür</th><th class="s">Alan</th><th class="s">Sınıf</th></tr></thead><tbody>
        ${p.odalar.map(o => `<tr><td>${esc(o.ad)}</td><td>${esc(ZEMIN[o.zemin]?.ad || o.zemin)}</td><td class="s">${fmt(Math.abs(G.alan(o.pts)))} m²</td><td class="s">${esc(odaTuru(o.ad))}</td></tr>`).join('') || '<tr><td colspan="4" class="bilgi">Tanımlı oda yok.</td></tr>'}
      </tbody></table>
    </div>
  </div>
  <h3 class="bol">Poz & Keşif Listesi</h3>
  <table class="tbl">
    <thead><tr><th></th><th>Kalem</th><th class="s">Miktar</th><th>Birim</th><th class="s">Malz. B.F</th><th class="s">İşç. B.F</th><th class="s">Malzeme</th><th class="s">İşçilik</th><th class="s">Tutar</th></tr></thead>
    <tbody>${satir}
      <tr><td colspan="6" class="s">Ara toplam (Malzeme + İşçilik)</td><td class="s">${paraYaz(m.malzemeToplam)}</td><td class="s">${paraYaz(m.iscilikToplam)}</td><td class="s"><b>${paraYaz(m.araToplam)}</b></td></tr>
      ${m.karTutar > 0 ? `<tr><td colspan="8" class="s">Müteahhit Kârı (%${p.ayar.muteahhitOran || 0})</td><td class="s">${paraYaz(m.karTutar)}</td></tr>` : ''}
      <tr><td colspan="8" class="s">KDV (%${p.ayar.kdvOran ?? 20})</td><td class="s">${paraYaz(m.kdvTutar)}</td></tr>
      <tr class="toplam"><td colspan="8" class="s">GENEL TOPLAM</td><td class="s">${paraYaz(m.toplam)}</td></tr>
    </tbody>
  </table>`;

  const mepBtn = g.querySelector('#mMepDetay') as HTMLButtonElement | null;
  if (mepBtn && onMepRapor) mepBtn.onclick = onMepRapor;

  g.querySelectorAll('input[data-fk]').forEach(el => {
    el.addEventListener('change', () => {
      const inp = el as HTMLInputElement;
      const k = inp.dataset.fk!;
      const tip = inp.dataset.tip!;
      degistir(() => {
        const cur = birimFiyatAl(k);
        if (tip === 'mal') cur.f = Math.max(0, +inp.value || 0);
        else cur.isc = Math.max(0, +inp.value || 0);
        p.fiyat[k] = cur;
      }, true);
      metrajSayfa(baglaPaftaFn, onMepRapor);
    });
  });

  g.querySelectorAll('input[data-ozel]').forEach(el => {
    el.addEventListener('change', () => {
      const inp = el as HTMLInputElement;
      const id = inp.dataset.ozel!;
      const tip = inp.dataset.tip!;
      const item = (p.ayar.ozelKalemler || []).find(x => x.id === id);
      if (!item) return;
      degistir(() => {
        if (tip === 'mal') item.fiyat = Math.max(0, +inp.value || 0);
        else item.iscilik = Math.max(0, +inp.value || 0);
      }, true);
      metrajSayfa(baglaPaftaFn, onMepRapor);
    });
  });

  g.querySelectorAll('input[data-gizli]').forEach(el => {
    el.addEventListener('change', () => {
      const inp = el as HTMLInputElement;
      const id = inp.dataset.gizli!;
      degistir(() => {
        const arr = new Set(p.ayar.gizliKalemler || []);
        if (inp.checked) arr.delete(id);
        else arr.add(id);
        p.ayar.gizliKalemler = [...arr];
      }, true);
      metrajSayfa(baglaPaftaFn, onMepRapor);
    });
  });

  g.querySelectorAll('button[data-sil-ozel]').forEach(el => {
    el.addEventListener('click', () => {
      const id = (el as HTMLElement).dataset.silOzel!;
      degistir(() => {
        p.ayar.ozelKalemler = (p.ayar.ozelKalemler || []).filter(x => x.id !== id);
      }, true);
      metrajSayfa(baglaPaftaFn, onMepRapor);
    });
  });

  (g.querySelector('#mPara') as HTMLSelectElement).onchange = e => {
    degistir(() => {
      p.ayar.paraBirimi = (e.target as HTMLSelectElement).value as ParaBirimi;
    }, true);
    metrajSayfa(baglaPaftaFn, onMepRapor);
  };
  (g.querySelector('#mKdv') as HTMLInputElement).onchange = e => {
    degistir(() => {
      p.ayar.kdvOran = Math.max(0, +(e.target as HTMLInputElement).value || 0);
    }, true);
    metrajSayfa(baglaPaftaFn, onMepRapor);
  };
  (g.querySelector('#mKar') as HTMLInputElement).onchange = e => {
    degistir(() => {
      p.ayar.muteahhitOran = Math.max(0, +(e.target as HTMLInputElement).value || 0);
    }, true);
    metrajSayfa(baglaPaftaFn, onMepRapor);
  };

  (g.querySelector('#mOzelEkle') as HTMLButtonElement).onclick = () => {
    const ad = 'Ek Özel İmalat';
    degistir(() => {
      p.ayar.ozelKalemler = p.ayar.ozelKalemler || [];
      p.ayar.ozelKalemler.push({
        id: uid(),
        grup: 'Özel Kalemler',
        ad,
        miktar: 1,
        birim: 'adet',
        fiyat: 5000,
        iscilik: 1500,
      });
    }, true);
    metrajSayfa(baglaPaftaFn, onMepRapor);
  };

  (g.querySelector('#mSifirla') as HTMLButtonElement).onclick = () => {
    degistir(() => {
      p.fiyat = {};
      p.ayar.gizliKalemler = [];
    }, true);
    metrajSayfa(baglaPaftaFn, onMepRapor);
  };

  (g.querySelector('#mCsv') as HTMLButtonElement).onclick = () => {
    const r = [['Grup', 'Kalem', 'Not', 'Miktar', 'Birim', 'Malzeme B.F', 'İşçilik B.F', 'Malzeme Tutar', 'İşçilik Tutar', 'Toplam Tutar']];
    for (const k of m.kalemler.filter(x => !x.gizli)) {
      r.push([
        k.grup,
        k.ad,
        k.not || '',
        fmt(k.miktar, 2),
        k.birim,
        String(Math.round(k.birimMal)),
        String(Math.round(k.birimIsc)),
        String(Math.round(k.toplamMal)),
        String(Math.round(k.toplamIsc)),
        String(Math.round(k.tutar)),
      ]);
    }
    r.push(['', 'Ara Toplam', '', '', '', '', '', String(Math.round(m.malzemeToplam)), String(Math.round(m.iscilikToplam)), String(Math.round(m.araToplam))]);
    r.push(['', `Müteahhit Kârı (%${p.ayar.muteahhitOran || 0})`, '', '', '', '', '', '', '', String(Math.round(m.karTutar))]);
    r.push(['', `KDV (%${p.ayar.kdvOran ?? 20})`, '', '', '', '', '', '', '', String(Math.round(m.kdvTutar))]);
    r.push(['', 'GENEL TOPLAM', '', '', '', '', '', '', '', String(Math.round(m.toplam))]);
    const csv = r.map(c => c.map(x => `"${String(x).replace(/"/g, '""')}"`).join(';')).join('\n');
    indir(asc(p.ad) + '_metraj.csv', new Blob(['\uFEFF' + csv], { type: 'text/csv;charset=utf-8' }));
  };

  (g.querySelector('#mPafta') as HTMLButtonElement).onclick = baglaPaftaFn;
}
