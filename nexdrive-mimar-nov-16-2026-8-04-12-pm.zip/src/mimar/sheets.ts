import { BORU_TIPLERI, ZEMIN } from './catalog';
import { P, S, duvarBoy, katTaban, paraYaz } from './core';
import { G, Pt } from './geometry';
import { LOGO } from './logo';
import { mepMuhendislikHesap } from './mep';
import { planCiz } from './plan2d';
import { metrajHesap } from './takeoff';
import type { Aciklik, KagitBoyutu, Kesit } from './types';
import { RAD, asc, bildir, esc, fmt, indir, tarihTR } from './utils';
import { D3 } from './webgl3d';

export const KAGITLAR: Record<KagitBoyutu, [number, number]> = {
  A4: [297, 210],
  A3: [420, 297],
  A2: [594, 420],
  A1: [841, 594],
};

export interface PaftaSayfaItem {
  t: string;
  alt: string;
  kat: string;
  olcek: string;
  ic: string;
  tip: 'plan' | 'tesisat' | 'kesit' | 'gorunus' | 'tablo';
  katId?: string;
  vaziyet?: boolean;
  tesisat?: boolean;
  img?: string;
  tabloSatirlar?: string[][];
}

export const PAFTA = {
  kagit: 'A4' as KagitBoyutu,
  olcek: 0 as number, // 0 = Otomatik, veya 20, 50, 100, 200, 500
  secim: {
    vaziyet: true,
    katlar: true,
    tesisat: true,
    kesitler: true,
    gorunus: true,
    mahal: true,
    dograma: true,
    metraj: true,
    mepRapor: true,
  },
  sayfalar: [] as PaftaSayfaItem[],
};

export function planResmi(
  o: { katId: string; dis?: boolean; arsa?: boolean; mobilya?: boolean; tesisat?: boolean; boru?: boolean; olcu?: boolean; kuzey?: boolean },
  w: number,
  h: number,
  hedefOlcek = 0,
): { img: string; olcek: string } {
  const c = document.createElement('canvas');
  c.width = w;
  c.height = h;
  const ctx = c.getContext('2d')!;
  const p = P();
  const pts: Pt[] = [];
  p.duvarlar.filter(dw => dw.kat === o.katId).forEach(dw => pts.push([dw.x1, dw.y1], [dw.x2, dw.y2]));
  if (o.dis && p.arsa) pts.push(...p.arsa.pts);
  if (o.dis) p.dis.forEach(d => pts.push([d.x ?? d.x1 ?? 0, d.y ?? d.y1 ?? 0]));
  const b = pts.length ? G.bbox(pts) : { x1: 0, y1: 0, x2: 10, y2: 8, w: 10, h: 8 };
  const pay = 2.6;
  const ham = Math.min(w / Math.max(4, b.w + pay * 2), h / Math.max(4, b.h + pay * 2));
  const [pw] = KAGITLAR[PAFTA.kagit] || [297, 210];
  const mPerPx = (pw - 28) / 1000 / w;
  const SCs = [20, 25, 50, 100, 200, 500];
  const sec = hedefOlcek > 0 ? hedefOlcek : SCs.find(s => 1 / (s * mPerPx) <= ham) || 500;
  const z = 1 / (sec * mPerPx);
  const cx = b.x1 + b.w / 2;
  const cy = b.y1 + b.h / 2;
  ctx.fillStyle = '#fff';
  ctx.fillRect(0, 0, w, h);
  planCiz(ctx, { tx: w / 2 - cx * z, ty: h / 2 - cy * z, z }, { ...o, w, h, baski: true, fs: 2.2 });
  return { img: c.toDataURL('image/png'), olcek: '1/' + sec };
}

export function kesitResmi(k: Kesit, w = 1400, h = 880) {
  return D3.kesitFoto(k, w, h);
}

function temizKagitBoyutu(k: KagitBoyutu) {
  const [pw, ph] = KAGITLAR[k] || [297, 210];
  return { pw, ph, icerikW: pw - 28, icerikH: ph - 41 };
}

function dogramaSvg(a: Aciklik): string {
  const w = 68;
  const h = 44;
  const pad = 6;
  const rw = Math.max(18, Math.min(w - pad * 2, a.g * 22));
  const rh = Math.max(20, Math.min(h - pad * 2, a.h * 15));
  const x = (w - rw) / 2;
  const y = (h - rh) / 2;
  const c = a.renk || P().cephe.dogramaRenk || '#383e42';
  const dolgu = a.tur === 'kapi' || a.tur === 'cift_kapi' ? '#e7d5bc' : '#cbe5f2';
  let extra = '';
  if (a.tur === 'cift_kapi' || a.tur === 'surme' || (a.tur === 'pencere' && a.g > 1.25)) {
    extra += `<line x1="${x + rw / 2}" y1="${y}" x2="${x + rw / 2}" y2="${y + rh}" stroke="${c}" stroke-width="1.3"/>`;
  }
  if (a.tur === 'pencere' || a.tur === 'balkon' || a.tur === 'surme') {
    extra += `<line x1="${x + 4}" y1="${y + 4}" x2="${x + rw * 0.35}" y2="${y + rh * 0.4}" stroke="#fff" stroke-width="1"/>`;
  }
  if (a.panjur) {
    extra += `<rect x="${x}" y="${y}" width="${rw}" height="6" fill="#475569"/>`;
  }
  return `<svg width="${w}" height="${h}" viewBox="0 0 ${w} ${h}" style="display:block;margin:auto"><rect x="${x}" y="${y}" width="${rw}" height="${rh}" fill="${dolgu}" stroke="${c}" stroke-width="1.8"/>${extra}</svg>`;
}

export function paftaUret() {
  const p = P();
  const M = metrajHesap();
  const s = PAFTA.secim;
  const { icerikW, icerikH } = temizKagitBoyutu(PAFTA.kagit);
  const resW = Math.round(icerikW * 6.2);
  const resH = Math.round(icerikH * 6.2);
  const S: PaftaSayfaItem[] = [];

  if (s.vaziyet) {
    const r = planResmi({ katId: p.katlar[0].id, dis: true, arsa: true, kuzey: true, olcu: false }, resW, resH, PAFTA.olcek || 200);
    S.push({
      t: 'Vaziyet Planı',
      alt: `Arsa ${M.arsaA ? fmt(M.arsaA) + ' m²' : 'tanımsız'}${M.taks != null ? ` · TAKS ${fmt(M.taks)} · KAKS ${fmt(M.kaks || 0)}` : ''}`,
      kat: 'Vaziyet',
      olcek: r.olcek,
      ic: `<img src="${r.img}" style="max-width:100%;max-height:100%;object-fit:contain">`,
      tip: 'plan',
      katId: p.katlar[0].id,
      vaziyet: true,
      img: r.img,
    });
  }

  if (s.katlar) {
    p.katlar.forEach((K, idx) => {
      const r = planResmi({ katId: K.id, mobilya: true, olcu: true, kuzey: true, tesisat: false, boru: false }, resW, resH, PAFTA.olcek);
      const ko = M.katOzet[idx];
      S.push({
        t: `${K.ad} Planı`,
        alt: `Net ${fmt(ko.net)} m² · Brüt ${fmt(ko.brut)} m² · Kot ${fmt(katTaban(idx), 2)} m`,
        kat: K.ad,
        olcek: r.olcek,
        ic: `<img src="${r.img}" style="max-width:100%;max-height:100%;object-fit:contain">`,
        tip: 'plan',
        katId: K.id,
        img: r.img,
      });
    });
  }

  if (s.tesisat) {
    p.katlar.forEach(K => {
      const hasTes = (p.tesisat || []).some(t => t.kat === K.id) || (p.borular || []).some(b => b.kat === K.id);
      if (!hasTes) return;
      const r = planResmi({ katId: K.id, mobilya: false, olcu: true, kuzey: true, tesisat: true, boru: true }, resW, Math.round(resH * 0.86), PAFTA.olcek);
      const lej = Object.values(BORU_TIPLERI)
        .map(b => `<span style="display:inline-flex;align-items:center;gap:4px;margin-right:10px;font-size:7pt"><i style="display:inline-block;width:14px;height:3px;background:${b.renk}"></i>${esc(b.kisa)}</span>`)
        .join('');
      S.push({
        t: `${K.ad} Tesisat & Boru Döşeme Planı`,
        alt: 'Sıhhi temiz/pis su, kalorifer, doğalgaz ve elektrik güzergâhları',
        kat: K.ad,
        olcek: r.olcek,
        ic: `<div style="width:100%;height:100%;display:flex;flex-direction:column;justify-content:space-between;align-items:center"><img src="${r.img}" style="max-width:100%;max-height:90%;object-fit:contain"><div style="border-top:0.2mm solid #ccc;padding-top:1.5mm;width:100%;text-align:center">${lej}</div></div>`,
        tip: 'tesisat',
        katId: K.id,
        tesisat: true,
        img: r.img,
      });
    });
  }

  if (s.kesitler) {
    (p.kesitler || []).forEach(k => {
      const img = kesitResmi(k);
      S.push({
        t: `Kesit ${k.ad}–${k.ad}`,
        alt: `Doğrultu kesiti · Kat yüksekliği: ${p.katlar.map(x => fmt(x.h) + 'm').join(' + ')}`,
        kat: `Kesit ${k.ad}-${k.ad}`,
        olcek: 'Görsel',
        ic: `<img src="${img}" style="max-width:100%;max-height:100%;object-fit:contain">`,
        tip: 'kesit',
        img,
      });
    });
  }

  if (s.gorunus) {
    const cep: [string, number, number][] = [
      ['Ön cephe (Güney)', 0, 0.04],
      ['Arka cephe (Kuzey)', Math.PI, 0.04],
      ['Sağ cephe (Doğu)', Math.PI / 2, 0.04],
      ['Sol cephe (Batı)', -Math.PI / 2, 0.04],
      ['Perspektif (Gündoğusu)', 0.72, 0.44],
      ['Perspektif (Günbatısı)', -2.25, 0.44],
    ];
    const fig = cep
      .map(([ad, yaw, pitch]) => {
        const img = D3.foto(760, 500, () => {
          D3._cepheGiz = true;
          D3.sahneKur();
          D3.mod = 'orbit';
          D3.orto = pitch < 0.1;
          D3.kesit = 'tumu';
          D3.kam.yaw = yaw;
          D3.kam.pitch = pitch;
          D3.odakla();
          D3.ortoBoy = Math.max(12, D3.kam.dist * 0.78);
        });
        return `<figure><img src="${img}"><figcaption>${ad}</figcaption></figure>`;
      })
      .join('');
    S.push({
      t: 'Cephe Görünüşleri ve Perspektif',
      alt: '4 ana cephe ortografik görünüş + 2 perspektif render',
      kat: 'Görünüşler',
      olcek: 'Görsel',
      ic: `<div class="izgara">${fig}</div>`,
      tip: 'gorunus',
    });
  }

  if (s.mahal && p.odalar.length) {
    const satirlar = p.odalar.map(o => {
      const K = p.katlar.find(x => x.id === o.kat);
      return [
        K?.ad || '',
        o.ad,
        fmt(Math.abs(G.alan(o.pts))) + ' m²',
        fmt(G.cevre(o.pts)) + ' m',
        ZEMIN[o.zemin]?.ad || o.zemin,
        o.duvarKaplama || 'Alçı sıva + plastik boya',
        o.tavanKaplama || 'Tavan boyası',
      ];
    });
    S.push({
      t: 'Mahal Listesi',
      alt: `Toplam ${p.odalar.length} mahal · Net toplam ${fmt(M.toplamNet)} m²`,
      kat: 'Mahaller',
      olcek: 'Tablo',
      ic: `<div style="width:100%;height:100%;overflow:hidden"><table><thead><tr><th>Kat</th><th>Mahal Adı</th><th class="s">Net Alan</th><th class="s">Çevre</th><th>Döşeme</th><th>Duvar Kaplaması</th><th>Tavan</th></tr></thead><tbody>${satirlar.map(r => `<tr><td>${esc(r[0])}</td><td><b>${esc(r[1])}</b></td><td class="s">${r[2]}</td><td class="s">${r[3]}</td><td>${esc(r[4])}</td><td>${esc(r[5])}</td><td>${esc(r[6])}</td></tr>`).join('')}</tbody></table></div>`,
      tip: 'tablo',
      tabloSatirlar: [['Kat', 'Mahal', 'Net', 'Cevre', 'Zemin', 'Duvar', 'Tavan'], ...satirlar],
    });
  }

  if (s.dograma && p.aciklar.length) {
    const gruplar = new Map<string, { tip: string; a: Aciklik; adet: number }>();
    p.aciklar.forEach(a => {
      const k = `${a.tur}_${a.g.toFixed(2)}x${a.h.toFixed(2)}_${a.p.toFixed(2)}_${a.panjur ? 'P' : 'N'}`;
      const cur = gruplar.get(k);
      if (cur) cur.adet++;
      else gruplar.set(k, { tip: a.tur, a, adet: 1 });
    });
    const rows = [...gruplar.values()].map((g, idx) => {
      const kod = (g.tip.startsWith('kapi') || g.tip === 'cift_kapi' ? 'K' : 'P') + (idx + 1);
      const ad =
        g.tip === 'kapi'
          ? 'Tek Kanat Kapı'
          : g.tip === 'cift_kapi'
            ? 'Çift Kanat Kapı'
            : g.tip === 'surme'
              ? 'Sürme Cam Kapı'
              : g.tip === 'balkon'
                ? 'Balkon Kapısı'
                : g.tip === 'cati_pencere'
                  ? 'Çatı Penceresi'
                  : 'Pencere';
      return {
        kod,
        ad,
        en: `${fmt(g.a.g * 100, 0)} cm`,
        boy: `${fmt(g.a.h * 100, 0)} cm`,
        par: `${fmt(g.a.p * 100, 0)} cm`,
        adet: g.adet,
        ozellik: g.a.panjur ? 'Panjurlu' : 'Standart',
        svg: dogramaSvg(g.a),
      };
    });
    S.push({
      t: 'Doğrama Açılım Cetveli (Kapı & Pencere)',
      alt: `${rows.length} farklı poz · Toplam ${p.aciklar.length} doğrama`,
      kat: 'Doğrama',
      olcek: 'Şematik',
      ic: `<div style="width:100%;height:100%;overflow:hidden"><table><thead><tr><th>Poz</th><th>Şematik Görünüş</th><th>Tip</th><th class="s">En</th><th class="s">Boy</th><th class="s">Parapet</th><th class="s">Adet</th><th>Not</th></tr></thead><tbody>${rows.map(r => `<tr><td><b>${r.kod}</b></td><td>${r.svg}</td><td>${r.ad}</td><td class="s">${r.en}</td><td class="s">${r.boy}</td><td class="s">${r.par}</td><td class="s"><b>${r.adet}</b></td><td>${r.ozellik}</td></tr>`).join('')}</tbody></table></div>`,
      tip: 'tablo',
      tabloSatirlar: [
        ['Poz', 'Tip', 'En', 'Boy', 'Parapet', 'Adet', 'Not'],
        ...rows.map(r => [r.kod, r.ad, r.en, r.boy, r.par, String(r.adet), r.ozellik]),
      ],
    });
  }

  if (s.metraj) {
    // Yükseklik bazlı sayfalama (mm cinsinden yaklaşık yükseklik hesabı)
    const aktifKalem = M.kalemler.filter(k => !k.gizli);
    const maxMm = Math.max(95, icerikH - 12);
    const baslikMm = 6;
    const satirMm = 5.1;
    const sayfalar: typeof aktifKalem[] = [];
    let cur: typeof aktifKalem = [];
    let hMm = baslikMm;
    for (const k of aktifKalem) {
      const ekH = k.not ? satirMm + 1.8 : satirMm;
      if (hMm + ekH > maxMm && cur.length) {
        sayfalar.push(cur);
        cur = [k];
        hMm = baslikMm + ekH;
      } else {
        cur.push(k);
        hMm += ekH;
      }
    }
    if (cur.length) sayfalar.push(cur);

    sayfalar.forEach((parca, i) => {
      const r = parca
        .map(
          k =>
            `<tr><td>${esc(k.grup)}</td><td>${esc(k.ad)}${k.not ? ` <small>(${esc(k.not)})</small>` : ''}</td><td class="s">${fmt(k.miktar, 1)} ${esc(k.birim)}</td><td class="s">${paraYaz(k.birimMal + k.birimIsc)}</td><td class="s">${paraYaz(k.tutar)}</td></tr>`,
        )
        .join('');
      const sonSayfa = i === sayfalar.length - 1;
      const topSatir = sonSayfa
        ? `<tr class="toplam"><td colspan="4" class="s">TOPLAM (KDV %${p.ayar.kdvOran ?? 20} DAHİL)</td><td class="s">${paraYaz(M.toplam)}</td></tr>`
        : '';
      S.push({
        t: `Keşif ve Maliyet${sayfalar.length > 1 ? ` (${i + 1}/${sayfalar.length})` : ''}`,
        alt: `Brüt ${fmt(M.toplamBrut)} m² · Toplam ${paraYaz(M.toplam)}`,
        kat: 'Metraj',
        olcek: 'Tablo',
        ic: `<div style="width:100%;height:100%;overflow:hidden"><table><thead><tr><th>Grup</th><th>Kalem</th><th class="s">Miktar</th><th class="s">B. Fiyat</th><th class="s">Tutar</th></tr></thead><tbody>${r}${topSatir}</tbody></table></div>`,
        tip: 'tablo',
        tabloSatirlar: [
          ['Grup', 'Kalem', 'Miktar', 'Birim Fiyat', 'Tutar'],
          ...parca.map(k => [k.grup, k.ad, `${fmt(k.miktar, 1)} ${k.birim}`, paraYaz(k.birimMal + k.birimIsc), paraYaz(k.tutar)]),
          ...(sonSayfa ? [['', 'GENEL TOPLAM (KDV DAHIL)', '', '', paraYaz(M.toplam)]] : []),
        ],
      });
    });
  }

  if (s.mepRapor && ((p.tesisat || []).length || (p.borular || []).length || p.odalar.length)) {
    const mep = mepMuhendislikHesap();
    const linyeSatir = mep.linyeListesi
      .map(
        l =>
          `<tr><td><b>${esc(l.kod)}</b></td><td>${esc(l.ad)}</td><td class="s">${l.adet}</td><td class="s">${fmt(l.gucW, 0)} W</td><td class="s">${l.sigortaA} A</td><td>${esc(l.kesit)}</td></tr>`,
      )
      .join('');
    const isiSatir = mep.odaIsitma
      .map(
        o =>
          `<tr><td>${esc(o.katAd)}</td><td><b>${esc(o.odaAd)}</b></td><td class="s">${fmt(o.hacim, 1)} m³</td><td class="s">${fmt(o.gerekKcal, 0)} kcal/h</td><td class="s">${o.oneriMetre} m</td><td>${o.yeterli ? 'Uygun' : 'Petek Eksik'}</td></tr>`,
      )
      .join('');
    const pdfRows: string[][] = [
      ['Kod/Kat', 'Tanim / Mahal', 'Adet/Hacim', 'Guc / Isi', 'Sigorta/Petek', 'Kesit / Durum'],
      ...mep.linyeListesi.map(l => [l.kod, l.ad, String(l.adet), `${l.gucW} W`, `${l.sigortaA} A`, l.kesit]),
      ...mep.odaIsitma.map(o => [o.katAd, o.odaAd, `${fmt(o.hacim, 1)} m3`, `${o.gerekKcal} kcal/h`, `${o.oneriMetre} m`, o.yeterli ? 'Uygun' : 'Eksik']),
    ];
    S.push({
      t: 'MEP Mühendislik Hesap & Linye Çizelgesi',
      alt: `Kurulu: ${fmt(mep.toplamKuruluW / 1000, 1)} kW (${mep.faz} · ${mep.anaSigortaA}A) · Isı: ${fmt(mep.toplamIsiKcal, 0)} kcal/h · Fiting: ${mep.fiting.dirsek90 + mep.fiting.dirsek45} dirsek, ${mep.fiting.te} te, ${mep.fiting.vana} vana`,
      kat: 'MEP Hesap',
      olcek: 'Tablo',
      ic: `<div style="width:100%;height:100%;overflow:hidden;display:grid;grid-template-columns:1fr 1fr;gap:4mm;align-content:start">
        <div>
          <div style="font-weight:700;font-size:8pt;margin-bottom:1.5mm">Elektrik Linye Yük Tablosu (${mep.faz} · Ana ${mep.anaSigortaA} A)</div>
          <table><thead><tr><th>Kod</th><th>Linye</th><th class="s">Adet</th><th class="s">Güç</th><th class="s">Sig.</th><th>Kablo</th></tr></thead><tbody>${linyeSatir || '<tr><td colspan="6">Tesisat verisi yok.</td></tr>'}</tbody></table>
          <div style="margin-top:2.5mm;font-size:7pt"><b>Fiting Özeti:</b> ${mep.fiting.dirsek90}×90°, ${mep.fiting.dirsek45}×45° dirsek, ${mep.fiting.te} te, ${mep.fiting.vana} vana · <b>Pis Su Düşüm:</b> ${mep.pisSuMaxDusumCm} cm · <b>Çakışma:</b> ${mep.cakismalar.length}</div>
        </div>
        <div>
          <div style="font-weight:700;font-size:8pt;margin-bottom:1.5mm">Isı Kaybı & Radyatör Çizelgesi (Toplam ${fmt(mep.toplamIsiKcal, 0)} kcal/h)</div>
          <table><thead><tr><th>Kat</th><th>Mahal</th><th class="s">Hacim</th><th class="s">Isı</th><th class="s">Öneri</th><th>Durum</th></tr></thead><tbody>${isiSatir || '<tr><td colspan="6">Isıtılan mahal yok.</td></tr>'}</tbody></table>
        </div>
      </div>`,
      tip: 'tablo',
      tabloSatirlar: pdfRows,
    });
  }

  PAFTA.sayfalar = S;
  return S;
}

function sayfaHTML(s: PaftaSayfaItem, no: number, top: number) {
  const p = P();
  const adaParsel = p.ada || p.parsel ? `Ada ${esc(p.ada || '—')} / Parsel ${esc(p.parsel || '—')}` : esc(p.adres || '—');
  return `<div class="sayfa">
    <div class="cerceve"></div>
    <div class="icerik">${s.ic}</div>
    <div class="baslikP">${esc(s.t)}<small>${esc(s.alt)}</small></div>
    <div class="antet">
      <div class="logo">${LOGO(false, 16)}<b>${esc(p.firma || 'NexDrive')}</b></div>
      <div><small>Proje</small><b>${esc(p.ad)}</b></div>
      <div><small>Ada / Parsel · Adres</small><b>${adaParsel}</b></div>
      <div><small>Ölçek · Revizyon</small><b>${esc(s.olcek)} · ${esc(p.revizyon || 'Rev.0')}</b></div>
      <div><small>Pafta / Sayfa</small><b>${esc(p.paftaNo || 'M-01')} (${no}/${top})</b></div>
      <div><small>Kat / İçerik</small><b>${esc(s.kat)}</b></div>
      <div><small>Çizen</small><b>${esc(p.cizen || '—')}</b></div>
      <div><small>Tarih</small><b>${tarihTR(Date.now())}</b></div>
      <div><small>Kuzey Açısı</small><b>${p.ayar.kuzey || 0}°</b></div>
    </div>
  </div>`;
}

export function paftaSayfa() {
  const p = P();
  const s = PAFTA.secim;
  const g = document.querySelector('#gPafta')!;
  const [pw, ph] = KAGITLAR[PAFTA.kagit] || [297, 210];
  g.innerHTML = `<div class="mbaslik">
    <h2>Çıktı Paftaları (${PAFTA.kagit})</h2>
    <label class="bilgi">Kâğıt <select id="pKagit">${(['A4', 'A3', 'A2', 'A1'] as KagitBoyutu[]).map(k => `<option value="${k}"${PAFTA.kagit === k ? ' selected' : ''}>${k} (${KAGITLAR[k][0]}×${KAGITLAR[k][1]} mm)</option>`).join('')}</select></label>
    <label class="bilgi">Ölçek <select id="pOlcek">${[0, 20, 50, 100, 200, 500].map(v => `<option value="${v}"${PAFTA.olcek === v ? ' selected' : ''}>${v ? '1/' + v : 'Otomatik'}</option>`).join('')}</select></label>
    <label class="bilgi"><input type="checkbox" id="pVaz" ${s.vaziyet ? 'checked' : ''}> Vaziyet</label>
    <label class="bilgi"><input type="checkbox" id="pKat" ${s.katlar ? 'checked' : ''}> Kat planları</label>
    <label class="bilgi"><input type="checkbox" id="pTes" ${s.tesisat ? 'checked' : ''}> Tesisat &amp; boru</label>
    <label class="bilgi"><input type="checkbox" id="pKes" ${s.kesitler ? 'checked' : ''}> Kesitler</label>
    <label class="bilgi"><input type="checkbox" id="pGor" ${s.gorunus ? 'checked' : ''}> Görünüşler</label>
    <label class="bilgi"><input type="checkbox" id="pMah" ${s.mahal ? 'checked' : ''}> Mahal listesi</label>
    <label class="bilgi"><input type="checkbox" id="pDog" ${s.dograma ? 'checked' : ''}> Doğrama</label>
    <label class="bilgi"><input type="checkbox" id="pMet" ${s.metraj ? 'checked' : ''}> Metraj</label>
    <label class="bilgi"><input type="checkbox" id="pMepR" ${s.mepRapor ? 'checked' : ''}> MEP Hesap</label>
    <button class="ubtn" id="pYenile">Yenile</button>
    <button class="ubtn" id="pVectorPdf">Vektör PDF indir</button>
    <button class="ubtn ana" id="pYazdir">Yazdır / PDF</button>
  </div>
  <div class="sayfalar" style="--pw:${pw}mm;--ph:${ph}mm"><div class="bilgi">Paftalar hazırlanıyor…</div></div>`;

  (g.querySelector('#pKagit') as HTMLSelectElement).onchange = e => {
    PAFTA.kagit = (e.target as HTMLSelectElement).value as KagitBoyutu;
    paftaSayfa();
  };
  (g.querySelector('#pOlcek') as HTMLSelectElement).onchange = e => {
    PAFTA.olcek = +((e.target as HTMLSelectElement).value) || 0;
    paftaSayfa();
  };
  (
    [
      ['#pVaz', 'vaziyet'],
      ['#pKat', 'katlar'],
      ['#pTes', 'tesisat'],
      ['#pKes', 'kesitler'],
      ['#pGor', 'gorunus'],
      ['#pMah', 'mahal'],
      ['#pDog', 'dograma'],
      ['#pMet', 'metraj'],
      ['#pMepR', 'mepRapor'],
    ] as const
  ).forEach(([q, k]) => {
    (g.querySelector(q) as HTMLInputElement).onchange = e => {
      PAFTA.secim[k] = (e.target as HTMLInputElement).checked;
      goster();
    };
  });

  const goster = () => {
    const say = paftaUret();
    const html = say.map((x, i) => sayfaHTML(x, i + 1, say.length)).join('');
    g.querySelector('.sayfalar')!.innerHTML = html || '<div class="bilgi">Seçili sayfa yok.</div>';
    const baskiEl = document.querySelector('#baski') as HTMLElement;
    baskiEl.style.setProperty('--pw', pw + 'mm');
    baskiEl.style.setProperty('--ph', ph + 'mm');
    baskiEl.innerHTML = html;
  };
  (g.querySelector('#pYenile') as HTMLButtonElement).onclick = goster;
  (g.querySelector('#pYazdir') as HTMLButtonElement).onclick = () => window.print();
  (g.querySelector('#pVectorPdf') as HTMLButtonElement).onclick = () => {
    const blob = pdfUret();
    indir(asc(p.ad) + `_pafta_${PAFTA.kagit}.pdf`, blob);
    bildir(`Vektör PDF oluşturuldu (${PAFTA.kagit}, ${PAFTA.sayfalar.length} sayfa)`);
  };
  requestAnimationFrame(goster);
}

/* Gerçek Çok Sayfalı Vektör PDF 1.4 Üretici */
function pdfStr(s: string): string {
  return '(' + asc(s).replace(/\\/g, '\\\\').replace(/\(/g, '\\(').replace(/\)/g, '\\)') + ')';
}

function pdfRenk(hex: string): string {
  const r = parseInt(hex.slice(1, 3), 16) / 255 || 0;
  const g = parseInt(hex.slice(3, 5), 16) / 255 || 0;
  const b = parseInt(hex.slice(5, 7), 16) / 255 || 0;
  return `${r.toFixed(3)} ${g.toFixed(3)} ${b.toFixed(3)}`;
}

function dataUrlJpegBytes(dataUrl: string): Uint8Array | null {
  try {
    const idx = dataUrl.indexOf(',');
    if (idx < 0) return null;
    const bin = atob(dataUrl.slice(idx + 1));
    const arr = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) arr[i] = bin.charCodeAt(i);
    return arr;
  } catch {
    return null;
  }
}

export function pdfUret(): Blob {
  if (!PAFTA.sayfalar.length) paftaUret();
  const p = P();
  const [pwMm, phMm] = KAGITLAR[PAFTA.kagit] || [297, 210];
  const mm = 72 / 25.4;
  const PW = pwMm * mm;
  const PH = phMm * mm;
  const enc = new TextEncoder();

  interface ObjEntry {
    id: number;
    data: Uint8Array;
  }
  const objs: ObjEntry[] = [];
  let nextId = 1;
  const alloc = () => nextId++;
  const addObj = (id: number, body: string | Uint8Array) => {
    objs.push({ id, data: typeof body === 'string' ? enc.encode(body) : body });
  };

  const fontId = alloc();
  addObj(fontId, '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>');
  const fontBoldId = alloc();
  addObj(fontBoldId, '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold >>');

  const pagesId = alloc();
  const pageIds: number[] = [];

  const toplam = PAFTA.sayfalar.length;
  PAFTA.sayfalar.forEach((sayfa, idx) => {
    const contentId = alloc();
    const pageId = alloc();
    pageIds.push(pageId);

    const ops: string[] = [];
    const xImgs: { name: string; id: number; w: number; h: number }[] = [];

    // Çerçeve (sol 17mm, sağ/üst/alt 7mm)
    const cx0 = 17 * mm, cy0 = 7 * mm, cw = (pwMm - 24) * mm, ch = (phMm - 14) * mm;
    ops.push('0.067 0.067 0.067 RG 1.1 w');
    ops.push(`${cx0.toFixed(2)} ${cy0.toFixed(2)} ${cw.toFixed(2)} ${ch.toFixed(2)} re S`);

    // Antet (sağ alt 168×23mm)
    const aw = 168 * mm, ah = 23 * mm, ax0 = PW - 7 * mm - aw, ay0 = 7 * mm;
    ops.push('0.6 w');
    ops.push(`${ax0.toFixed(2)} ${ay0.toFixed(2)} ${aw.toFixed(2)} ${ah.toFixed(2)} re S`);
    ops.push(`${ax0.toFixed(2)} ${(ay0 + ah / 2).toFixed(2)} m ${(ax0 + aw).toFixed(2)} ${(ay0 + ah / 2).toFixed(2)} l S`);
    const colW = [46 * mm, 30.5 * mm, 30.5 * mm, 30.5 * mm, 30.5 * mm];
    let curX = ax0;
    for (let ci = 0; ci < 4; ci++) {
      curX += colW[ci];
      ops.push(`${curX.toFixed(2)} ${ay0.toFixed(2)} m ${curX.toFixed(2)} ${(ay0 + ah).toFixed(2)} l S`);
    }

    const txt = (x: number, y: number, s: string, sz = 7.5, bold = false, rgb = '0.08 0.08 0.08') => {
      ops.push(`BT ${rgb} rg /${bold ? 'F2' : 'F1'} ${sz} Tf 1 0 0 1 ${x.toFixed(2)} ${y.toFixed(2)} Tm ${pdfStr(s)} Tj ET`);
    };

    // Başlık & antet yazıları
    txt(19 * mm, 18 * mm, sayfa.t, 12, true);
    txt(19 * mm, 12 * mm, sayfa.alt, 7.5, false, '0.32 0.32 0.32');
    txt(ax0 + 4, ay0 + 14, p.firma || 'NexDrive Engineering', 8.5, true, '0.05 0.3 0.35');
    txt(ax0 + 4, ay0 + 6, 'NEXDRIVE MIMAR', 6.5, false, '0.35 0.35 0.35');

    const cells: [number, number, string, string][] = [
      [1, 1, 'PROJE', p.ad],
      [2, 1, 'ADA / PARSEL', p.ada || p.parsel ? `${p.ada || '-'}/${p.parsel || '-'}` : p.adres || '-'],
      [3, 1, 'OLCEK / REV', `${sayfa.olcek} ${p.revizyon || 'Rev.0'}`],
      [4, 1, 'PAFTA', `${p.paftaNo || 'M-01'} (${idx + 1}/${toplam})`],
      [1, 0, 'KAT / ICERIK', sayfa.kat],
      [2, 0, 'CIZEN', p.cizen || '-'],
      [3, 0, 'TARIH', tarihTR(Date.now())],
      [4, 0, 'KUZEY', `${p.ayar.kuzey || 0} deg`],
    ];
    for (const [ci, row, lbl, val] of cells) {
      let x = ax0 + colW.slice(0, ci).reduce((a, b) => a + b, 0) + 3;
      const y = ay0 + (row ? ah / 2 : 0);
      txt(x, y + ah / 2 - 7, lbl, 5.2, false, '0.4 0.4 0.4');
      txt(x, y + 3, val.slice(0, 22), 7.2, true);
    }

    // İçerik çizimi
    const ix0 = 21 * mm, iy0 = 34 * mm, iw = (pwMm - 32) * mm, ih = (phMm - 45) * mm;
    if ((sayfa.tip === 'plan' || sayfa.tip === 'tesisat') && sayfa.katId) {
      const kid = sayfa.katId;
      const pts: Pt[] = [];
      p.duvarlar.filter(w => w.kat === kid).forEach(w => pts.push([w.x1, w.y1], [w.x2, w.y2]));
      if (sayfa.vaziyet && p.arsa) pts.push(...p.arsa.pts);
      const b = pts.length ? G.bbox(pts) : { x1: 0, y1: 0, x2: 10, y2: 8, w: 10, h: 8 };
      const scNum = parseInt(sayfa.olcek.replace('1/', ''), 10) || 100;
      const mToPt = (1000 / scNum) * mm;
      const fit = Math.min(mToPt, Math.min(iw / Math.max(4, b.w + 4), ih / Math.max(4, b.h + 4)));
      const ocx = ix0 + iw / 2 - (b.x1 + b.w / 2) * fit;
      const ocy = iy0 + ih / 2 + (b.y1 + b.h / 2) * fit;
      const PX = (wx: number) => ocx + wx * fit;
      const PY = (wy: number) => ocy - wy * fit; // Y ters (plan aşağı artar, PDF yukarı artar)

      // Arsa (vaziyet)
      if (sayfa.vaziyet && p.arsa && p.arsa.pts.length >= 3) {
        ops.push('0.15 0.15 0.15 RG 1.2 w [4 3] 0 d');
        p.arsa.pts.forEach((pt, i) => ops.push(`${PX(pt[0]).toFixed(2)} ${PY(pt[1]).toFixed(2)} ${i ? 'l' : 'm'}`));
        ops.push('s [] 0 d');
      }

      // Odalar (dolgu + etiket)
      p.odalar
        .filter(o => o.kat === kid)
        .forEach(o => {
          const mc = G.merkez(o.pts);
          txt(PX(mc[0]) - 14, PY(mc[1]) + 2, o.ad, 7, true, '0.1 0.15 0.25');
          txt(PX(mc[0]) - 12, PY(mc[1]) - 6, `${fmt(Math.abs(G.alan(o.pts)))} m2`, 6, false, '0.35 0.35 0.35');
        });

      // Duvarlar (vektör çizgiler)
      p.duvarlar
        .filter(w => w.kat === kid)
        .forEach(w => {
          ops.push(`${w.tur === 'dis' ? '0.08 0.12 0.18 RG' : '0.35 0.38 0.44 RG'} ${Math.max(0.6, w.k * fit).toFixed(2)} w`);
          if (w.egri && Math.abs(w.egri) > 0.01) {
            const ep = G.egriNoktalar(w.x1, w.y1, w.x2, w.y2, w.egri, 14);
            ep.forEach((pt, i) => ops.push(`${PX(pt[0]).toFixed(2)} ${PY(pt[1]).toFixed(2)} ${i ? 'l' : 'm'}`));
            ops.push('S');
          } else {
            ops.push(`${PX(w.x1).toFixed(2)} ${PY(w.y1).toFixed(2)} m ${PX(w.x2).toFixed(2)} ${PY(w.y2).toFixed(2)} l S`);
          }
          // Duvar uzunluk etiketi
          txt(PX((w.x1 + w.x2) / 2), PY((w.y1 + w.y2) / 2) + 3, fmt(duvarBoy(w)), 5.5, false, '0.2 0.4 0.55');
        });

      // Açıklıklar (kapı + pencere)
      p.aciklar.forEach(a => {
        const w = p.duvarlar.find(dw => dw.id === a.duvar && dw.kat === kid);
        if (!w) return;
        const L = Math.hypot(w.x2 - w.x1, w.y2 - w.y1) || 1;
        const ux = (w.x2 - w.x1) / L, uy = (w.y2 - w.y1) / L;
        const mx = w.x1 + ux * a.t * L, my = w.y1 + uy * a.t * L;
        const ax = mx - ux * (a.g / 2), ay = my - uy * (a.g / 2);
        const bx = mx + ux * (a.g / 2), by = my + uy * (a.g / 2);
        ops.push(`1 1 1 RG ${Math.max(1, w.k * fit + 0.8).toFixed(2)} w`);
        ops.push(`${PX(ax).toFixed(2)} ${PY(ay).toFixed(2)} m ${PX(bx).toFixed(2)} ${PY(by).toFixed(2)} l S`);
        ops.push('0.1 0.45 0.7 RG 0.7 w');
        ops.push(`${PX(ax).toFixed(2)} ${PY(ay).toFixed(2)} m ${PX(bx).toFixed(2)} ${PY(by).toFixed(2)} l S`);
      });

      // Tesisat planındaysa boru döşemeleri (renkli & kesik çizgi)
      if (sayfa.tesisat) {
        (p.borular || [])
          .filter(b => b.kat === kid)
          .forEach(b => {
            const bt = BORU_TIPLERI[b.tur];
            if (!bt || b.pts.length < 2) return;
            ops.push(`${pdfRenk(bt.renk)} RG ${Math.max(1.1, b.cap / 28).toFixed(2)} w`);
            if (bt.cizgi.length) ops.push(`[${bt.cizgi.slice(0, 2).join(' ')}] 0 d`);
            b.pts.forEach((pt, i) => ops.push(`${PX(pt[0]).toFixed(2)} ${PY(pt[1]).toFixed(2)} ${i ? 'l' : 'm'}`));
            ops.push('S [] 0 d');
          });
      }

      // Kuzey oku
      const kx = ix0 + iw - 14, ky = iy0 + ih - 14;
      ops.push('0.1 0.1 0.1 RG 1 w');
      const kr = ((p.ayar.kuzey || 0) * RAD);
      ops.push(`${kx.toFixed(2)} ${ky.toFixed(2)} m ${(kx + Math.sin(kr) * 14).toFixed(2)} ${(ky + Math.cos(kr) * 14).toFixed(2)} l S`);
      txt(kx - 3, ky + 16, 'N', 7, true);
    } else if (sayfa.tabloSatirlar?.length) {
      // Vektör tablo çizimi
      const rows = sayfa.tabloSatirlar;
      const cols = rows[0].length;
      const cwTab = iw / cols;
      const rhTab = Math.min(13.5, (ih - 6) / rows.length);
      rows.forEach((r, ri) => {
        const y = iy0 + ih - (ri + 1) * rhTab;
        if (ri === 0) {
          ops.push('0.91 0.96 0.97 rg');
          ops.push(`${ix0.toFixed(2)} ${y.toFixed(2)} ${iw.toFixed(2)} ${rhTab.toFixed(2)} re f`);
        }
        ops.push('0.65 0.65 0.65 RG 0.4 w');
        ops.push(`${ix0.toFixed(2)} ${y.toFixed(2)} ${iw.toFixed(2)} ${rhTab.toFixed(2)} re S`);
        r.forEach((cell, ci) => {
          txt(ix0 + ci * cwTab + 3, y + 3.2, cell.slice(0, 34), ri === 0 ? 7 : 6.4, ri === 0);
        });
      });
    } else if (sayfa.img && sayfa.img.startsWith('data:image/jpeg')) {
      // Kesit veya görünüş JPEG görselini PDF XObject olarak göm
      const jBytes = dataUrlJpegBytes(sayfa.img);
      if (jBytes) {
        const imgId = alloc();
        const iwPx = 760;
        const ihPx = 500;
        const hdr = enc.encode(`<< /Type /XObject /Subtype /Image /Width ${iwPx} /Height ${ihPx} /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length ${jBytes.length} >>\nstream\n`);
        const ftr = enc.encode('\nendstream');
        const combined = new Uint8Array(hdr.length + jBytes.length + ftr.length);
        combined.set(hdr, 0);
        combined.set(jBytes, hdr.length);
        combined.set(ftr, hdr.length + jBytes.length);
        addObj(imgId, combined);
        xImgs.push({ name: 'Im1', id: imgId, w: iwPx, h: ihPx });
        const sc = Math.min(iw / iwPx, ih / ihPx);
        const dw = iwPx * sc, dh = ihPx * sc;
        const dx = ix0 + (iw - dw) / 2, dy = iy0 + (ih - dh) / 2;
        ops.push(`q ${dw.toFixed(2)} 0 0 ${dh.toFixed(2)} ${dx.toFixed(2)} ${dy.toFixed(2)} cm /Im1 Do Q`);
      }
    }

    const streamStr = ops.join('\n');
    addObj(contentId, `<< /Length ${enc.encode(streamStr).length} >>\nstream\n${streamStr}\nendstream`);
    const xRes = xImgs.length ? `/XObject << ${xImgs.map(x => `/${x.name} ${x.id} 0 R`).join(' ')} >>` : '';
    addObj(
      pageId,
      `<< /Type /Page /Parent ${pagesId} 0 R /MediaBox [0 0 ${PW.toFixed(2)} ${PH.toFixed(2)}] /Resources << /Font << /F1 ${fontId} 0 R /F2 ${fontBoldId} 0 R >> ${xRes} >> /Contents ${contentId} 0 R >>`,
    );
  });

  const catalogId = alloc();
  addObj(pagesId, `<< /Type /Pages /Kids [${pageIds.map(id => `${id} 0 R`).join(' ')}] /Count ${pageIds.length} >>`);
  addObj(catalogId, `<< /Type /Catalog /Pages ${pagesId} 0 R >>`);

  // PDF binary montajı
  objs.sort((a, b) => a.id - b.id);
  const chunks: Uint8Array[] = [enc.encode('%PDF-1.4\n%\xE2\xE3\xCF\xD3\n')];
  let offset = chunks[0].length;
  const offsets: number[] = [0];
  for (const o of objs) {
    offsets[o.id] = offset;
    const pre = enc.encode(`${o.id} 0 obj\n`);
    const post = enc.encode('\nendobj\n');
    chunks.push(pre, o.data, post);
    offset += pre.length + o.data.length + post.length;
  }
  const xrefPos = offset;
  let xref = `xref\n0 ${objs.length + 1}\n0000000000 65535 f \n`;
  for (let i = 1; i <= objs.length; i++) {
    xref += String(offsets[i] || 0).padStart(10, '0') + ' 00000 n \n';
  }
  xref += `trailer\n<< /Size ${objs.length + 1} /Root ${catalogId} 0 R >>\nstartxref\n${xrefPos}\n%%EOF`;
  chunks.push(enc.encode(xref));
  return new Blob(chunks as BlobPart[], { type: 'application/pdf' });
}
