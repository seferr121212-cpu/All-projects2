import type { BoruTuru, FiyatKalem, Mobilya } from './types';

export const ZEMIN: Record<string, { ad: string; renk: string; r3: string }> = {
  parke: { ad: 'Parke', renk: '#ead2a8', r3: '#c9a06a' },
  laminat: { ad: 'Laminat', renk: '#e3cfae', r3: '#b8935f' },
  seramik: { ad: 'Seramik', renk: '#dde7ee', r3: '#d7dde2' },
  mermer: { ad: 'Mermer', renk: '#eeeeea', r3: '#e6e4dc' },
  hali: { ad: 'Halı / kilim', renk: '#e7d9e4', r3: '#a98fa3' },
  beton: { ad: 'Şap / beton', renk: '#e2e2e2', r3: '#b9b9b6' },
  deck: { ad: 'Deck (ahşap dış)', renk: '#dcc3a0', r3: '#a77e52' },
};

export const ODA_ADLARI = [
  'Salon', 'Mutfak', 'Yatak Odası', 'Ebeveyn Yatak Odası', 'Çocuk Odası',
  'Banyo', 'WC', 'Ebeveyn Banyosu', 'Antre', 'Koridor', 'Hol',
  'Balkon', 'Teras', 'Çalışma Odası', 'Kiler', 'Çamaşır Odası',
  'Giyinme Odası', 'Yemek Odası', 'Garaj', 'Depo', 'Kazan Dairesi',
];

export function odaZemini(ad: string): string {
  const a = ad.toLocaleLowerCase('tr');
  if (/banyo|wc|tuvalet|duş|çamaşır|kazan|mutfak/.test(a)) return 'seramik';
  if (/balkon|teras/.test(a)) return 'deck';
  if (/garaj|depo|kiler/.test(a)) return 'beton';
  if (/antre|hol|koridor/.test(a)) return 'seramik';
  return 'parke';
}

export const ISLAK = (a: string): boolean => /banyo|wc|tuvalet|duş|çamaşır/i.test(a);
export const ACIK_ALAN_ODA = (a: string): boolean => /balkon|teras|veranda/i.test(a);

export const BLOK: Record<string, { ad: string; m2: number; bazK: number; fk: string }> = {
  gazbeton: { ad: 'Gazbeton blok (60×25)', m2: 6.67, bazK: 0.2, fk: 'blok_gazbeton' },
  tugla: { ad: 'Yatay delikli tuğla (19×19)', m2: 25, bazK: 0.19, fk: 'blok_tugla' },
  bims: { ad: 'Bims blok (39×19)', m2: 12.5, bazK: 0.19, fk: 'blok_bims' },
};

export const CATI: Record<string, string> = {
  duz: 'Düz çatı (teras)',
  besik: 'Beşik çatı',
  kirma: 'Kırma çatı',
  tek: 'Tek eğimli',
};

export const DOGRAMA_RENK: Record<string, { ad: string; hex: string }> = {
  beyaz: { ad: 'Beyaz PVC', hex: '#f4f4f2' },
  antrasit: { ad: 'Antrasit (RAL 7016)', hex: '#383e42' },
  ahsap: { ad: 'Altın Meşe (Ahşap)', hex: '#8b5a33' },
  siyah: { ad: 'Mat Siyah Alüminyum', hex: '#212428' },
};

export const AH = '#b88a5a';
export const AC = '#d9c2a0';
export const BEY = '#f1f1ee';
export const GRI = '#8d939b';
export const KOY = '#3c4148';
export const KUM = '#9fb2c4';
export const KUMAS = '#6e7f95';

export interface MobilyaTip {
  ad: string;
  k: string;
  w: number;
  d: number;
  h: number;
  ozel?: 'merdiven' | 'merdiven_l' | 'merdiven_u' | 'merdiven_doner' | 'kolon';
  p?: (m: MobilyaTip) => [number, number, number, number, number, number, string][];
}

export const MOB: Record<string, MobilyaTip> = {
  yatak2: { ad: 'Çift yatak', k: 'Yatak odası', w: 1.6, d: 2.05, h: 0.55, p: () => [[-0.8, -1.02, 0.8, -0.95, 0, 1.0, AH], [-0.8, -0.95, 0.8, 1.02, 0, 0.32, AH], [-0.78, -0.93, 0.78, 1.0, 0.32, 0.55, BEY], [-0.7, -0.88, -0.06, -0.5, 0.55, 0.66, BEY], [0.06, -0.88, 0.7, -0.5, 0.55, 0.66, BEY], [-0.79, -0.2, 0.79, 0.99, 0.55, 0.6, KUM]] },
  yatak1: { ad: 'Tek yatak', k: 'Yatak odası', w: 0.95, d: 2.0, h: 0.5, p: () => [[-0.47, -1, 0.47, -0.94, 0, 0.9, AH], [-0.47, -0.94, 0.47, 1, 0, 0.3, AH], [-0.45, -0.92, 0.45, 0.98, 0.3, 0.5, BEY], [-0.35, -0.86, 0.35, -0.52, 0.5, 0.6, BEY], [-0.46, -0.2, 0.46, 0.97, 0.5, 0.55, KUM]] },
  gardirop: { ad: 'Gardırop', k: 'Yatak odası', w: 1.8, d: 0.6, h: 2.2, p: m => [[-m.w / 2, -0.3, m.w / 2, 0.3, 0, 2.2, AC]] },
  komodin: { ad: 'Komodin', k: 'Yatak odası', w: 0.5, d: 0.4, h: 0.5, p: () => [[-0.25, -0.2, 0.25, 0.2, 0, 0.5, AH]] },
  calisma: { ad: 'Çalışma masası', k: 'Yatak odası', w: 1.2, d: 0.6, h: 0.75, p: m => [[-m.w / 2, -0.3, m.w / 2, 0.3, 0.72, 0.76, AC], [-m.w / 2, -0.3, -m.w / 2 + 0.05, 0.3, 0, 0.72, GRI], [m.w / 2 - 0.05, -0.3, m.w / 2, 0.3, 0, 0.72, GRI]] },
  kanepe: { ad: 'Kanepe (3’lü)', k: 'Salon', w: 2.2, d: 0.9, h: 0.85, p: () => [[-1.1, -0.45, 1.1, 0.45, 0, 0.42, KUMAS], [-1.1, -0.45, 1.1, -0.2, 0.42, 0.85, KUMAS], [-1.1, -0.2, -0.92, 0.45, 0.42, 0.62, KUMAS], [0.92, -0.2, 1.1, 0.45, 0.42, 0.62, KUMAS]] },
  kose: { ad: 'Köşe koltuk', k: 'Salon', w: 2.8, d: 2.0, h: 0.85, p: () => [[-1.4, -1, 1.4, -0.1, 0, 0.42, KUMAS], [-1.4, -1, 1.4, -0.75, 0.42, 0.85, KUMAS], [0.5, -0.1, 1.4, 1, 0, 0.42, KUMAS], [1.15, -0.75, 1.4, 1, 0.42, 0.85, KUMAS]] },
  koltuk: { ad: 'Berjer', k: 'Salon', w: 0.85, d: 0.85, h: 0.85, p: () => [[-0.42, -0.42, 0.42, 0.42, 0, 0.42, KUMAS], [-0.42, -0.42, 0.42, -0.2, 0.42, 0.85, KUMAS]] },
  sehpa: { ad: 'Orta sehpa', k: 'Salon', w: 1.1, d: 0.6, h: 0.42, p: () => [[-0.55, -0.3, 0.55, 0.3, 0.36, 0.42, AH], [-0.5, -0.25, 0.5, 0.25, 0, 0.36, KOY]] },
  tv: { ad: 'TV ünitesi', k: 'Salon', w: 1.8, d: 0.45, h: 0.5, p: () => [[-0.9, -0.22, 0.9, 0.22, 0, 0.5, AC], [-0.65, -0.05, 0.65, 0.0, 0.55, 1.3, KOY]] },
  kitaplik: { ad: 'Kitaplık', k: 'Salon', w: 1.0, d: 0.35, h: 2.0, p: () => [[-0.5, -0.17, 0.5, 0.17, 0, 2, AH]] },
  masa: { ad: 'Yemek masası', k: 'Mutfak', w: 1.6, d: 0.9, h: 0.75, p: m => [[-m.w / 2, -m.d / 2, m.w / 2, m.d / 2, 0.72, 0.76, AH], [-m.w / 2 + 0.05, -m.d / 2 + 0.05, -m.w / 2 + 0.12, -m.d / 2 + 0.12, 0, 0.72, AH], [m.w / 2 - 0.12, -m.d / 2 + 0.05, m.w / 2 - 0.05, -m.d / 2 + 0.12, 0, 0.72, AH], [-m.w / 2 + 0.05, m.d / 2 - 0.12, -m.w / 2 + 0.12, m.d / 2 - 0.05, 0, 0.72, AH], [m.w / 2 - 0.12, m.d / 2 - 0.12, m.w / 2 - 0.05, m.d / 2 - 0.05, 0, 0.72, AH]] },
  sandalye: { ad: 'Sandalye', k: 'Mutfak', w: 0.45, d: 0.5, h: 0.9, p: () => [[-0.22, -0.25, 0.22, 0.25, 0.42, 0.46, AH], [-0.22, 0.2, 0.22, 0.25, 0.46, 0.9, AH], [-0.2, -0.23, -0.16, -0.19, 0, 0.42, KOY], [0.16, -0.23, 0.2, -0.19, 0, 0.42, KOY], [-0.2, 0.19, -0.16, 0.23, 0, 0.42, KOY], [0.16, 0.19, 0.2, 0.23, 0, 0.42, KOY]] },
  tezgah: { ad: 'Mutfak tezgahı', k: 'Mutfak', w: 2.4, d: 0.6, h: 0.9, p: m => [[-m.w / 2, -0.3, m.w / 2, 0.3, 0, 0.86, BEY], [-m.w / 2, -0.3, m.w / 2, 0.3, 0.86, 0.9, KOY], [-m.w / 2, -0.3, m.w / 2, -0.02, 1.45, 2.15, BEY]] },
  evye: { ad: 'Evye', k: 'Mutfak', w: 0.8, d: 0.6, h: 0.9, p: () => [[-0.4, -0.3, 0.4, 0.3, 0, 0.86, BEY], [-0.4, -0.3, 0.4, 0.3, 0.86, 0.9, '#c7ced6']] },
  ocak: { ad: 'Ocak / fırın', k: 'Mutfak', w: 0.6, d: 0.6, h: 0.9, p: () => [[-0.3, -0.3, 0.3, 0.3, 0, 0.88, GRI], [-0.3, -0.3, 0.3, 0.3, 0.88, 0.9, '#1f2226']] },
  buzdolabi: { ad: 'Buzdolabı', k: 'Mutfak', w: 0.7, d: 0.7, h: 1.85, p: () => [[-0.35, -0.35, 0.35, 0.35, 0, 1.85, '#dfe3e7']] },
  camasir: { ad: 'Çamaşır mak.', k: 'Banyo', w: 0.6, d: 0.6, h: 0.85, p: () => [[-0.3, -0.3, 0.3, 0.3, 0, 0.85, BEY]] },
  wc: { ad: 'Klozet', k: 'Banyo', w: 0.4, d: 0.65, h: 0.42, p: () => [[-0.2, -0.32, 0.2, -0.12, 0, 0.8, BEY], [-0.18, -0.12, 0.18, 0.32, 0, 0.42, BEY]] },
  lavabo: { ad: 'Lavabo', k: 'Banyo', w: 0.6, d: 0.45, h: 0.85, p: () => [[-0.3, -0.22, 0.3, 0.22, 0.7, 0.85, BEY], [-0.06, -0.22, 0.06, -0.1, 0, 0.7, BEY], [-0.25, -0.22, 0.25, -0.2, 1.0, 1.7, '#cfe3ee']] },
  dus: { ad: 'Duşakabin', k: 'Banyo', w: 0.9, d: 0.9, h: 2.0, p: () => [[-0.45, -0.45, 0.45, 0.45, 0, 0.06, BEY], [-0.45, 0.43, 0.45, 0.45, 0.06, 2.0, 'cam'], [0.43, -0.45, 0.45, 0.45, 0.06, 2.0, 'cam']] },
  kuvet: { ad: 'Küvet', k: 'Banyo', w: 1.7, d: 0.75, h: 0.55, p: () => [[-0.85, -0.37, 0.85, 0.37, 0, 0.55, BEY], [-0.78, -0.3, 0.78, 0.3, 0.55, 0.56, '#a9d4ea']] },
  merdiven: { ad: 'Düz merdiven', k: 'Yapı', w: 1.0, d: 3.2, h: 0, ozel: 'merdiven' },
  merdiven_l: { ad: 'L merdiven', k: 'Yapı', w: 2.2, d: 2.4, h: 0, ozel: 'merdiven_l' },
  merdiven_u: { ad: 'U merdiven', k: 'Yapı', w: 2.2, d: 2.8, h: 0, ozel: 'merdiven_u' },
  merdiven_doner: { ad: 'Döner merdiven', k: 'Yapı', w: 1.8, d: 1.8, h: 0, ozel: 'merdiven_doner' },
  kolon: { ad: 'Kolon', k: 'Yapı', w: 0.3, d: 0.3, h: 0, ozel: 'kolon' },
  bitki: { ad: 'Saksı bitki', k: 'Salon', w: 0.45, d: 0.45, h: 1.1, p: () => [[-0.18, -0.18, 0.18, 0.18, 0, 0.4, '#a8664a'], [-0.22, -0.22, 0.22, 0.22, 0.4, 1.1, '#4f8a4a']] },
};

export const MOB_KAT = ['Salon', 'Yatak odası', 'Mutfak', 'Banyo', 'Yapı'];

export const mobOlcu = (m: Pick<Mobilya, 'tip' | 'w' | 'd'>) => ({
  w: m.w ?? MOB[m.tip]?.w ?? 1,
  d: m.d ?? MOB[m.tip]?.d ?? 1,
});

export const DIS: Record<string, { ad: string; cap?: number; alan?: boolean; cizgi?: boolean; gizli?: boolean; w?: number; d?: number; renk?: string; r3?: string }> = {
  agac: { ad: 'Ağaç', cap: 3.5 },
  cali: { ad: 'Çalı', cap: 1.0 },
  cim: { ad: 'Çim alanı', alan: true, renk: '#b6d99a', r3: '#6fa24f' },
  yol: { ad: 'Yol / kaldırım', alan: true, renk: '#d6d1c7', r3: '#c4bdb0' },
  otopark: { ad: 'Otopark / asfalt', alan: true, renk: '#9ea3aa', r3: '#5f646b' },
  havuz: { ad: 'Havuz', alan: true, renk: '#8fd0ee', r3: '#3aa7d8' },
  cit: { ad: 'Çevre duvarı / çit', cizgi: true },
  araba: { ad: 'Otomobil', w: 1.85, d: 4.5 },
  kot: { ad: 'Kot noktası', gizli: true },
};

export const TES: Record<string, { ad: string; g: string; duvar?: boolean; renk: string; kot?: number }> = {
  priz: { ad: 'Priz', g: 'Elektrik', duvar: true, renk: '#d14b3f', kot: 0.35 },
  etanj: { ad: 'Etanj priz', g: 'Elektrik', duvar: true, renk: '#d14b3f', kot: 0.5 },
  anahtar: { ad: 'Anahtar', g: 'Elektrik', duvar: true, renk: '#d14b3f', kot: 1.1 },
  lamba: { ad: 'Tavan lambası', g: 'Elektrik', renk: '#d14b3f', kot: 2.75 },
  aplik: { ad: 'Aplik', g: 'Elektrik', duvar: true, renk: '#d14b3f', kot: 2.0 },
  tv: { ad: 'TV / data', g: 'Elektrik', duvar: true, renk: '#7b4fc9', kot: 0.45 },
  klima: { ad: 'Klima', g: 'Elektrik', duvar: true, renk: '#2a8fb5', kot: 2.3 },
  pano: { ad: 'Sigorta panosu', g: 'Elektrik', duvar: true, renk: '#1c2d44', kot: 1.6 },
  su: { ad: 'Temiz su çıkışı', g: 'Sıhhi & ısıtma', renk: '#1f7fd6', kot: 0.55 },
  gider: { ad: 'Pis su gideri', g: 'Sıhhi & ısıtma', renk: '#7a5232', kot: 0.05 },
  yer_suzgeci: { ad: 'Yer süzgeci', g: 'Sıhhi & ısıtma', renk: '#7a5232', kot: 0.0 },
  kollektor: { ad: 'Su/Isıtma kollektörü', g: 'Sıhhi & ısıtma', duvar: true, renk: '#1f7fd6', kot: 0.6 },
  sayac: { ad: 'Su sayacı', g: 'Sıhhi & ısıtma', duvar: true, renk: '#1f7fd6', kot: 1.2 },
  kombi: { ad: 'Kombi', g: 'Sıhhi & ısıtma', duvar: true, renk: '#e0812b', kot: 1.5 },
  petek: { ad: 'Petek', g: 'Sıhhi & ısıtma', duvar: true, renk: '#e0812b', kot: 0.4 },
  hidrofor: { ad: 'Hidrofor / depo', g: 'Sıhhi & ısıtma', renk: '#1f7fd6', kot: 0.3 },
  saft: { ad: 'Tesisat şaftı (dikey)', g: 'Altyapı & şaft', renk: '#16878c', kot: 0 },
  logar: { ad: 'Rögar / logar', g: 'Altyapı & şaft', renk: '#5d4037', kot: -0.6 },
  dogalgaz_sayac: { ad: 'Doğalgaz sayacı', g: 'Altyapı & şaft', duvar: true, renk: '#d4a017', kot: 1.4 },
};

export interface BoruTipBilgi {
  ad: string;
  kisa: string;
  renk: string;
  cizgi: number[];
  caplar: number[];
  varsCap: number;
  varsKot: number;
  varsEgim: number;
  fk: string;
}

export const BORU_TIPLERI: Record<BoruTuru, BoruTipBilgi> = {
  temiz_su_soguk: {
    ad: 'Temiz su (soğuk · PPRC)',
    kisa: 'Soğuk su',
    renk: '#1976d2',
    cizgi: [],
    caplar: [20, 25, 32],
    varsCap: 20,
    varsKot: 0.15,
    varsEgim: 0,
    fk: 'tes_su',
  },
  temiz_su_sicak: {
    ad: 'Temiz su (sıcak · PPRC)',
    kisa: 'Sıcak su',
    renk: '#d93829',
    cizgi: [8, 3],
    caplar: [20, 25],
    varsCap: 20,
    varsKot: 0.25,
    varsEgim: 0,
    fk: 'tes_su_sicak',
  },
  pis_su: {
    ad: 'Pis su gider borusu (PVC)',
    kisa: 'Pis su',
    renk: '#6d4c3d',
    cizgi: [],
    caplar: [50, 75, 110, 125],
    varsCap: 110,
    varsKot: -0.08,
    varsEgim: 1.5,
    fk: 'tes_gider',
  },
  kalorifer: {
    ad: 'Kalorifer / yerden ısıtma (PEX/PPRC)',
    kisa: 'Kalorifer',
    renk: '#e0812b',
    cizgi: [10, 4, 2, 4],
    caplar: [16, 20, 25, 32],
    varsCap: 20,
    varsKot: -0.02,
    varsEgim: 0,
    fk: 'tes_kalorifer',
  },
  elektrik_kablo: {
    ad: 'Elektrik kablo / spiral boru',
    kisa: 'Elektrik',
    renk: '#c0392b',
    cizgi: [4, 4],
    caplar: [16, 20, 25],
    varsCap: 16,
    varsKot: 2.55,
    varsEgim: 0,
    fk: 'tes_kablo',
  },
  dogalgaz: {
    ad: 'Doğalgaz hattı (çelik / bakır)',
    kisa: 'Doğalgaz',
    renk: '#c89b0c',
    cizgi: [12, 4, 3, 4],
    caplar: [20, 25, 32],
    varsCap: 25,
    varsKot: 2.15,
    varsEgim: 0,
    fk: 'tes_dogalgaz',
  },
};

export const VARSAYILAN_FIYAT: Record<string, FiyatKalem> = {
  blok_gazbeton: { ad: 'Gazbeton blok', b: 'adet', f: 48, isc: 18 },
  blok_tugla: { ad: 'Tuğla', b: 'adet', f: 12, isc: 7 },
  blok_bims: { ad: 'Bims blok', b: 'adet', f: 32, isc: 14 },
  siva_ic: { ad: 'İç sıva', b: 'm²', f: 220, isc: 160 },
  siva_dis: { ad: 'Dış sıva', b: 'm²', f: 240, isc: 180 },
  mantolama: { ad: 'Mantolama', b: 'm²', f: 620, isc: 330 },
  boya: { ad: 'İç cephe boyası', b: 'lt', f: 240, isc: 120 },
  dis_boya: { ad: 'Dış cephe boyası', b: 'lt', f: 280, isc: 150 },
  parke: { ad: 'Parke', b: 'm²', f: 680, isc: 220 },
  laminat: { ad: 'Laminat', b: 'm²', f: 400, isc: 150 },
  seramik: { ad: 'Yer seramiği', b: 'm²', f: 480, isc: 220 },
  mermer: { ad: 'Mermer', b: 'm²', f: 2100, isc: 500 },
  hali: { ad: 'Halı', b: 'm²', f: 520, isc: 130 },
  sap: { ad: 'Şap / beton zemin', b: 'm²', f: 210, isc: 110 },
  deck: { ad: 'Deck', b: 'm²', f: 1100, isc: 300 },
  duvar_seramik: { ad: 'Duvar seramiği', b: 'm²', f: 500, isc: 250 },
  supurgelik: { ad: 'Süpürgelik', b: 'm', f: 110, isc: 50 },
  kapi_ic: { ad: 'İç kapı', b: 'adet', f: 7500, isc: 2000 },
  kapi_dis: { ad: 'Çelik dış kapı', b: 'adet', f: 27000, isc: 5000 },
  kapi_garaj: { ad: 'Otomatik garaj kapısı', b: 'adet', f: 48000, isc: 7500 },
  kapi_cift: { ad: 'Çift kanat giriş kapısı', b: 'adet', f: 38000, isc: 6000 },
  pencere: { ad: 'PVC / Alüminyum pencere', b: 'm²', f: 5200, isc: 1300 },
  balkon: { ad: 'Balkon / sürme kapısı', b: 'm²', f: 5500, isc: 1350 },
  panjur: { ad: 'Panjur / kepenk sistemi', b: 'm²', f: 3200, isc: 800 },
  beton: { ad: 'Hazır beton', b: 'm³', f: 3500, isc: 700 },
  demir: { ad: 'İnşaat demiri', b: 'kg', f: 25, isc: 6 },
  kolon_kiris: { ad: 'Kolon + kiriş betonu', b: 'm³', f: 3500, isc: 900 },
  merdiven_beton: { ad: 'Merdiven betonu & kalıp', b: 'm³', f: 4200, isc: 2600 },
  merdiven_kaplama: { ad: 'Merdiven basamak kaplaması', b: 'adet', f: 1200, isc: 550 },
  korkuluk: { ad: 'Balkon / merdiven korkuluğu', b: 'm', f: 2400, isc: 650 },
  cati: { ad: 'Çatı (kiremit + konstrüksiyon)', b: 'm²', f: 1350, isc: 550 },
  oluk: { ad: 'Yağmur oluğu + iniş borusu', b: 'm', f: 420, isc: 180 },
  teras: { ad: 'Teras yalıtımı', b: 'm²', f: 800, isc: 300 },
  hafriyat: { ad: 'Hafriyat kazı + nakliye', b: 'm³', f: 220, isc: 130 },
  dis_dolgu: { ad: 'Dışarıdan dolgu malzemesi', b: 'm³', f: 320, isc: 100 },
  cim: { ad: 'Çim (rulo)', b: 'm²', f: 180, isc: 80 },
  agac: { ad: 'Ağaç fidanı', b: 'adet', f: 1400, isc: 400 },
  cali: { ad: 'Çalı / süs bitkisi', b: 'adet', f: 260, isc: 90 },
  cit: { ad: 'Çevre duvarı / çit', b: 'm', f: 1150, isc: 450 },
  havuz: { ad: 'Havuz (anahtar teslim)', b: 'm²', f: 17000, isc: 5000 },
  yol: { ad: 'Kaldırım / parke taşı', b: 'm²', f: 450, isc: 200 },
  otopark: { ad: 'Asfalt / beton otopark', b: 'm²', f: 380, isc: 140 },
  tes_priz: { ad: 'Priz / anahtar / data noktası', b: 'adet', f: 420, isc: 230 },
  tes_lamba: { ad: 'Aydınlatma noktası', b: 'adet', f: 500, isc: 250 },
  tes_kablo: { ad: 'Elektrik kablosu + spiral boru', b: 'm', f: 38, isc: 26 },
  tes_pano: { ad: 'Sigorta panosu (komple)', b: 'adet', f: 6500, isc: 2000 },
  tes_klima: { ad: 'Klima tesisatı (bakır hat)', b: 'adet', f: 2600, isc: 900 },
  tes_su: { ad: 'Soğuk su borusu (PPRC)', b: 'm', f: 115, isc: 75 },
  tes_su_sicak: { ad: 'Sıcak su borusu (kılıflı PPRC)', b: 'm', f: 135, isc: 80 },
  tes_gider: { ad: 'Pis su borusu (PVC Ø50/110)', b: 'm', f: 155, isc: 90 },
  tes_kalorifer: { ad: 'Kalorifer / ısıtma borusu', b: 'm', f: 125, isc: 75 },
  tes_dogalgaz: { ad: 'Doğalgaz tesisat borusu', b: 'm', f: 290, isc: 160 },
  tes_kombi: { ad: 'Kombi (montaj dahil)', b: 'adet', f: 38000, isc: 4000 },
  tes_petek: { ad: 'Petek (montaj dahil)', b: 'adet', f: 3100, isc: 700 },
  tes_sayac: { ad: 'Su / doğalgaz sayacı + kollektör', b: 'adet', f: 2200, isc: 800 },
  tes_saft_logar: { ad: 'Şaft / rögar / hidrofor grubu', b: 'adet', f: 5500, isc: 2200 },
  tes_dirsek: { ad: 'Boru ek parçası (Dirsek / Te / Redüksiyon)', b: 'adet', f: 45, isc: 30 },
  tes_vana: { ad: 'Kesme vanası / çekvalf / küresel vana', b: 'adet', f: 360, isc: 140 },
};

export const zeminFiyatKey = (z: string): string => (z === 'beton' ? 'sap' : z);

export const PARA_BIRIM: Record<'TRY' | 'USD' | 'EUR', { sembol: string; ad: string }> = {
  TRY: { sembol: '₺', ad: 'TL (₺)' },
  USD: { sembol: '$', ad: 'USD ($)' },
  EUR: { sembol: '€', ad: 'EUR (€)' },
};
