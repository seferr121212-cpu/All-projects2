import { BORU_TIPLERI, MOB, TES, mobOlcu } from './catalog';
import type { Mobilya, TesisatNokta } from './types';
import { RAD, fmt } from './utils';

export type RGB = [number, number, number];
export type V3 = [number, number, number];

export interface HitSpec {
  tur: string;
  id: string;
  ad: string;
  detay?: string;
}

export interface MeshHedef {
  tri(p: V3, q: V3, r: V3, c: RGB, a?: number, mt?: number): void;
  quad(p: V3, q: V3, r: V3, s: V3, c: RGB, a?: number, mt?: number): void;
  triSmooth(p: V3, np: V3, q: V3, nq: V3, r: V3, nr: V3, c: RGB, a?: number, mt?: number): void;
  quadSmooth(p: V3, np: V3, q: V3, nq: V3, r: V3, nr: V3, s: V3, ns: V3, c: RGB, a?: number, mt?: number): void;
  boruSeg(x1: number, y1: number, z1: number, x2: number, y2: number, z2: number, r: number, c: RGB): void;
  pushHitBox(hit: HitSpec | undefined, min: V3, max: V3): void;
}

// Malzeme ID'leri (webgl3d.ts GL_FS ile senkron)
const MT_DUZ = 0;
const MT_AHSAP = 2;
const MT_MERMER = 4;
const MT_KROM = 8;
const MT_PIRINC = 9;
const MT_SERAMIK = 10;
const MT_KUMAS = 11;
const MT_ISIK = 12;
const MT_MAT = 13;

const hex = (h: string): RGB => [
  parseInt(h.slice(1, 3), 16) / 255,
  parseInt(h.slice(3, 5), 16) / 255,
  parseInt(h.slice(5, 7), 16) / 255,
];

// Zenginleştirilmiş PBR-benzeri Mimari Palet
const C_MESE: RGB = [0.74, 0.56, 0.36];
const C_CEVIZ: RGB = [0.42, 0.27, 0.17];
const C_ACIK_AH: RGB = [0.85, 0.75, 0.59];
const C_BEYAZ: RGB = [0.95, 0.95, 0.93];
const C_KREM: RGB = [0.91, 0.88, 0.82];
const C_ADA_YESIL: RGB = [0.48, 0.56, 0.50];
const C_SERAMIK: RGB = [0.97, 0.97, 0.98];
const C_MERMER: RGB = [0.93, 0.92, 0.90];
const C_KROM: RGB = [0.82, 0.85, 0.89];
const C_PIRINC: RGB = [0.84, 0.67, 0.35];
const C_BAKIR: RGB = [0.78, 0.48, 0.32];
const C_SIYAH: RGB = [0.14, 0.15, 0.18];
const C_ANTRASIT: RGB = [0.23, 0.26, 0.30];
const C_GRI: RGB = [0.56, 0.59, 0.63];
const C_PASLANMAZ: RGB = [0.74, 0.78, 0.82];
const C_KUMA: RGB = [0.43, 0.50, 0.59];
const C_KUMA_KOYU: RGB = [0.31, 0.37, 0.45];
const C_KUMA_BEJ: RGB = [0.81, 0.77, 0.70];
const C_YASTIK_TEAL: RGB = [0.20, 0.55, 0.60];
const C_YASTIK_HARDAL: RGB = [0.83, 0.61, 0.23];
const C_YASTIK_TER: RGB = [0.73, 0.36, 0.29];
const C_YATAK_ORTU: RGB = [0.54, 0.63, 0.72];
const C_CAM: RGB = [0.58, 0.80, 0.90];
const C_KUVET_SU: RGB = [0.56, 0.82, 0.93];
const C_TOPRAK: RGB = [0.26, 0.19, 0.13];
const C_SAKSI: RGB = [0.72, 0.42, 0.31];
const C_YAPRAK1: RGB = [0.23, 0.49, 0.24];
const C_YAPRAK2: RGB = [0.32, 0.58, 0.29];
const C_YAPRAK3: RGB = [0.17, 0.40, 0.19];
const C_ISIK: RGB = [1.0, 0.94, 0.76];
const C_EKRAN: RGB = [0.24, 0.52, 0.78];

class L3D {
  private cs: number;
  private sn: number;
  private minB: V3 = [Infinity, Infinity, Infinity];
  private maxB: V3 = [-Infinity, -Infinity, -Infinity];

  constructor(
    private m: MeshHedef,
    private cx: number,
    private cy: number,
    private cz: number,
    private sx: number,
    private sy: number,
    rDeg: number,
    private hit?: HitSpec,
  ) {
    const R = rDeg * RAD;
    this.cs = Math.cos(R);
    this.sn = Math.sin(R);
  }

  pt(lx: number, ly: number, lz: number): V3 {
    const x = lx * this.sx;
    const y = ly * this.sy;
    const wx = this.cx + x * this.cs - y * this.sn;
    const wy = this.cy + lz;
    const wz = this.cz + x * this.sn + y * this.cs;
    if (this.hit) {
      if (wx < this.minB[0]) this.minB[0] = wx;
      if (wy < this.minB[1]) this.minB[1] = wy;
      if (wz < this.minB[2]) this.minB[2] = wz;
      if (wx > this.maxB[0]) this.maxB[0] = wx;
      if (wy > this.maxB[1]) this.maxB[1] = wy;
      if (wz > this.maxB[2]) this.maxB[2] = wz;
    }
    return [wx, wy, wz];
  }

  nrm(lx: number, ly: number, lz: number): V3 {
    const x = lx / (this.sx || 1);
    const y = ly / (this.sy || 1);
    const wx = x * this.cs - y * this.sn;
    const wy = lz;
    const wz = x * this.sn + y * this.cs;
    const L = Math.hypot(wx, wy, wz) || 1;
    return [wx / L, wy / L, wz / L];
  }

  box(x0: number, y0: number, z0: number, x1: number, y1: number, z1: number, col: RGB, a = 1, mt = 0) {
    const ax0 = Math.min(x0, x1), ax1 = Math.max(x0, x1);
    const ay0 = Math.min(y0, y1), ay1 = Math.max(y0, y1);
    const az0 = Math.min(z0, z1), az1 = Math.max(z0, z1);
    const B0 = this.pt(ax0, ay0, az0), B1 = this.pt(ax1, ay0, az0);
    const B2 = this.pt(ax1, ay1, az0), B3 = this.pt(ax0, ay1, az0);
    const T0 = this.pt(ax0, ay0, az1), T1 = this.pt(ax1, ay0, az1);
    const T2 = this.pt(ax1, ay1, az1), T3 = this.pt(ax0, ay1, az1);
    this.m.quad(B3, B2, B1, B0, col, a, mt);
    this.m.quad(T0, T1, T2, T3, col, a, mt);
    this.m.quad(B0, B1, T1, T0, col, a, mt);
    this.m.quad(B2, B3, T3, T2, col, a, mt);
    this.m.quad(B1, B2, T2, T1, col, a, mt);
    this.m.quad(B3, B0, T0, T3, col, a, mt);
  }

  /** Kenarları pahlı/yumuşatılmış mimari kutu (masa tablası, minder, tezgah, baza) */
  bevelBox(x0: number, y0: number, z0: number, x1: number, y1: number, z1: number, b: number, col: RGB, a = 1, mt = 0) {
    const ax0 = Math.min(x0, x1), ax1 = Math.max(x0, x1);
    const ay0 = Math.min(y0, y1), ay1 = Math.max(y0, y1);
    const az0 = Math.min(z0, z1), az1 = Math.max(z0, z1);
    const bx = Math.min(b, (ax1 - ax0) * 0.25, (ay1 - ay0) * 0.25);
    const bz = Math.min(b, (az1 - az0) * 0.28);
    if (bx < 0.002 || bz < 0.002) {
      this.box(ax0, ay0, az0, ax1, ay1, az1, col, a, mt);
      return;
    }
    // Alt tabaka, orta gövde ve üst pahlı taç
    const B0 = this.pt(ax0 + bx, ay0 + bx, az0), B1 = this.pt(ax1 - bx, ay0 + bx, az0);
    const B2 = this.pt(ax1 - bx, ay1 - bx, az0), B3 = this.pt(ax0 + bx, ay1 - bx, az0);

    const M0 = this.pt(ax0, ay0, az0 + bz), M1 = this.pt(ax1, ay0, az0 + bz);
    const M2 = this.pt(ax1, ay1, az0 + bz), M3 = this.pt(ax0, ay1, az0 + bz);

    const U0 = this.pt(ax0, ay0, az1 - bz), U1 = this.pt(ax1, ay0, az1 - bz);
    const U2 = this.pt(ax1, ay1, az1 - bz), U3 = this.pt(ax0, ay1, az1 - bz);

    const T0 = this.pt(ax0 + bx, ay0 + bx, az1), T1 = this.pt(ax1 - bx, ay0 + bx, az1);
    const T2 = this.pt(ax1 - bx, ay1 - bx, az1), T3 = this.pt(ax0 + bx, ay1 - bx, az1);

    // Alt & Üst
    this.m.quad(B3, B2, B1, B0, col, a, mt);
    this.m.quad(T0, T1, T2, T3, col, a, mt);
    // Alt pah
    this.m.quad(B0, B1, M1, M0, col, a, mt);
    this.m.quad(B1, B2, M2, M1, col, a, mt);
    this.m.quad(B2, B3, M3, M2, col, a, mt);
    this.m.quad(B3, B0, M0, M3, col, a, mt);
    // Dikey yanlar
    this.m.quad(M0, M1, U1, U0, col, a, mt);
    this.m.quad(M1, M2, U2, U1, col, a, mt);
    this.m.quad(M2, M3, U3, U2, col, a, mt);
    this.m.quad(M3, M0, U0, U3, col, a, mt);
    // Üst pah (yumuşak vertex normalli parlama yakalar!)
    const nU0 = this.nrm(-0.5, -0.5, 0.7), nU1 = this.nrm(0.5, -0.5, 0.7);
    const nU2 = this.nrm(0.5, 0.5, 0.7), nU3 = this.nrm(-0.5, 0.5, 0.7);
    const nTop = this.nrm(0, 0, 1);
    this.m.quadSmooth(U0, nU0, U1, nU1, T1, nTop, T0, nTop, col, a, mt);
    this.m.quadSmooth(U1, nU1, U2, nU2, T2, nTop, T1, nTop, col, a, mt);
    this.m.quadSmooth(U2, nU2, U3, nU3, T3, nTop, T2, nTop, col, a, mt);
    this.m.quadSmooth(U3, nU3, U0, nU0, T0, nTop, T3, nTop, col, a, mt);
  }

  /** Pürüzsüz vertex normalli silindir / koni */
  cyl(lx: number, ly: number, lz: number, r0: number, r1: number, h: number, seg: number, col: RGB, a = 1, mt = 0) {
    const bot = this.pt(lx, ly, lz);
    const top = this.pt(lx, ly, lz + h);
    const nBot = this.nrm(0, 0, -1);
    const nTop = this.nrm(0, 0, 1);
    const slopeZ = (r0 - r1) / (h || 1);
    const botRing: V3[] = [];
    const topRing: V3[] = [];
    const sideNrm: V3[] = [];
    for (let i = 0; i < seg; i++) {
      const ang = (i / seg) * Math.PI * 2;
      const ca = Math.cos(ang), sa = Math.sin(ang);
      botRing.push(this.pt(lx + ca * r0, ly + sa * r0, lz));
      topRing.push(this.pt(lx + ca * r1, ly + sa * r1, lz + h));
      sideNrm.push(this.nrm(ca, sa, slopeZ));
    }
    for (let i = 0; i < seg; i++) {
      const ni = (i + 1) % seg;
      this.m.quadSmooth(botRing[i], sideNrm[i], botRing[ni], sideNrm[ni], topRing[ni], sideNrm[ni], topRing[i], sideNrm[i], col, a, mt);
      if (r1 > 0.002) this.m.triSmooth(top, nTop, topRing[i], nTop, topRing[ni], nTop, col, a, mt);
      if (r0 > 0.002) this.m.triSmooth(bot, nBot, botRing[ni], nBot, botRing[i], nBot, col, a, mt);
    }
  }

  /** Torna / Lathe profili ([r, z] dizisini Z ekseninde pürüzsüz normallerle döndürür) */
  lathe(lx: number, ly: number, lz: number, prof: [number, number][], seg: number, col: RGB, a = 1, mt = 0) {
    if (prof.length < 2) return;
    const rings: V3[][] = [];
    const nrms: V3[][] = [];
    // Profil teğetlerinden pürüzsüz R-Z normalleri
    const rzN: [number, number][] = prof.map((_, i) => {
      const i0 = Math.max(0, i - 1);
      const i1 = Math.min(prof.length - 1, i + 1);
      const dr = prof[i1][0] - prof[i0][0];
      const dz = prof[i1][1] - prof[i0][1];
      const L = Math.hypot(dr, dz) || 1;
      return [dz / L, -dr / L];
    });
    for (let pi = 0; pi < prof.length; pi++) {
      const [rad, z] = prof[pi];
      const [nr, nz] = rzN[pi];
      const rowP: V3[] = [];
      const rowN: V3[] = [];
      for (let i = 0; i < seg; i++) {
        const ang = (i / seg) * Math.PI * 2;
        const ca = Math.cos(ang), sa = Math.sin(ang);
        rowP.push(this.pt(lx + ca * rad, ly + sa * rad, lz + z));
        rowN.push(this.nrm(ca * nr, sa * nr, nz));
      }
      rings.push(rowP);
      nrms.push(rowN);
    }
    for (let pi = 0; pi + 1 < prof.length; pi++) {
      for (let i = 0; i < seg; i++) {
        const ni = (i + 1) % seg;
        this.m.quadSmooth(
          rings[pi][i], nrms[pi][i],
          rings[pi][ni], nrms[pi][ni],
          rings[pi + 1][ni], nrms[pi + 1][ni],
          rings[pi + 1][i], nrms[pi + 1][i],
          col, a, mt,
        );
      }
    }
    if (prof[0][0] > 0.004) {
      const bot = this.pt(lx, ly, lz + prof[0][1]);
      const nb = this.nrm(0, 0, -1);
      for (let i = 0; i < seg; i++) {
        const ni = (i + 1) % seg;
        this.m.triSmooth(bot, nb, rings[0][ni], nb, rings[0][i], nb, col, a, mt);
      }
    }
    const last = prof.length - 1;
    if (prof[last][0] > 0.004) {
      const top = this.pt(lx, ly, lz + prof[last][1]);
      const nt = this.nrm(0, 0, 1);
      for (let i = 0; i < seg; i++) {
        const ni = (i + 1) % seg;
        this.m.triSmooth(top, nt, rings[last][i], nt, rings[last][ni], nt, col, a, mt);
      }
    }
  }

  /** Kavisli yol boyunca değişken yarıçaplı pürüzsüz boru/dal/batarya/kulp */
  tube(pts: V3[], r0: number, r1: number, seg: number, col: RGB, a = 1, mt = 0) {
    if (pts.length < 2) return;
    const rings: V3[][] = [];
    const nrms: V3[][] = [];
    let prevU: V3 = [1, 0, 0];

    for (let pi = 0; pi < pts.length; pi++) {
      const p = pts[pi];
      const pPrev = pts[Math.max(0, pi - 1)];
      const pNext = pts[Math.min(pts.length - 1, pi + 1)];
      let tx = pNext[0] - pPrev[0], ty = pNext[1] - pPrev[1], tz = pNext[2] - pPrev[2];
      const tl = Math.hypot(tx, ty, tz) || 1;
      tx /= tl; ty /= tl; tz /= tl;

      let up: V3 = pi === 0
        ? (Math.abs(tz) < 0.9 ? [0, 0, 1] : [1, 0, 0])
        : prevU;
      // Gram-Schmidt ile teğete dik normal düzlem
      const dot = up[0] * tx + up[1] * ty + up[2] * tz;
      let nx = up[0] - dot * tx, ny = up[1] - dot * ty, nz = up[2] - dot * tz;
      const nl = Math.hypot(nx, ny, nz) || 1;
      nx /= nl; ny /= nl; nz /= nl;
      prevU = [nx, ny, nz];

      const bx = ty * nz - tz * ny;
      const by = tz * nx - tx * nz;
      const bz = tx * ny - ty * nx;

      const rad = r0 + (r1 - r0) * (pi / (pts.length - 1));
      const rowP: V3[] = [];
      const rowN: V3[] = [];
      for (let i = 0; i < seg; i++) {
        const ang = (i / seg) * Math.PI * 2;
        const ca = Math.cos(ang), sa = Math.sin(ang);
        const dx = nx * ca + bx * sa;
        const dy = ny * ca + by * sa;
        const dz = nz * ca + bz * sa;
        rowP.push(this.pt(p[0] + dx * rad, p[1] + dy * rad, p[2] + dz * rad));
        rowN.push(this.nrm(dx, dy, dz));
      }
      rings.push(rowP);
      nrms.push(rowN);
    }

    for (let pi = 0; pi + 1 < rings.length; pi++) {
      for (let i = 0; i < seg; i++) {
        const ni = (i + 1) % seg;
        this.m.quadSmooth(
          rings[pi][i], nrms[pi][i],
          rings[pi][ni], nrms[pi][ni],
          rings[pi + 1][ni], nrms[pi + 1][ni],
          rings[pi + 1][i], nrms[pi + 1][i],
          col, a, mt,
        );
      }
    }
    // Kapaklar
    const c0 = this.pt(pts[0][0], pts[0][1], pts[0][2]);
    const t0: V3 = [pts[0][0] - pts[1][0], pts[0][1] - pts[1][1], pts[0][2] - pts[1][2]];
    const n0 = this.nrm(t0[0], t0[1], t0[2]);
    const last = pts.length - 1;
    const c1 = this.pt(pts[last][0], pts[last][1], pts[last][2]);
    const t1: V3 = [pts[last][0] - pts[last - 1][0], pts[last][1] - pts[last - 1][1], pts[last][2] - pts[last - 1][2]];
    const n1 = this.nrm(t1[0], t1[1], t1[2]);
    for (let i = 0; i < seg; i++) {
      const ni = (i + 1) % seg;
      this.m.triSmooth(c0, n0, rings[0][ni], n0, rings[0][i], n0, col, a, mt);
      this.m.triSmooth(c1, n1, rings[last][i], n1, rings[last][ni], n1, col, a, mt);
    }
  }

  cylX(lx1: number, ly1: number, lz1: number, lx2: number, ly2: number, lz2: number, r: number, col: RGB, mt = 0, rEnd?: number) {
    this.tube([[lx1, ly1, lz1], [lx2, ly2, lz2]], r, rEnd ?? r, 10, col, 1, mt);
  }

  /** Çok kollu alaşım jantlı, fren diskli & kaliperli tekerlek */
  wheel(lx: number, ly: number, lz: number, rad: number, gen: number, seg: number, tireCol: RGB, rimCol: RGB) {
    const hw = gen / 2;
    const rr = rad * 0.64;
    const sideSign = lx < 0 ? -1 : 1;
    const outX = lx + sideSign * hw;
    const inX = lx - sideSign * hw;
    const L0 = this.pt(inX, ly, lz);
    const R0 = this.pt(outX + sideSign * 0.008, ly, lz);
    const nOut = this.nrm(sideSign, 0, 0);
    const nIn = this.nrm(-sideSign, 0, 0);

    const inRing: V3[] = [];
    const outRing: V3[] = [];
    const rimRing: V3[] = [];
    const treadNrm: V3[] = [];

    for (let i = 0; i < seg; i++) {
      const ang = (i / seg) * Math.PI * 2;
      const ca = Math.cos(ang), sa = Math.sin(ang);
      inRing.push(this.pt(inX, ly + ca * rad, lz + sa * rad));
      outRing.push(this.pt(outX, ly + ca * rad, lz + sa * rad));
      rimRing.push(this.pt(outX + sideSign * 0.006, ly + ca * rr, lz + sa * rr));
      treadNrm.push(this.nrm(0, ca, sa));
    }

    for (let i = 0; i < seg; i++) {
      const ni = (i + 1) % seg;
      this.m.quadSmooth(inRing[i], treadNrm[i], outRing[i], treadNrm[i], outRing[ni], treadNrm[ni], inRing[ni], treadNrm[ni], tireCol, 1, MT_MAT);
      this.m.triSmooth(L0, nIn, inRing[ni], nIn, inRing[i], nIn, tireCol, 1, MT_MAT);
      this.m.triSmooth(R0, nOut, outRing[i], nOut, outRing[ni], nOut, tireCol, 1, MT_MAT);
      // Koyu fren diski iç çemberi
      this.m.triSmooth(R0, nOut, rimRing[i], nOut, rimRing[ni], nOut, [0.16, 0.17, 0.2], 1, MT_MAT);
    }

    // 5 çift alaşım jant kolu + göbek kapağı
    for (let s = 0; s < 5; s++) {
      const ang = (s / 5) * Math.PI * 2;
      const ca = Math.cos(ang), sa = Math.sin(ang);
      const sx = outX + sideSign * 0.012;
      this.tube([[sx, ly, lz], [sx, ly + ca * rr * 0.94, lz + sa * rr * 0.94]], 0.022, 0.014, 6, rimCol, 1, MT_KROM);
    }
    this.cylX(outX, ly, lz, outX + sideSign * 0.022, ly, lz, rad * 0.16, rimCol, MT_KROM);
  }

  /** Ön yüze bakan dairesel disk (Y+ yüzeyinde çamaşır tamburu / kontrol kadranı) */
  discY(lx: number, ly: number, lz: number, rad: number, depth: number, seg: number, col: RGB, a = 1, mt = 0) {
    const cF = this.pt(lx, ly + depth, lz);
    const nF = this.nrm(0, 1, 0);
    const ring0: V3[] = [];
    const ring1: V3[] = [];
    const nSide: V3[] = [];
    for (let i = 0; i < seg; i++) {
      const ang = (i / seg) * Math.PI * 2;
      const ca = Math.cos(ang), sa = Math.sin(ang);
      ring0.push(this.pt(lx + ca * rad, ly, lz + sa * rad));
      ring1.push(this.pt(lx + ca * rad * 0.92, ly + depth, lz + sa * rad * 0.92));
      nSide.push(this.nrm(ca, 0.4, sa));
    }
    for (let i = 0; i < seg; i++) {
      const ni = (i + 1) % seg;
      this.m.quadSmooth(ring0[i], nSide[i], ring0[ni], nSide[ni], ring1[ni], nSide[ni], ring1[i], nSide[i], col, a, mt);
      this.m.triSmooth(cF, nF, ring1[i], nF, ring1[ni], nF, col, a, mt);
    }
  }

  /** Pürüzsüz normalli eliptik kubbe / yaprak / meyve */
  dome(lx: number, ly: number, lz: number, rx: number, ry: number, rz: number, lat: number, lon: number, col: RGB, a = 1, full = false, mt = 0) {
    const rings: V3[][] = [];
    const nrms: V3[][] = [];
    const startTheta = full ? -Math.PI / 2 : 0;
    for (let la = 0; la <= lat; la++) {
      const theta = startTheta + (la / lat) * (full ? Math.PI : Math.PI / 2);
      const ct = Math.cos(theta), st = Math.sin(theta);
      const rowP: V3[] = [];
      const rowN: V3[] = [];
      for (let lo = 0; lo < lon; lo++) {
        const phi = (lo / lon) * Math.PI * 2;
        const cp = Math.cos(phi), sp = Math.sin(phi);
        rowP.push(this.pt(lx + rx * ct * cp, ly + ry * ct * sp, lz + rz * st));
        rowN.push(this.nrm((ct * cp) / (rx || 1), (ct * sp) / (ry || 1), st / (rz || 1)));
      }
      rings.push(rowP);
      nrms.push(rowN);
    }
    for (let la = 0; la < lat; la++) {
      for (let lo = 0; lo < lon; lo++) {
        const nlo = (lo + 1) % lon;
        this.m.quadSmooth(
          rings[la][lo], nrms[la][lo],
          rings[la][nlo], nrms[la][nlo],
          rings[la + 1][nlo], nrms[la + 1][nlo],
          rings[la + 1][lo], nrms[la + 1][lo],
          col, a, mt,
        );
      }
    }
    if (!full) {
      const botC = this.pt(lx, ly, lz);
      const nBot = this.nrm(0, 0, -1);
      for (let lo = 0; lo < lon; lo++) {
        const nlo = (lo + 1) % lon;
        this.m.triSmooth(botC, nBot, rings[0][nlo], nBot, rings[0][lo], nBot, col, a, mt);
      }
    }
  }

  /** Kabarık, köşeleri sıkıştırılmış süperelipsoid minder & yastık (pürüzsüz normalli) */
  cushion(lx: number, ly: number, lz: number, rx: number, ry: number, rz: number, col: RGB, tiltX = 0, mt = MT_KUMAS) {
    const lat = 6, lon = 14;
    const cs = Math.cos(tiltX), sn = Math.sin(tiltX);
    const rings: V3[][] = [];
    const nrms: V3[][] = [];
    const sgnPow = (v: number, p: number) => Math.sign(v) * Math.pow(Math.abs(v), p);

    for (let la = 0; la <= lat; la++) {
      const u = -Math.PI / 2 + (la / lat) * Math.PI;
      const cu = Math.cos(u), su = Math.sin(u);
      const rowP: V3[] = [];
      const rowN: V3[] = [];
      for (let lo = 0; lo < lon; lo++) {
        const v = (lo / lon) * Math.PI * 2;
        const cv = Math.cos(v), sv = Math.sin(v);
        // Süperelipsoid exponent e1=0.68, e2=0.68 -> dolgun yumuşak köşeli form
        const px0 = rx * sgnPow(cu, 0.72) * sgnPow(cv, 0.72);
        const py0 = ry * sgnPow(cu, 0.72) * sgnPow(sv, 0.72);
        const pz0 = rz * sgnPow(su, 0.78);
        // Eğim (yaslanma yastığı için Y-Z düzleminde döndür)
        const py = py0 * cs - pz0 * sn;
        const pz = py0 * sn + pz0 * cs;
        rowP.push(this.pt(lx + px0, ly + py, lz + pz));

        const nx0 = (cu * cv) / (rx || 1);
        const ny0 = (cu * sv) / (ry || 1);
        const nz0 = su / (rz || 1);
        rowN.push(this.nrm(nx0, ny0 * cs - nz0 * sn, ny0 * sn + nz0 * cs));
      }
      rings.push(rowP);
      nrms.push(rowN);
    }
    for (let la = 0; la < lat; la++) {
      for (let lo = 0; lo < lon; lo++) {
        const nlo = (lo + 1) % lon;
        this.m.quadSmooth(
          rings[la][lo], nrms[la][lo],
          rings[la][nlo], nrms[la][nlo],
          rings[la + 1][nlo], nrms[la + 1][nlo],
          rings[la + 1][lo], nrms[la + 1][lo],
          col, 1, mt,
        );
      }
    }
  }

  /** Yan profil prizması (opsiyonel pürüzsüz üst/ön normal yumuşatmalı) */
  prismSide(prof: [number, number][], lx0: number, lx1: number, col: RGB, a = 1, mt = 0, smooth = false) {
    if (prof.length < 3) return;
    const Lpts = prof.map(([y, z]) => this.pt(lx0, y, z));
    const Rpts = prof.map(([y, z]) => this.pt(lx1, y, z));
    if (smooth) {
      const vNrm: V3[] = prof.map((_, i) => {
        const i0 = (i - 1 + prof.length) % prof.length;
        const i1 = (i + 1) % prof.length;
        const dy = prof[i1][0] - prof[i0][0];
        const dz = prof[i1][1] - prof[i0][1];
        return this.nrm(0, dz, -dy);
      });
      for (let i = 0; i < prof.length; i++) {
        const ni = (i + 1) % prof.length;
        this.m.quadSmooth(Lpts[i], vNrm[i], Lpts[ni], vNrm[ni], Rpts[ni], vNrm[ni], Rpts[i], vNrm[i], col, a, mt);
      }
    } else {
      for (let i = 0; i < prof.length; i++) {
        const ni = (i + 1) % prof.length;
        this.m.quad(Lpts[i], Lpts[ni], Rpts[ni], Rpts[i], col, a, mt);
      }
    }
    for (let i = 1; i + 1 < prof.length; i++) {
      this.m.tri(Lpts[0], Lpts[i + 1], Lpts[i], col, a, mt);
      this.m.tri(Rpts[0], Rpts[i], Rpts[i + 1], col, a, mt);
    }
  }

  finishHit() {
    if (this.hit && isFinite(this.minB[0])) {
      this.m.pushHitBox(this.hit, this.minB, this.maxB);
    }
  }
}

export function mobilya3DEkle(
  m: MeshHedef,
  o: Mobilya,
  y0: number,
  hit?: HitSpec,
) {
  const T = MOB[o.tip];
  if (!T) return;
  const { w, d } = mobOlcu(o);
  const sx = w / (T.w || 1);
  const sy = d / (T.d || 1);
  const L = new L3D(m, o.x, y0, o.y, sx, sy, o.r || 0, hit);

  switch (o.tip) {
    case 'yatak2': {
      // Tornalanmış pirinç yüksüklü ceviz ayaklar
      for (const [ax, ay] of [[-0.73, -0.94], [0.73, -0.94], [-0.73, 0.94], [0.73, 0.94]]) {
        L.cyl(ax, ay, 0, 0.014, 0.018, 0.04, 12, C_PIRINC, 1, MT_PIRINC);
        L.cyl(ax, ay, 0.04, 0.018, 0.032, 0.11, 12, C_CEVIZ, 1, MT_AHSAP);
      }
      // Pahlı yüzen ceviz karyola kasası
      L.bevelBox(-0.81, -1.01, 0.15, 0.81, 1.02, 0.34, 0.025, C_MESE, 1, MT_AHSAP);
      // Kanatlı ceviz çerçeve + 12 dikey yivli kapitone kumaş başlık + arka gizli sıcak LED şerit
      L.bevelBox(-0.86, -1.03, 0.15, 0.86, -0.95, 1.14, 0.02, C_CEVIZ, 1, MT_AHSAP);
      L.box(-0.84, -1.045, 0.45, 0.84, -1.025, 1.11, C_ISIK, 1, MT_ISIK);
      for (let i = 0; i < 12; i++) {
        const px = -0.75 + i * 0.136;
        L.cyl(px, -0.93, 0.48, 0.062, 0.062, 0.61, 12, C_KUMA_BEJ, 1, MT_KUMAS);
      }
      // Ortopedik pahlı şilte + çarşaf fitili
      L.bevelBox(-0.77, -0.88, 0.34, 0.77, 0.97, 0.56, 0.035, C_BEYAZ, 1, MT_KUMAS);
      // Yorgan + yanlara kıvrılan dokuma şal örtü
      L.bevelBox(-0.785, -0.26, 0.36, 0.785, 0.985, 0.60, 0.045, C_YATAK_ORTU, 1, MT_KUMAS);
      L.bevelBox(-0.80, 0.42, 0.32, 0.80, 0.995, 0.62, 0.03, C_KUMA_KOYU, 1, MT_KUMAS);
      L.box(-0.82, 0.46, 0.24, -0.78, 0.94, 0.58, C_KUMA_KOYU, 1, MT_KUMAS);
      L.box(0.78, 0.46, 0.24, 0.82, 0.94, 0.58, C_KUMA_KOYU, 1, MT_KUMAS);
      // 6 adet kabarık süperelipsoid yastık (büyük yastıklar + eğimli kırlentler + rulo bel yastığı)
      L.cushion(-0.39, -0.74, 0.66, 0.33, 0.14, 0.14, C_SERAMIK, 0.85);
      L.cushion(0.39, -0.74, 0.66, 0.33, 0.14, 0.14, C_SERAMIK, 0.85);
      L.cushion(-0.39, -0.57, 0.61, 0.28, 0.14, 0.10, C_YASTIK_TEAL, 0.45);
      L.cushion(0.39, -0.57, 0.61, 0.28, 0.14, 0.10, C_YASTIK_TEAL, 0.45);
      L.cushion(0, -0.43, 0.63, 0.26, 0.10, 0.09, C_YASTIK_HARDAL, 0.25);
      // Yatak üstünde ahşap kahve tepsisi + fincan
      L.bevelBox(-0.18, 0.02, 0.60, 0.22, 0.32, 0.63, 0.008, C_CEVIZ, 1, MT_AHSAP);
      L.lathe(-0.02, 0.16, 0.63, [[0.03, 0], [0.042, 0.05], [0.04, 0.085], [0.035, 0.085], [0.028, 0.006]], 14, C_SERAMIK, 1, MT_SERAMIK);
      break;
    }

    case 'yatak1': {
      for (const [ax, ay] of [[-0.41, -0.92], [0.41, -0.92], [-0.41, 0.92], [0.41, 0.92]]) {
        L.cyl(ax, ay, 0, 0.013, 0.017, 0.04, 12, C_PIRINC, 1, MT_PIRINC);
        L.cyl(ax, ay, 0.04, 0.017, 0.030, 0.10, 12, C_CEVIZ, 1, MT_AHSAP);
      }
      L.bevelBox(-0.47, -0.98, 0.14, 0.47, 1.0, 0.32, 0.025, C_MESE, 1, MT_AHSAP);
      L.bevelBox(-0.49, -1.01, 0.14, 0.49, -0.93, 1.0, 0.02, C_CEVIZ, 1, MT_AHSAP);
      for (let i = 0; i < 6; i++) {
        L.cyl(-0.37 + i * 0.148, -0.91, 0.44, 0.065, 0.065, 0.51, 12, C_KUMA_BEJ, 1, MT_KUMAS);
      }
      L.bevelBox(-0.44, -0.86, 0.32, 0.44, 0.96, 0.51, 0.03, C_BEYAZ, 1, MT_KUMAS);
      L.bevelBox(-0.455, -0.22, 0.34, 0.455, 0.97, 0.55, 0.04, C_YATAK_ORTU, 1, MT_KUMAS);
      L.bevelBox(-0.465, 0.45, 0.32, 0.465, 0.98, 0.565, 0.025, C_YASTIK_TEAL, 1, MT_KUMAS);
      L.cushion(0, -0.71, 0.62, 0.32, 0.13, 0.13, C_SERAMIK, 0.85);
      L.cushion(0, -0.51, 0.57, 0.24, 0.11, 0.09, C_YASTIK_HARDAL, 0.35);
      break;
    }

    case 'gardirop': {
      const hw = T.w / 2;
      L.box(-hw + 0.02, -0.28, 0, hw - 0.02, 0.23, 0.08, C_CEVIZ, 1, MT_AHSAP);
      L.bevelBox(-hw, -0.3, 0.08, hw, 0.25, 2.16, 0.015, C_MESE, 1, MT_AHSAP);
      L.bevelBox(-hw - 0.015, -0.31, 2.16, hw + 0.015, 0.295, 2.23, 0.018, C_CEVIZ, 1, MT_AHSAP);
      const nK = 4;
      const kw = (T.w - 0.03) / nK;
      for (let i = 0; i < nK; i++) {
        const x0 = -hw + 0.015 + i * kw + 0.006;
        const x1 = x0 + kw - 0.012;
        if (i === 1 || i === 2) {
          // Orta iki kapak çerçeveli reflekte füme cam vitrin + iç ahşap raflar görünür!
          L.box(x0, 0.245, 0.10, x0 + 0.045, 0.275, 2.14, C_CEVIZ, 1, MT_AHSAP);
          L.box(x1 - 0.045, 0.245, 0.10, x1, 0.275, 2.14, C_CEVIZ, 1, MT_AHSAP);
          L.box(x0 + 0.045, 0.245, 0.10, x1 - 0.045, 0.275, 0.16, C_CEVIZ, 1, MT_AHSAP);
          L.box(x0 + 0.045, 0.245, 2.08, x1 - 0.045, 0.275, 2.14, C_CEVIZ, 1, MT_AHSAP);
          L.box(x0 + 0.045, 0.258, 0.16, x1 - 0.045, 0.268, 2.08, [0.35, 0.42, 0.48], 0.48);
        } else {
          // Shaker çerçeveli mat krem kapak + iç göbek paneli
          L.bevelBox(x0, 0.25, 0.10, x1, 0.28, 2.14, 0.008, C_KREM, 1, MT_SERAMIK);
          L.box(x0 + 0.045, 0.274, 0.16, x1 - 0.045, 0.286, 2.08, C_BEYAZ, 1, MT_SERAMIK);
        }
        const hx = i % 2 === 0 ? x1 - 0.055 : x0 + 0.055;
        L.tube([[hx, 0.28, 0.78], [hx, 0.31, 0.80], [hx, 0.31, 1.38], [hx, 0.28, 1.40]], 0.008, 0.008, 8, C_PIRINC, 1, MT_PIRINC);
      }
      break;
    }

    case 'komodin': {
      for (const [ax, ay] of [[-0.21, -0.16], [0.21, -0.16], [-0.21, 0.16], [0.21, 0.16]]) {
        L.cyl(ax, ay, 0, 0.011, 0.014, 0.03, 10, C_PIRINC, 1, MT_PIRINC);
        L.cyl(ax, ay, 0.03, 0.014, 0.022, 0.10, 10, C_CEVIZ, 1, MT_AHSAP);
      }
      L.bevelBox(-0.25, -0.2, 0.13, 0.25, 0.18, 0.50, 0.015, C_MESE, 1, MT_AHSAP);
      L.bevelBox(-0.265, -0.21, 0.50, 0.265, 0.20, 0.535, 0.012, C_CEVIZ, 1, MT_AHSAP);
      for (const [z0, z1] of [[0.15, 0.31], [0.33, 0.48]]) {
        L.bevelBox(-0.225, 0.18, z0, 0.225, 0.202, z1, 0.006, C_ACIK_AH, 1, MT_AHSAP);
        L.tube([[-0.06, 0.20, (z0 + z1) / 2], [-0.06, 0.225, (z0 + z1) / 2], [0.06, 0.225, (z0 + z1) / 2], [0.06, 0.20, (z0 + z1) / 2]], 0.006, 0.006, 8, C_PIRINC, 1, MT_PIRINC);
      }
      // Torna seramik gövdeli + piliseli abajurlu başucu lambası + açık kitap
      L.lathe(-0.08, -0.04, 0.535, [[0.055, 0], [0.072, 0.04], [0.078, 0.09], [0.042, 0.15], [0.025, 0.19], [0.01, 0.20]], 18, C_SERAMIK, 1, MT_SERAMIK);
      L.cyl(-0.08, -0.04, 0.72, 0.008, 0.008, 0.07, 8, C_PIRINC, 1, MT_PIRINC);
      L.lathe(-0.08, -0.04, 0.75, [[0.135, 0], [0.125, 0.06], [0.092, 0.17]], 18, C_ISIK, 0.94, MT_ISIK);
      L.bevelBox(0.06, -0.06, 0.535, 0.22, 0.14, 0.562, 0.004, C_YASTIK_TEAL);
      break;
    }

    case 'calisma': {
      const hw = T.w / 2;
      // Açılı A-form çelik ayaklar + yatay travers
      L.cylX(-hw + 0.04, -0.24, 0, -hw + 0.09, -0.18, 0.72, 0.018, C_ANTRASIT, MT_KROM);
      L.cylX(-hw + 0.04, 0.24, 0, -hw + 0.09, 0.18, 0.72, 0.018, C_ANTRASIT, MT_KROM);
      L.cylX(-hw + 0.06, -0.21, 0.22, -hw + 0.06, 0.21, 0.22, 0.012, C_ANTRASIT, MT_KROM);
      // Sağ ceviz çekmece ünitesi
      L.bevelBox(hw - 0.39, -0.26, 0.06, hw - 0.03, 0.26, 0.72, 0.012, C_CEVIZ, 1, MT_AHSAP);
      for (const [z0, z1] of [[0.09, 0.28], [0.30, 0.49], [0.51, 0.70]]) {
        L.bevelBox(hw - 0.37, 0.255, z0, hw - 0.05, 0.275, z1, 0.005, C_ANTRASIT, 1, MT_MAT);
        L.box(hw - 0.26, 0.275, z1 - 0.03, hw - 0.16, 0.285, z1 - 0.01, C_PIRINC, 1, MT_PIRINC);
      }
      // Pahlı masif meşe tabla + deri sümen altlık
      L.bevelBox(-hw, -0.3, 0.72, hw, 0.3, 0.765, 0.014, C_MESE, 1, MT_AHSAP);
      L.bevelBox(-0.34, -0.06, 0.765, 0.26, 0.26, 0.772, 0.003, [0.22, 0.20, 0.19], 1, MT_MAT);
      // Kavisli alüminyum ayak + Ultrawide monitör (parlak ekranlı)
      L.bevelBox(-0.18, -0.18, 0.765, 0.08, -0.06, 0.78, 0.004, C_PASLANMAZ, 1, MT_KROM);
      L.cylX(-0.05, -0.14, 0.78, -0.05, -0.17, 0.97, 0.018, C_PASLANMAZ, MT_KROM);
      L.bevelBox(-0.38, -0.15, 0.85, 0.28, -0.125, 1.18, 0.008, C_SIYAH, 1, MT_MAT);
      L.box(-0.365, -0.124, 0.865, 0.265, -0.12, 1.165, C_EKRAN, 1, MT_ISIK);
      // Klavye + kablosuz mouse + kupa
      L.bevelBox(-0.24, 0.03, 0.772, 0.08, 0.16, 0.786, 0.003, C_ANTRASIT);
      L.dome(0.16, 0.10, 0.772, 0.032, 0.052, 0.022, 4, 12, C_SIYAH);
      L.lathe(0.28, -0.08, 0.765, [[0.035, 0], [0.042, 0.08], [0.038, 0.095], [0.030, 0.01]], 14, C_YASTIK_TEAL, 1, MT_SERAMIK);
      // Mafsallı pirinç mimar lambası (kavisli boyun)
      L.cyl(-hw + 0.17, -0.15, 0.765, 0.075, 0.068, 0.022, 16, C_SIYAH, 1, MT_MAT);
      L.tube([[-hw + 0.17, -0.15, 0.785], [-hw + 0.21, -0.16, 0.96], [-hw + 0.23, -0.10, 1.11], [-hw + 0.12, 0.0, 1.14]], 0.009, 0.007, 10, C_PIRINC, 1, MT_PIRINC);
      L.lathe(-hw + 0.10, 0.02, 1.07, [[0.072, 0], [0.058, 0.04], [0.022, 0.08]], 16, C_SIYAH, 1, MT_MAT);
      L.dome(-hw + 0.10, 0.02, 1.07, 0.035, 0.035, 0.025, 3, 10, C_ISIK, 1, true, MT_ISIK);
      break;
    }

    case 'kanepe': {
      for (const [ax, ay] of [[-0.99, -0.36], [0.99, -0.36], [-0.99, 0.36], [0.99, 0.36]]) {
        L.cyl(ax, ay, 0, 0.013, 0.016, 0.035, 10, C_PIRINC, 1, MT_PIRINC);
        L.cyl(ax, ay, 0.035, 0.016, 0.030, 0.105, 10, C_CEVIZ, 1, MT_AHSAP);
      }
      // Ceviz kaide
      L.bevelBox(-1.08, -0.44, 0.14, 1.08, 0.44, 0.24, 0.02, C_MESE, 1, MT_AHSAP);
      // Kavisli kolçaklar
      L.bevelBox(-1.11, -0.44, 0.24, -0.92, 0.44, 0.62, 0.035, C_KUMA_KOYU, 1, MT_KUMAS);
      L.bevelBox(0.92, -0.44, 0.24, 1.11, 0.44, 0.62, 0.035, C_KUMA_KOYU, 1, MT_KUMAS);
      L.cylX(-1.015, -0.40, 0.61, -1.015, 0.40, 0.61, 0.088, C_KUMA_KOYU, MT_KUMAS);
      L.cylX(1.015, -0.40, 0.61, 1.015, 0.40, 0.61, 0.088, C_KUMA_KOYU, MT_KUMAS);
      // Açılı arka sırt iskeleti
      L.prismSide([[-0.44, 0.24], [-0.28, 0.24], [-0.34, 0.78], [-0.47, 0.76]], -0.94, 0.94, C_KUMA_KOYU, 1, MT_KUMAS, true);
      // 3 adet süperelipsoid oturma minderi + 3 adet sırt yastığı
      for (let i = 0; i < 3; i++) {
        const cx = -0.61 + i * 0.61;
        L.cushion(cx, 0.10, 0.34, 0.30, 0.35, 0.105, C_KUMA, 0);
        L.cushion(cx, -0.22, 0.61, 0.295, 0.12, 0.22, C_KUMA, 0.22);
      }
      // Kırlentler + sol kol üzerine atılmış örgü battaniye
      L.cushion(-0.77, -0.02, 0.56, 0.16, 0.08, 0.17, C_YASTIK_HARDAL, 0.32);
      L.cushion(0.77, -0.02, 0.56, 0.16, 0.08, 0.17, C_YASTIK_TEAL, 0.32);
      L.cushion(-0.56, -0.06, 0.52, 0.12, 0.065, 0.12, C_YASTIK_TER, 0.25);
      L.bevelBox(-1.13, -0.08, 0.36, -0.90, 0.32, 0.70, 0.025, C_KUMA_BEJ, 1, MT_KUMAS);
      break;
    }

    case 'kose': {
      for (const [ax, ay] of [[-1.3, -0.92], [0, -0.92], [1.3, -0.92], [-1.3, -0.16], [0.56, 0.92], [1.3, 0.92]]) {
        L.cyl(ax, ay, 0, 0.013, 0.016, 0.035, 10, C_PIRINC, 1, MT_PIRINC);
        L.cyl(ax, ay, 0.035, 0.016, 0.030, 0.10, 10, C_CEVIZ, 1, MT_AHSAP);
      }
      L.bevelBox(-1.38, -0.98, 0.135, 1.38, -0.1, 0.24, 0.02, C_MESE, 1, MT_AHSAP);
      L.bevelBox(0.50, -0.10, 0.135, 1.38, 0.98, 0.24, 0.02, C_MESE, 1, MT_AHSAP);
      L.bevelBox(-1.41, -1.0, 0.24, -1.22, -0.08, 0.63, 0.035, C_KUMA_KOYU, 1, MT_KUMAS);
      L.prismSide([[-1.0, 0.24], [-0.80, 0.24], [-0.86, 0.79], [-1.03, 0.77]], -1.38, 1.38, C_KUMA_KOYU, 1, MT_KUMAS, true);
      L.bevelBox(1.19, -0.80, 0.24, 1.40, 1.00, 0.79, 0.035, C_KUMA_KOYU, 1, MT_KUMAS);
      // Oturma ve sırt minderleri (süperelipsoid)
      for (let i = 0; i < 3; i++) {
        const cx = -0.83 + i * 0.78;
        L.cushion(cx, -0.43, 0.34, 0.385, 0.35, 0.105, C_KUMA, 0);
        L.cushion(cx, -0.74, 0.62, 0.37, 0.12, 0.22, C_KUMA, 0.22);
      }
      // Sağ uzanma chaise minderi
      L.cushion(0.84, 0.45, 0.34, 0.345, 0.54, 0.105, C_KUMA, 0);
      L.cushion(1.12, 0.12, 0.62, 0.11, 0.80, 0.21, C_KUMA, 0);
      // Kırlentler
      L.cushion(-1.02, -0.56, 0.57, 0.17, 0.08, 0.18, C_YASTIK_TEAL, 0.35);
      L.cushion(0.92, -0.56, 0.57, 0.17, 0.08, 0.18, C_YASTIK_HARDAL, 0.35);
      L.cushion(0.96, 0.36, 0.57, 0.09, 0.17, 0.18, C_YASTIK_TER, 0);
      break;
    }

    case 'koltuk': {
      // İskandinav kavisli masif meşe iskelet & açılı ayaklar
      for (const [bx, by, tx, ty] of [
        [-0.36, -0.36, -0.31, -0.30],
        [0.36, -0.36, 0.31, -0.30],
        [-0.36, 0.36, -0.31, 0.30],
        [0.36, 0.36, 0.31, 0.30],
      ]) {
        L.cylX(bx, by, 0, tx, ty, 0.20, 0.020, C_CEVIZ, MT_AHSAP, 0.028);
      }
      L.bevelBox(-0.39, -0.39, 0.17, 0.39, 0.39, 0.25, 0.018, C_MESE, 1, MT_AHSAP);
      // Kolçaklar (kavisli ahşap kolçak + yan kayıt)
      L.tube([[-0.35, -0.31, 0.25], [-0.36, -0.32, 0.58], [-0.36, 0.0, 0.62], [-0.35, 0.30, 0.58], [-0.35, 0.30, 0.25]], 0.026, 0.024, 12, C_CEVIZ, 1, MT_AHSAP);
      L.tube([[0.35, -0.31, 0.25], [0.36, -0.32, 0.58], [0.36, 0.0, 0.62], [0.35, 0.30, 0.58], [0.35, 0.30, 0.25]], 0.026, 0.024, 12, C_CEVIZ, 1, MT_AHSAP);
      // Plush minder + açılı sırt + bel yastığı
      L.cushion(0, 0.04, 0.35, 0.31, 0.34, 0.11, C_KUMA, 0);
      L.cushion(0, -0.25, 0.62, 0.31, 0.12, 0.25, C_KUMA_KOYU, 0.25);
      L.cushion(0, -0.09, 0.52, 0.20, 0.075, 0.13, C_YASTIK_HARDAL, 0.3);
      break;
    }

    case 'sehpa': {
      // Dikey çıtalı silindirik meşe kaide ayakları + füme cam / mermer pahlı tabla
      for (const cx of [-0.30, 0.30]) {
        const nSl = 12;
        for (let i = 0; i < nSl; i++) {
          const ang = (i / nSl) * Math.PI * 2;
          L.cyl(cx + Math.cos(ang) * 0.17, Math.sin(ang) * 0.17, 0, 0.014, 0.014, 0.38, 8, C_CEVIZ, 1, MT_AHSAP);
        }
        L.cyl(cx, 0, 0.36, 0.19, 0.19, 0.025, 20, C_CEVIZ, 1, MT_AHSAP);
      }
      // Oval uçlu / pahlı mermer tabla
      L.bevelBox(-0.56, -0.31, 0.385, 0.56, 0.31, 0.435, 0.022, C_MERMER, 1, MT_MERMER);
      // Torna seramik vazo + yapraklı dal + sanat kitabı + espresso fincanı
      L.lathe(-0.24, -0.06, 0.435, [[0.045, 0], [0.075, 0.07], [0.072, 0.14], [0.032, 0.20], [0.042, 0.23]], 18, C_YASTIK_TEAL, 1, MT_SERAMIK);
      L.tube([[-0.24, -0.06, 0.64], [-0.21, -0.04, 0.78], [-0.18, -0.01, 0.87]], 0.005, 0.003, 6, C_CEVIZ, 1, MT_AHSAP);
      L.dome(-0.18, -0.01, 0.87, 0.045, 0.03, 0.02, 3, 8, C_YAPRAK2, 1, true);
      L.bevelBox(0.05, -0.14, 0.435, 0.34, 0.14, 0.47, 0.006, C_KREM);
      L.bevelBox(0.08, -0.11, 0.47, 0.31, 0.11, 0.495, 0.005, C_YASTIK_TER);
      L.lathe(0.19, 0.0, 0.495, [[0.030, 0], [0.040, 0.04], [0.038, 0.065]], 14, C_SERAMIK, 1, MT_SERAMIK);
      break;
    }

    case 'tv': {
      for (const [ax, ay] of [[-0.82, -0.17], [0.82, -0.17], [-0.82, 0.17], [0.82, 0.17]]) {
        L.cyl(ax, ay, 0, 0.012, 0.015, 0.04, 10, C_PIRINC, 1, MT_PIRINC);
        L.cyl(ax, ay, 0.04, 0.015, 0.025, 0.11, 10, C_CEVIZ, 1, MT_AHSAP);
      }
      // Ana ceviz konsol + beyaz mermer üst tabla + dikey akustik çıtalı kapaklar
      L.bevelBox(-0.90, -0.22, 0.15, 0.90, 0.21, 0.48, 0.015, C_CEVIZ, 1, MT_AHSAP);
      L.bevelBox(-0.91, -0.225, 0.48, 0.91, 0.225, 0.515, 0.012, C_MERMER, 1, MT_MERMER);
      for (let i = 0; i < 16; i++) {
        const sx0 = -0.87 + i * 0.036;
        L.box(sx0, 0.21, 0.17, sx0 + 0.020, 0.228, 0.46, C_MESE, 1, MT_AHSAP);
        const rx0 = 0.33 + i * 0.036;
        L.box(rx0, 0.21, 0.17, rx0 + 0.020, 0.228, 0.46, C_MESE, 1, MT_AHSAP);
      }
      // Orta açık raf + amplifikatör + kitaplar
      L.box(-0.28, -0.02, 0.18, 0.28, 0.21, 0.45, C_SIYAH, 1, MT_MAT);
      L.box(-0.24, 0.02, 0.19, 0.24, 0.22, 0.29, C_ANTRASIT, 1, MT_KROM);
      L.box(-0.24, 0.02, 0.31, 0.24, 0.215, 0.33, C_MESE, 1, MT_AHSAP);
      // Soundbar + Vazo
      L.bevelBox(-0.44, 0.09, 0.515, 0.44, 0.18, 0.575, 0.01, C_SIYAH, 1, MT_MAT);
      L.lathe(-0.74, 0.04, 0.515, [[0.04, 0], [0.065, 0.06], [0.055, 0.13], [0.025, 0.18]], 14, C_SERAMIK, 1, MT_SERAMIK);
      // Ultra ince OLED TV + metal stand + parlak ambiyanslı ekran + arka LED şeridi
      L.bevelBox(-0.22, -0.08, 0.515, 0.22, 0.04, 0.54, 0.005, C_PASLANMAZ, 1, MT_KROM);
      L.box(-0.04, -0.05, 0.54, 0.04, -0.02, 0.65, C_PASLANMAZ, 1, MT_KROM);
      L.box(-0.70, -0.04, 0.63, 0.70, -0.015, 1.41, C_SIYAH, 1, MT_MAT);
      L.box(-0.68, -0.014, 0.65, 0.68, -0.008, 1.39, C_EKRAN, 1, MT_ISIK);
      L.box(-0.62, -0.055, 0.68, 0.62, -0.042, 1.35, C_ISIK, 1, MT_ISIK);
      break;
    }

    case 'kitaplik': {
      // Endüstriyel antrasit metal dikmeler + pirinç çapraz gergi + pahlı meşe raflar + dekorasyon
      L.box(-0.5, -0.17, 0, 0.5, 0.17, 0.06, C_ANTRASIT, 1, MT_MAT);
      for (const [px, py] of [[-0.48, -0.15], [0.48, -0.15], [-0.48, 0.15], [0.48, 0.15]]) {
        L.cyl(px, py, 0.06, 0.014, 0.014, 1.94, 10, C_ANTRASIT, 1, MT_KROM);
      }
      L.cylX(-0.48, -0.16, 0.12, 0.48, -0.16, 1.92, 0.006, C_PIRINC, MT_PIRINC);
      L.cylX(0.48, -0.16, 0.12, -0.48, -0.16, 1.92, 0.006, C_PIRINC, MT_PIRINC);
      const rafZ = [0.06, 0.44, 0.82, 1.20, 1.58, 1.96];
      const bookCols: RGB[] = [C_YASTIK_TEAL, C_YASTIK_TER, C_KUMA, C_YASTIK_HARDAL, C_KREM, C_CEVIZ];
      rafZ.forEach((z, ri) => {
        L.bevelBox(-0.49, -0.16, z, 0.49, 0.16, z + 0.032, 0.006, C_MESE, 1, MT_AHSAP);
        if (ri < 4) {
          for (let bi = 0; bi < 6; bi++) {
            const bx = -0.40 + (ri % 2) * 0.14 + bi * 0.048;
            if (bx > 0.34) continue;
            const bh = 0.21 + ((bi + ri) % 3) * 0.045;
            L.bevelBox(bx, -0.12, z + 0.032, bx + 0.038, 0.12, z + 0.032 + bh, 0.003, bookCols[(bi + ri) % bookCols.length]);
          }
        }
      });
      // Raflarda seramik vazolar & saksı bitkisi
      L.lathe(-0.22, 0, 1.612, [[0.045, 0], [0.075, 0.07], [0.062, 0.15], [0.035, 0.21]], 14, C_YASTIK_TEAL, 1, MT_SERAMIK);
      L.lathe(0.24, 0, 0.852, [[0.05, 0], [0.07, 0.10]], 12, C_SAKSI);
      L.dome(0.24, 0, 0.99, 0.11, 0.09, 0.09, 4, 10, C_YAPRAK2, 1, true);
      L.bevelBox(0.14, -0.04, 1.612, 0.38, 0.01, 1.88, 0.005, C_CEVIZ, 1, MT_AHSAP);
      L.box(0.16, 0.01, 1.635, 0.36, 0.015, 1.855, C_SERAMIK);
      break;
    }

    case 'masa': {
      const hw = T.w / 2, hd = T.d / 2;
      // Splayed A-frame ahşap ayaklar + orta pirinç bağlantı çubuğu
      L.cylX(-hw + 0.12, -hd + 0.08, 0, -hw + 0.26, 0, 0.72, 0.032, C_CEVIZ, MT_AHSAP);
      L.cylX(-hw + 0.12, hd - 0.08, 0, -hw + 0.26, 0, 0.72, 0.032, C_CEVIZ, MT_AHSAP);
      L.cylX(hw - 0.12, -hd + 0.08, 0, hw - 0.26, 0, 0.72, 0.032, C_CEVIZ, MT_AHSAP);
      L.cylX(hw - 0.12, hd - 0.08, 0, hw - 0.26, 0, 0.72, 0.032, C_CEVIZ, MT_AHSAP);
      L.cylX(-hw + 0.22, 0, 0.22, hw - 0.22, 0, 0.22, 0.014, C_PIRINC, MT_PIRINC);
      // Pahlı masif meşe masa tablası + keten runner
      L.bevelBox(-hw, -hd, 0.715, hw, hd, 0.76, 0.018, C_MESE, 1, MT_AHSAP);
      L.box(-hw * 0.65, -0.14, 0.76, hw * 0.65, 0.14, 0.766, C_KUMA_BEJ, 1, MT_KUMAS);
      // Orta seramik kase + meyveler + 2 pirinç şamdan
      L.lathe(0, 0, 0.766, [[0.07, 0], [0.15, 0.03], [0.19, 0.08], [0.18, 0.085], [0.06, 0.02]], 18, C_SERAMIK, 1, MT_SERAMIK);
      L.dome(-0.05, 0.02, 0.82, 0.044, 0.044, 0.044, 4, 10, C_YASTIK_TER, 1, true);
      L.dome(0.05, -0.02, 0.82, 0.042, 0.042, 0.042, 4, 10, C_YASTIK_HARDAL, 1, true);
      L.dome(0.0, 0.04, 0.83, 0.036, 0.036, 0.036, 4, 10, C_YAPRAK2, 1, true);
      for (const sxPos of [-0.36, 0.36]) {
        L.lathe(sxPos, 0, 0.766, [[0.038, 0], [0.012, 0.02], [0.012, 0.14], [0.022, 0.16]], 12, C_PIRINC, 1, MT_PIRINC);
        L.cyl(sxPos, 0, 0.926, 0.009, 0.009, 0.10, 10, C_SERAMIK);
      }
      break;
    }

    case 'sandalye': {
      // Splayed ceviz ayaklar + döşemeli minder + kavisli Wishbone/Scandi sırtlık (+d/2 yönünde)
      for (const [bx, by, tx, ty] of [
        [-0.20, -0.23, -0.17, -0.18],
        [0.20, -0.23, 0.17, -0.18],
        [-0.20, 0.23, -0.17, 0.19],
        [0.20, 0.23, 0.17, 0.19],
      ]) {
        L.cylX(bx, by, 0, tx, ty, 0.42, 0.015, C_CEVIZ, MT_AHSAP);
      }
      L.bevelBox(-0.205, -0.215, 0.41, 0.205, 0.215, 0.445, 0.012, C_MESE, 1, MT_AHSAP);
      L.cushion(0, 0, 0.46, 0.195, 0.205, 0.035, C_KUMA);
      // Kavisli yan kol-sırt kemeri (tube) + arka Y destek
      L.tube([
        [-0.18, 0.0, 0.45],
        [-0.20, 0.16, 0.66],
        [-0.17, 0.24, 0.80],
        [0.0, 0.26, 0.83],
        [0.17, 0.24, 0.80],
        [0.20, 0.16, 0.66],
        [0.18, 0.0, 0.45],
      ], 0.017, 0.017, 10, C_CEVIZ, 1, MT_AHSAP);
      L.cylX(0, 0.21, 0.45, 0, 0.25, 0.82, 0.013, C_CEVIZ, MT_AHSAP);
      break;
    }

    case 'tezgah': {
      const hw = T.w / 2;
      L.box(-hw, -0.28, 0, hw, 0.23, 0.09, C_ANTRASIT, 1, MT_MAT);
      L.box(-hw, -0.3, 0.09, hw, 0.26, 0.86, C_BEYAZ);
      const nMod = Math.max(2, Math.round(T.w / 0.6));
      const mw = T.w / nMod;
      for (let i = 0; i < nMod; i++) {
        const x0 = -hw + i * mw + 0.012;
        const x1 = x0 + mw - 0.024;
        L.bevelBox(x0, 0.26, 0.10, x1, 0.282, 0.68, 0.005, C_ADA_YESIL);
        L.bevelBox(x0, 0.26, 0.70, x1, 0.282, 0.85, 0.005, C_ADA_YESIL);
        L.tube([[(x0 + x1) / 2 - 0.06, 0.28, 0.77], [(x0 + x1) / 2 - 0.06, 0.302, 0.77], [(x0 + x1) / 2 + 0.06, 0.302, 0.77], [(x0 + x1) / 2 + 0.06, 0.28, 0.77]], 0.006, 0.006, 8, C_PIRINC, 1, MT_PIRINC);
        L.tube([[(x0 + x1) / 2, 0.28, 0.46], [(x0 + x1) / 2, 0.302, 0.46], [(x0 + x1) / 2, 0.302, 0.60], [(x0 + x1) / 2, 0.28, 0.60]], 0.006, 0.006, 8, C_PIRINC, 1, MT_PIRINC);
      }
      // Damarlı Carrara mermer tezgah + tam boy mermer alınlık + tezgah altı LED bandı
      L.bevelBox(-hw - 0.01, -0.3, 0.86, hw + 0.01, 0.31, 0.905, 0.008, C_MERMER, 1, MT_MERMER);
      L.box(-hw, -0.3, 0.905, hw, -0.275, 1.46, C_MERMER, 1, MT_MERMER);
      L.box(-hw + 0.04, -0.26, 1.43, hw - 0.04, -0.22, 1.45, C_ISIK, 1, MT_ISIK);
      // Üst meşe kapaklı dolaplar
      L.box(-hw, -0.3, 1.45, hw, 0.04, 2.20, C_BEYAZ);
      for (let i = 0; i < nMod; i++) {
        const x0 = -hw + i * mw + 0.012;
        const x1 = x0 + mw - 0.024;
        L.bevelBox(x0, 0.04, 1.47, x1, 0.065, 2.18, 0.005, C_MESE, 1, MT_AHSAP);
      }
      // Tezgah üstü kahve makinesi & ahşap kesme tahtası & yağ şişesi
      L.bevelBox(-hw + 0.16, -0.18, 0.905, -hw + 0.44, 0.08, 1.20, 0.012, C_PASLANMAZ, 1, MT_KROM);
      L.bevelBox(0.05, -0.05, 0.905, 0.42, 0.20, 0.935, 0.005, C_MESE, 1, MT_AHSAP);
      L.lathe(0.56, -0.12, 0.905, [[0.035, 0], [0.035, 0.15], [0.014, 0.21], [0.014, 0.25]], 12, C_YAPRAK1, 0.85, MT_SERAMIK);
      break;
    }

    case 'evye': {
      L.box(-0.4, -0.28, 0, 0.4, 0.23, 0.09, C_ANTRASIT, 1, MT_MAT);
      L.box(-0.4, -0.3, 0.09, 0.4, 0.26, 0.86, C_BEYAZ);
      L.bevelBox(-0.38, 0.26, 0.10, -0.01, 0.282, 0.84, 0.005, C_ADA_YESIL);
      L.bevelBox(0.01, 0.26, 0.10, 0.38, 0.282, 0.84, 0.005, C_ADA_YESIL);
      L.cyl(-0.06, 0.30, 0.62, 0.006, 0.006, 0.14, 8, C_PIRINC, 1, MT_PIRINC);
      L.cyl(0.06, 0.30, 0.62, 0.006, 0.006, 0.14, 8, C_PIRINC, 1, MT_PIRINC);
      // Mermer tezgah + çelik havuz + süzgeç
      L.bevelBox(-0.41, -0.3, 0.86, 0.41, 0.31, 0.905, 0.008, C_MERMER, 1, MT_MERMER);
      L.bevelBox(-0.33, -0.22, 0.898, 0.33, 0.22, 0.914, 0.004, C_PASLANMAZ, 1, MT_KROM);
      L.box(-0.28, -0.17, 0.900, 0.12, 0.17, 0.910, C_GRI, 1, MT_KROM);
      L.cyl(-0.08, 0, 0.910, 0.036, 0.036, 0.006, 14, C_SIYAH);
      // Kavisli kuğu boynu çekilebilir krom batarya (smooth curved tube!)
      L.cyl(0, -0.23, 0.91, 0.024, 0.020, 0.08, 14, C_KROM, 1, MT_KROM);
      L.tube([
        [0, -0.23, 0.98],
        [0, -0.23, 1.12],
        [0, -0.20, 1.20],
        [0, -0.11, 1.23],
        [0, -0.03, 1.19],
        [0, -0.01, 1.11],
      ], 0.012, 0.011, 12, C_KROM, 1, MT_KROM);
      L.cyl(0, -0.01, 1.07, 0.017, 0.014, 0.04, 12, C_KROM, 1, MT_KROM);
      // Sabunluk
      L.lathe(0.24, -0.21, 0.905, [[0.03, 0], [0.03, 0.09], [0.01, 0.13]], 12, C_ANTRASIT, 1, MT_SERAMIK);
      break;
    }

    case 'ocak': {
      // Ankastre fırın + seramik cam ocak + demir döküm ızgara + tencere + ÜST DAVLUMBAZ
      L.bevelBox(-0.3, -0.3, 0, 0.3, 0.29, 0.88, 0.01, C_PASLANMAZ, 1, MT_KROM);
      L.bevelBox(-0.26, 0.28, 0.13, 0.26, 0.312, 0.69, 0.008, C_SIYAH, 1, MT_MAT);
      L.box(-0.19, 0.308, 0.25, 0.19, 0.318, 0.57, [0.22, 0.24, 0.28], 0.85);
      L.tube([[-0.22, 0.31, 0.64], [-0.22, 0.348, 0.64], [0.22, 0.348, 0.64], [0.22, 0.31, 0.64]], 0.010, 0.010, 8, C_KROM, 1, MT_KROM);
      for (const kx of [-0.18, -0.06, 0.06, 0.18]) {
        L.discY(kx, 0.29, 0.79, 0.022, 0.026, 12, C_KROM, 1, MT_KROM);
      }
      // Ocak cam tablası + 4 bek + paslanmaz tencere
      L.bevelBox(-0.3, -0.3, 0.88, 0.3, 0.3, 0.908, 0.005, C_SIYAH, 1, MT_SERAMIK);
      for (const [bx, by, r] of [[-0.14, -0.13, 0.088], [0.14, -0.13, 0.068], [-0.14, 0.13, 0.072], [0.14, 0.13, 0.095]]) {
        L.cyl(bx, by, 0.908, r, r * 0.92, 0.014, 16, C_ANTRASIT, 1, MT_MAT);
        L.cyl(bx, by, 0.922, r * 0.45, r * 0.45, 0.008, 12, C_PIRINC, 1, MT_PIRINC);
      }
      // Tencere + cam kapak
      L.lathe(-0.14, -0.13, 0.922, [[0.095, 0], [0.105, 0.11], [0.105, 0.12]], 18, C_PASLANMAZ, 1, MT_KROM);
      L.dome(-0.14, -0.13, 1.04, 0.10, 0.10, 0.035, 3, 14, C_CAM, 0.55);
      // Davlumbaz (z = 1.62 .. 2.48)
      L.bevelBox(-0.32, -0.3, 1.62, 0.32, 0.25, 1.69, 0.01, C_PASLANMAZ, 1, MT_KROM);
      L.prismSide([[-0.30, 1.69], [0.22, 1.69], [0.06, 1.88], [-0.30, 1.88]], -0.30, 0.30, C_PASLANMAZ, 1, MT_KROM);
      L.box(-0.14, -0.3, 1.88, 0.14, -0.02, 2.48, C_PASLANMAZ, 1, MT_KROM);
      L.box(-0.24, -0.18, 1.615, 0.24, -0.06, 1.622, C_ISIK, 1, MT_ISIK);
      break;
    }

    case 'buzdolabi': {
      // Amerikan çift kapılı + alt derin donduruculu inox buzdolabı
      L.bevelBox(-0.35, -0.35, 0, 0.35, 0.30, 1.86, 0.015, C_PASLANMAZ, 1, MT_KROM);
      L.bevelBox(-0.345, 0.30, 0.66, -0.006, 0.355, 1.845, 0.008, [0.83, 0.86, 0.90], 1, MT_KROM);
      L.bevelBox(0.006, 0.30, 0.66, 0.345, 0.355, 1.845, 0.008, [0.83, 0.86, 0.90], 1, MT_KROM);
      L.bevelBox(-0.345, 0.30, 0.03, 0.345, 0.355, 0.64, 0.008, [0.80, 0.83, 0.87], 1, MT_KROM);
      // Uzun krom boru kulplar
      L.tube([[-0.05, 0.35, 0.78], [-0.05, 0.388, 0.80], [-0.05, 0.388, 1.72], [-0.05, 0.35, 1.74]], 0.010, 0.010, 8, C_KROM, 1, MT_KROM);
      L.tube([[0.05, 0.35, 0.78], [0.05, 0.388, 0.80], [0.05, 0.388, 1.72], [0.05, 0.35, 1.74]], 0.010, 0.010, 8, C_KROM, 1, MT_KROM);
      L.tube([[-0.22, 0.35, 0.56], [-0.22, 0.388, 0.56], [0.22, 0.388, 0.56], [0.22, 0.35, 0.56]], 0.010, 0.010, 8, C_KROM, 1, MT_KROM);
      // Su sebili & LED dijital panel
      L.bevelBox(-0.24, 0.348, 1.02, -0.10, 0.365, 1.42, 0.004, C_SIYAH, 1, MT_MAT);
      L.box(-0.22, 0.358, 1.32, -0.12, 0.368, 1.39, C_EKRAN, 1, MT_ISIK);
      break;
    }

    case 'camasir': {
      L.bevelBox(-0.3, -0.3, 0, 0.3, 0.29, 0.85, 0.016, C_BEYAZ, 1, MT_SERAMIK);
      L.bevelBox(-0.28, 0.282, 0.69, -0.07, 0.305, 0.82, 0.005, C_SERAMIK, 1, MT_SERAMIK);
      L.bevelBox(-0.04, 0.282, 0.71, 0.27, 0.305, 0.80, 0.004, C_SIYAH, 1, MT_MAT);
      L.box(0.08, 0.298, 0.735, 0.23, 0.310, 0.775, C_EKRAN, 1, MT_ISIK);
      L.discY(0, 0.285, 0.755, 0.033, 0.032, 16, C_KROM, 1, MT_KROM);
      // Kademeli krom tambur kapağı + füme bombeli cam
      L.discY(0, 0.285, 0.40, 0.215, 0.025, 24, C_KROM, 1, MT_KROM);
      L.discY(0, 0.292, 0.40, 0.165, 0.035, 22, C_SIYAH, 0.88, MT_SERAMIK);
      break;
    }

    case 'wc': {
      // Torna tek parça heykel formunda modern seramik klozet + kapak + gizli rezervuar butonu
      L.lathe(0, 0.06, 0, [
        [0.12, 0.0],
        [0.13, 0.12],
        [0.15, 0.22],
        [0.19, 0.32],
        [0.20, 0.38],
        [0.17, 0.39],
        [0.12, 0.28],
      ], 24, C_SERAMIK, 1, MT_SERAMIK);
      // Su havuzu & ergonomik kapak
      L.cyl(0, 0.06, 0.31, 0.11, 0.11, 0.02, 16, C_KUVET_SU, 0.85);
      L.cyl(0, 0.06, 0.385, 0.185, 0.188, 0.03, 22, C_BEYAZ, 1, MT_SERAMIK);
      // Arka rezervuar tankı + çift kademeli krom basma butonu
      L.bevelBox(-0.19, -0.32, 0.22, 0.19, -0.11, 0.80, 0.022, C_SERAMIK, 1, MT_SERAMIK);
      L.bevelBox(-0.20, -0.33, 0.79, 0.20, -0.10, 0.825, 0.01, C_BEYAZ, 1, MT_SERAMIK);
      L.cyl(0, -0.215, 0.825, 0.028, 0.028, 0.015, 14, C_KROM, 1, MT_KROM);
      break;
    }

    case 'lavabo': {
      // Yüzen çıtalı meşe banyo dolabı + mermer tezgah + torna çanak lavabo + kavisli batarya + LED arkadan aydınlatmalı ayna
      L.bevelBox(-0.3, -0.22, 0.42, 0.3, 0.21, 0.74, 0.012, C_MESE, 1, MT_AHSAP);
      for (let i = 0; i < 12; i++) {
        const sx0 = -0.28 + i * 0.047;
        L.box(sx0, 0.21, 0.44, sx0 + 0.028, 0.23, 0.72, C_CEVIZ, 1, MT_AHSAP);
      }
      L.bevelBox(-0.31, -0.22, 0.74, 0.31, 0.23, 0.775, 0.008, C_MERMER, 1, MT_MERMER);
      // Torna çanak seramik lavabo
      L.lathe(0, 0.02, 0.775, [[0.11, 0], [0.18, 0.04], [0.22, 0.11], [0.20, 0.115], [0.15, 0.04], [0.08, 0.015]], 24, C_SERAMIK, 1, MT_SERAMIK);
      L.cyl(0, 0.02, 0.79, 0.032, 0.032, 0.008, 12, C_KROM, 1, MT_KROM);
      // Kavisli krom yüksek batarya
      L.tube([
        [0, -0.17, 0.775],
        [0, -0.17, 0.94],
        [0, -0.14, 1.00],
        [0, -0.06, 0.99],
        [0, -0.02, 0.94],
      ], 0.012, 0.010, 12, C_KROM, 1, MT_KROM);
      // Katlı el havlusu + sıvı sabunluk
      L.bevelBox(0.19, -0.08, 0.775, 0.29, 0.14, 0.815, 0.008, C_KUMA_BEJ, 1, MT_KUMAS);
      // Büyük yuvarlak arkadan LED aydınlatmalı ayna!
      L.discY(0, -0.225, 1.38, 0.34, 0.012, 28, C_ISIK, 1, MT_ISIK);
      L.discY(0, -0.215, 1.38, 0.31, 0.015, 28, [0.76, 0.88, 0.94], 1, MT_KROM);
      break;
    }

    case 'dus': {
      // Kayrak görünümlü tekne + paslanmaz çizgisel süzgeç
      L.bevelBox(-0.45, -0.45, 0, 0.45, 0.45, 0.06, 0.01, C_SERAMIK, 1, MT_SERAMIK);
      L.box(-0.36, -0.39, 0.055, 0.36, -0.32, 0.066, C_KROM, 1, MT_KROM);
      // Mat siyah minimalist profil + temperli cam paneller + kulp
      L.box(-0.45, 0.43, 0.06, 0.45, 0.45, 2.02, C_CAM, 0.28);
      L.box(0.43, -0.45, 0.06, 0.45, 0.45, 2.02, C_CAM, 0.28);
      L.box(-0.45, 0.42, 0.06, 0.45, 0.46, 0.085, C_SIYAH, 1, MT_MAT);
      L.box(-0.45, 0.42, 2.0, 0.45, 0.46, 2.035, C_SIYAH, 1, MT_MAT);
      L.box(0.42, -0.45, 0.06, 0.46, 0.45, 0.085, C_SIYAH, 1, MT_MAT);
      L.box(0.42, -0.45, 2.0, 0.46, 0.45, 2.035, C_SIYAH, 1, MT_MAT);
      L.box(0.42, 0.42, 0.06, 0.46, 0.46, 2.035, C_SIYAH, 1, MT_MAT);
      L.tube([[0.25, 0.45, 0.86], [0.25, 0.49, 0.88], [0.25, 0.49, 1.24], [0.25, 0.45, 1.26]], 0.009, 0.009, 8, C_KROM, 1, MT_KROM);
      // Termostatik batarya + kavisli yağmurlama kolonu + geniş tepe duşu + duvar şampuan nişi
      L.bevelBox(-0.12, -0.44, 0.98, 0.12, -0.38, 1.04, 0.008, C_KROM, 1, MT_KROM);
      L.tube([[0, -0.41, 1.04], [0, -0.41, 1.98], [0, -0.36, 2.06], [0, -0.14, 2.06], [0, -0.12, 2.01]], 0.012, 0.011, 12, C_KROM, 1, MT_KROM);
      L.cyl(0, -0.12, 1.99, 0.15, 0.14, 0.018, 22, C_KROM, 1, MT_KROM);
      // Şampuan şişeleri rafta
      L.bevelBox(-0.34, -0.44, 1.15, -0.16, -0.33, 1.18, 0.004, C_ANTRASIT);
      L.lathe(-0.28, -0.38, 1.18, [[0.022, 0], [0.022, 0.13], [0.008, 0.16]], 10, C_YASTIK_TEAL);
      L.lathe(-0.21, -0.38, 1.18, [[0.020, 0], [0.020, 0.11], [0.008, 0.14]], 10, C_YASTIK_HARDAL);
      break;
    }

    case 'kuvet': {
      // Stadyum-oval torna/lathe benzeri bağımsız akrilik küvet (yumuşak oval kenarlı)
      const nSt = 24;
      const ringOutB: [number, number][] = [];
      const ringOutT: [number, number][] = [];
      const ringInT: [number, number][] = [];
      for (let i = 0; i < nSt; i++) {
        const ang = (i / nSt) * Math.PI * 2;
        const ca = Math.cos(ang), sa = Math.sin(ang);
        const rx = 0.82, ry = 0.35;
        ringOutB.push([ca * rx * 0.90, sa * ry * 0.88]);
        ringOutT.push([ca * rx, sa * ry]);
        ringInT.push([ca * (rx - 0.065), sa * (ry - 0.06)]);
      }
      for (let i = 0; i < nSt; i++) {
        const ni = (i + 1) % nSt;
        const n0 = L.nrm(Math.cos((i / nSt) * Math.PI * 2), Math.sin((i / nSt) * Math.PI * 2), -0.15);
        const n1 = L.nrm(Math.cos((ni / nSt) * Math.PI * 2), Math.sin((ni / nSt) * Math.PI * 2), -0.15);
        const pB0 = L.pt(ringOutB[i][0], ringOutB[i][1], 0);
        const pB1 = L.pt(ringOutB[ni][0], ringOutB[ni][1], 0);
        const pT0 = L.pt(ringOutT[i][0], ringOutT[i][1], 0.56);
        const pT1 = L.pt(ringOutT[ni][0], ringOutT[ni][1], 0.56);
        const pI0 = L.pt(ringInT[i][0], ringInT[i][1], 0.56);
        const pI1 = L.pt(ringInT[ni][0], ringInT[ni][1], 0.56);
        const pIB0 = L.pt(ringInT[i][0] * 0.9, ringInT[i][1] * 0.9, 0.14);
        const pIB1 = L.pt(ringInT[ni][0] * 0.9, ringInT[ni][1] * 0.9, 0.14);
        m.quadSmooth(pB0, n0, pB1, n1, pT1, n1, pT0, n0, C_SERAMIK, 1, MT_SERAMIK);
        const nTop = L.nrm(0, 0, 1);
        m.quadSmooth(pT0, nTop, pT1, nTop, pI1, nTop, pI0, nTop, C_SERAMIK, 1, MT_SERAMIK);
        const nIn = L.nrm(-n0[0], -n0[1], 0.2);
        m.quadSmooth(pI0, nIn, pI1, nIn, pIB1, nIn, pIB0, nIn, C_SERAMIK, 1, MT_SERAMIK);
      }
      // Su yüzeyi + küvet yastığı + ahşap küvet köprüsü (mum + havlu) + ayaklı krom batarya
      L.cyl(0, 0, 0.44, 0.72, 0.72, 0.02, 20, C_KUVET_SU, 0.78);
      L.cushion(-0.62, 0, 0.54, 0.09, 0.21, 0.055, C_KUMA_BEJ, 0);
      L.bevelBox(-0.10, -0.37, 0.56, 0.14, 0.37, 0.59, 0.006, C_MESE, 1, MT_AHSAP);
      L.cyl(0.02, -0.14, 0.59, 0.032, 0.032, 0.06, 12, C_SERAMIK);
      L.dome(0.02, -0.14, 0.665, 0.012, 0.012, 0.02, 3, 8, C_ISIK, 1, true, MT_ISIK);
      // Yer tipi kavisli batarya
      L.tube([[0.76, -0.32, 0], [0.76, -0.32, 0.72], [0.73, -0.28, 0.81], [0.64, -0.18, 0.80], [0.58, -0.10, 0.72]], 0.018, 0.012, 12, C_KROM, 1, MT_KROM);
      break;
    }

    case 'bitki': {
      // 3 ayaklı meşe sehpa + torna seramik saksı + çoklu kavisli ahşap gövde + 16 doğal yaprak kümesi
      for (let i = 0; i < 3; i++) {
        const ang = (i / 3) * Math.PI * 2;
        L.cylX(Math.cos(ang) * 0.16, Math.sin(ang) * 0.16, 0, Math.cos(ang) * 0.13, Math.sin(ang) * 0.13, 0.24, 0.013, C_CEVIZ, MT_AHSAP);
      }
      L.lathe(0, 0, 0.12, [[0.11, 0], [0.16, 0.12], [0.18, 0.26], [0.185, 0.31], [0.16, 0.31], [0.15, 0.27]], 22, C_SAKSI, 1, MT_SERAMIK);
      L.cyl(0, 0, 0.38, 0.155, 0.155, 0.02, 16, C_TOPRAK, 1, MT_MAT);
      const yapraklar: [number, number, number, number, RGB][] = [
        [0.02, 0.02, 1.04, 0.12, C_YAPRAK1],
        [-0.09, 0.07, 0.92, 0.11, C_YAPRAK2],
        [0.11, -0.08, 0.89, 0.115, C_YAPRAK2],
        [-0.10, -0.10, 0.82, 0.105, C_YAPRAK3],
        [0.12, 0.09, 0.78, 0.11, C_YAPRAK1],
        [-0.15, 0.0, 0.70, 0.10, C_YAPRAK2],
        [0.0, 0.15, 0.68, 0.105, C_YAPRAK3],
        [0.15, -0.01, 0.64, 0.095, C_YAPRAK1],
        [0.01, -0.15, 0.60, 0.095, C_YAPRAK2],
        [-0.12, 0.12, 0.56, 0.085, C_YAPRAK3],
        [0.12, 0.12, 0.54, 0.09, C_YAPRAK2],
      ];
      yapraklar.forEach(([yx, yy, yz, yr, col]) => {
        L.tube([[0, 0, 0.39], [yx * 0.45, yy * 0.45, (0.39 + yz) * 0.52], [yx * 0.9, yy * 0.9, yz - 0.03]], 0.009, 0.005, 8, C_CEVIZ, 1, MT_AHSAP);
        L.dome(yx, yy, yz, yr * 1.2, yr * 0.75, yr * 0.38, 4, 10, col, 1, true);
      });
      break;
    }

    default: {
      if (T.p) {
        T.p(T).forEach(([x0, z0, x1, z1, py0, py1, col]) => {
          const c = col === 'cam' ? C_CAM : hex(col);
          L.box(x0, z0, py0, x1, z1, py1, c, col === 'cam' ? 0.35 : 1);
        });
      }
      break;
    }
  }
  L.finishHit();
}

export function araba3DEkle(m: MeshHedef, cx: number, dy: number, cz: number, rDeg: number) {
  const L = new L3D(m, cx, dy, cz, 1, 1, rDeg);
  const cGovde: RGB = [0.16, 0.31, 0.46];
  const cTampon: RGB = [0.13, 0.15, 0.18];
  const cCam: RGB = [0.18, 0.27, 0.36];
  const cLastik: RGB = [0.11, 0.12, 0.14];
  const cJant: RGB = [0.85, 0.88, 0.92];
  const cFar: RGB = [1.0, 0.97, 0.84];
  const cStop: RGB = [0.92, 0.16, 0.14];

  // 4 çok-kollu alaşım jantlı tekerlek
  for (const [wx, wy] of [[-0.84, -1.36], [0.84, -1.36], [-0.84, 1.36], [0.84, 1.36]]) {
    L.wheel(wx, wy, 0.32, 0.32, 0.23, 18, cLastik, cJant);
  }
  // Alt şase difüzör + yan etekler + tamponlar
  L.bevelBox(-0.88, -2.20, 0.20, 0.88, 2.20, 0.35, 0.03, cTampon, 1, MT_MAT);
  L.bevelBox(-0.91, -2.26, 0.23, 0.91, -2.10, 0.56, 0.04, cTampon, 1, MT_MAT);
  L.bevelBox(-0.91, 2.10, 0.23, 0.91, 2.26, 0.56, 0.04, cTampon, 1, MT_MAT);

  // Aerodinamik fastback gövde (pürüzsüz normalli profil + omuz çizgisi)
  L.prismSide(
    [
      [-2.20, 0.32],
      [-2.17, 0.64],
      [-1.78, 0.78],
      [-1.04, 0.89],
      [-0.44, 1.41],
      [0.92, 1.41],
      [1.76, 0.95],
      [2.16, 0.87],
      [2.21, 0.55],
      [2.18, 0.32],
    ],
    -0.89,
    0.89,
    cGovde,
    1,
    MT_KROM,
    true,
  );
  // Panoramik cam kabin + yan krom cam çerçevesi
  L.prismSide(
    [
      [-1.00, 0.90],
      [-0.45, 1.38],
      [0.90, 1.38],
      [1.68, 0.94],
    ],
    -0.81,
    0.81,
    cCam,
    0.78,
    MT_SERAMIK,
    true,
  );
  // Ön panjur, LED far şeritleri, arka boydan boya LED stop bar, yan aynalar, egzozlar
  L.bevelBox(-0.46, -2.27, 0.36, 0.46, -2.17, 0.62, 0.02, cTampon, 1, MT_MAT);
  L.box(-0.44, -2.275, 0.60, 0.44, -2.17, 0.62, C_KROM, 1, MT_KROM);
  L.box(-0.85, -2.27, 0.54, -0.52, -2.17, 0.64, cFar, 1, MT_ISIK);
  L.box(0.52, -2.27, 0.54, 0.85, -2.17, 0.64, cFar, 1, MT_ISIK);
  L.box(-0.86, 2.18, 0.62, 0.86, 2.27, 0.72, cStop, 1, MT_ISIK);
  L.bevelBox(-1.05, -0.78, 0.89, -0.88, -0.62, 0.99, 0.02, cGovde, 1, MT_KROM);
  L.bevelBox(0.88, -0.78, 0.89, 1.05, -0.62, 0.99, 0.02, cGovde, 1, MT_KROM);
  // Çift krom egzoz çıkışı
  L.cylX(-0.56, 2.15, 0.27, -0.56, 2.28, 0.27, 0.045, C_KROM, MT_KROM);
  L.cylX(0.56, 2.15, 0.27, 0.56, 2.28, 0.27, 0.045, C_KROM, MT_KROM);
}

export function agac3DEkle(m: MeshHedef, x: number, dy: number, z: number, cap: number) {
  const L = new L3D(m, x, dy, z, 1, 1, 0);
  const r = cap / 2;
  // Geniş kök tabanlı gövde + kıvrımlı ana ve ikincil dallar
  L.cyl(0, 0, 0, 0.28, 0.14, r * 1.15, 14, C_CEVIZ, 1, MT_AHSAP);
  L.tube([[0, 0, r * 0.68], [r * 0.18, r * 0.08, r * 1.08], [r * 0.42, r * 0.16, r * 1.52]], 0.11, 0.05, 8, C_CEVIZ, 1, MT_AHSAP);
  L.tube([[0, 0, r * 0.72], [-r * 0.20, -r * 0.10, r * 1.10], [-r * 0.44, -r * 0.24, r * 1.46]], 0.10, 0.045, 8, C_CEVIZ, 1, MT_AHSAP);
  L.tube([[0, 0, r * 0.85], [-r * 0.08, r * 0.22, r * 1.25], [-r * 0.14, r * 0.42, r * 1.68]], 0.08, 0.04, 8, C_CEVIZ, 1, MT_AHSAP);

  // Çok katmanlı, pürüzsüz normalli organik yaprak kümeleri
  const kumeler: [number, number, number, number, RGB][] = [
    [0, 0, r * 1.72, r * 0.86, C_YAPRAK1],
    [r * 0.46, r * 0.18, r * 1.52, r * 0.56, C_YAPRAK2],
    [-r * 0.44, -r * 0.24, r * 1.46, r * 0.58, C_YAPRAK3],
    [-r * 0.18, r * 0.42, r * 1.62, r * 0.54, C_YAPRAK2],
    [r * 0.26, -r * 0.36, r * 1.48, r * 0.52, C_YAPRAK1],
    [0.05, 0.08, r * 2.22, r * 0.62, C_YAPRAK2],
    [-r * 0.28, 0.12, r * 1.98, r * 0.48, C_YAPRAK1],
    [r * 0.28, -0.05, r * 1.96, r * 0.46, C_YAPRAK3],
  ];
  for (const [kx, ky, kz, kr, kc] of kumeler) {
    L.dome(kx, ky, kz, kr, kr * 0.94, kr * 0.76, 5, 14, kc, 1, true);
  }
}

export function cali3DEkle(m: MeshHedef, x: number, dy: number, z: number, cap: number) {
  const L = new L3D(m, x, dy, z, 1, 1, 0);
  const r = cap / 2;
  L.dome(0, 0, r * 0.35, r * 0.88, r * 0.88, r * 0.62, 5, 14, C_YAPRAK1, 1, true);
  L.dome(r * 0.38, r * 0.16, r * 0.28, r * 0.54, r * 0.54, r * 0.44, 4, 12, C_YAPRAK2, 1, true);
  L.dome(-r * 0.32, -r * 0.22, r * 0.30, r * 0.50, r * 0.50, r * 0.42, 4, 12, C_YAPRAK3, 1, true);
  L.dome(-r * 0.14, r * 0.32, r * 0.26, r * 0.42, r * 0.42, r * 0.36, 4, 10, C_YAPRAK2, 1, true);
}

export function tesisat3DEkle(m: MeshHedef, t: TesisatNokta, y0: number, katH: number) {
  const T = TES[t.tip];
  if (!T) return;
  const hit: HitSpec = {
    tur: 'tesisat',
    id: t.id,
    ad: T.ad,
    detay: `${T.g} · Kot: ${fmt(t.kot ?? T.kot ?? 0)} m`,
  };
  const kot = t.kot ?? T.kot ?? 0;

  if (t.tip === 'lamba') {
    const L = new L3D(m, t.x, y0 + katH, t.y, 1, 1, 0, hit);
    L.cyl(0, 0, -0.02, 0.065, 0.065, 0.02, 16, C_PIRINC, 1, MT_PIRINC);
    L.cyl(0, 0, -0.24, 0.006, 0.006, 0.22, 8, C_SIYAH, 1, MT_MAT);
    // Kavisli torna sarkıt abajur & sıcak parlayan iç ampul
    L.lathe(0, 0, -0.40, [[0.22, 0], [0.20, 0.05], [0.14, 0.12], [0.05, 0.16]], 24, C_KREM, 1, MT_SERAMIK);
    L.dome(0, 0, -0.37, 0.055, 0.055, 0.055, 4, 12, C_ISIK, 1, true, MT_ISIK);
    L.finishHit();
    return;
  }

  if (t.tip === 'aplik') {
    const L = new L3D(m, t.x, y0 + Math.min(katH - 0.25, kot), t.y, 1, 1, t.r || 0, hit);
    L.cyl(0, 0.005, 0, 0.075, 0.07, 0.015, 14, C_PIRINC, 1, MT_PIRINC);
    L.tube([[0, 0.01, 0], [0, 0.08, 0.02], [0, 0.08, 0.08]], 0.009, 0.009, 8, C_PIRINC, 1, MT_PIRINC);
    L.lathe(0, 0.08, 0.06, [[0.065, 0], [0.075, 0.07], [0.055, 0.13]], 16, C_ISIK, 0.92, MT_ISIK);
    L.finishHit();
    return;
  }

  if (t.tip === 'kombi') {
    const L = new L3D(m, t.x, y0 + Math.max(1.0, kot - 0.35), t.y, 1, 1, t.r || 0, hit);
    L.bevelBox(-0.22, -0.08, 0, 0.22, 0.22, 0.72, 0.02, C_BEYAZ, 1, MT_SERAMIK);
    L.bevelBox(-0.14, 0.215, 0.19, 0.14, 0.232, 0.35, 0.005, C_SIYAH, 1, MT_MAT);
    L.box(-0.08, 0.228, 0.23, 0.08, 0.236, 0.31, C_EKRAN, 1, MT_ISIK);
    L.cyl(0, 0.04, 0.72, 0.05, 0.05, Math.max(0.25, katH - kot - 0.35), 14, C_PASLANMAZ, 1, MT_KROM);
    for (const bx of [-0.15, -0.07, 0.01, 0.09, 0.16]) {
      L.cyl(bx, 0.04, -0.15, 0.01, 0.01, 0.15, 8, C_BAKIR, 1, MT_PIRINC);
    }
    L.finishHit();
    return;
  }

  if (t.tip === 'petek') {
    const L = new L3D(m, t.x, y0 + Math.max(0.12, kot - 0.25), t.y, 1, 1, t.r || 0, hit);
    L.bevelBox(-0.55, -0.04, 0, 0.55, 0.05, 0.56, 0.01, C_SERAMIK, 1, MT_SERAMIK);
    for (let px = -0.50; px <= 0.50; px += 0.052) {
      L.bevelBox(px, 0.045, 0.02, px + 0.028, 0.072, 0.54, 0.004, C_BEYAZ, 1, MT_SERAMIK);
    }
    L.cyl(0.58, 0.01, 0.48, 0.018, 0.018, 0.065, 12, C_KROM, 1, MT_KROM);
    L.finishHit();
    return;
  }

  if (t.tip === 'klima') {
    const L = new L3D(m, t.x, y0 + Math.min(katH - 0.32, kot), t.y, 1, 1, t.r || 0, hit);
    L.bevelBox(-0.47, -0.06, 0, 0.47, 0.17, 0.29, 0.025, C_SERAMIK, 1, MT_SERAMIK);
    L.box(-0.44, 0.155, 0.03, 0.44, 0.18, 0.075, C_ANTRASIT, 1, MT_MAT);
    L.box(0.32, 0.165, 0.14, 0.38, 0.176, 0.17, C_EKRAN, 1, MT_ISIK);
    L.finishHit();
    return;
  }

  if (t.tip === 'pano') {
    const L = new L3D(m, t.x, y0 + kot - 0.2, t.y, 1, 1, t.r || 0, hit);
    L.bevelBox(-0.22, -0.04, 0, 0.22, 0.08, 0.48, 0.01, C_KREM, 1, MT_SERAMIK);
    L.bevelBox(-0.19, 0.075, 0.03, 0.19, 0.095, 0.45, 0.005, C_BEYAZ, 1, MT_SERAMIK);
    L.box(0.12, 0.092, 0.18, 0.16, 0.108, 0.28, C_SIYAH, 1, MT_MAT);
    L.finishHit();
    return;
  }

  if (t.tip === 'kollektor') {
    const L = new L3D(m, t.x, y0 + kot - 0.2, t.y, 1, 1, t.r || 0, hit);
    L.bevelBox(-0.25, -0.04, 0, 0.25, 0.09, 0.40, 0.01, C_PASLANMAZ, 1, MT_KROM);
    L.cylX(-0.20, 0.05, 0.28, 0.20, 0.05, 0.28, 0.016, C_PIRINC, MT_PIRINC);
    L.cylX(-0.20, 0.05, 0.14, 0.20, 0.05, 0.14, 0.016, hex(BORU_TIPLERI.temiz_su_soguk.renk), MT_KROM);
    L.finishHit();
    return;
  }

  if (t.tip === 'priz' || t.tip === 'etanj' || t.tip === 'anahtar' || t.tip === 'tv') {
    const L = new L3D(m, t.x, y0 + kot, t.y, 1, 1, t.r || 0, hit);
    L.bevelBox(-0.045, -0.015, -0.045, 0.045, 0.012, 0.045, 0.004, C_BEYAZ, 1, MT_SERAMIK);
    L.box(-0.025, 0.010, -0.025, 0.025, 0.018, 0.025, t.tip === 'anahtar' ? C_KREM : C_ANTRASIT);
    L.finishHit();
  }
}
