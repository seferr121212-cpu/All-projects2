export const RAD = Math.PI / 180;

export const uid = (): string => Math.random().toString(36).slice(2, 10);

export const kopya = <T>(o: T): T => JSON.parse(JSON.stringify(o));

export const yuv = (v: number, s: number): number => Math.round(v / s) * s;

export const r3 = (v: number): number => Math.round(v * 1000) / 1000;

export const sinir = (v: number, a: number, b: number): number => Math.max(a, Math.min(b, v));

export const fmt = (v: number, d = 2): string =>
  Number(v || 0).toLocaleString('tr-TR', { minimumFractionDigits: d, maximumFractionDigits: d });

export const esc = (s: unknown): string =>
  String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c] || c));

export const tarihTR = (t = Date.now()): string => new Date(t).toLocaleDateString('tr-TR');

export const cm = (v: number): number => Math.round(v * 100);

export const saatYaz = (h: number | null | undefined): string =>
  h == null
    ? '—'
    : String(Math.floor(h)).padStart(2, '0') + ':' + String(Math.round((h % 1) * 60)).padStart(2, '0');

export const asc = (s: string): string =>
  String(s)
    .replace(/[çÇğĞıİöÖşŞüÜ]/g, c => ({ ç: 'c', Ç: 'C', ğ: 'g', Ğ: 'G', ı: 'i', İ: 'I', ö: 'o', Ö: 'O', ş: 's', Ş: 'S', ü: 'u', Ü: 'U' }[c] || c))
    .replace(/[^\x20-\x7e]/g, '');

export function bildir(m: string, sure = 2600): void {
  const b = document.querySelector('#bildirim') as HTMLElement | null;
  if (!b) return;
  b.textContent = m;
  b.style.display = 'block';
  clearTimeout((bildir as unknown as { _t?: number })._t);
  (bildir as unknown as { _t?: number })._t = window.setTimeout(() => {
    b.style.display = 'none';
  }, sure);
}

export function indir(ad: string, veri: Blob | string, tip?: string): void {
  const b = veri instanceof Blob ? veri : new Blob([veri], { type: tip || 'application/octet-stream' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(b);
  a.download = ad.replace(/[\\/:*?"<>|]/g, '_');
  document.body.appendChild(a);
  a.click();
  setTimeout(() => {
    URL.revokeObjectURL(a.href);
    a.remove();
  }, 500);
}

export function dataURLBlob(u: string): Blob {
  const [b, d] = u.split(',');
  const m = b.match(/:(.*?);/)?.[1] || 'image/png';
  const s = atob(d);
  const a = new Uint8Array(s.length);
  for (let i = 0; i < s.length; i++) a[i] = s.charCodeAt(i);
  return new Blob([a], { type: m });
}
