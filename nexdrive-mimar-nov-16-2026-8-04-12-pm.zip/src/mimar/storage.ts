import type { Proje } from './types';
import { bildir } from './utils';

export interface DepoVeri {
  projeler: Record<string, Proje>;
  son: string | null;
}

const LS_KEY = 'nxmimar:v1';
const DB_NAME = 'nxmimar_idb';
const STORE_NAME = 'depo';
const RECORD_KEY = 'ana';

let bellekDepo: DepoVeri | null = null;
let idbHazir: IDBDatabase | null = null;

function idbAc(): Promise<IDBDatabase | null> {
  if (idbHazir) return Promise.resolve(idbHazir);
  if (typeof indexedDB === 'undefined') return Promise.resolve(null);
  return new Promise(resolve => {
    try {
      const req = indexedDB.open(DB_NAME, 1);
      req.onupgradeneeded = () => {
        const db = req.result;
        if (!db.objectStoreNames.contains(STORE_NAME)) db.createObjectStore(STORE_NAME);
      };
      req.onsuccess = () => {
        idbHazir = req.result;
        resolve(idbHazir);
      };
      req.onerror = () => resolve(null);
    } catch {
      resolve(null);
    }
  });
}

function lsOku(): DepoVeri {
  try {
    const raw = localStorage.getItem(LS_KEY);
    return raw ? (JSON.parse(raw) as DepoVeri) : { projeler: {}, son: null };
  } catch {
    return { projeler: {}, son: null };
  }
}

export const DEPO = {
  async baslat(): Promise<DepoVeri> {
    const ls = lsOku();
    const db = await idbAc();
    if (!db) {
      bellekDepo = ls;
      return ls;
    }
    return new Promise(resolve => {
      try {
        const tx = db.transaction(STORE_NAME, 'readonly');
        const st = tx.objectStore(STORE_NAME);
        const req = st.get(RECORD_KEY);
        req.onsuccess = () => {
          const val = req.result as DepoVeri | undefined;
          if (val && val.projeler && Object.keys(val.projeler).length) {
            bellekDepo = val;
            resolve(val);
          } else {
            bellekDepo = ls;
            if (Object.keys(ls.projeler).length) DEPO.yaz(ls);
            resolve(ls);
          }
        };
        req.onerror = () => {
          bellekDepo = ls;
          resolve(ls);
        };
      } catch {
        bellekDepo = ls;
        resolve(ls);
      }
    });
  },

  oku(): DepoVeri {
    if (bellekDepo) return bellekDepo;
    bellekDepo = lsOku();
    return bellekDepo;
  },

  yaz(d: DepoVeri): boolean {
    bellekDepo = d;
    // IndexedDB'ye yaz (yüksek kapasiteli altlık görselleri ve büyük projeler için)
    idbAc().then(db => {
      if (!db) return;
      try {
        const tx = db.transaction(STORE_NAME, 'readwrite');
        tx.objectStore(STORE_NAME).put(d, RECORD_KEY);
      } catch {
        // yoksay
      }
    });
    // localStorage'a hafif kopya veya tam yazım dene (5MB aşarsa altlık görselsiz metadata yedekle)
    try {
      localStorage.setItem(LS_KEY, JSON.stringify(d));
      return true;
    } catch {
      try {
        const hafif: DepoVeri = {
          son: d.son,
          projeler: Object.fromEntries(
            Object.entries(d.projeler).map(([id, pr]) => [
              id,
              { ...pr, altlik: pr.altlik ? { ...pr.altlik, src: '' } : null },
            ]),
          ),
        };
        localStorage.setItem(LS_KEY, JSON.stringify(hafif));
        return true;
      } catch {
        if (!idbHazir) bildir('Tarayıcı depolaması dolu olabilir — JSON olarak yedek al.', 4500);
        return !!idbHazir;
      }
    }
  },
};
