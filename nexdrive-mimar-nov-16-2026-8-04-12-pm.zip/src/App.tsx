import { useEffect, useRef } from 'react';
import { DEPO } from './mimar/storage';
import { basla } from './mimar/studio';

export default function App() {
  const initRef = useRef(false);

  useEffect(() => {
    if (initRef.current) return;
    initRef.current = true;
    DEPO.baslat().then(() => {
      basla();
    });
  }, []);

  return (
    <>
      <div id="uygulama">
        <header id="ust">
          <div className="marka">NexDrive <b>Mimar</b></div>
          <span className="ayrac" />
          <input id="projeAd" defaultValue="Örnek Daire" title="Proje adını düzenle" />
          <select id="katSec" title="Hızlı kat seçici" />
          <button className="ubtn gizleM" id="bProjeler">Projeler</button>
          <button className="ubtn gizleM" id="bSablon">Şablonlar</button>
          <button className="ubtn ana gizleM" id="bYazi">Yazıdan plan</button>
          <span className="ayrac gizleM" />
          <button className="ubtn" id="bGeri" disabled title="Geri al (Ctrl+Z)">↶</button>
          <button className="ubtn" id="bIleri" disabled title="İleri al (Ctrl+Y)">↷</button>
          <button className="ubtn gizleM" id="bAltlik">Altlık</button>
          <button className="ubtn gizleM" id="bDisa">Dışa aktar</button>
          <button className="ubtn gizleM" id="bMepRapor" title="Elektrik linye, ısıtma & boru çakışma analizi">MEP Analiz</button>
          <button className="ubtn gizleM" id="bYardim" title="Kısayollar (?)">?</button>
          <button className="ubtn" id="bMobilMenu">☰ Menü</button>
          <div className="sekmeler">
            <button data-v="plan" className="aktif">Plan</button>
            <button data-v="3d">3D</button>
            <button data-v="metraj">Metraj</button>
            <button data-v="pafta">Pafta</button>
          </div>
        </header>

        <div id="secenek" />
        <aside id="araclar" />

        <main id="orta">
          <div id="gPlan" className="gorunum aktif">
            <canvas id="c2d" />
          </div>

          <div id="g3d" className="gorunum">
            <canvas id="c3d" />
            <div className="yuzer">
              <div id="gec3d" className="satir">
                <button className="ubtn aktif" data-m="orbit">Döndür</button>
                <button className="ubtn" data-m="gez">İçinde yürü</button>
              </div>
              <select id="k3d">
                <option value="tumu">Tüm bina</option>
                <option value="kat">Sadece aktif kat</option>
              </select>
              <label title="Aktif kesit düzlemi kaydırma">
                Kesit <input type="range" id="kesitOfset3d" min="-6" max="6" step="0.1" defaultValue="0" style={{ width: '74px' }} />
              </label>
              <button className="ubtn" id="o3d">Ortografik</button>
              <select id="kam3d" title="Hızlı kamera açısı">
                <option value="izo">İzometrik (3D)</option>
                <option value="on">Ön Cephe</option>
                <option value="arka">Arka Cephe</option>
                <option value="sol">Sol Cephe</option>
                <option value="sag">Sağ Cephe</option>
                <option value="ust">Üst Plan</option>
              </select>
              <label title="3D boru ve şaftları göster">
                <input type="checkbox" id="tes3d" defaultChecked /> Borular
              </label>
              <label title="Duvarları şeffaflaştırıp iç tesisatı gör">
                <input type="checkbox" id="xray3d" /> X-Ray MEP
              </label>
              <label title="3D aksları göster">
                <input type="checkbox" id="aks3d" /> Akslar
              </label>
              <button className="ubtn" id="olc3d" title="3D iki nokta mesafe ölç">Ölç</button>
              <select id="tar3d">
                <option value="06-21">21 Haz</option>
                <option value="03-21">21 Mar</option>
                <option value="12-21">21 Ara</option>
              </select>
              <label>
                Güneş <input type="range" id="saat3d" min="5" max="20" step="0.25" defaultValue="14" style={{ width: '76px' }} />
                <span id="saatYaz3d">14:00</span>
              </label>
              <button className="ubtn" id="oynat3d" title="Günü oynat">▶</button>
              <label>
                <input type="checkbox" id="golge3d" defaultChecked /> Gölge
              </label>
              <button className="ubtn" id="objIndir" title="3D Mesh (.obj) indir">.obj</button>
              <button className="ubtn ana" id="foto3d">Görsel al</button>
            </div>
            <div id="gezIpucu">Sürükle: etrafa bak · W A S D / Oklar: yürü · Q / E: alçal / yüksel</div>
            <div id="d3SecimKart" />
          </div>

          <div id="gMetraj" className="gorunum" />
          <div id="gPafta" className="gorunum" />
        </main>

        <aside id="panel" />

        <footer id="durum">
          <span>Araç: <b id="dArac">Seç</b></span>
          <span id="dKoord">0.00, 0.00 m</span>
          <span id="dKat">Zemin Kat</span>
          <span id="dAlan">Net: 0.00 m²</span>
          <span>Oda: <b id="dOda">—</b></span>
          <span id="dKayit" style={{ marginLeft: 'auto' }}>Hazır</span>
        </footer>
      </div>

      <div id="perde" />
      <div id="bildirim" />
      <div id="baglamMenu" />
      <div id="baski" />

      <input type="file" id="dosyaResim" accept="image/*" style={{ display: 'none' }} />
      <input type="file" id="dosyaJson" accept="application/json,.json" style={{ display: 'none' }} />
      <input type="file" id="dosyaDxf" accept=".dxf,text/plain" style={{ display: 'none' }} />
    </>
  );
}
