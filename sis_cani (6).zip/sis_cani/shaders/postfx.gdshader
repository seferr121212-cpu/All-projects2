shader_type canvas_item;
// SİS ÇANI - son işleme: renk düzenleme, yumuşak parlama, vinyet, film greni.

uniform sampler2D screen_tex : hint_screen_texture, filter_linear_mipmap;
uniform float vignette = 0.55;
uniform float grain = 0.045;
uniform float bloom = 0.55;
uniform float saturation = 0.88;
uniform float contrast = 1.1;
uniform vec3 shadow_tint : source_color = vec3(0.86, 0.93, 1.1);
uniform vec3 high_tint : source_color = vec3(1.1, 1.0, 0.88);
uniform float flash = 0.0;
uniform float aberration = 0.0;   // Büyük Yankı yakınken ekran bozulması

void fragment() {
	vec2 uv = SCREEN_UV;
	vec3 c = texture(screen_tex, uv).rgb;
	if (aberration > 0.001) {
		vec2 dir = (uv - 0.5) * aberration * 0.02;
		float wob = sin(uv.y * 80.0 + TIME * 12.0) * aberration * 0.002;
		c.r = texture(screen_tex, uv + dir + vec2(wob, 0.0)).r;
		c.b = texture(screen_tex, uv - dir - vec2(wob, 0.0)).b;
	}
	vec3 b = textureLod(screen_tex, uv, 2.5).rgb * 0.5 + textureLod(screen_tex, uv, 4.0).rgb * 0.5;
	b = max(b - vec3(0.35), vec3(0.0)) * 1.8;
	c += b * bloom;
	float l = dot(c, vec3(0.299, 0.587, 0.114));
	c = mix(vec3(l), c, saturation);
	c = (c - 0.5) * contrast + 0.5;
	c *= mix(shadow_tint, high_tint, smoothstep(0.08, 0.6, l));
	vec2 d = uv - 0.5;
	d.x *= 1.3;
	c *= clamp(1.0 - dot(d, d) * vignette * 2.2, 0.0, 1.0);
	float n = fract(sin(dot(floor(uv * vec2(960.0, 540.0)) + floor(TIME * 24.0) * 1.37, vec2(12.9898, 78.233))) * 43758.5453);
	c += (n - 0.5) * grain;
	c = mix(c, vec3(1.0), flash);
	COLOR = vec4(max(c, vec3(0.0)), 1.0);
}
